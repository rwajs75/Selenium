package templates;

import helpers.common.Common;
import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


import javax.xml.crypto.Data;
import java.util.List;

import static helpers.common.Common.*;
import static helpers.dictionary.StaticStrings.*;


/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 *
 * Dla zwiększenia czytelności testu docelowego należy usunąć wszystkie użyte
 * tu komentarze.
 *
 * @author Sławomir Kamiński
 */
@DisplayName("nazwa testu")
public class TemplateTest {

    /**
     * Obiekt WebDriver używany do przeprowadzenia testu
     */
    protected WebDriver driver;

    /**
     * Środowisko testowe (definiowane przez dodanie opcji -DappEnv do komendy Maven)
     */
    private String appEnv;

    /**
     * Dane wejściowe (tylko jeśli test jest kolejną częścią procesu)
     */
    private CustomTestDTO input;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv"); //środowisko (CP/UT)
        if (appEnv == null) appEnv = "CP";

        input = new TestDataManager(appEnv).getCustomTestData(new CustomDataRequest("RST-XXXXX", "APKA", appEnv, DataRowStatus.AKTYWNY,"ETAP TESTU"));

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        PageFactory.initElements(driver, PageObjectTemplate.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
    }

    /**
     * Przykładowa metoda testowa
     */
    @Test
    @DisplayName("nazwa metody")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP); //wymagane zastosowanie w bloku try/catch z powodów technicznych

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        Common.reportSummaryAndSendResults("RST-YYYYY", "APKA", appEnv, DataRowStatus.AKTYWNY, "ETAP",
                true, "param1", "param2");
        if (driver != null)  driver.quit();
    }

    /* Przykładowe definicje kroków (do uzupełnienia
     * w teście docelowym)
    */
    private void krok1() {}
    private void krok2() {}
    private void krok3() {}
}
