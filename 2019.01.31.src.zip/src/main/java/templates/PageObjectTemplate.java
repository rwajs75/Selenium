package templates;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Szablon obiektu typu PageObject.
 * Zawiera wzory definiowania elementów wymaganych (których istnienie
 * w dokumencie jest wymagane do powodzenia testu) oraz opcjonalnych
 * (których istnienie jest początkowo weryfikowane)
 *
 * @author Sławomir Kamiński
 */
public class PageObjectTemplate {

    /* Przykładowa lista obiektów wymaganch - ich istnienie
     * jest domyślnie oczekiwane wewnątrz testu, inicjalizowane przez PageFactory
     */
    @FindBy(xpath = "//button[1]")
    public static WebElement requiredElement1;
    @FindBy(className = "elementClass")
    public static WebElement requiredElement2;
    @FindBy(id = "uniqueId")
    public static WebElement requiredElement3;
    @FindBy(name = "elementName")
    public static WebElement requiredElement4;

    /* Przykładowa lista obiektów opcjonalnych - ich istnienie
     * musi być najpierw zwerfikowane funkcją Common.waitUntilObjectPresent()
     * np. WebElement element = waitUntilObjectPresent(optionalElement2, 15);
     */
    public static final By optionalElement1 = By.xpath("//div[1]/input[@type='text']");
    public static final By optionalElement2 = By.id("optionaElementId");
    public static final By optionalElement3 = By.name("optionalElementName");
}
