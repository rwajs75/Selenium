package salescloud.ikonto.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class IKontoBVipUposazeni {

    @FindBy(id = "l_uposazonych")
    public static WebElement listaLiczbaUposazonych;

    @FindBy(id = "button_next")
    public static WebElement przyciskDalej;
}
