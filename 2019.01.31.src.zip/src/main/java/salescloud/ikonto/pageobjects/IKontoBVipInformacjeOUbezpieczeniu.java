package salescloud.ikonto.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class IKontoBVipInformacjeOUbezpieczeniu {

    @FindBy(id = "wysokosc_skladk")
    public static WebElement poleTekstoweWysokoscSkladki;

    @FindBy(id = "bank_skladki_BZWBKSA")
    public static WebElement opcjaBZWBK;

    @FindBy(id = "bank_skladki_PEKAOSA")
    public static WebElement opcjaPekao;

    @FindBy(id = "nr_rach_bankowego")
    public static WebElement poleTekstoweNrRachunku;

    @FindBy(id = "czy_zidentyfikowano_klienta")
    public static WebElement checkboxZidentyfikowanoKlienta;

    @FindBy(id = "button_next")
    public static WebElement przyciskDalej;
}
