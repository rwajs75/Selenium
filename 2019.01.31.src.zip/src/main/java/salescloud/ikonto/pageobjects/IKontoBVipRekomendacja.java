package salescloud.ikonto.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class IKontoBVipRekomendacja {

    @FindBy(xpath = "//input[@value='Dalej']")
    public static WebElement przyciskDalej;


}
