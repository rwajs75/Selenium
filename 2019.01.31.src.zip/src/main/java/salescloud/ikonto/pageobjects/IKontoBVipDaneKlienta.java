package salescloud.ikonto.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class IKontoBVipDaneKlienta {

    @FindBy(id = "ubezpieczony_jest_ubezpieczajacym_true")
    public static WebElement opcjaUbezpieczajacyToUbezpieczony;

    @FindBy(id = "ubezpieczony_jest_ubezpieczajacym_false")
    public static WebElement opcjaUbezpieczajacyToNieUbezpieczony;

    @FindBy(id = "ubezpieczajacy_plec")
    public static WebElement poleTekstowePlec;

    @FindBy(id = "ubezpieczajacy_data_urodzenia")
    public static WebElement poleTekstoweDataUrodzenia;

    @FindBy(id = "ubezpieczajacy_pesel")
    public static WebElement poleTekstowePesel;

    @FindBy(id = "ubezpieczajacy_nr_dokumentu_tozsamosci")
    public static WebElement poleTekstoweNrDokumentuTozsamosci;

    @FindBy(id = "ubezpieczajacy_telefon")
    public static WebElement poleTekstoweTelefon;

    @FindBy(id = "ubezpieczajacy_email")
    public static WebElement poleTekstoweEmail;

    @FindBy(id = "ubezpieczajacy_email_powt")
    public static WebElement poleTekstoweEmailPowt;

    @FindBy(id = "ubezpieczajacy_kod_pocztowy")
    public static WebElement poleTekstoweKodPocztowy;

    @FindBy(id = "ubezpieczajacy_miasto")
    public static WebElement poleTekstoweMiasto;

    @FindBy(id = "ubezpieczajacy_ulica")
    public static WebElement poleTekstoweUlica;

    @FindBy(id = "ubezpieczajacy_nr_domu")
    public static WebElement poleTekstoweNrDomu;

    @FindBy(id = "ubezpieczajacy_nr_mieszkania")
    public static WebElement poleTekstoweNrMieszkania;

    @FindBy(id = "ubezpieczajacy_jest_rezydentem_podatkowym_pl_true")
    public static WebElement opcjaRezydentPodatkowyTrue;

    @FindBy(id = "ubezpieczajacy_jest_rezydentem_podatkowym_pl_false")
    public static WebElement opcjaRezydentPodatkowyFalse;


    @FindBy(xpath = "//input[@value='Dalej']")
    public static WebElement przyciskDalej;


}
