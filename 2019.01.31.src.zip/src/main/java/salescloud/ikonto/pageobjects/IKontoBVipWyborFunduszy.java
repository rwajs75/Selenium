package salescloud.ikonto.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class IKontoBVipWyborFunduszy {

    @FindBy(id = "wybrany_fundusz_0_fundusz")
    public static WebElement listaFunduszKapitalowy;

    @FindBy(xpath = "//*[@type='button' and contains(@class,'button-blue')]")
    public static WebElement przyciskDalej;
}
