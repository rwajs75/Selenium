package salescloud.ikonto.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class IKontoBVipAnalizaPotrzeb {

    @FindBy(id = "czy_klient_ma_inny_produkt_false")
    public static WebElement opcjaBrakInnychProduktow;

    @FindBy(id = "generate_proposal")
    public static WebElement przyciskWygenerujWniosek;
}
