package salescloud.ikonto;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import salescloud.ikonto.pageobjects.*;

public class IKontoCommonPageObjects {

    public static void initIKontoElement(WebDriver driver) {
        PageFactory.initElements(driver, IKontoBVipRekomendacja.class);
        PageFactory.initElements(driver, IKontoBVipWyborFunduszy.class);
        PageFactory.initElements(driver, IKontoBVipDaneKlienta.class);
        PageFactory.initElements(driver, IKontoBVipUposazeni.class);
        PageFactory.initElements(driver, IKontoBVipInformacjeOUbezpieczeniu.class);
        PageFactory.initElements(driver, IKontoBVipAnalizaPotrzeb.class);
    }
}
