package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static helpers.common.Common.*;
import static helpers.common.Common.waitTillSpinnerDisable1;
import static salescloud.pageobjects.SalesCloudCommon.getDataRange;

public class SalesCloudWniosekZdrowie {


    // Zdrowie
    @FindBy(xpath = "//*[contains(text(),'Zdrowie')]")
    public static WebElement przyciskZdrowie;

    @FindBy(xpath = "//*[@aria-label='Śmierć wskutek NW - wybierz']")
    public static WebElement poleOpcjiSmiercWskutekNW;

    @FindBy(xpath = "//input[@name='field']")
    public static WebElement poleTekstoweSumaUbezpieczenia;

    public static final By zakresSumaUbezpieczenia = By.xpath("//input[@name='field']/../*[@role='alert']/*/*");

    public static final By listaRozwijanaSumaUbezpieczenia = By.xpath("//*[@aria-label='Suma ubezpieczenia']");


    public static final By listaRozwijanaPoziomSwiadczen = By.xpath("//*[@aria-label='Poziom świadczeń']");

    public static final By listaRozwijanaWariant = By.xpath("//*[@aria-label='Wariant']");

    public static final By listaRozwijanaWyborPierwszejOpcji = By.xpath("//*[contains(@id,'select_container_')][@aria-hidden='false']//*[contains(@id,'select_option_')][1]");

    public static final By listaRozwijanaWyborTrzeciejOpcji = By.xpath("//*[contains(@id,'select_container_')][@aria-hidden='false']//*[contains(@id,'select_option_')][3]");

    public static final By przyciskWyboru100 = By.xpath("//*[@role='radio'][@value='100']/*");


    /**
     * Funkcja zaznaczająca checkox po nazwie [WniosekZdrowie]
     * @param nazwa
     * @param driver
     */
    public static void checkboxHealthApplication(String nazwa, WebDriver driver){

        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        nazwa = "//*[@aria-label='"+nazwa+" - wybierz']";
        WebElement element;
        clickElement(By.xpath(nazwa));
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
    }

    /**
     * Funkcja zaznaczająca checbox przy ryzyku i uzupelniajaca dane
     * @param ryzykoZdrowie
     * @param driver
     */
    public static void selectHealthRisk(String ryzykoZdrowie, WebDriver driver) {

        String pokazParametry = "//*[@aria-label='" + ryzykoZdrowie + " - pokaż parametry']";
        checkboxHealthApplication(ryzykoZdrowie, driver);
        WebElement element;
        if ((element = waitUntilElementPresent(By.xpath(pokazParametry), 3)) == null) {
            reporter().logPass("Ponowna próba zaznaczenia checbox: "+ryzykoZdrowie);
            checkboxHealthApplication(ryzykoZdrowie, driver);
        }

        String zakres = "";

        //Lista rozwijana suma ubezpieczenia
        if ((waitUntilElementPresent(SalesCloudWniosekZdrowie.listaRozwijanaSumaUbezpieczenia, 1)) != null) {
            clickElement(SalesCloudWniosekZdrowie.listaRozwijanaSumaUbezpieczenia);
            if (waitUntilElementPresent(SalesCloudWniosekZdrowie.listaRozwijanaWyborTrzeciejOpcji, 1) != null) {
                clickElement(SalesCloudWniosekZdrowie.listaRozwijanaWyborTrzeciejOpcji);
                waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            }
            if ((waitUntilElementPresent(SalesCloudWniosekZdrowie.listaRozwijanaWyborPierwszejOpcji, 1)) != null) {
                clickElement(SalesCloudWniosekZdrowie.listaRozwijanaWyborPierwszejOpcji);
                waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            }
        }

        //Lista rozwijana wariant
        if (waitUntilElementPresent(SalesCloudWniosekZdrowie.listaRozwijanaWariant, 1) != null) {
            clickElement(SalesCloudWniosekZdrowie.listaRozwijanaWariant);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            if (waitUntilElementPresent(SalesCloudWniosekZdrowie.listaRozwijanaWyborPierwszejOpcji, 1) != null) {
                clickElement(SalesCloudWniosekZdrowie.listaRozwijanaWyborPierwszejOpcji);
                waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            }
        }

        //Lista rozwijana poziom swiadczen
        if (waitUntilElementPresent(SalesCloudWniosekZdrowie.listaRozwijanaPoziomSwiadczen, 1) != null) {
            clickElement(SalesCloudWniosekZdrowie.listaRozwijanaPoziomSwiadczen);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            if (waitUntilElementPresent(SalesCloudWniosekZdrowie.listaRozwijanaWyborPierwszejOpcji, 1) != null) {
                clickElement(SalesCloudWniosekZdrowie.listaRozwijanaWyborPierwszejOpcji);
                waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            }
        }

        //Suma Ubezpieczenia
        if (waitUntilElementPresent(SalesCloudWniosekZdrowie.zakresSumaUbezpieczenia, 1) != null) {
            enterIntoElement(SalesCloudWniosekZdrowie.poleTekstoweSumaUbezpieczenia, "1");
            zakres = getDataRange(SalesCloudWniosekZdrowie.zakresSumaUbezpieczenia);
            enterIntoElement(SalesCloudWniosekZdrowie.poleTekstoweSumaUbezpieczenia, zakres);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        }

        //radiobutton 100%
        if (waitUntilElementPresent(SalesCloudWniosekZdrowie.przyciskWyboru100, 1) != null) {
            clickElement(SalesCloudWniosekZdrowie.przyciskWyboru100);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        }

        clickElement(By.xpath("//*[@aria-label='" + ryzykoZdrowie + " - pokaż parametry']"));
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
    }

}
