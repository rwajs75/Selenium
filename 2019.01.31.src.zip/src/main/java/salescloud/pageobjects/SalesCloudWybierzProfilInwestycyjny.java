package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWybierzProfilInwestycyjny {

    @FindBy(xpath = "//*[text()='Dalej']/../..")
    public static WebElement przyciskDalej;

    public static By selectInvestmentProfile(String profil) {
        switch (profil) {
            case "Konserwatywny": return By.xpath("//div[@class='investment-profile__list']/div[1]/div[1]/button");
            case "Umiarkowanie Konserwatywny": return By.xpath("//div[@class='investment-profile__list']/div[2]/div[1]/button");
            case "Zrównoważoony": return By.xpath("//div[@class='investment-profile__list']/div[3]/div[1]/button");
            case "Umiarkowanie Agresywny": return By.xpath("//div[@class='investment-profile__list']/div[4]/div[1]/button");
            case "Agresywny": return By.xpath("//div[@class='investment-profile__list']/div[5]/div[1]/button");
            default: throw new IllegalArgumentException();
        }
    }
}
