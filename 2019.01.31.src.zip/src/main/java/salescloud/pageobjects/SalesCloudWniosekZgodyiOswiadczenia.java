package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWniosekZgodyiOswiadczenia {

    // Zgody i oświadczenia
    @FindBy(xpath = "//*[contains(text(),'Zgody i oświadczenia')]")
    public static WebElement przyciskZgodyiOswiadczenia;

    public static final By przyciskWyboruSumaUbezpieczenia = By.xpath("//*[@aria-label='Sumy ubezpieczenia']");

    public static final By przyciskWyboruWniosekNie = By.xpath("//*[@aria-label='Nie']");



}
