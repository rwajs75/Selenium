package salescloud.pageobjects;

import helpers.common.Common;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

import static helpers.common.Common.scrollToElement;

public class SalesCloudWniosekDaneOsobowe {

    // Dane osobowe
    @FindBy(xpath = "//*[@role='combobox' and @aria-label='Zawód']")
    public static WebElement poleTekstoweZawod;
    @FindBy(xpath = "//*[@name='postalCode']")
    public static WebElement poleTekstoweKodPocztowy;
    @FindBy(xpath = "//*[@name='homeNo']")
    public static WebElement poleTekstoweNrDomu;
    @FindBy(xpath = "//*[@name='flatNumber']")
    public static WebElement poleTekstoweNrMieszkania;
    @FindBy(xpath = "//*[@role='radio' and @aria-label='Polsce']")
    public static WebElement przyciskWyboruRezydentPodatkowy;
    @FindBy(xpath = "//*[@type='button'][@aria-label='Dodaj nowego uczestnika']/*")
    public static WebElement przyciskDodajNowegoUczestnika;

    @FindBy(xpath = "//*[@type='button']/*[contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapisz;

    @FindBy(xpath = "//*[@type='button']/*[contains(text(), 'Wybierz pakiet')]")
    public static WebElement przyciskWybierzPakiet;

    /**
     *  Funkcja wybierająca zawód na bazie wzoru: 2004 (Aktor)
     *  oryginalny xpath: //*[@id="ul-110"]//*[contains(text(), '2004 Aktor')]
     */

    public static void chooseJob(String zawodID, WebDriver driver) {
        try {
            if (!poleTekstoweZawod.isEnabled()) {
                Common.reporter().logFail("Pole tekstowe z zawodem: " + zawodID +" jest niewidoczne");
            }
            scrollToElement(poleTekstoweZawod);
            if (poleTekstoweZawod.isDisplayed()) {
                poleTekstoweZawod.clear();
                poleTekstoweZawod.sendKeys(zawodID);
                WebElement element = driver.findElement(By.xpath("//*[@id='ul-110']//*[contains(text(), '"+zawodID+"')]"));
                element.click();
                Common.reporter().logPass("Kliknięto i wybrano zawód: " + zawodID);
            }
        } catch (NoSuchElementException e) {
            Common.reporter().logFail("Nie istnieje element z opcją wyboru zawodu: " + zawodID);
        } catch (ElementNotVisibleException e) {
            Common.reporter().logFail("Nie jest widoczny element z opcją wyboru zawodu: " + zawodID);
        }
    }



}
