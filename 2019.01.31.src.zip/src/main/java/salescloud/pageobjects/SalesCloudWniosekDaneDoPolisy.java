package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWniosekDaneDoPolisy {

    @FindBy(xpath = "//*[contains(text(), 'Zakończ sprzedaż')]")
    public static WebElement przyciskZakonczSprzedaz;

}
