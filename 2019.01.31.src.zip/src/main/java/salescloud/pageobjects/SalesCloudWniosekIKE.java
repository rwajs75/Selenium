package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWniosekIKE {

    @FindBy(xpath = "//*[@name='paymentAmount']")
    public static WebElement poleKwotaWplaty;

    @FindBy(xpath = "//*[@name='savingsUseStartAge']")
    public static WebElement poleWiekRozpoczeciaUzytkowania;

    @FindBy(xpath = "//*[text()='Przelicz zysk']/../..")
    public static WebElement przyciskPrzeliczZysk;

    @FindBy(xpath = "//*[@name='selectedTaxOfficeName']")
    public static WebElement poleUrzadSkarbowy;

    @FindBy(xpath = "//*[@name='postCode']")
    public static WebElement poleKodPocztowy;

    @FindBy(xpath = "//*[@name='city']")
    public static WebElement poleMiejscowosc;

    @FindBy(xpath = "//*[@name='street']")
    public static WebElement poleUlica;

    @FindBy(xpath = "//*[@name='homeNumber']")
    public static WebElement poleNumerDomu;

    @FindBy(xpath = "//*[@name='flatNumber']")
    public static WebElement poleNumerMieszkania;

    @FindBy(xpath = "//input[@name='MANDATORYconsentGroupGiven']/..")
    public static WebElement poleWyboruOswiadczeniaWymagane;

    @FindBy(xpath = "//*[text()='Dalej']/../..")
    public static WebElement przyciskDalej;

    @FindBy(xpath = "//*[contains(text(), 'Jako Klient oświadczam')]/../..")
    public static WebElement checkboxOswiadczenieKlienta;

    @FindBy(xpath = "//*[contains(text(), 'Jako Agent potwierdzam')]/../..")
    public static WebElement checkboxOswiadczenieAgenta;

    @FindBy(xpath = "//*[contains(text(), 'Generuj kod sms')]")
    public static WebElement przyciskGenerujKodSMS;
}
