package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWniosekSprzedaz {

    // Zakończenie procesu sprzedaży
    @FindBy(xpath = "//div//h4[contains(text(), 'Podsumowanie')]")
    public static WebElement poleTekstoweNumerWniosku;

    @FindBy(xpath = "//*[contains(text(),'Finalizacja sprzedaży')]")
    public static WebElement przyciskFinalizacjaSprzedazy;

    @FindBy(xpath = "//*[contains(text(),'Zakończenie procesu sprzedaży')]")
    public static WebElement przyciskZakonczenieProcesuSprzedazy;

    @FindBy(xpath = "//*[@id='nwp']//section[1]/div/button")
    public static WebElement przyciskDalejKodSMS;

    @FindBy(xpath = "//*[@id='nwp']//section[2]/div/button")
    public static WebElement przyciskDalejWniosek;

    @FindBy(xpath = "(//*[@name='customerVerified']/*)[1]")
    public static WebElement przyciskWyboruPotwierdzamTak;

    @FindBy(xpath = "//*[@name='customerVerified']//md-radio-button[@value='false']")
    public static WebElement przyciskWyboruPotwierdzamNie;

    @FindBy(xpath = "//*[@name='paymentMethod']//md-radio-button[@value='CASH_OR_CARD']")
    public static WebElement przyciskWyboruPlatnoscGotowka;

    @FindBy(xpath = "//*[@name='paymentMethod']//md-radio-button[@value='TRANSFER']")
    public static WebElement przyciskWyboruPlatnoscPrzelew;

    @FindBy(xpath = "//*[@name='regularPaymentsBank']//md-radio-button[@value='PEKAO']")
    public static WebElement przyciskWyboruBankPEKAO;

    @FindBy(xpath = "//*[@name='regularPaymentsBank']//md-radio-button[@value='BZ_WBK']")
    public static WebElement przyciskWyboruBankBZWBK;
    public static By przyciskWyboruBankBZWBKBy = By.xpath("//*[@name='regularPaymentsBank']//md-radio-button[@value='BZ_WBK']");

    @FindBy(xpath = "//button/*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;

    public static By przyciskDalejPIN = By.xpath("//button/*[contains(text(), 'Dalej')]");
    public static By przyciskGenerujKodSMSPIN = By.xpath("//button/*[contains(text(), 'Generuj kod SMS')]");

    @FindBy(xpath = "//*[@id='nwp']//additional-info//button")
    public static WebElement przyciskGenerujWniosekTestowy;

    @FindBy(xpath = "//button/*[contains(text(), 'Generuj kod SMS')]")
    public static WebElement przyciskGenerujKodSMS;

    @FindBy(xpath = "//*[contains(text(), 'Generuj kod sms')]")
    public static WebElement przyciskGenerujKodSMS2;

    @FindBy(xpath = "//button/*[contains(text(), 'Generuj')]")
    public static WebElement przyciskGenerujSMS;

    public static By przyciskGenerujNowyPIN = By.xpath("//button/*[contains(text(), 'Wygeneruj nowy PIN')]");
    public static By przyciskWygenerujNowyPIN = By.xpath("//button/*[contains(text(), 'Generuj ponownie')]");

    @FindBy(xpath = "//button//*[contains(text(), 'Zakończ sprzedaż')]")
    public static WebElement przyciskZakonczSprzedaz;

    @FindBy(xpath = "//button/*[contains(text(), 'Anuluj')]")
    public static WebElement przyciskAnuluj;

    @FindBy(xpath = "//*[@name='pin']")
    public static WebElement poleTekstoweWprowadzPIN;

    @FindBy(xpath = "//*[@formcontrolname='pin']")
    public static WebElement poleTekstoweWprowadzPIN2;

    public static final By poleTekstoweDziekujeOtrzymalismyWniosek = By.xpath("//*[contains(text(), 'Dziękujemy, otrzymaliśmy wniosek')]");
    public static final By poleTekstoweOfertaZaakceptowana = By.xpath("//*[contains(text(), 'Oferta zaakceptowana')]");

    @FindBy(xpath = "//button/*[contains(text(), 'Ok')]")
    public static WebElement przyciskOK;

    public static final By przyciskOkUT = By.xpath("//button/*[contains(text(), 'Ok')]");

    @FindBy(xpath = "//*[@role='checkbox'][@aria-label='accepted']")
    public static WebElement przyciskAkceptacjaWnioskuSMS;

    @FindBy(xpath = "//button/*[contains(text(), 'Zatwierdź kod pin')]")
    public static WebElement przyciskZatwierdzKodPIN;

    @FindBy(xpath = "//*[contains(text(), 'Kup polisę / zatwierdź kod pin')]")
    public static WebElement przyciskKupPoliseZatwierdzKodPIN;





}
