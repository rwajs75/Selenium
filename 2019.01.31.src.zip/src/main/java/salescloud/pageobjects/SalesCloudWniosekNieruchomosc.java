package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static helpers.common.Common.clickElement;

public class SalesCloudWniosekNieruchomosc {

    @FindBy(xpath = "//*[@name='postCode']")
    public static WebElement poleTekstoweKodPocztowy;

    @FindBy(xpath = "//*[@name='homeNumber']")
    public static WebElement poleTekstoweNumerBudynku;

    @FindBy(xpath = "//*[@name='flatNumber']")
    public static WebElement poleTekstoweNumerMieszkania;

    @FindBy(xpath = "//*[@name='usableArea']")
    public static WebElement poleTekstowePowierzchnia;

    @FindBy(xpath = "//*[@name='constructionOrRenovationYear']")
    public static WebElement poleTekstoweRokBudowy;

    @FindBy(xpath = "//*[contains(text(), 'Dostosuj ofertę')]")
    public static WebElement przyciskDostosujOferte;


}
