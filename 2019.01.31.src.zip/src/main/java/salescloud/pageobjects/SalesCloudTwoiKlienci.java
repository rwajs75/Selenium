package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudTwoiKlienci {

    @FindBy(xpath = "//*[@id='content']//div[1]/button")
    public static WebElement przyciskDodajNowegoKlienta;

    @FindBy(xpath = "//*[@id='content']//button//*[contains(text(), 'Szukaj')]")
    public static WebElement przyciskSzukaj;

    @FindBy(xpath = "(//*[@data-label='Klient'])[1]")
    public static WebElement przyciskDaneKlientaPierwszaPozycja;

    @FindBy(xpath = "//*[@name='searchFieldCode']")
    public static WebElement przyciskOpcjeWyszukiwania;

    @FindBy(xpath = "//*[@value='phoneNumber']")
    public static WebElement przyciskOpcjeWyszukiwaniaTelefon;

    @FindBy(xpath = "//*[@value='pesel']")
    public static WebElement getPrzyciskOpcjeWyszukiwaniaPESEL;

    @FindBy(xpath = "//*[@name='searchValue'][@placeholder='Kogo szukasz?']")
    public static WebElement poleTekstoweKogoSzukasz;


    //Dane znalezionego klienta

    @FindBy(xpath = "//*[@ng-if=\"$ctrl.customer.partyType === 'PERSON'\" and @class=\"ng-binding ng-scope\"]") //TRZEBA PARSOWAĆ
    public static WebElement imieINazwisko;

    @FindBy(xpath = "//a[contains(@href, 'tel')]")
    public static WebElement numerTelefonu;

    @FindBy(xpath = "//a[contains(@href, 'mailto')]")
    public static WebElement email;

    @FindBy(xpath = "//*[@ng-if='$ctrl.customer.birthDate']") //TRZEBA PARSOWAĆ
    public static WebElement dataUrodzeniaIWiek;

    @FindBy(xpath = "//*[@ng-if='$ctrl.customer.address']") //TRZEBA PARSOWAĆ
    public static WebElement adresZamieszkania;

    @FindBy(xpath = "//*[@ng-if='$ctrl.customer.pesel']") //TRZEBA PARSOWAĆ
    public static WebElement pesel;

    @FindBy(xpath = "//*[@ng-if='$ctrl.customer.identityCardNumber']") //TRZEBA PARSOWAĆ
    public static WebElement numerDowoduOsobistego;
}