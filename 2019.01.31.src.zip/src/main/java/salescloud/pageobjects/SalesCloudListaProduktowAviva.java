package salescloud.pageobjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

import java.util.NoSuchElementException;

import static helpers.common.Common.clickElement;
import static helpers.common.Common.reporter;
import static org.openqa.selenium.By.xpath;

public class SalesCloudListaProduktowAviva {

    static WebDriver driver;

        public static void pickProduct(String produkt, WebDriver driver) {
            switch (produkt) {
                // Produkty - Przycisk 'Wniosek'
                case "Wniosek_NowaPerspektywa":
                    produkt = "proposal_NWP2";
                    break;
                case "Wniosek_UbezpieczeniePakietowe":
                    produkt = "proposal_NWP_PAK1";
                    break;
                case "Wniosek_OpiekunVIP":
                    produkt = "proposal_PGV";
                    break;
                case "Wniosek_JuniorGo":
                    produkt = "proposal_ABS_17";
                    break;
                case "Wniosek_BonusVIP":
                    produkt = "proposal_BVIP_08";
                    break;
                case "Wniosek_IKZE":
                    produkt = "proposal_IKZE_12";
                    break;
                case "Wniosek_IKE":
                    produkt = "proposal_IKE_12";
                    break;
                case "Wniosek_TwojDom":
                    produkt = "proposal_MY_HOME_PLUS";
                    break;
                case "Wniosek_MojeBezpieczenstwoPreztiz":
                    produkt = "proposal_MBP";
                    break;
                case "Wniosek_RozsądnyPartner":
                    produkt = "proposal_A01";
                    break;
                case "Wniosek_TwojaPodróż":
                    produkt = "proposal_WPODROZY";
                    break;
                case "Wniosek_wDrodze":
                    produkt = "proposal_MOTOD";
                    break;

                // Produkty - Przycisk 'O Produkcie'
                case "oProdukcie_NowaPerspektywa":
                    produkt = "about_NWP2";
                    break;
                case "oProdukcie_UbezpieczeniePakietowe":
                    produkt = "about_NWP_PAK1";
                    break;
                case "oProdukcie_OpiekunVIP":
                    produkt = "about_PGV";
                    break;
                case "oProdukcie_JuniorGo":
                    produkt = "about_ABS_17";
                    break;
                case "oProdukcie_BonusVIP":
                    produkt = "about_BVIP_08";
                    break;
                case "oProdukcie_IKZE":
                    produkt = "about_IKZE_12";
                    break;
                case "oProdukcie_IKE":
                    produkt = "about_IKE_12";
                    break;
                case "oProdukcie_TwojDom":
                    produkt = "about_MY_HOME_PLUS";
                    break;
                case "oProdukcie_MojeBezpieczenstwoPreztiz":
                    produkt = "about_MBP";
                    break;
                case "oProdukcie_RozsądnyPartner":
                    produkt = "about_A01";
                    break;
                case "oProdukcie_TwojaPodróż":
                    produkt = "about_WPODROZY";
                    break;
                case "oProdukcie_wDrodze":
                    produkt = "about_MOTOD";
                    break;
                default:
                    throw new RuntimeException();
            }

            WebElement element = driver.findElement(By.xpath("(//*[@data-st='" + produkt + "'])[1]"));
            clickElement(element);


          /*
            // Funkcja wybierająca
            // DO DODANIA REPORTER !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            try{
                WebElement element = driver.findElement(By.xpath("(//*[@data-st='"+produkt+"'])[1]"));
                if (!element.isEnabled()){
                    reporter().logFail("Element: "+produkt+ " nieaktywny");
                }
                JavascriptExecutor je = (JavascriptExecutor) driver;
                je.executeScript("arguments[0].scrollIntoView(true);", element);
                if (element.isDisplayed()){
                    element.click();
                    reporter().logPass("Kliknięto w element o lokatorze" + produkt);
                }
            } catch (NoSuchElementException e){
                //reporter.logFail("");
            } catch (ElementClickInterceptedException e){
                //reporter.logFail("");
            }
        } catch (NoSuchElementException e){
            //reporter.logFail("");
        }*/
    }
}