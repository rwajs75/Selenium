package salescloud.pageobjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

import static helpers.common.Common.*;
import static salescloud.pageobjects.SalesCloudCommon.initElement;
import static salescloud.pageobjects.SalesCloudCommon.selectCheckBoxProperty;

public class SalesCloudWniosekAnkietaMedyczna {

    public static String xpath;
    public static String ladowanieDanych;

    // Ankieta Medyczna - pozostałe opcje
    @FindBy(xpath = "//*[contains(text(),'Ankieta medyczna')]")
    public static WebElement przyciskAnkietaMedyczna;
    //@FindBy(id = "vm.surveyForms.f_$START_AGP_01_ms_checkbox_f_$791_0")
    @FindBy(tagName = "md-checkbox")
    public static WebElement przyciskWyboruOswiadczam;
    @FindBy(id = "vm.surveyForms.f_$AG_SZ_01_ms_integer_f_$811$4_1_7")
    public static WebElement poleTekstoweWzrost;
    @FindBy(id = "vm.surveyForms.f_$AG_SZ_01_ms_integer_f_$812$4_2_8")
    public static WebElement poleTekstoweWaga;
    @FindBy(id = "vm.surveyForms.f_$AG_SZ_01_ms_text_f_$952$8_25")
    public static WebElement poleTekstoweLekarzRodzinny;

    // Zakładki Ankiety
    @FindBy(xpath = "//md-tab-item[contains(text(), 'Ankieta dotycząca stylu życia')]")
    public static WebElement przyciskAnkietaDotyczacaStyluZycia;
    @FindBy(xpath = "//md-tab-item[contains(text(), 'Ankieta dotycząca stanu zdrowia')]")
    public static WebElement przyciskAnkietaDotyczacaStyluZdrowia;

    // Przyciski
    @FindBy(xpath = "(//button[contains(., 'Zapisz')])[2]")
    public static WebElement przyciskZapisz;
    @FindBy(xpath = "(//button[contains(., 'Zamknij')])[2]")
    public static WebElement przyciskZamknijAnkiete;

    // Otworz ankietę medyczną przy NWP2
    @FindBy(xpath = "//*[@type='button']/*[contains(text(), 'Otwórz ankietę')]")
    public static WebElement otworzAnkiete;

    /**
     * Funkcja na podstawie nazwy Pytania wyszukuje i pobiera element wpsolny dla Pytania=Odpowiedzi (idGrupy).
     * Następnie zaznacza wybrana odpowiedz
     * @param nazwaPytania
     * @param nazwaOdpowiedzi
     */
    public static void selectMedicalQuestionnaire(String nazwaPytania, String nazwaOdpowiedzi) {
        reporter().logPass("####################");
        reporter().logPass("Nazwa pytania: "+nazwaPytania);
        reporter().logPass("Odpowiedź: "+nazwaOdpowiedzi);
        String pobranieNgClass="";
        String nazwa = "//*[contains(text(), '" + nazwaPytania + "')]/..";
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        WebElement element;
        if ((element = waitUntilElementPresent(By.xpath(nazwa), 5)) != null) {
            pobranieNgClass = getElementProperty(By.xpath("//*[contains(text(), '" + nazwaPytania + "')]/.."), "ng-class");
        }
        String[] idGrupy1 = pobranieNgClass.split("invalid");
        String[] idGrupy2 = idGrupy1[0].split("form.monthYearForm_");
        String idGrupy="";
        if (idGrupy2.length >=2) {
            idGrupy = idGrupy2[1].substring(0, idGrupy2[1].length() - 2);
        }else{
            reporter().logFail("Błędne wyciągniecie idGrupy z nazwy pytania");
        }
        reporter().logPass("Pobrano idGrupy: " + idGrupy);
        String radioButton = "//*[@name='" + idGrupy + "']/md-radio-button[@value='" + nazwaOdpowiedzi + "']";
        String poleTekstowe = "//*[@name='" + idGrupy + "']";
        if (nazwaOdpowiedzi.equals("tak") || nazwaOdpowiedzi.equals("nie")) {
            if ((element = waitUntilElementPresent(By.xpath(radioButton), 1)) != null) {
                clickElement(By.xpath(radioButton));
                if (nazwaOdpowiedzi.equals("tak"))
                    waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            }
        } else {
            if ((element = waitUntilElementPresent(By.xpath(poleTekstowe), 1)) != null){
                enterIntoTextField(By.xpath(poleTekstowe), nazwaOdpowiedzi);
            }
        }
    }

    /**
     * Funkcja domylsna do uzupelniania wszystkich pytań (Ubezpieczonego) z ankiety medycznej na odpowiedz 'NIE'
     */
    public static void selectDefaultMedicalQuestionnaire(WebDriver driver){
        initElement(driver);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        selectCheckBoxProperty("Oświadczam, że na wszystkie pytania odpowiem zgodnie z prawdą");
        selectMedicalQuestionnaire("Czy przebywał(a) Pan(i) w okresie ostatnich 12 miesięcy", "nie");
        selectMedicalQuestionnaire("Czy uprawia Pan(i) sport lub jakąkolwiek formę aktywności fizycznej", "nie");
        selectMedicalQuestionnaire("Wzrost (cm)", "190");
        selectMedicalQuestionnaire("Waga (kg)", "90");
        selectMedicalQuestionnaire("Czy w okresie ostatnich 12 miesięcy Pana(-ni) waga zmieniła się o co najmniej 5", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek palił(a) Pan(i) papierosy lub e-papierosy", "nie");
        selectMedicalQuestionnaire("Czy pije lub pił(a) Pan(i) alkohol", "nie");
        selectMedicalQuestionnaire("Czy zażywa lub zażywał(a) Pan(i) narkotyki, inne środki odurzające lub substancje psychoaktywne", "nie");
        selectMedicalQuestionnaire("Dane Pana(-ni) lekarza rodzinnego wraz z adresem placówki medycznej", "TestyAuto");
        clickElement(SalesCloudWniosekAnkietaMedyczna.przyciskAnkietaDotyczacaStyluZdrowia);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        selectMedicalQuestionnaire("Czy w okresie ostatnich 10 lat był(a) Pan(i) przyjęty(-ta) do szpitala lub miał(a) Pan(i) zabieg chirurgiczny w placówce medycznej","nie");
        selectMedicalQuestionnaire("Czy oczekuje Pan(i) na zabieg operacyjny, chirurgiczny, konsultację lekarską lub wyniki badań diagnostycznych","nie");
        selectMedicalQuestionnaire("objawy chorobowe, takie jak: bóle brzucha lub głowy o niewyjaśnionej przyczynie, powiększone węzły chłonne, zaburzenia rytmu serca, duszności, zmiany w obrębie gruczołu piersiowego, gruczołu krokowego lub narządów płciowych","nie");
        selectMedicalQuestionnaire("inne objawy, które wydawały się na tyle niepokojące","nie");
        selectMedicalQuestionnaire("Czy w okresie ostatnich 3 lat wykonywał(a) Pan(i) badania laboratoryjne, obrazowe lub czynnościowe, których wynik wymagał dalszej obserwacji, diagnostyki lub leczenia", "nie");
        selectMedicalQuestionnaire("Czy w okresie ostatnich 5 (pięciu) lat przyjmował(a) Pan(i) lub przyjmuje leki z zalecenia lekarza dłużej niż", "nie");
        selectMedicalQuestionnaire("Czy ktoś z grona Pana(-ni) naturalnych rodziców lub rodzeństwa chorował, choruje lub zmarł na", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu nerwowego","nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu oddechowego","nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu krążenia", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu pokarmowego", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu moczowego", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu kostno-stawowego","nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni):","nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) wadę lub chorobę narządu wzroku, chorobę uszu lub zaburzenia słuchu","nie");
        selectMedicalQuestionnaire("Czy w okresie ostatnich 10 lat przebywał(a) Pan(i) na zwolnieniu lekarskim dłużej","nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek ubiegał(a) się Pan(i) lub otrzymał(a) Pan(i) świadczenie rehabilitacyjne","nie");
    }

    public static void selectDefaultChildMedicalQuestionnaire(WebDriver driver){
        initElement(driver);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        selectCheckBoxProperty("Oświadczam, że na wszystkie pytania odpowiem zgodnie z prawdą");
        selectMedicalQuestionnaire("Wzrost (cm)", "170");
        selectMedicalQuestionnaire("Waga (kg)", "60");
        selectMedicalQuestionnaire("Dane Pana(-ni) lekarza rodzinnego wraz z adresem placówki medycznej", "TestyAuto");
        selectMedicalQuestionnaire("Czy w okresie ostatnich 10 lat był(a) Pan(i) przyjęty(-ta) do szpitala lub miał(a) Pan(i) zabieg chirurgiczny w placówce medycznej", "nie");
        selectMedicalQuestionnaire("Czy oczekuje Pan(i) na zabieg operacyjny, chirurgiczny, konsultację lekarską lub wyniki badań diagnostycznych", "nie");
        selectMedicalQuestionnaire("objawy chorobowe, takie jak: bóle brzucha lub głowy o niewyjaśnionej przyczynie", "nie");
        selectMedicalQuestionnaire("inne objawy, które wydawały się na tyle niepokojące", "nie");
        selectMedicalQuestionnaire("Czy w okresie ostatnich 3 lat wykonywał(a) Pan(i) badania laboratoryjne, obrazowe lub czynnościowe", "nie");
        selectMedicalQuestionnaire("Czy w okresie ostatnich 5 (pięciu) lat przyjmował(a) Pan(i) lub przyjmuje leki z zalecenia lekarza dłużej", "nie");
        selectMedicalQuestionnaire("Czy ktoś z grona Pana(-ni) naturalnych rodziców lub rodzeństwa chorował, choruje lub zmarł na", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu nerwowego", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu oddechowego", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu krążenia", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu pokarmowego", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu moczowego", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) chorobę układu kostno-stawowego", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni):", "nie");
        selectMedicalQuestionnaire("Czy kiedykolwiek rozpoznano u Pana(-ni) wadę lub chorobę narządu wzroku, chorobę uszu lub zaburzenia słuchu", "nie");
    }

}