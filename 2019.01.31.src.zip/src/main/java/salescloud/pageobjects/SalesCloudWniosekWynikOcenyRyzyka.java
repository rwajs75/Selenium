package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWniosekWynikOcenyRyzyka {

    // Wynik Oceny Ryzyka
    @FindBy(xpath = "//*[contains(text(),'Wynik oceny ryzyka')]")
    public static WebElement przyciskWynikOcenyRyzyka;

    @FindBy(xpath = "//*[@role='radio'][@value='false']")
    public static  WebElement przyciskWyboruDokumentacjaMedycznaNie;

    @FindBy(xpath = "//*[@role='radio'][@value='true']")
    public static  WebElement przyciskWyboruDokumentacjaMedycznaTak;


}
