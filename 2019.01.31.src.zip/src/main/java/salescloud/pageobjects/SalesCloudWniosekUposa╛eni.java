package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWniosekUposażeni {

    // Uposażeni
    @FindBy(xpath = "//*[contains(text(),'Uposażeni')]")
    public static WebElement przyciskUposazeni;
}
