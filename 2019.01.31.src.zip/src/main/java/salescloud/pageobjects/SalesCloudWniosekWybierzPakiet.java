package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWniosekWybierzPakiet {

    @FindBy(xpath = "(//*[@on-select='$ctrl.choosePackage($packageCode)']//button)[1]")
    public static WebElement przyciskWybierzPakietTY;
    @FindBy(xpath = "(//*[@on-select='$ctrl.choosePackage($packageCode)']//button)[2]")
    public static WebElement przyciskWybierzPakietJApodstawowy;
    @FindBy(xpath = "(//*[@on-select='$ctrl.choosePackage($packageCode)']//button)[3]")
    public static WebElement przyciskWybierzPakietJArozszerzony;
    @FindBy(xpath = "(//*[@on-select='$ctrl.choosePackage($packageCode)']//button)[4]")
    public static WebElement przyciskWybierzPakietMY;

    // Obowiązkowe oświadczenie medyczne
    @FindBy(xpath = "//button[@ng-click='dialog.hide()']")
    public static WebElement przyciskPotwierdzam;

    @FindBy(xpath = "//*[@type='button']/*[contains(text(), 'Wniosek')]")
    public static WebElement przyciskWniosek;

    public static final By przyciskZgodyObowiazkowe = By.xpath("//*[@aria-label='primaryInsuredSameAsInsurer' and @aria-checked='false']");

}