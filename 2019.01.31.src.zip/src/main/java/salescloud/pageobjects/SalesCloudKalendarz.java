package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudKalendarz {

    @FindBy(xpath = "//button[contains(text(), 'Inne kalendarze')]")
    public static WebElement przyciskInneKalendarze;

    @FindBy(xpath = "//*[@aria-label='Dodaj zdarzenie']")
    public static WebElement przyciskDodajZdarzenie;

    @FindBy(xpath = "//*[@placeholder='Tytuł wydarzenia']")
    public static WebElement poleTekstoweTytulWydarzenia;

    @FindBy(xpath = "//*[@placeholder='Wybierz rodzaj zdarzenia']")
    public static WebElement listaWybierzRodzajZdarzenia;

    @FindBy(name = "startDate")
    public static WebElement przyciskDataPoczątku;

    @FindBy(name = "startTime")
    public static WebElement przyciskGodzinaPoczatku;

    @FindBy(name = "endTime")
    public static WebElement przyciskGodzinaKonca;

    @FindBy(xpath = "//*[@aria-label='Cały dzień']")
    public static WebElement poleOpcjiCalyDzien;

    @FindBy(xpath = "//md-dialog[@role='dialog']//button//*[contains(text(), 'Dodaj')]")
    public static WebElement przyciskDodaj;

    public static final By przyciskDodajBy = By.xpath("//md-dialog[@role='dialog']//button//*[contains(text(), 'Dodaj')]");

    @FindBy(xpath = "//div//button//*[contains(text(), 'Dodaj')]")
    public static WebElement przyciskDodajAlternatywny;

    @FindBy(xpath = "//button//*[contains(text(), 'Więcej opcji')]")
    public static WebElement przyciskWiecejOpcji;

    // Zaproś osobę
    @FindBy(xpath = "//md-input-container//*[@aria-label='Wyszukaj imię, nazwisko osoby']")
    public static WebElement przyciskZapros;

    @FindBy(xpath = "//button//span[contains(text(), 'Szczegóły')]")
    public static WebElement przyciskSzczegoly;

    //Szczegoly spotkania w kalendarzu
    @FindBy(xpath = "//button//span[contains(text(), 'Edytuj')]")
    public static WebElement przyciskEdytuj;

    @FindBy(xpath = "//button//span[contains(text(), 'Usuń')]")
    public static WebElement przyciskUsun;

    //Usun TAK/NIE
    @FindBy(xpath = "//button[contains(text(), 'Tak')]")
    public static WebElement przyciskTAK;

    @FindBy(xpath = "//button[contains(text(), 'Nie')]")
    public static WebElement przyciskNIE;

    @FindBy(xpath = "//*[@aria-label='Wszystkie zdarzenia']")
    public static WebElement poleOpcjiWszystkieZdarzenia;

    @FindBy(xpath = "//button//span[contains(text(), 'Ok')]")
    public static WebElement przyciskOK;

    @FindBy(xpath = "//button//span[contains(text(), 'Zamknij')]")
    public static WebElement przyciskZamknij;

    @FindBy(xpath = "//*[@aria-label='Wydarzenie cykliczne']")
    public static WebElement poleOpcjiWydarzenieCykliczne;

    @FindBy(xpath = "//md-input-container//textarea[@name='description']")
    public static WebElement poleTekstoweOpis;

    @FindBy(xpath = "//*[@placeholder='Wybierz częstotliwość']")
    public static WebElement listaWybierzCzestotliwosc;

    @FindBy(xpath = "//*[@aria-label='Zapisz']")
    public static WebElement przyciskZapisz;

}
