package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class SalesCloudDashboard {

    @FindBy (xpath = "//*[@id='content']//*[contains(text(), 'TRYB BIURO')]")
    public static WebElement przyciskTrybBiuro;

    @FindBy (xpath = "//*[@class='card-dashboard activity-dashboard _md']")
    public static WebElement tablicaDashboardWyniki;

    @FindBy (xpath = "//*[@class='card-dashboard tasks-dashboard _md']")
    public static WebElement tablicaDashboardPowiadomienia;

    @FindBy (xpath = "//*[@class='card-dashboard online-activity-dashboard _md']")
    public static WebElement tablicaDashboardAktywnosc;

    @FindBy (xpath = "//*[@class='card-dashboard retention-dashboard _md']")
    public static WebElement tablicaDashboardAkcjeRetencyjne;

    //Wyniki
    @FindBy (xpath = "//*[@id='content']//*[contains(text(), 'Foldery Potrzeb')]")
    public static WebElement przyciskFolderyPotrzeb;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Wnioski')]")
    public static WebElement przyciskWnioski;

    @FindBy(xpath = "//*[contains(text(), 'Spotkania z ')]/../../..")
    public static WebElement przyciskSpotkaniaZKlientami;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Pokaż szczegóły')]")
    public static List<WebElement> przyciskPokazSzczegoly;

    //Powiadomienia
    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'bez spotkań')]")
    public static WebElement przyciskAgentybezspotkan;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Brak wydarzeń w kalendarzu')]")
    public static WebElement przyciskBrakWydarzen;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Brak nowych odnowień')]")
    public static WebElement przyciskBrakOdnowien;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'wydarzenie w kalendarzu')]")
    public static WebElement przyciskWydarzenieWKalendarzu;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'wydarzeń w kalendarzu')]")
    public static WebElement przyciskKilkaWydarzenWKalendarzu;

    //Aktywność
    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Online')]")
    public static WebElement przyciskOnline;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Dzisiaj aktywni w Sales Cloudzie')]")
    public static WebElement przyciskDzisiajAktywniwSC;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Nieaktywni ponad 3 dni')]")
    public static WebElement przyciskNieaktywniPonad3Dni;

    // Akcje Retencyjne

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Niezakończone')]")
    public static WebElement przyciskNiezakonczone;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Uratowane')]")
    public static WebElement przyciskUratowane;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Nieuratowane')]")
    public static WebElement przyciskNieuratowane;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), ' Szczegółowy raport ')]")
    public static WebElement przyciskSzczegolowyRaport;

}
