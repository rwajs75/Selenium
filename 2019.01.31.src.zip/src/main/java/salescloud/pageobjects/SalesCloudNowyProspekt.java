package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudNowyProspekt {

    @FindBy(xpath = "//*[@aria-label='Osoba fizyczna']")
    public static WebElement przyciskWyboruOsobaFizyczna;
    @FindBy(xpath = "//*[@aria-label='Osoba prawna']")
    public static WebElement przyciskWyboruOsobaPrawna;
    @FindBy(name = "firstName")
    public static WebElement poleTekstoweImie;
    @FindBy(name = "lastName")
    public static WebElement poleTekstoweNazwisko;
    @FindBy(name = "phone")
    public static WebElement poleTekstoweNumerTelefonu;
    @FindBy(name = "email")
    public static WebElement poleTekstoweAdresEmail;
    @FindBy(name = "sex")
    public static WebElement poleTekstowePlec;  // Do wyboru Kobieta/Mężczyzna
    @FindBy(name = "birthDate")
    public static WebElement poleTekstoweDataUrodzenia;
    @FindBy(name = "pesel")
    public static WebElement poleTekstowePesel;
    @FindBy(name = "identityCardNumber")
    public static WebElement poleTekstoweNrDowoduOsobistego;

    //adres
    @FindBy(xpath = "//span[text()='Pokaż']")
    public static WebElement przyciakAdresRozwin;

    public static final By przyciakAdresRozwin1 = By.xpath("//span[text()='Pokaż']");
    public static final By przyciakAdresRozwin2 = By.xpath("//*[text()=' Pokaż ']");

    @FindBy(name = "postCode")
    public static WebElement poleTekstoweKodPocztowy;
    @FindBy(name = "city")
    public static WebElement poleTekstoweMiasto;
    @FindBy(name = "street")
    public static WebElement poleTekstoweUlica;
    @FindBy(name = "homeNo")
    public static WebElement poleTekstoweNrDomu;
    @FindBy(name = "apartmentNo")
    public static WebElement poleTekstoweNrMieszkania;


    @FindBy(xpath = "//*[@type='button']//*[contains(text(), 'Dodaj')]")
    public static WebElement przyciskDodaj;



}
