package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudFolderPotrzeb {

    @FindBy(xpath = "//*[@ng-click='$ctrl.tryRedirectToCreateFactFindFn(clientCode)']")
    public static WebElement przyciskUtworzFolderPotrzeb;

    public static final By przyciskZalozNowyFolderPotrzeb = By.xpath("//*[@aria-label='Załóż nowy folder potrzeb']");

    public static final By przyciskRozpocznij = By.xpath("//*[@aria-label='Rozpocznij']");

    // Ankieta
    @FindBy(xpath = "//*[@aria-label='Zgadzam się na przeprowadzenie ankiety']")
    public static WebElement przyciskWyboruZgadzamSieNaAnkiete;
    @FindBy(xpath = "//*[@aria-label='Odmawiam przeprowadzenia ankiety']")
    public static WebElement przyciskWyboruOdmawiamAnkiety;
    @FindBy(xpath = "//*[@aria-label='Następna strona']")
    public static WebElement przyciskDalej;

    // Dalszy etap po wyborze rodzaju polisy
    @FindBy(xpath = "//*[@role='dialog']//*[@type='button' and contains(text(),'O produkcie')]")
    public static WebElement przyciskOProdukcie;
    @FindBy(xpath = "//*[@role='dialog']//*[@type='button' and contains(text(),'Anuluj')]")
    public static WebElement przyciskAnuluj;
    @FindBy(xpath = "//*[@id='recProductRecommendation']/div[1]")
    public static WebElement poleOpcjiJakoAgent;
    @FindBy(xpath = "//*[@aria-label='Wniosek']")
    public static WebElement przyciskPrzejdzDoWniosku;

    // Wybor rodzaju wniosku
    @FindBy(name = "recElectronicContract")
    public static WebElement przyciskWniosekElektroniczny;
    @FindBy(name = "recPaperContract")
    public static WebElement przyciskWniosekPapierowy;

    //Popup
    @FindBy (xpath = "//*[@role='dialog']//*[@type='button' and contains(text(),'Anuluj')]")
    public static WebElement przyciskAnulujPopUP;
    @FindBy (xpath = "//*[@role='dialog']//*[@type='button' and contains(text(),'O produkcie')]")
    public static WebElement przyciskOprodukciePopUP;

    public static final By przyciskOkPopUP = By.xpath("//*[contains(text(), 'Ok')]");

    //
    @FindBy(id = "recContractNumber")
    public static WebElement poleTekstowePodajNumerWniosku;
    @FindBy(xpath = "//button[contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapiszWniosekPapierowy;
    public static final By komunikatUwagaNumerWniosku = By.xpath("//*[contains(text(), 'Ten numer wniosku został już użyty')]");
    public static final By przyciskPobierz = By.xpath("//button[contains(text(), 'Pobierz')]");



}
