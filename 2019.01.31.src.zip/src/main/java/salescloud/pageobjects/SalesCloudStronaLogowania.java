package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudStronaLogowania {

    public static By poleTekstoweLogin = By.id("username");
    @FindBy(id = "password")
    public static WebElement poleTekstoweHaslo;
    @FindBy(name = "submit")
    public static WebElement przyciskZaloguj;
    @FindBy(xpath = "//*[@class='av-ladowanieDanych-overlay-container ng-scope layout-align-center-center layout-row']")
    public static WebElement loading;

}
