package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWniosekOferta {

    @FindBy(xpath = "//button//*[contains(text(), 'Dane do polisy')]")
    public static WebElement przyciskDaneDoPolisy;
}
