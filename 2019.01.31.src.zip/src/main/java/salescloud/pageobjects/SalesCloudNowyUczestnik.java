package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudNowyUczestnik {

    @FindBy(xpath = "//*[@role='listbox'][@aria-label='Rola']")
    public static WebElement poleWyboruRola;

    @FindBy(xpath = "//*[@name='firstName']")
    public static WebElement poleTekstoweImie;

    @FindBy(xpath = "//*[@role='listbox'][@aria-label='Płeć']")
    public static WebElement poleWyboruPlec;

    @FindBy(xpath = "//*[@name='pesel']")
    public static WebElement poleTekstowePesel;

    @FindBy(xpath = "//*[@name='birthDate']")
    public static WebElement poleTekstoweDataUrodzenia;

    @FindBy(xpath = "//*[@type='button']/*[contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapisz;


}
