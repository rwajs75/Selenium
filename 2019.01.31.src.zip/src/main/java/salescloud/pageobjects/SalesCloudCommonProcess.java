package salescloud.pageobjects;

public class SalesCloudCommonProcess {
}
