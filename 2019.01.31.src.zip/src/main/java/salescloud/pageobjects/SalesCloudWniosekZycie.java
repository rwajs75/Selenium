package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWniosekZycie {

    // Zycie
    @FindBy(xpath = "//a[@name='LIFE_section']//..//*[contains(text(),'Życie')]")
    public static WebElement przyciskZycie;

    @FindBy(xpath = "//*[@name='sumAssured']")
    public static WebElement poleTekstoweSumaUbezpieczenia;

    public static final By zakresSumaUbezpieczenia = By.xpath("//*[@name='sumAssured']/../*[@role='alert']/*/*");

    @FindBy(xpath = "//*[@name='premium']")
    public static WebElement poleTekstoweSkladka;




}
