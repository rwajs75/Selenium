package salescloud.pageobjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

import static helpers.common.Common.clickElement;
import static helpers.common.Common.waitTillSpinnerDisable2;

public class SalesCloudMenuGlowne {

    @FindBy(xpath = "//*[@aria-label='Pokaż-ukryj menu']")
    public static WebElement przyciskPokazUkryjMenu;
    @FindBy(xpath = "//*[@aria-label='Pulpit']")
    public static WebElement przyciskPulpit;
    @FindBy(xpath = "//*[@aria-label='Kalendarz']")
    public static WebElement przyciskKalendarz;
    @FindBy(xpath = "//*[@aria-label='Twoi klienci']")
    public static WebElement przyciskTwoiKlienci;
    @FindBy(xpath = "//*[@aria-label='Klienci']")
    public static WebElement przyciskKlienci;
    @FindBy(xpath = "//*[@aria-label='Oferty']")
    //wnioski
    public static WebElement przyciskOferty;
    @FindBy(xpath = "//*[@aria-label='Polisy']")
    public static WebElement przyciskPolisy;
    @FindBy(xpath = "//*[@data-st='leadActions']")
    public static WebElement przyciskAkcje;
    @FindBy(xpath = "//*[@data-st='menuDistribute']")
    public static WebElement przyciskPrzydzielanie;
    @FindBy(xpath = "//*[@aria-label='Wyniki']")
    public static WebElement przyciskWyniki;
    @FindBy(xpath = "//*[@aria-label='Akademia rozwoju']")
    public static WebElement przyciskAkademiaRozwoju;
    @FindBy(xpath = "//*[@aria-label='Środowisko szkoleniowe']")
    public static WebElement przyciskSrdowiskoSzkolniowe;

    @FindBy(xpath = "//*[@aria-label='Poczta']")
    public static WebElement przyciskPoczta;
    @FindBy(xpath = "//*[@aria-label='Portal Agentów']")
    public static WebElement przyciskPortalAgentow;

    //Wyloguj
    @FindBy(xpath = "//*[@aria-owns='menu_container_1']")
    public static WebElement przyciskMenu;
    @FindBy(xpath = "//*[@aria-label='aviva:logout']")
    public static WebElement przyciskWyloguj;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'SalesCloud')]")
    public static WebElement przyciskSalesCloud;

    public static void salesCloudMenu(String ariaLabel, WebDriver driver) {
        clickElement(By.xpath("//*[@aria-label='" + ariaLabel + "']"));
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
    }
}
