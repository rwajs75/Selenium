package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static helpers.common.Common.enterIntoTextField;

public class SalesCloudWniosekInwestycje {

    // Inwestycje
    @FindBy(xpath = "//*[contains(text(),'Inwestycje')]")
    public static WebElement przyciskInwestycje;

    @FindBy(xpath = "//*[@name='split_0']//input")
    public static WebElement poleTekstoweFunduszGwarantowany;
    @FindBy(xpath = "//*[@name='split_1']//input")
    public static WebElement poleTekstoweFunduszStabilnegoWzrostu;

    @FindBy(xpath = "//*[@name='duration']")
    public static WebElement poleTekstoweCzasTrwaniaUmowy;

    public static final By zakresCzasTrwaniaUmowy = By.xpath("//*[@name='duration']/../*[@role='alert']/*/*");

    @FindBy(xpath = "//*[@name='premium']")
    public static WebElement poleTekstoweWysokoscSkladkiInwectycyjne;

    public static final By zakresWysokoscSkladkiInwectycyjne = By.xpath("//*[@name='premium']/../*[@role='alert']/*/*");






    /** DO DODANIA KOLEJNE OPCJE */

    @FindBy(xpath = "//*[contains(text(),'Zatwierdź wybór funduszy')]")
    public static WebElement przyciskZatwierdzWyborFunduszy;


    public static void selectCapital(String nazwaFunduszu, String wartosc){
        enterIntoTextField(By.xpath("//*[contains(text(), '"+nazwaFunduszu+"')]/..//input"),wartosc);
    }
}
