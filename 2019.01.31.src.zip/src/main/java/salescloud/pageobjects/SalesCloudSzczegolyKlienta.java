package salescloud.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudSzczegolyKlienta {

    //Dane Klienta
    @FindBy(xpath = "//*[@ng-if=\"$ctrl.customer.partyType === 'PERSON'\" and @class='ng-binding ng-scope']")
    public static WebElement daneKlientaImieNazwisko;

    @FindBy(xpath = "//*[@ng-if='$ctrl.customer.phone']")
    public static WebElement daneKlientaTelefon;

    @FindBy(xpath = "//*[@ng-if='$ctrl.customer.email']")
    public static WebElement daneKlientaMail;

    @FindBy(xpath = "//*[@ng-if='$ctrl.customer.pesel']")
    public static WebElement daneKlientaPESEL;

    //Menu glowne
    @FindBy(xpath = "//*[@role='tablist']//*[contains(text(), 'Profil') and @role='tab']")
    public static WebElement przyciskProfil;

    @FindBy(xpath = "//*[@role='tablist']//*[contains(text(), 'Pasaż Produktów') and @role='tab']")
    public static WebElement przyciskPasazProduktow;

    @FindBy(xpath = "//*[@role='tablist']//*[contains(text(), 'Polisy') and @role='tab']")
    public static WebElement przyciskPolisyKlienta;

    @FindBy(xpath = "//*[@role='tablist']//*[contains(text(), 'Sprzedaż') and @role='tab']")
    public static WebElement przyciskSprzedaż;

    @FindBy(xpath = "//*[@role='tablist']//*[contains(text(), 'Notatki') and @role='tab']")
    public static WebElement przyciskNotatki;

    public static final By przyciskFolderPotrzebUtworz = By.xpath("//*[contains(@class, 'av-link ng-scope') and text() = 'Utwórz']");

    public static final By przyciskFolderPotrzebWiecej = By.xpath("//*[@class='av-link'and text() = 'Więcej']");

    //Notatki
    @FindBy(xpath = "//*[@placeholder='Wprowadź notatkę. Będzie ona zapisana na Profilu Klienta.']")
    public static WebElement poleTekstoweWprowadzNotatke;

    @FindBy(xpath = "//button/*[contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapiszNotatke;

    @FindBy(xpath = "//button/*[contains(text(), 'Anuluj')]")
    public static WebElement przyciskAnulujNotatke;

    @FindBy(xpath = "//button/*[contains(text(), 'Edytuj')]")
    public static WebElement przyciskEdytujNotatke;

    @FindBy(xpath = "//button/*[contains(text(), 'Usuń')]")
    public static WebElement przyciskUsuńNotatke;

    @FindBy(xpath = "//button/*[contains(text(), 'Powrót')]")
    public static WebElement przyciskPowrotNotatke;

    @FindBy(xpath = "//*[@role='button'][contains(text(), 'Więcej')]")
    public static WebElement przyciskWiecejNotatki;

    //Profil
    @FindBy(xpath = "//*[@role='button'][contains(text(), 'Więcej')]")
    public static WebElement pzyciskEdytujZgody;



}