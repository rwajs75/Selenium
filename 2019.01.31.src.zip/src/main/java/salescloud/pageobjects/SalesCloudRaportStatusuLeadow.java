package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudRaportStatusuLeadow {


    @FindBy (xpath = "//*[@aria-label='Wyniki']")
    public static WebElement przyciskWyniki;

    @FindBy(xpath = "//*[@aria-label='Raportuj aktywność']")
    public static WebElement przyciskRaportujAktywnosc;

    @FindBy(xpath = "//*[@aria-label='Raport statusu leadów']")
    public static WebElement przyciskRaportStatusuLeadow;

    @FindBy(xpath = "//*[@aria-label='Kampania']")
    public static WebElement listaKamapania;

    @FindBy(xpath = "//*[@placeholder='Wybierz przedział czasowy']")
    public static WebElement listaPrzedzialCzasowy;

    @FindBy(xpath = "//*[@data-st='generate']")
    public static WebElement przyciskGeneruj;

    @FindBy(xpath = "//*[@class='av-link']")
    public static WebElement przyciskEksportdoPliku;

    @FindBy(xpath = "//*[@class='lead-report']")
    public static WebElement tabelazRaportem;
























}
