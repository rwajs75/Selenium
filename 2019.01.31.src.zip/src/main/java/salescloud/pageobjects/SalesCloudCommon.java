package salescloud.pageobjects;

import helpers.generators.RandomIntGenerator;
import helpers.generators.RandomStringGenerator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.common.Common.getElementText;
import static helpers.common.Common.reporter;
import static helpers.generators.IDGenerator.generateID;
import static helpers.generators.PESELGenerator.generatePESELForDate;
import static helpers.login.Login.url;

public class SalesCloudCommon {

    //Krecioly
    public static final By ladowanieDanych = By.xpath("//*[@class='av-ladowanieDanych-overlay-container ng-scope layout-align-center-center layout-row']");
    public static final By ladowanieDanychWniosek = By.xpath("//*[@role='progressbar']");

    /**
     * Inicjalizacja wszystkich PageFactory do testu [SalesCloud]
     *
     * @param driver
     */
    public static void initElement(WebDriver driver) {
        reporter().logPass("# Inicjalizacja obiektów #");
        PageFactory.initElements(driver, SalesCloudCommon.class);
        PageFactory.initElements(driver, SalesCloudStronaLogowania.class);
        PageFactory.initElements(driver, SalesCloudTwoiKlienci.class);
        PageFactory.initElements(driver, SalesCloudSzczegolyKlienta.class);
        PageFactory.initElements(driver, SalesCloudNowyProspekt.class);
        PageFactory.initElements(driver, SalesCloudFolderPotrzeb.class);
        PageFactory.initElements(driver, SalesCloudWniosekDaneOsobowe.class);
        PageFactory.initElements(driver, SalesCloudWniosekZycie.class);
        PageFactory.initElements(driver, SalesCloudWniosekAnkietaMedyczna.class);
        PageFactory.initElements(driver, SalesCloudNowyUczestnik.class);
        PageFactory.initElements(driver, SalesCloudWniosekInwestycje.class);
        PageFactory.initElements(driver, SalesCloudWniosekIKE.class);
        PageFactory.initElements(driver, SalesCloudWniosekZycie.class);
        PageFactory.initElements(driver, SalesCloudWniosekZdrowie.class);
        PageFactory.initElements(driver, SalesCloudWniosekWynikOcenyRyzyka.class);
        PageFactory.initElements(driver, SalesCloudWniosekZgodyiOswiadczenia.class);
        PageFactory.initElements(driver, SalesCloudWniosekUposażeni.class);
        PageFactory.initElements(driver, SalesCloudWniosekSprzedaz.class);
        PageFactory.initElements(driver, SalesCloudWniosekWybierzPakiet.class);
        PageFactory.initElements(driver, SalesCloudWniosekNieruchomosc.class);
        PageFactory.initElements(driver, SalesCloudWniosekOferta.class);
        PageFactory.initElements(driver, SalesCloudWniosekDaneDoPolisy.class);
        PageFactory.initElements(driver, SalesCloudKalendarz.class);
        PageFactory.initElements(driver, SalesCloudWybierzProfilInwestycyjny.class);
    }

    /**
     * Funckja dodająca nowego klienta w SalesCloud oraz zwracająca dane Imie,Nazwisko,Pesel,Mail
     *
     * @param nrTel
     * @param nowyMail
     * @param srodowisko
     * @return imie , nazwisko , pesel, nowyMail
     */
    public static String[] salesCloudRegisterNewClient(String nrTel, String nowyMail, String srodowisko, String aplikacja) {

        String nazwisko = "NAZWISKO" + RandomStringGenerator.generateCharsSequence().toUpperCase();
        String imie = "IMIE" + RandomStringGenerator.generateCharsSequence().toUpperCase();
        String rokString = LocalDate.now().minusYears(40).format(DateTimeFormatter.ofPattern("yyyy"));
        int rok = Integer.parseInt(rokString);
        int miesiac = RandomIntGenerator.liczbaLosowa(10,2);
        int dzien = RandomIntGenerator.liczbaLosowa(10,15);
        //String dataUrodzenia = dzien+"-"+miesiac+"-"+rok;
        String pesel = generatePESELForDate(rok, miesiac, dzien, 'm');
        String nrDowodu = generateID();
        clickButton(SalesCloudTwoiKlienci.przyciskDodajNowegoKlienta);
        enterIntoTextField(SalesCloudNowyProspekt.poleTekstoweImie, imie);
        enterIntoTextField(SalesCloudNowyProspekt.poleTekstoweNazwisko, nazwisko);
        enterIntoElement(SalesCloudNowyProspekt.poleTekstoweNumerTelefonu, nrTel);
        if (nowyMail.equals("")) {
            nowyMail = creationNewMailDBforImmediateUse(srodowisko, aplikacja);
        }
        enterIntoElement(SalesCloudNowyProspekt.poleTekstoweAdresEmail, nowyMail);
        enterIntoTextField(SalesCloudNowyProspekt.poleTekstowePesel, pesel);
        enterIntoTextField(SalesCloudNowyProspekt.poleTekstoweNrDowoduOsobistego, nrDowodu);

        /** Zmienione 02.01.2019 @PMendalka */
        if (waitUntilElementPresent(SalesCloudNowyProspekt.przyciakAdresRozwin1, 2)!=null)
            clickElement(SalesCloudNowyProspekt.przyciakAdresRozwin1);
        if (waitUntilElementPresent(SalesCloudNowyProspekt.przyciakAdresRozwin2, 2)!=null)
            clickElement(SalesCloudNowyProspekt.przyciakAdresRozwin2);
        //clickElement(SalesCloudNowyProspekt.przyciakAdresRozwin);

        enterIntoTextField(SalesCloudNowyProspekt.poleTekstoweKodPocztowy, "01-022");
        enterIntoTextField(SalesCloudNowyProspekt.poleTekstoweMiasto, "Warszawa");
        enterIntoTextField(SalesCloudNowyProspekt.poleTekstoweUlica, "Józefa Bellottiego");
        enterIntoTextField(SalesCloudNowyProspekt.poleTekstoweNrDomu, "3B");
        enterIntoTextField(SalesCloudNowyProspekt.poleTekstoweNrMieszkania, "13");

        clickElement(SalesCloudNowyProspekt.przyciskDodaj);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        if (waitUntilElementPresent(By.xpath("//*[@ng-if='$ctrl.customer.email']"), 10) != null) {
            waitUntilElementVisibleFail(SalesCloudSzczegolyKlienta.daneKlientaMail, 1);
        } else {
            reporter().logFail("Dane szczegółowe klienta nie zostały wyświetlone");
        }
        String daneKlientaM = getElementText(SalesCloudSzczegolyKlienta.daneKlientaMail);
        if (daneKlientaM.equals(nowyMail)) {
            reporter().logPass("Dane klienta poprawnie zapisane i wyswietlone: Adres mail: " + nowyMail);
        } else {
            reporter().logFail("Dane klienta niepoprawne. Wynik odczytany: " + daneKlientaM + " Wynik oczekiwany: " + nowyMail);
        }

        String pobraneNazwiskoImie = getElementText(SalesCloudSzczegolyKlienta.daneKlientaImieNazwisko);
        nazwisko = nazwisko.toUpperCase();
        imie = imie.toUpperCase();
        if (pobraneNazwiskoImie.equals(imie + "\n" + nazwisko)) {
            reporter().logPass("Dane klienta poprawnie zapisane i wyswietlone: Imie,Nazwisko: " + pobraneNazwiskoImie);
        } else {
            reporter().logFail("Dane klienta niepoprawne. Wynik odczytany: " + pobraneNazwiskoImie + " Wynik oczekiwany: " + imie + "\n" + nazwisko);
        }

        String daneKlientaT = getElementText(SalesCloudSzczegolyKlienta.daneKlientaTelefon);
        if (daneKlientaT.equals(nrTel)) {
            reporter().logPass("Dane klienta poprawnie zapisane i wyswietlone: Numer Telefonu: " + nrTel);
        } else {
            reporter().logFail("Dane klienta niepoprawne. Wynik odczytany: " + daneKlientaT + " Wynik oczekiwany: " + nrTel);
        }
        String daneKlientaP = getElementText(SalesCloudSzczegolyKlienta.daneKlientaPESEL);
        if (daneKlientaP.equals("PESEL: " + pesel)) {
            reporter().logPass("Dane klienta poprawnie zapisane i wyswietlone: Pesel: " + pesel);
        } else {
            reporter().logFail("Dane klienta niepoprawne. Wynik odczytany: " + daneKlientaP + " Wynik oczekiwany: PESEL: " + pesel);
        }

        return new String[]{imie, nazwisko, pesel, nowyMail, nrDowodu};

    }

    /**
     * Funkcja pobierajaca zakres danych mozliwych do wpisania w pole tekstowe [Wnioski]
     * Wybiera pierwszą wartość z zakresu
     *
     * @param by
     * @return
     */
    public static String getDataRange(By by) {
        String zu6 = "";
        if (waitUntilElementPresent(by, 1) != null) {
            String[] zu1 = getElementText(by).split("lat");
            String[] zu2 = zu1[0].trim().split("zł");

            String[] zu3 = zu2[0].split("przedziału");
            String zu4;
            if (zu3.length >= 2) {
                zu4 = zu3[1].trim();
            } else {
                zu4 = zu3[0].trim();
            }

            String[] zu5 = zu4.split("wartość");
            if (zu5.length >= 2) {
                zu6 = zu5[1].trim();
            } else {
                zu6 = zu5[0].trim();
            }
        } else {
            reporter().logFail("Dla obiektu: " + by + " nie zostal wyswietlony zakres danych do wprowadzania");
        }
        return zu6.substring(1);
    }

    /**
     * Funkcja klikajaca w zakladki z rolami uczestnikow
     *
     * @param imie - imie uczestnika
     */
    public static void clickTabRole(String imie) {
        clickElement(By.xpath("//*[@role='tab']//*[contains(text(), '" + imie + "')]"));
    }

    /**
     * Funkcja wyszukujaca klienta w SalesCloud po numerze telefonu. Jezeli nie istnieje tworzy nowe konto
     *
     * @param nrTel
     * @param srodowisko
     * @param aplikacja
     * @param driver
     * @return dane klienta: [imie, nazwisko, pesel, email, nr dowodu]
     */
    public static String[] salesCloudSearchClient(String nrTel, String srodowisko, String aplikacja, WebDriver driver) {
        String[] daneKlienta = null;
        initElement(driver);
        clickElement(SalesCloudTwoiKlienci.przyciskOpcjeWyszukiwania);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickElement(SalesCloudTwoiKlienci.przyciskOpcjeWyszukiwaniaTelefon);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        enterIntoElement(SalesCloudTwoiKlienci.poleTekstoweKogoSzukasz, nrTel);
        clickElement(SalesCloudTwoiKlienci.przyciskSzukaj);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
        String daneKlientaLista = "(//a[contains(@href, '/sales-application/customer')])[1]"; // (//a[contains(@href, '/sales-application/customer')])[1]
        if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Wystąpił błąd w trakcie wyszukiwania')]"), 10) == null) {
            if (waitUntilElementPresent(By.xpath(daneKlientaLista), 30) != null) {
                clickElement(By.xpath(daneKlientaLista));
                waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
                reporter().logPass("Dane klienta zostaly odnalezione");
                return new String[]{
                        SalesCloudTwoiKlienci.imieINazwisko.getText().split("\\n")[0],
                        SalesCloudTwoiKlienci.imieINazwisko.getText().split("\\n")[1],
                        SalesCloudTwoiKlienci.pesel.getText().substring(7),
                        SalesCloudTwoiKlienci.email.getText(),
                        SalesCloudTwoiKlienci.numerDowoduOsobistego.getText().substring(25)
                };
            } else {
                reporter().logPass("Brak danych klienta zarejestrowanego na numer telefonu: " + nrTel + ". Rejestruje nowego klienta");
                daneKlienta = salesCloudRegisterNewClient(nrTel, "", srodowisko, aplikacja);
                return new String[]{daneKlienta[0], daneKlienta[1], daneKlienta[2], daneKlienta[3]};
            }
        } else {
            reporter().logFail("Wystąpił błąd w trakcie wyszukiwania");
            return new String[]{};
        }
    }

    /**
     * Funkcja zaznaczajaca przycisk wyboru (radioButton)
     * @param glownyWiersz - np. Rodzaj domu (Nazwa sekcji pola)
     * @param poleWyboru - np. Blizniak (Przycisk wyboru)
     */
    public static void selectRadioButtonProperty(String glownyWiersz, String poleWyboru){
        clickElement(By.xpath("//*[@label='"+glownyWiersz+"']//*[contains(text(), '"+poleWyboru+"')]/.."));
    }

    /**
     * Funkcja zaznaczająca pole opcji (checkBox)
     * @param nazwaCheckbox - nazwa checkbox np. Nieruchomosc w budowie
     */
    public static void selectCheckBoxProperty(String nazwaCheckbox){
        clickElement(By.xpath("//*[contains(text(), '"+nazwaCheckbox+"')]"));
    }

    /**
     * Funkcja wybierająca opcję z listy rozwijanej.
     * @param nazwaListy nazwa checkboxa, np. 'Częstotliwość wpłat'
     * @param opcja opcja, np. 'Co miesiąc'
     */
    public static void selectDropdownListOption(String nazwaListy, String opcja) {
        clickElement(By.xpath("//*[text()='" + nazwaListy + "']/../..//*[@role='listbox']"));
        pauseFor(1);
        clickElement(By.xpath("//md-option[contains(text(), '" + opcja + "')]"));
    }

    /**
     * Funkcja klikajaca w przycisk na wyswietlonym popup
     */
    public static void clickPopUp(String nazwaPrzycisku , int timeout){
        if ((waitUntilElementPresent(By.xpath("//button[contains(text(), '"+nazwaPrzycisku+"')]"), timeout)) != null) {
            clickElement(By.xpath("//button[contains(text(), '" + nazwaPrzycisku + "')]"));
        }else{
            reporter().logPass("PopUp nie zostal wyswietlony");
        }
    }

    /**
     * Funkcja wyszukujaca klienta w SalesCloud po numerze PESEL.
     *
     * @param pesel
     * @param driver
     * @return dane klienta: [imie, nazwisko, pesel, email, nr dowodu]
     */
    public static String[] salesCloudSearchClient(String pesel, WebDriver driver) {
        String[] daneKlienta = null;
        initElement(driver);
        clickElement(SalesCloudTwoiKlienci.przyciskOpcjeWyszukiwania);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickElement(SalesCloudTwoiKlienci.getPrzyciskOpcjeWyszukiwaniaPESEL);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        enterIntoElement(SalesCloudTwoiKlienci.poleTekstoweKogoSzukasz, pesel);
        clickElement(SalesCloudTwoiKlienci.przyciskSzukaj);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
        String daneKlientaLista = "(//a[contains(@href, '/sales-application/customer')])[1]"; // (//a[contains(@href, '/sales-application/customer')])[1]
        if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Wystąpił błąd w trakcie wyszukiwania')]"), 10) == null) {
            if (waitUntilElementPresent(By.xpath(daneKlientaLista), 30) != null) {
                clickElement(By.xpath(daneKlientaLista));
                waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
                reporter().logPass("Dane klienta zostaly odnalezione");
                return new String[]{
                        SalesCloudTwoiKlienci.imieINazwisko.getText().split("\\n")[0],
                        SalesCloudTwoiKlienci.imieINazwisko.getText().split("\\n")[1],
                        SalesCloudTwoiKlienci.pesel.getText().substring(7),
                        SalesCloudTwoiKlienci.email.getText(),
                        SalesCloudTwoiKlienci.numerDowoduOsobistego.getText().substring(25)
                };
            } else {
                //reporter().logPass("Brak danych klienta zarejestrowanego na numerze pesel: " + pesel + ". Rejestruje nowego klienta");
                //daneKlienta = salesCloudRegisterNewClient(nrTel, "", srodowisko, aplikacja); //TODO: Czy zostawić ?
                return new String[]{daneKlienta[0], daneKlienta[1], daneKlienta[2], daneKlienta[3]};
            }
        } else {
            reporter().logFail("Wystąpił błąd w trakcie wyszukiwania");
            return new String[]{};
        }
    }

    /**
     * Funkcja klikajaca po menu SalesCloud
     * @param podzakladka - drugie podmenu
     * @param driver
     */
    public static void clickMenuSalesCloud(String podzakladka, String appEnv, WebDriver driver) {

        if (url == null) {
            url = driver.getCurrentUrl();
            reporter().logPass("URL = NULL. Pobrano aktualny URL: " + url);
        }

        if (waitUntilElementVisible(SalesCloudMenuGlowne.przyciskMenu, 10) != null) {
            clickElement(SalesCloudMenuGlowne.przyciskMenu);
            if (podzakladka.equals("Wyloguj")) {
                waitUntilElementVisible(SalesCloudMenuGlowne.przyciskWyloguj, 10);
                clickElement(SalesCloudMenuGlowne.przyciskWyloguj);
                waitUntilElementVisible(SalesCloudMenuGlowne.przyciskSalesCloud, 10);
                clickElement(SalesCloudMenuGlowne.przyciskSalesCloud);
            } else {
                reporter().logFail("W menu nie została odnaleziona pozycja: " + podzakladka);
            }
        }
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
    }
}
