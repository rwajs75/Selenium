package salescloud.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SalesCloudWyszukiwarkaTwoiKlienci {

    @FindBy(xpath = "//*[@aria-label='Twoi klienci']")
    public static WebElement przyciskTwoiKlienci;

    @FindBy(xpath = "//*[@placeholder='Kogo szukasz?']")
    public static WebElement poleTekstoweKogoSzukasz;

    @FindBy(xpath = "//*[@name='searchFieldCode']")
    public static WebElement listaRozwijalnaWarunek;

    @FindBy(xpath = "//*[@value='firstName']")
    public static WebElement listaRozwiajalnaWarunekImie;

    @FindBy(xpath = "//*[@placeholder='Wybierz status']")
    public static WebElement listaWybierzStatus;

    @FindBy(xpath = "//*[@value='3_CLIENTS']")
    public static WebElement listaRozwiajalnaWybierzStatusKlient;

    @FindBy(xpath = "//*[@id='content']//*[contains(text(), 'Wiek')]")
    public static WebElement poleTeksoweWiek;

    @FindBy(xpath = "//*[@data-st='ageFrom']")
    public static WebElement poleTekstoweWiekOD;

    @FindBy(xpath = "//*[@data-st='ageTo']")
    public static WebElement poleTekstoweWiekDo;

    @FindBy(xpath ="//*[@name='searchPersonSex']")
    public static WebElement listaRozwijalnaPlec;

    @FindBy(xpath = "//*[@id='select_option_32']")
    public static WebElement listaRozwiajalnaPlecKobieta;

    @FindBy(xpath = "//*[@id='content']/..//*[contains(text(), 'Szukaj')] ")
    public static WebElement przyciskSzukaj;

    @FindBy(xpath = "//*[@ng-if='customer.partyType !== 'COMPANY'] ")
    public static WebElement przyciskKlient;







}
