package tia7.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Tia7FormularzTravel {

    @FindBy(xpath = "//button[contains(text(), 'Aktualizuj')]")
    public static WebElement przyciskAktualizuj;

    // KOD PROMOCYJNY ! ! !
    @FindBy(xpath = "//*[contains(text(), 'Promo code')]//.//../..//input")
    public static WebElement poleTekstoweKodPromocyjny;
}
