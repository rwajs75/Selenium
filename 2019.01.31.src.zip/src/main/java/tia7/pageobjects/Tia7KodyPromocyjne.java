package tia7.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Tia7KodyPromocyjne {

    /** Otworzenie zakładki 'Promocje' */
    @FindBy(xpath = "//table[contains(@id, 'HomeManagement')]")
    public static WebElement przyciskManagement;
    @FindBy(xpath = "//*[contains(text(), 'Marketing')]//..//..//..//*[@title='Rozwiń']")
    public static WebElement przyciskMarketing;
    @FindBy(xpath = "//*[contains(text(), 'Promocje')]")
    public static WebElement przyciskPromocje;

    /** Dodanie promocji - pozostałe elementy w funkcji generycznej 'setSelectInputTia7' */
    @FindBy(xpath = "//button[contains(text(), 'Nowy')]")
    public static WebElement przyciskNowy;
    // ----- Popup 'Wybór daty i godziny' -----
    @FindBy(xpath = "(//*[@title='Wybór daty i godziny'])[1]")
    public static WebElement przyciskDataStartu;
    @FindBy(xpath = "//*[(@title='Wybór daty i godziny') and contains(@id, 'datEndInput')]")
    public static WebElement przyciskDataKonca;
    @FindBy(xpath = "(//*[contains(@name, 'datEndInput')])[1]")
    public static WebElement poleTekstoweDataKonca;
    @FindBy(xpath = "//*[contains(text(), 'Wybór daty i godziny')]//..//..//..//..//..//..//..//button[contains(@id, 'ok')]")
    public static WebElement przyciskOKDataiGodzina;
    @FindBy(xpath = "//*[contains(text(), 'Wybór daty i godziny')]//..//..//..//..//..//..//..//button[contains(@id, 'cancel')]")
    public static WebElement przyciskCancelDataiGodzina;
    // ----------------------------------------
    @FindBy(xpath = "//*[contains(@id, 'DialogPromotionEdit')]/button[contains(@id, 'ok')]")
    public static WebElement przyciskOK;
    @FindBy(xpath = "//*[contains(@id, 'DialogPromotionEdit')]/button[contains(@id, 'cancel')]")
    public static WebElement przyciskAnuluj;

    /** Dodanie zniżek 'Zniżki per ryzyko' */
    @FindBy(xpath = "//*[contains(@id, 'discountAccordion')]//*[contains(text(), 'Edytuj')]")
    public static WebElement przyciskEdytuj;
    @FindBy(xpath = "//button[contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapiszEdycjaZnizek;
    @FindBy(xpath = "//button[contains(text(), 'Anuluj')]")
    public static WebElement przyciskAnulujEdycjaZnizek;

    /** Inne */
    @FindBy(xpath = "//button[contains(text(), 'Zamknij')]")
    public static WebElement przyciskZamknij;
}
