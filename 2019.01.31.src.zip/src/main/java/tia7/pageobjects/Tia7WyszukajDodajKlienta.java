package tia7.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Tia7WyszukajDodajKlienta {

    @FindBy(id="pageTemplate1:sf_c:r1:1:pt:P2000PartySearchSbf:SearchP2000PartySearchIdNoAltSearch::content")
    public static WebElement poleTekstoweIdKlienta;

    @FindBy(id="pageTemplate1:sf_c:r1:1:pt:P2000PartySearchSbf:SearchP2000PartySearchCivilRegCodeSearch::content")
    public static WebElement poleTekstowePesel;

    @FindBy(id="pageTemplate1:sf_c:r1:1:pt:P2000PartySearchSbf:SearchP2000PartySearchBirthdateSearchCust::content")
    public static WebElement poleTekstoweDataUrodzenia;

    @FindBy(id="pageTemplate1:sf_c:r1:1:pt:P2000PartySearchSbf:SearchP2000PartySearchSurnameSearch::content")
    public static WebElement poleTekstoweNazwisko;

    @FindBy(id="pageTemplate1:sf_c:r1:1:pt:P2000PartySearchSbf:SearchP2000PartySearchForename::content")
    public static WebElement poleTekstoweImię;

    @FindBy(id="pageTemplate1:sf_c:r1:1:pt:P2000PartySearchSbf:SearchP2000PartySearchPostAreaCodeSearch::content")
    public static WebElement poleTekstoweKodPocztowy;

    @FindBy(id="pageTemplate1:sf_c:r1:1:pt:P2000PartySearchSbf:SearchP2000PartySearchCitySearch::content")
    public static WebElement poleTekstoweMiasto;

    @FindBy(id="pageTemplate1:sf_c:r1:1:pt:P2000PartySearchSbf:cb4")
    public static WebElement przyciskSzukaj;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:P2000PartySearchCreateItem")
    public static WebElement przyciskNowyKlient;


}
