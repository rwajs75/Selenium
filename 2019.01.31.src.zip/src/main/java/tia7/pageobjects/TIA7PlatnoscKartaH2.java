package tia7.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TIA7PlatnoscKartaH2 {


   @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:1:pt:SourceCodeInput::content")
    public static WebElement listaRozwijanaKodZrodlowy;

   @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:1:pt:PolicyNewPolicyLine")
    public static WebElement przyciskNowaLiniaPolisowa;

    @FindBy(xpath = "//*[@_adfiv='H2']")
    public static WebElement wyborH2TwojDom;


    @FindBy(xpath = "//*[@_afrpdo='yes']")
    public static WebElement przyciskTak;

    //Nowa linia polisowa

    @FindBy(xpath = "//*[@_afrpdo='yes']")
    public static WebElement przyciskTakNLP;



   // Sposob użytkowania

   @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:H2PropertyTypeSoRadio:_0")
   public static WebElement przyciskWyboruMieszkanie;

   @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:H2PropertyTypeSoRadio:_1")
   public static WebElement przyciskWyboruDom;

   @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2RenovationSoRadio:_0")
    public static WebElement przyciskWyboruWTrakcieBudowyNie;

    @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:H2RenovationSoRadio:_1")
    public static WebElement przyciskWyboruWTrakcieBudowyTak;

    @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:H2BuildYearInputNumber::content")
    public static WebElement poleTekstoweRokBudowy;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:3:pt:ExtObjHouseHoldReg3:0:pt1:H2FloorAreaInputNumber")
    public static WebElement poleTekstowePowierzchniaM2;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:H2FloorNumberSoc::content")
    public static WebElement listaRozwijalnaPietro;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:H2ChildrenListSoc::content")
    public static WebElement listaRozwijalnaLiczbaOsobm2;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2BuildWoodenStructureSoRadio:_0")
    public static WebElement przyciskWyboruDrewnianaKonstrukcjaNie;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2BuildWoodenStructureSoRadio:_1")
    public static WebElement przyciskWyboruDrewnianaKonstrukcjaTak;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2NotClaimYearsSoc::content")
    public static WebElement listaRozwijalnaLiczbaLatBezSzkody;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2ClaimsSoRadio:_0")
    public static WebElement przyciskWyboruWystapienieSzkodyNie;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2ClaimsSoRadio:_1")
    public static WebElement przyciskWyboruWystapienieSzkodyTak;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2BusinessActivitySoRadio:_0")
    public static WebElement przyciskWyboruDzialanoscNie;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2BusinessActivitySoRadio:_1")
    public static WebElement przyciskWyboruDzialanoscTak;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2LegalTitleSoc::content")
    public static WebElement listaRozwijalnaTytulPrawny;

    //Zabiezpieczenia

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2FireExtinguisherSoRadio:_0")
    public static WebElement przyciskWyboruUrzadzenieGasniczeNie;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2FireExtinguisherSoRadio:_1")
    public static WebElement przyciskWyboruUrzadzenieGasniczeTak;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2AntiburglarDoorSoRadio:_0")
    public static WebElement przyciskWyboruDrzwiAntywlamanioweNie;

    @FindBy(id = "pageTemplate1:sf_c:r1:0:pt:TIADynamicTaskFlowRg:0:pt:ExtObjHouseHoldReg3:0:pt1:H2AntiburglarDoorSoRadio:_1")
    public static WebElement przyciskWyboruDrzwiAntywlamanioweTak;

    @FindBy(id = "pageTemplate1:sf_c:r1:0:pt:TIADynamicTaskFlowRg:0:pt:ExtObjHouseHoldReg3:0:pt1:H2BarRollerBlindSoRadio:_0")
    public static WebElement przyciskWyboruKratyRoletyNie;

    @FindBy(id = "pageTemplate1:sf_c:r1:0:pt:TIADynamicTaskFlowRg:0:pt:ExtObjHouseHoldReg3:0:pt1:H2BarRollerBlindSoRadio:_1")
    public static WebElement przyciskWyboruKratyRoletyTak;

    @FindBy(id = "pageTemplate1:sf_c:r1:0:pt:TIADynamicTaskFlowRg:0:pt:ExtObjHouseHoldReg3:0:pt1:H2AlarmSoRadio:_0")
    public static WebElement przyciskWyboruAlarmDzwiekowyNie;

    @FindBy(id = "pageTemplate1:sf_c:r1:0:pt:TIADynamicTaskFlowRg:0:pt:ExtObjHouseHoldReg3:0:pt1:H2AlarmSoRadio:_1")
    public static WebElement przyciskWyboruAlarmDzwiekowyTak;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2MonitoringSoRadio:_0")
    public static WebElement przyciskWyboruAlarmzInterwiecjaNie;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2MonitoringSoRadio:_1")
    public static WebElement przyciskWyboruAlarmzInterwiecjaTak;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2SecuritySoRadio:_0")
    public static WebElement przyciskWyboruStalyNadzorNie;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2SecuritySoRadio:_1")
    public static WebElement przyciskWyboruStalyNadzorTak;

    //Block ryzyka

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2RtfB3:0:pt1:FireVariant:_0")
    public static WebElement poleOpcjiWariantPodstawowy;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2RtfB3:0:pt1:RenTorrentialRainYn::content")
    public static WebElement poleOpcjiZalanieWoda;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2RtfB3:0:pt1:RenFireHouseYn::content")
    public static WebElement poleOpcjiNieruchomosc;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:1:pt:ExtObjHouseHoldReg3:0:pt1:H2RtfB3:0:pt1:RenFireHouseSum::content")
    public static WebElement poleTekstoweSumaUbez;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:H2RtfB3:0:pt1:valuePropertyRencmb")
    public static WebElement przyciskOcenaRyzyka;

    //Informacja o płatności

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:ExPmtR2:0:pt1:PaymentMethodLov::content")
    public static WebElement listaRozwijalnaMetodaPlatnosci;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:ExPmtR2:0:pt1:InstlPlanTypeLov::content")
    public static WebElement listaRozwijalnaSkladkaJednorazowa;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:ExPmtR2:0:pt1:PaymentAmountInput::content")
    public static WebElement poleTekstoweKwotawPLN;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:ExPmtR2:0:pt1:PaymentTransNumberInput::content")
    public static WebElement poleTekstoweNumerTransakcji;

    @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:2:pt:DynamicObjectCalculate")
    public static WebElement przyciskOblicz;

    @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:2:pt:ExtObjHouseHoldReg3:0:pt1:H2RtfB3:0:pt1:CottPrice::content")
    public static WebElement poleTekstoweRazemSkladka;

    @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:2:pt:DynamicObjectComplete")
    public static WebElement przyciskComplete;

    //Pop-up Wystaw polise


    @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:2:pt:DynamicObjectActionAllowedDropDown::listHolder")
    public static WebElement listaWystawPolise;

    @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:2:pt:onPolicyDialogOkBtn")
    public static WebElement przyciskWybierz;

    //Wystaw polise

    @FindBy(id = "pageTemplate1:sf_c:r2:2:pt:TIADynamicTaskFlowRg:4:pt:CompletePopup::ok")
    public static WebElement przyciskOk2;















































}
