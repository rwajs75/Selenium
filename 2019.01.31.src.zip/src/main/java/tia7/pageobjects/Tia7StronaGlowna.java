package tia7.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Tia7StronaGlowna {


    @FindBy(xpath="//*[@id='pageTemplate1:sf_t:pt_statInd'']/img[@title='Zajęte']")
    public static WebElement pasekPostepuLadowaniaDanych;

    @FindBy(id="pageTemplate1:sf_t:dynTabsPane:0:tabIndex::disclosureAnchor")
    public static WebElement przyciskHome;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomePartySearch")
    public static WebElement przyciskWyszukajDodajKlienta;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeConfiguration")
    public static WebElement przyciskKonfiguracja;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeManagement::icon")
    public static WebElement przyciskManagement;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeWorkplaceRgLc0:0:pt:sr1:0:ptext:qryId1::mode")
    public static WebElement przyciskZaawansowane;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeWorkplaceRgLc0:0:pt:sr1:0:ptext:qryId1::search")
    public static WebElement przyciskSzukaj;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeWorkplaceRgLc0:0:pt:sr1:0:ptext:qryId1::reset")
    public static WebElement przyciskResetuj;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeWorkplaceRgLc0:0:pt:sr1:0:ptext:pcext:outputText1")
    public static WebElement tekstListaZadań;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeWorkplaceRgLc0:0:pt:sr1:0:ptext:qryId1:value00::content")
    public static WebElement poleTekstowePolicyNo;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeWorkplaceRgLc0:0:pt:sr1:0:ptext:qryId1:value10::content")
    public static WebElement poleTekstoweNrSzkody;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeWorkplaceRgLc0:0:pt:sr1:0:ptext:qryId1:value20::content")
    public static WebElement listaRozwijanaFirma;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeWorkplaceRgLc0:0:pt:sr1:0:ptext:qryId1:value30::content")
    public static WebElement listaRozwijanaDepartament;

    @FindBy(id="pageTemplate1:sf_c:r0:0:pt:HomeWorkplaceRgLc0:0:pt:sr1:0:ptext:qryId1:value40::content")
    public static WebElement poleTekstoweUzytkownik;



}
