package tia7.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Tia7FormularzMoto {

    // Kliniecie w Pojazd
    @FindBy(xpath = "//table//a[contains(text(), 'Pojazd')]")
    public static WebElement przyciskPojazd;

    // Dane Motoru
    @FindBy(xpath = "//label[contains(text(), 'Rok produkcji')]//..//..//input")
    public static WebElement poleTekstoweRokProdukcji;

    @FindBy(xpath = "//label[contains(text(), 'Kod pocztowy')]//..//..//input")
    public static WebElement poleTekstoweKodPocztowy;

    @FindBy(xpath = "(//*[contains(@id, 'ExtObjMotorReg1:0:pt1:r1:0:pt1:pc1:t1:0:sbc1')])[1]")
    public static WebElement poleOpcjiWybierzWyposażenie;

    @FindBy(xpath = "//label[contains(text(), 'Numer rejestracyjny')]//..//..//..//input")
    public static WebElement poleTekstoweNumerRejestracyjny;

    @FindBy(xpath = "//label[contains(text(), 'Numer VIN')]//..//..//..//input")
    public static WebElement poleTekstoweNumerVIN;

    @FindBy(xpath = "//label[contains(text(), 'Data kolejnego badania technicznego')]//..//..//..//input")
    public static WebElement poleTekstoweDataKolBadTechnicznego;

    @FindBy(xpath = "//*[contains(text(), 'Składka łączna :')]")
    public static WebElement poleTekstoweSkladkaLaczna;

    // KOD PROMOCYJNY ! ! !
    @FindBy(xpath = "//input[contains(@id, 'promotionalCodeInputField')]")
    public static WebElement poleTekstoweKodPromocyjny;

    // Akceptacja polisy
    @FindBy(xpath = "//button[contains(text(), 'Wybierz')]")
    public static WebElement przyciskWybierz;

    public static By przyciskOK = By.xpath("//*[contains(@id,'CompletePopup')]//button[contains(text(), 'OK')]");
}
