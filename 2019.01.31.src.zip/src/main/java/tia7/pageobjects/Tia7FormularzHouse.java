package tia7.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Tia7FormularzHouse {

    // ZAKŁADKA MAPAR - DANE PRODUKCYJNE
    @FindBy(xpath = "//td[contains(@id, 'ssdObjHouseHold')]")
    public static WebElement listaDaneProduktowe;

    // SPOSÓB UŻYTKOWANIA
    public static final By listaPietroBy = By.xpath("//label[contains(text(), 'Piętro')]//..//..//select");

    // BLOK RYZYKA
    @FindBy(xpath = "//button[contains(@id, 'valuePropertyRencmb')]")
    public static WebElement przyciskObliczKlasyRyzykaH2;
    @FindBy(xpath = "//button[contains(@id, 'HEvaluatePropertyBtn')]")
    public static WebElement przyciskObliczKlasyRyzykaH3;
    @FindBy(xpath = "//input[contains(@id, 'FireHouseYn')]")
    public static WebElement poleOpcjiNieruchomośćMieszkalna;
    @FindBy(xpath = "//input[contains(@id, 'RenFireHouseSum')]")
    public static WebElement poleTekstoweSumaUbezpieczenia;

    // KOD PROMOCYJNY ! ! !
    @FindBy(xpath = "//input[contains(@id, 'H2PromoCodeInput')]")
    public static WebElement poleTekstoweKodPromocyjnyH2;
    @FindBy(xpath = "//input[contains(@id, 'H3PromoCodeInput')]")
    public static WebElement poleTekstoweKodPromocyjnyH3;
}
