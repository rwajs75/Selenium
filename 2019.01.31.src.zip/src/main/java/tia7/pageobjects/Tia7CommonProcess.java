package tia7.pageobjects;

import helpers.database.TestDataManager;
import helpers.generators.RandomIntGenerator;
import helpers.generators.RandomStringGenerator;
import helpers.restapi.Rest;
import helpers.throwables.GeneralStepException;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaStronaGlowna;
import myaviva.pageobjects.MyAvivaZmienHaslo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import static ecard.Platnosc.platnoscEcard;
import static helpers.common.Common.*;
import static helpers.common.Common.clickButton;
import static helpers.common.Common.waitTillSpinnerDisable1;
import static helpers.generators.PESELGenerator.generatePESELForDate;
import static helpers.login.Login.LoginWeb;
import static myaviva.pageobjects.MyAvivaCommonPageObjects.clickMenuMyAviva;
import static tia7.pageobjects.Tia7Common.*;

public class Tia7CommonProcess {

    /**
     * Funkcja rejestrująca nowego klienta w TIA7
     *
     * @param nrTel    - numer telefonu klienta
     * @param nowyMail - adres mailowy klienta
     */
    public static String[] TIA7registerNewClient(String nrTel, String nowyMail, String srodowisko, String aplikacja) {

        String nazwisko = "NAZWISKO" + RandomStringGenerator.generateCharsSequence().toUpperCase();
        String imie = "IMIE" + RandomStringGenerator.generateCharsSequence().toUpperCase();
        String rokString = LocalDate.now().minusYears(40).format(DateTimeFormatter.ofPattern("yyyy"));
        int rok = Integer.parseInt(rokString);
        int miesiac = RandomIntGenerator.liczbaLosowa(10, 2);
        int dzien = RandomIntGenerator.liczbaLosowa(10, 15);
        String dataUrodzenia = dzien + "-" + miesiac + "-" + rok;
        String pesel = generatePESELForDate(rok, miesiac, dzien, 'm');
        clickButton(Tia7WyszukajDodajKlienta.przyciskNowyKlient);
        enterIntoTextField(Tia7NowyKlient.poleTekstoweImie, imie);
        enterIntoTextField(Tia7NowyKlient.poleTekstoweNazwisko, nazwisko);
        enterIntoTextField(Tia7NowyKlient.poleTekstowePESEL, pesel);
        enterIntoTextField(Tia7NowyKlient.poleTekstoweDataUrodzenia, dataUrodzenia);
        waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
        selectDropdownListOption(Tia7NowyKlient.listaPlec, "Mężczyzna");
        selectDropdownListOption(Tia7NowyKlient.listaLiczbaDzieci, "0");
        selectDropdownListOption(Tia7NowyKlient.listaStanCywilny, "panna/kawaler");
        selectDropdownListOption(Tia7NowyKlient.listaRokUzyskaniaPrawaJazdyKatB, LocalDate.now().minusYears(15).format(DateTimeFormatter.ofPattern("yyyy")));
        selectRadioOption(Tia7NowyKlient.przyciskWyboruZgodaPrzetwarzanieWewnatrzAviva); //TODO: Funkcja wybierająca TAK / NIE ??? - Obecnie wszystko na NIE
        selectRadioOption(Tia7NowyKlient.przyciskWyboruZgodaPrzetwarzaniePozaAviva);
        selectRadioOption(Tia7NowyKlient.przyciskWyboruZgodaPrzetwarzanieEmailSms);
        waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
        clickElement(Tia7NowyKlient.przyciskLupka);
        waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
        enterIntoTextField(Tia7NowyKlient.poleTekstoweKodPocztowy, "01-022");
        clickButton(Tia7NowyKlient.przyciskSzukaj);
        clickButton(Tia7NowyKlient.przyciskWybierz);
        waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
        enterIntoTextField(Tia7NowyKlient.poleTekstoweNrBudynku, "3b");
        enterIntoTextField(Tia7NowyKlient.poleTekstoweNrMieszkania, "13");
        if (waitUntilElementPresent(Tia7NowyKlient.przyciskDodajBy, 2) == null) {
            clickElement(Tia7NowyKlient.listaKlientDaneKontaktowe);
        }
        clickElement(Tia7NowyKlient.przyciskDodaj);
        selectDropdownListOption(Tia7NowyKlient.listaDaneKontaktowe, "E-Mail");
        if (nowyMail.equals("")) {
            nowyMail = creationNewMailDBforImmediateUse(srodowisko, aplikacja);
        }
        enterIntoElement(Tia7NowyKlient.poleTekstoweSzczegoly, nowyMail);
        clickElement(Tia7NowyKlient.przyciskDodaj);
        selectDropdownListOption(Tia7NowyKlient.listaDaneKontaktowe2, "Tel komórkowy");
        enterIntoElement(Tia7NowyKlient.poleTekstoweSzczegoly2, nrTel);
        if (waitUntilElementPresent(Tia7NowyKlient.poleOpcjiPocztaBy, 2) == null) {
            clickElement(Tia7NowyKlient.listaSposobDostarczeniaDokumentow);
        }
        clickElement(Tia7NowyKlient.poleOpcjiPoczta);
        clickElement(Tia7NowyKlient.poleOpcjiEmail);
        clickButton(Tia7NowyKlient.przyciskZapisz);
        waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
        clickButton(Tia7NowyKlient.przyciskPodgladPodmiotu);
        waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
        String idPodmiotu = getElementText(Tia7NowyKlient.poleTekstoweIdPodmiotu);
        return new String[]{imie, nazwisko, pesel, dataUrodzenia, nowyMail, idPodmiotu};
    }

    public static Boolean activationMailsmsMyAviva(WebDriver driver, String email, String nrTelefon, String appEnv) {
        TestDataManager manager = new TestDataManager(appEnv);
        String activationUrl = Rest.getActivationLink(email, appEnv);
        Boolean uslugaNieodstepna = false;
        if (activationUrl == null) {
            reporter().logFail("Niepowodzenie aktywacji maila: nie udało się pobrać linku aktywacyjnego.");
        }
        driver.get(activationUrl);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, MyAvivaZmienHaslo.class);
        String pass = manager.getLoginCredentials("MyAviva", "", appEnv).get(2);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
        if (waitUntilElementPresent(MyAvivaZmienHaslo.poleTekstoweHasloRej, 30) != null) {
            enterIntoTextField(MyAvivaZmienHaslo.poleTekstoweHasloRej, pass);
            if (waitUntilElementPresent(MyAvivaZmienHaslo.poleTekstoweHasloRejPotworz, 5) != null) {
                reporter().logFail("Konto na podany adres mailowy zostało użyte w innym teście.");
            }
            clickElement(MyAvivaZmienHaslo.checkboxAkceptuje);
            clickButton(MyAvivaZmienHaslo.przyciskZalozKonto);
            waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
        } else {
            reporter().logFail("Problem z wyświetleniem strony z aktywacja maila");
        }
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
        if (waitUntilElementPresent(MyAvivaZmienHaslo.poleTekstoweKodSMS, 30) != null) {
            Map<String, String> map = manager.getUsersOanAndPartyId(email, appEnv);
            String pin = Rest.getTwoFAPin(map.get("partyId"), map.get("oan"), nrTelefon, appEnv);
            enterIntoTextField(MyAvivaZmienHaslo.poleTekstoweKodSMS, pin);
            clickButton(MyAvivaZmienHaslo.przyciskZapiszSMS);
            waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
            waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        } else {
            reporter().logFail("Problem z wyświetleniem strony z aktywacją kodu pin");
        }

        if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Witaj w MojejAvivie')]"), 30) != null &&
                (waitUntilElementPresent(By.xpath("//*[@aria-label='Ubezpieczenia']"), 30) != null)) {
            reporter().logPass("Poprawnie zalogowano na konto klienta: " + email);
            uslugaNieodstepna = false;
        } else {
            try {
                reporter().logPass("############################");
                if (driver.getTitle().contains("503")) {
                    //reporter().logError("Usługa niedostępna");
                    reporter().logWarn("Usluga niedostepna 503, próba przelogowania");
                    LoginWeb("MyAviva",appEnv, email, driver);
                    uslugaNieodstepna = false;
                }
            } catch (GeneralStepException e) {
                uslugaNieodstepna = true;
                reporter().logFail("Usluga niedostepna 503");
                reporter().logPass("############################");
            }
        }
        if (uslugaNieodstepna.equals(true)) {
            if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Twoje konto')]"), 5)!=null) {
                clickMenuMyAviva("Twoje konto", "Wyloguj", appEnv, driver);
            }else{
                reporter().logPass("Menu 'Twoje konto' nie jest widoczne, próba przelogowania");
                LoginWeb("MyAviva",appEnv, email, driver);
                uslugaNieodstepna = false;
            }

        }
        return uslugaNieodstepna;
    }

    public static void verifyPoliceMyAviva(String nazwaProcesu, String nrPolisy, String appEnv, WebDriver driver, boolean czyOplacone) {
        if (nazwaProcesu.equals("Kwotacja")) {
            clickMenuMyAviva("Twoje konto", "Moje Wnioski", appEnv, driver);
            waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
            waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
            if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Status wniosku')]/../*[contains(text(), 'Nieaktywny')]"), 10) != null &&
                    waitUntilElementPresent(By.xpath("//*[contains(text(), 'Przelicz ponownie')]"), 10) != null ||
                    (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Status wniosku')]/../*[contains(text(), 'Aktywny')]"), 10) != null) &&
                            waitUntilElementPresent(By.xpath("//*[contains(text(), 'Kontynuuj')]"), 10) != null) {
                reporter().logPass("Polisa/Kwotacja poprawnie podpięta do konta w MyAviva");
            } else {
                reporter().logFail("Polisa/Kwotacja nie została podpięta do konta w MyAviva");
            }
        } else if (nazwaProcesu.equals("Polisa")) {
            if (waitUntilElementPresent(MyAvivaStronaGlowna.przyciskZaplac, 30) != null) {
                clickElement(MyAvivaStronaGlowna.przyciskZaplac);
                platnoscEcard(true, driver);
                if (waitUntilElementPresent(MyAvivaStronaGlowna.poleTekstoweStatus, 30) != null) {
                    String oplata = getElementText(MyAvivaStronaGlowna.poleTekstoweStatus);
                    if (oplata.equals("Dziękujemy, Twoja polisa została opłacona prawidłowo.")) {
                        reporter().logPass("Dziękujemy, Twoja polisa została opłacona prawidłowo.");
                        if (waitUntilElementPresent(By.xpath("//*[contains(text(), '" + nrPolisy + "')]"), 30) != null) {
                            reporter().logPass("Polisa prawidłowo dołączona do konta");
                        } else {
                            reporter().logFail("Polisa nie jest widoczna na głównej stronie MyAviva");
                        }
                    } else {
                        reporter().logFail("Problem z oplaceniem polisy");
                    }
                } else {
                    reporter().logFail("Problem z pojawieniem się statusu realizacji platności");
                }
            } else if (czyOplacone) {
                clickElement(MyAvivaStronaGlowna.przyciskSzczegoly);
                clickElement(MyAvivaStronaGlowna.przyciskHarmonogram);
                if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Opłacona')]"), 20) != null) {
                    reporter().logPass("Polisa: " + nrPolisy + " została uprzednio opłacona w systemie TIA7");
                } else {
                    reporter().logFail("Polisa: " + nrPolisy + " nie została opłacona w systemie TIA7");
                }
            } else {
                reporter().logFail("Problem, nie znaleziono przycisku 'Zaplać'");
            }
        }
    }

    public static String savePolice(String nazwaProcesu, String nrPolisy) {
        clickElement(Tia7Common.przyciskZapisz);
        clickElement(Tia7Common.przyciskComplete);
        switchToNewPopUp();
        selectTIA7Process(nazwaProcesu);
        switchToNewPopUp();
        waitTillSpinnerDisable2(Tia7Common.ladowanieDanych, 90, true);
        if (waitUntilElementPresent(By.xpath("(//*[contains(@title, 'Błąd')])[1]"), 10) != null &&
                (waitUntilElementPresent(Tia7FormularzMoto.przyciskOK, 10) == null))
            reporter().logFail("Problem z zapisaniem polisy");
        clickElement(Tia7FormularzMoto.przyciskOK);
        if (waitUntilElementPresent(By.xpath("(//*[contains(text(),'" + nrPolisy + "')])[1]"), 10) != null) {
            String nr = getElementText(By.xpath("(//*[contains(text(),'"+nrPolisy+"')])[1]"));
            String nr1 [] = nr.split("-");
            if (nr1.length >= 2) { nrPolisy = nr1[1].trim();
            }else{ nrPolisy = nr1[0].trim(); }
            reporter().logPass("Zarejestrowano polise/kwotacje o numerze: " + nrPolisy);
        } else {
            reporter().logFail("Problem z zarejestrowaniem polisy/kwotacje");
        }
        return nrPolisy;
    }

    /**
     * Metoda wykonujaca:
     * 1. Zapisanie polisy w TIA
     * 2. Aktywowaniu nowego konta w MyAviva
     * 3. Oplacenie polisy w MyAviva
     * 4. Weryfikacja czy polisa/kwotacja jest widoczna na liście Wnioskow/Polis
     * @param nazwaProcesu
     * @param nrPolisy
     * @param eMail
     * @param nrTel
     * @param appEnv
     * @param driver
     * @param czyOplacone
     * @param czyAktywowacKonto
     */
    public static void verifyMyAviva(String nazwaProcesu, String nrPolisy, String eMail, String nrTel, String appEnv, WebDriver driver, boolean czyOplacone, boolean czyAktywowacKonto){
        if (czyAktywowacKonto) {
            Boolean uslugaNiedostepna = activationMailsmsMyAviva(driver, eMail,nrTel,appEnv);
            if (uslugaNiedostepna.equals(true))
                LoginWeb("MyAviva", appEnv, eMail, driver);
        } else {
            LoginWeb("MyAviva", appEnv, eMail, driver);
        }
        //Weryfikacja polisy/kwotacji
        verifyPoliceMyAviva(nazwaProcesu, nrPolisy, appEnv, driver, czyOplacone);
    }

    /**
     * Metoda wykonujaca:
     * 1. Logowanie do TIA
     * 2. Weryfikację czy polisa opłacana z poziomu MyAviva rzeczywiście została opłacona (Sprawdzenie salda w TIA7)
     * @param appEnv
     * @param nrPolisy
     * @param idKlienta
     *
     */
    public static void verifyTia7Balance(String aplikacja, String appEnv, String nrPolisy, String idKlienta){
        LoginWeb(aplikacja, appEnv, "AutoCZT3", driver);
        clickElement(Tia7StronaGlowna.przyciskWyszukajDodajKlienta);
        setSelectInputTia7("Numer polisy", nrPolisy, "input");
        clickElement(Tia7WyszukajDodajKlienta.przyciskSzukaj);
        clickElement(By.xpath("//*[contains(text(), '"+idKlienta+"')]"));
        clickElement(By.xpath("//a[contains(text(), '" +nrPolisy+ "')]"));
        if (waitUntilElementPresent(By.xpath("//*[@summary='BalancePolicyTable']"), 5) == null) {
            clickElement(By.xpath("//table//*[contains(text(), 'Uproszczony Widok Płatności')]"));
            String saldo = driver.findElement(By.xpath("//*[@summary='BalancePolicyTable']//td[6]")).getText();
            int saldoWartosc = Integer.parseInt(String.valueOf(saldo));
            if (saldoWartosc > 0) {
                reporter().logFail("Polisa o numerze: " + nrPolisy + " nie została opłacona");
            } else {
                reporter().logPass("Polisa o numerze: " + nrPolisy + " została opłacona", true);

            }
        }
    }

    /**
     * Metoda wykonujaca:
     * 1. Zapisanie polisy w TIA
     * 2. Aktywowaniu nowego konta w MyAviva
     * 3. Oplacenie polisy w MyAviva
     * 4. Weryfikacja czy polisa/kwotacja jest widoczna na liście Wnioskow/Polis
     * @param nazwaProcesu
     * @param nrPolisy
     * @param eMail
     * @param nrTel
     * @param appEnv
     * @param driver
     * @param czyOplacone
     */
    public static void savePoliceAndVerifyMyAviva(String nazwaProcesu, String nrPolisy, String eMail, String nrTel, String appEnv, WebDriver driver, boolean czyOplacone){
        clickElement(Tia7Common.przyciskZapisz);
        clickElement(Tia7Common.przyciskComplete);
        switchToNewPopUp();
        selectTIA7Process(nazwaProcesu);
        switchToNewPopUp();
        waitTillSpinnerDisable2(Tia7Common.ladowanieDanych, 90, true);
        if (waitUntilElementPresent(By.xpath("(//*[contains(@title, 'Błąd')])[1]"), 10)!=null &&
                (waitUntilElementPresent(Tia7FormularzMoto.przyciskOK, 10)==null))
            reporter().logFail("Problem z zapisaniem polisy");
        clickElement(Tia7FormularzMoto.przyciskOK);
        if (waitUntilElementPresent(By.xpath("(//*[contains(text(),'"+nrPolisy+"')])[1]"), 10)!=null) {
            reporter().logPass("Zarejestrowano polise/kwotacje o numerze: " + nrPolisy);
        }else {
            reporter().logFail("Problem z zarejestrowaniem polisy/kwotacje");
        }
        Boolean uslugaNiedostepna = activationMailsmsMyAviva(driver, eMail,nrTel,appEnv);
        if (uslugaNiedostepna.equals(true))
            LoginWeb("MyAviva", appEnv, eMail, driver);
        //Weryfikacja polisy/kwotacji
        verifyPoliceMyAviva(nazwaProcesu, nrPolisy, appEnv, driver, czyOplacone);
    }


    /**
     * Funkcja dodająca kody promocyjne dla konkretnego produktu uwzględniając ilość i wartość % zniżki
     * @param nazwaPromocji           - nazwa promocji która zostanie dodana do listy 'promocji'
     * @param produkt                 - wybor procuktu (np. C1 - Motor)
     * @param iloscKodow              - ilosc kodów do dodania
     * @param wartoscProcentowaZnizki - wartość % zniżki (wybrana jest procentowa)
     */
    public static String[] generatePromoCode (String nazwaPromocji, String produkt, int iloscKodow, int wartoscProcentowaZnizki) {

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /** DODAWANIE PROMOCJI - ROZPOCZECIE */
        clickElement(Tia7KodyPromocyjne.przyciskNowy);
        switchToNewPopUp();
        setSelectInputTia7("Nazwa promocji", nazwaPromocji, "input");
        setSelectInputTia7("Opis promocji", "Promocja_Testowa", "input");
        clickElement(Tia7KodyPromocyjne.przyciskDataStartu);
        switchToNewPopUp();
        clickElement(Tia7KodyPromocyjne.przyciskOKDataiGodzina);
        clickElement(Tia7KodyPromocyjne.poleTekstoweDataKonca);
        String newDate = LocalDateTime.now().plusDays(2).format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"));
        enterIntoElement(Tia7KodyPromocyjne.poleTekstoweDataKonca, newDate);
        selectTIA7Product(produkt, true);
        setSelectInputTia7("WebPortal", "", "input");
        setSelectInputTia7("CCenter", "", "input");
        setSelectInputTia7("ExternalCC", "", "input");
        setSelectInputTia7("PWeb", "", "input");
        setSelectInputTia7("Ilość kodów", String.valueOf(iloscKodow), "input");
        setSelectInputTia7("Typ zniżki", "P Procentowa", "select");   //TODO: Modyfikacja funkcji pod kątem zniżki procentowej / kwotowej ?
        clickElement(Tia7KodyPromocyjne.przyciskOK);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /** DODAWANIE ZNIZEK - ROZPOCZECIE */

        clickElement(By.xpath("(//table//*[contains(text(), '" + nazwaPromocji + "')])[1]"));
        // Moto
        if (waitUntilElementPresent(By.xpath("(//*[contains(text(), 'OC')]//..//..//input)[1]"), 5) != null) {
            pickRiskName("OC");
            pickRiskName("AutoCasco");
            pickRiskName("AC Kradzież");
            reporter().logPass("Zaznaczono ryzyka dla Kodu Promocyjnego produktu Moto");
        }
        // Travel
        if (waitUntilElementPresent(By.xpath("(//*[contains(text(), 'Koszty leczenia i assistance')]//..//..//input)[1]"), 5) != null) {
            pickRiskName("Koszty leczenia i assistance");
            reporter().logPass("Zaznaczono ryzyko dla Kodu Promocyjnego produktu Travel");
        }
        // H2
        if (waitUntilElementPresent(By.xpath("(//*[contains(text(), 'Cost of rent')]//..//..//input)[1]"), 5) != null) {
            pickRiskName("Fire & Other perils - Flat/house + basic elements");
            pickRiskName("Fire & Other perils - basic elements");
            pickRiskName("Fire & Other perils - movables");
            pickRiskName("Fire & Other perils - other buildings");
            pickRiskName("Fire & Other perils - special movables");
            pickRiskName("Theft with burglary - movables + basic elements");
            pickRiskName("Theft with burglary - special movables");
            pickRiskName("TPL");
            pickRiskName("Home Assistance");
            pickRiskName("Devastation");
            pickRiskName("Cost of rent");
            pickRiskName("PA - death by misadventure");
            pickRiskName("PA - death by accident");
            pickRiskName("PA - damage by misadventure");
            pickRiskName("PA - hospital stay by misadventure");
            pickRiskName("Travel - treatment + assistance");
            pickRiskName("Travel - luggage");
            pickRiskName("Travel - sport equiment");
            pickRiskName("Single-track vehicle - theft");
            pickRiskName("Single-track vehicle - assistance");
            pickRiskName("Glass");
            pickRiskName("Theft with burglary - everyday things");
            pickRiskName("Fire - Flat/house under construction + basic elements");
            pickRiskName("Fire - other buildings under construction");
            pickRiskName("Fire - Construction equipment");
            /** PONIŻSZYCH NIE WIDZI */
            //pickRiskName("Burglary - Basic elements under construction");
            reporter().logPass("Zaznaczono ryzyla dla Kodu Promocyjnego produktu H2/H3");
        }
        //H3
        if (waitUntilElementPresent(By.xpath("(//*[contains(text(), 'Theft without burglary')]//..//..//input)[1]"), 5) != null) {
            pickRiskName("Fire & Other perils - Flat/house + basic elements");
            pickRiskName("Fire & Other perils - basic elements");
            pickRiskName("Fire & Other perils - movables");
            pickRiskName("Fire & Other perils - other buildings");
            pickRiskName("Fire & Other perils - special movables");
            pickRiskName("Theft with burglary - movables + basic elements");
            pickRiskName("Theft with burglary - special movables");
            pickRiskName("TPL");
            pickRiskName("Home Assistance");
            pickRiskName("Devastation");
            pickRiskName("Theft without burglary");
            pickRiskName("PA - death by misadventure");
            pickRiskName("PA - death by accident");
            pickRiskName("PA - damage by misadventure");
            pickRiskName("PA - hospital stay by misadventure");
            pickRiskName("Travel - treatment + assistance");
            pickRiskName("Travel - luggage");
            pickRiskName("Travel - sport equiment");
            pickRiskName("Bike - casco");
            pickRiskName("Bike - assistance");
            pickRiskName("Glass");
            pickRiskName("Theft with burglary - Everyday things");
            pickRiskName("Fire - Cost of garden plants");
            pickRiskName("Fire - Cottage + basic elements");
            pickRiskName("Fire - Cottage movables + basic elements");
            /** PONIŻSZYCH NIE WIDZI */
            //pickRiskName("Fire - Cottage other buildings");
            //pickRiskName("Theft with burglary - Cottage basic elements + movables");*/

        }
        clickElement(Tia7KodyPromocyjne.przyciskEdytuj);
        switchToNewPopUp();
        setSelectInputTia7("Wartość", String.valueOf(wartoscProcentowaZnizki), "input");   //TODO: Modyfikacja funkcji pod kątem zniżki procentowej / kwotowej ?
        clickElement(Tia7KodyPromocyjne.przyciskZapiszEdycjaZnizek);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /** KODY PROMOCYJNE - ROZPOCZECIE */

        String promoKod = driver.findElement(By.xpath("(//*[contains(@id, 'TableCodes')]//span)[10]")).getText();
        clickElement(Tia7KodyPromocyjne.przyciskZamknij);
        return new String[]{nazwaPromocji, produkt, newDate, promoKod, String.valueOf(wartoscProcentowaZnizki)};
    }

    public static void pickRiskName(String ryzyko){
        clickElement(By.xpath("(//*[contains(text(), '"+ryzyko+"')]//..//..//input)[1]"));
        reporter().logPass("Zaznaczono ryzyko " + ryzyko);
    }


    /**
     * Funkcja weryfikująca wpisanie kodu promocyjnego na polisach Moto/H2/H3/Travel w TIA7
     * @param promoCode - Kod promocyjny użyty do testu
     */
    public static void promoCodeVerification(String promoCode) {
        clickElement(Tia7Common.przyciskZapisz);
        // MOTO
        if (waitUntilElementPresent(By.xpath("//input[contains(@id, 'promotionalCodeInputField')]"), 5) != null) {
            String amountBeforePromotion = driver.findElement(By.xpath("//*[contains(@id, 'TotalPremiumPfl')]//span")).getText();
            String [] aBP = amountBeforePromotion.split(":");
            int BeforePromotion = Integer.parseInt(String.valueOf(aBP[1].trim()));
            enterIntoElement(Tia7FormularzMoto.poleTekstoweKodPromocyjny, promoCode);
            clickElement(Tia7Common.przyciskZapisz);
            String amountAfterPromotion = driver.findElement(By.xpath("//*[contains(@id, 'TotalPremiumPfl')]//span")).getText();
            String [] aAP = amountAfterPromotion.split(":");
            int AfterPromotion = Integer.parseInt(String.valueOf(aAP[1].trim()));
            if (BeforePromotion > AfterPromotion) { //TODO: Dodać bardziej wiarygodną weryfikację :) Promocja to 5% mniej. . .
                reporter().logPass("Kwota: " + BeforePromotion + "została zmniejszona do wartości: " + AfterPromotion + "po użyciu 5% kodu promocyjnego");
            } else {
                reporter().logFail("Kwota nie została zmniejszona po użyciu kodu pormocyjnego");
            }
        }
        // H2
        else if (waitUntilElementPresent(By.xpath("//*[contains(@id, 'pt:ssdObjHouseHold')]//*[contains(text(), 'MAPAR')]"), 5) != null) {
            String amountBeforePromotion = driver.findElement(By.xpath("//*[contains(@id, 'CottPrice')]//input")).getAttribute("value");
            int BeforePromotion = Integer.parseInt(String.valueOf(amountBeforePromotion));
            if (waitUntilElementPresent(By.xpath("//input[contains(@id, 'H2PromoCodeInput')]"), 2) == null) {
                clickElement(By.xpath("//table//*[contains(text() , 'Zniżki + Franszyzy')]"));
            }
            enterIntoElement(Tia7FormularzHouse.poleTekstoweKodPromocyjnyH2, promoCode);
            clickElement(Tia7Common.przyciskZapisz);
            String amountAfterPromotion = driver.findElement(By.xpath("//*[contains(@id, 'CottPrice')]//input")).getAttribute("value");
            int AfterPromotion = Integer.parseInt(String.valueOf(amountAfterPromotion));
            if (BeforePromotion > AfterPromotion) { //TODO: Dodać bardziej wiarygodną weryfikację :) Promocja to 5% mniej. . .
                reporter().logPass("Kwota: " + BeforePromotion + "została zmniejszona do wartości: " + AfterPromotion + "po użyciu 5% kodu promocyjnego");
            } else {
                reporter().logFail("Kwota nie została zmniejszona po użyciu kodu pormocyjnego");
            }
        }
        // H3
        else if (waitUntilElementPresent(By.xpath("//*[contains(@id, 'pt:ssdObjHouseHold')]//*[contains(text(), 'MRESI')]"), 2) != null) {
            String amountBeforePromotion = driver.findElement(By.xpath("//*[contains(@id, 'TotalPriceALL')]//input")).getAttribute("value");
            int BeforePromotion = Integer.parseInt(String.valueOf(amountBeforePromotion));
            if (waitUntilElementPresent(By.xpath("//input[contains(@id, 'H3PromoCodeInput')]"), 2) == null) {
                clickElement(By.xpath("//table//*[contains(text() , 'Zniżki + Franszyzy')]"));
            }
            enterIntoElement(Tia7FormularzHouse.poleTekstoweKodPromocyjnyH3, promoCode);
            clickElement(Tia7Common.przyciskZapisz);
            String amountAfterPromotion = driver.findElement(By.xpath("//*[contains(@id, 'TotalPriceALL')]//input")).getAttribute("value");
            int AfterPromotion = Integer.parseInt(String.valueOf(amountAfterPromotion));
            if (BeforePromotion > AfterPromotion) { //TODO: Dodać bardziej wiarygodną weryfikację :) Promocja to 5% mniej. . .
                reporter().logPass("Kwota: " + BeforePromotion + "została zmniejszona do wartości: " + AfterPromotion + "po użyciu 5% kodu promocyjnego");
            } else {
                reporter().logFail("Kwota nie została zmniejszona po użyciu kodu pormocyjnego");
            }
        }
        // Travel
        else if (waitUntilElementPresent(By.xpath("//input[contains(@name, 'PriceArealTotalRiskPrice')]"), 2) != null) {
            String amountBeforePromotion = driver.findElement(By.xpath("//*[contains(@id, 'PriceArealTotalRiskPrice')]//input")).getAttribute("value");
            double BeforePromotion = Double.parseDouble(String.valueOf(amountBeforePromotion).replace(',', '.'));
            enterIntoElement(Tia7FormularzTravel.poleTekstoweKodPromocyjny, promoCode);
            clickElement(Tia7Common.przyciskZapisz);
            String amountAfterPromotion = driver.findElement(By.xpath("//*[contains(@id, 'PriceArealTotalRiskPrice')]//input")).getAttribute("value");
            double AfterPromotion = Double.parseDouble(String.valueOf(amountAfterPromotion).replace(',', '.'));
            if (BeforePromotion > AfterPromotion) { //TODO: Dodać bardziej wiarygodną weryfikację :) Promocja to 5% mniej. . .
                reporter().logPass("Kwota: " + BeforePromotion + "została zmniejszona do wartości: " + AfterPromotion + "po użyciu 5% kodu promocyjnego");
            } else {
                reporter().logFail("Kwota nie została zmniejszona po użyciu kodu pormocyjnego");
            }
        }
        else {
            reporter().logFail("Pole kod promocyjny nie istnieje");
        }
    }
}
