package tia7.pageobjects;

import helpers.generators.RandomIntGenerator;
import lombok.extern.log4j.Log4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import static helpers.common.Common.*;
import static helpers.common.Common.enterIntoTextField;

@Log4j
public class Tia7Common {

    private static WebDriver driver;

    public static void initElement(WebDriver driver) {
        reporter().logPass("# Inicjalizacja obiektów $");
        PageFactory.initElements(driver, Tia7NowyKlient.class);
        PageFactory.initElements(driver, Tia7StronaGlowna.class);
        PageFactory.initElements(driver, Tia7WyszukajDodajKlienta.class);
        PageFactory.initElements(driver, Tia7Common.class);
        PageFactory.initElements(driver, Tia7Polisa.class);
        PageFactory.initElements(driver, Tia7FormularzMoto.class);
        PageFactory.initElements(driver, Tia7FormularzHouse.class);
        PageFactory.initElements(driver, Tia7FormularzTravel.class);
        PageFactory.initElements(driver, Tia7KodyPromocyjne.class);
    }

    //Krecioly
    public static final By ladowanieDanych = By.xpath("//*[@id='pageTemplate1:sf_t:pt_statInd']/img[@title='Zajęte']");
    // Pozostałe
    @FindBy(xpath = "//button[contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapisz;

    @FindBy(xpath = "//button[contains(text(), 'omplete')]")
    public static WebElement przyciskComplete;

    @FindBy(xpath = "//input[contains(@name, 'RiskAmountPlnInput')]")
    public static WebElement kwotaPLNMoto;

    @FindBy(xpath = "//input[contains(@name, 'PaymentAmountInput')]")
    public static WebElement kwotaPLNH2H3Travel;

    @FindBy(xpath = "//input[contains(@name, 'RiskTransNumberInput')]")
    public static WebElement numerTransakcji;

    @FindBy(xpath = "//input[contains(@name, 'PaymentTransNumberInput')]")
    public static WebElement numerTransakcjiH2H3Travel;

    public static final By tabelaUproszczonyWidokPlatnosci = By.xpath("//*[@summary='BalancePolicyTable']");
    public static final By uproszczonyWidokPlatnosci = By.xpath("//table//*[contains(text(), 'Uproszczony Widok Płatności')]");
    public static final By saldoWartosc = By.xpath("//*[@summary='BalancePolicyTable']//td[6]");

    /**
     * Funkcja wybierająca typ polisy w TIA7
     * 1) Podczas dodawania nowej plisy
     * 2) Podczas dodawania nowego kodu promocji
     *
     * @param nazwaPolisy - Moto / House / Trawel
     * @param czyPromocja - true / false - jeśli true wybiera produkt przy dodaniu nowego kodu promocji
     */
    public static void selectTIA7Product(String nazwaPolisy, boolean czyPromocja) {
        if (czyPromocja) {
            selectDropdownListOption(By.xpath("//*[contains(@id, 'DialogPromotionEdit')]//*[contains(text(), 'Produkt')]//..//..//select"), nazwaPolisy);
        } else {
            clickElement(By.xpath("//table//ul/li[contains(text(), '" + nazwaPolisy + "')]"));
            waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
            clickElement(Tia7Polisa.przyciskTak);
            waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
        }
    }

    /**
     * Funkcja wybierająca typ procesu w TIA7
     *
     * @param nazwaProcesu - Polisa / Kwotacja / itd
     */
    public static void selectTIA7Process(String nazwaProcesu) {
        clickElement(By.xpath("//table//ul/li[contains(text(), '" + nazwaProcesu + "')]"));
        waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
        clickElement(Tia7FormularzMoto.przyciskWybierz);
        waitTillSpinnerDisable2(Tia7Common.ladowanieDanych, 90, true);
    }

    /**
     * Funkcja wpisująca text w pole tekstowe
     * Funkcja wybierająca wartość z listy wyboru
     * Funkcja wybierajaca checbox poprzez klikniecie w text
     *
     * @param nazwaPola  - text , nazwa nad polem
     * @param wartosc    - wartość teksowa  lub z listy wyboru
     * @param wlasciwosc input - pole tekstowe
     *                   select - pole wyboru
     *                   label - klikniecie w text
     */
    public static void setSelectInputTia7(String nazwaPola, String wartosc, String wlasciwosc) {
        int ilosc;
        String xpath = "//*[contains(text(), '" + nazwaPola + "')]";
        By xpath1 = By.xpath(xpath + "//..//..//..//" + wlasciwosc);
        By xpath2 = By.xpath(xpath + "//..//..//" + wlasciwosc);

        Boolean wykonane = false;
        if (waitUntilElementPresent(xpath1, 30) != null || (waitUntilElementPresent(xpath2, 30) != null)) {
            if (waitUntilElementPresent(xpath1, 0) != null &&
                    wlasciwosc.equals("input") &&
                    wartosc.equals("")) {
                ilosc = getCountObjects(xpath1);
                if (ilosc == 1) {
                    clickElement(xpath1);
                    wykonane = true;
                }
            }
            if (waitUntilElementPresent(xpath2, 0) != null &&
                    wlasciwosc.equals("input") &&
                    wartosc.equals("") &&
                    wykonane.equals(false)) {
                ilosc = getCountObjects(xpath2);
                if (ilosc == 1) {
                    clickElement(xpath2);
                    wykonane = true;
                }
            }
            if (waitUntilElementPresent(xpath1, 0) != null &&
                    wlasciwosc.equals("input") &&
                    !wartosc.equals("") &&
                    wykonane.equals(false)) {
                ilosc = getCountObjects(xpath1);
                if (ilosc == 1) {
                    enterIntoTextField(xpath1, wartosc);
                    wykonane = true;
                }
            }
            if (waitUntilElementPresent(xpath2, 0) != null &&
                    wlasciwosc.equals("input") &&
                    !wartosc.equals("") &&
                    wykonane.equals(false)) {
                ilosc = getCountObjects(xpath2);
                if (ilosc == 1) {
                    enterIntoTextField(xpath2, wartosc);
                    wykonane = true;
                }
            }
            if (waitUntilElementPresent(xpath1, 0) != null &&
                    wlasciwosc.equals("select") &&
                    !wartosc.equals("") &&
                    wykonane.equals(false)) {
                ilosc = getCountObjects(xpath1);
                if (ilosc == 1) {
                    selectDropdownListOption(xpath1, wartosc);
                    wykonane = true;
                }
            }
            if (waitUntilElementPresent(xpath2, 0) != null &&
                    wlasciwosc.equals("select") &&
                    !wartosc.equals("") &&
                    wykonane.equals(false)) {
                ilosc = getCountObjects(xpath2);
                if (ilosc == 1) {
                    selectDropdownListOption(xpath2, wartosc);
                    wykonane = true;
                }
            }

            if (wykonane.equals(false)) {
                reporter().logFail("Zweryfikuj poprawność wyszukiwania objektow. Znaleziono więcej niż jeden obiekt pasujący do podanych właściwości");
            }
        } else {
            reporter().logFail("Nie znaleziona pola: " + wlasciwosc + " : " + xpath1 + " lub " + xpath2);
        }
    }

    /**
     * Funkcja pobierająca i wpisująca kwotę przy płatności 'Przelew' w TIA7
     */
    public static void getPaymentAmount(WebDriver driver) {
        if (waitUntilElementPresent(By.xpath("//input[contains(@name, 'RiskAmountPlnInput')]"), 2) != null) {
            String kwotaMoto = driver.findElement(By.xpath("//*[contains(@id, 'TotalPremiumPfl')]//span")).getText();
            String[] enterAmmonut = kwotaMoto.split(":");
            scrollToElement(kwotaPLNMoto);
            enterIntoElement(kwotaPLNMoto, enterAmmonut[1].trim());
            reporter().logPass("W Pole 'Kwota w PLN' została wprowadzona kwota: " + enterAmmonut);
        }
        if (waitUntilElementPresent(By.xpath("//*[contains(@id, 'pt:ssdObjHouseHold')]//*[contains(text(), 'MAPAR')]"), 2) != null) {
            String kwotaH2 = driver.findElement(By.xpath("//*[contains(@id, 'CottPrice')]//input")).getAttribute("value");
            scrollToElement(kwotaPLNH2H3Travel);
            enterIntoElement(kwotaPLNH2H3Travel, kwotaH2);
            reporter().logPass("W Pole 'Kwota w PLN' została wprowadzona kwota: " + kwotaH2);
        }
        if (waitUntilElementPresent(By.xpath("//*[contains(@id, 'pt:ssdObjHouseHold')]//*[contains(text(), 'MRESI')]"), 2) != null) {
            String kwotaH3 = driver.findElement(By.xpath("//*[contains(@id, 'TotalPriceALL')]//input")).getAttribute("value");
            scrollToElement(kwotaPLNH2H3Travel);
            enterIntoElement(kwotaPLNH2H3Travel, kwotaH3);
            reporter().logPass("W Pole 'Kwota w PLN' została wprowadzona kwota: " + kwotaH3);
        }
        if (waitUntilElementPresent(By.xpath("//input[contains(@name, 'PriceArealTotalRiskPrice')]"), 2) != null) {
            String kwotaTravel = driver.findElement(By.xpath("//*[contains(@id, 'PriceArealTotalRiskPrice')]//input")).getAttribute("value");
            scrollToElement(kwotaPLNH2H3Travel);
            enterIntoElement(kwotaPLNH2H3Travel, kwotaTravel);
            reporter().logPass("W Pole 'Kwota w PLN' została wprowadzona kwota: " + kwotaTravel);
        }
        // Transakcja
        int nrTransakcji = RandomIntGenerator.liczbaLosowa(1111111111, 999999999);
        if (waitUntilElementPresent(By.xpath("//input[contains(@name, 'RiskTransNumberInput')]"), 1) != null) {
            enterIntoElement(numerTransakcji, String.valueOf(nrTransakcji));
            reporter().logPass("W Pole 'Numer Transakcji' została wprowadzona liczba: " + nrTransakcji);
        } else {
            enterIntoElement(numerTransakcjiH2H3Travel, String.valueOf(nrTransakcji));
            reporter().logPass("W Pole 'Numer Transakcji' została wprowadzona liczba: " + nrTransakcji);
        }
        reporter().logPass("Funkcja płatności kartą zakończona");
    }

    /** //TODO: POPRAWIC - OBECNIE NIE DZIAŁA ! ! ! :)
     * Funkcja dodająca określoną liczbę dni do daty systemowej
     * Funkcja wpisująca zmodyfikowaną date do pola tekstowego
     * @param liczbaDni - ile dni dodać do daty systemowej
     * @param format    - interesujący nas format daty np. 'dd-MM-yyyy HH:mm'
     * @param by        - obiekt do którego wisujemy datę
     * @throws ParseException
     */
    public static void setNewDate(int liczbaDni, String format, By by) throws ParseException {

        try {
            Date currentDate = new Date();
            String setCurrentDate = String.valueOf(currentDate);

            SimpleDateFormat dateFormat = new SimpleDateFormat(format);
            Calendar c = Calendar.getInstance();
            c.setTime(dateFormat.parse(setCurrentDate));
            c.add(Calendar.DATE, liczbaDni);
            setCurrentDate = dateFormat.format(c.getTime());

            WebElement element = driver.findElement(by);
            if (!element.isEnabled()) {
                reporter().logFail("Pole tekstowe o lokatorze " + by + " jest wyłączone");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                element.click();
                element.clear();
                pauseFor(1);
                enterIntoTextField(element, setCurrentDate);
                reporter().logFail("W pole tekstowe o lokatorze " + by + " wpisano wartość " + setCurrentDate);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }
}