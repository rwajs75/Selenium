package tia7.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Tia7StronaLogowania {

    public static By poleTekstoweLogin = By.id("pt:r1:0:pt:s1:username::content");

    @FindBy(id="pt:r1:0:pt:s1:password::content")
    public static WebElement poleTekstoweHaslo;

    @FindBy(id="pt:r1:0:pt:s1:login")
    public static WebElement przyciskLogin;

}
