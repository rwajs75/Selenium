package tia7.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static helpers.common.Common.clickElement;

public class Tia7Polisa {

    @FindBy(xpath = "//*[contains(@id,'CoverTreeNewQuoteTtb')]")
    public static WebElement przyciskNowy;

    @FindBy(xpath = "//*[contains(@id, 'NewQuotePopup::yes')]")
    public static WebElement przyciskTak;

    @FindBy(id = "pageTemplate1:sf_c:r1:1:pt:TIADynamicTaskFlowRg:0:pt:CoverRgLc0:0:pt:NewQuotePopup::no")
    public static WebElement przyciskNie;

    @FindBy(xpath = "//input[contains(@id, 'PolicyPolicyNoAlt')]")
    public static WebElement poleTekstoweNrPolisy;

    @FindBy(xpath = "//select[contains(@id, 'SourceCodeInput')]")
    public static WebElement listaKodZrodlowy;

    //Nowa linia polisowa
    @FindBy(xpath = "//button[contains(@id, 'PolicyNewPolicyLine')]")
    public static WebElement przyciskNowaLiniaPolisowa;

    @FindBy(xpath = "//input[contains(@id, 'PolicyNewPolicyLineStartDate')]")
    public static WebElement dataPoczątkuOchrony;

    @FindBy(xpath = "//button[contains(@id, 'NewPolicyLinePopup::yes')]")
    public static WebElement przyciskTakNLP;

	@FindBy(xpath = "//button[contains(@id, 'NewPolicyLinePopup::no')]")
	public static WebElement przyciskNieNLP;

    //Dostosuj linię polisową
    @FindBy(xpath = "//button[contains(@id, 'PolicyLineAdjustPolicyLine')]")
    public static WebElement przyciskDostosujLiniePolisowa;

	@FindBy(xpath = "//select[contains(@id, 'PolicyLineAdjustTransactionCause')]")
	public static WebElement listaPowodTransakcji;

	@FindBy(xpath = "//button[contains(@id, 'AdjustPolicyLinePopup::ok')]")
	public static WebElement przyciskOkDLP;

	@FindBy(xpath = "//button[contains(@id, 'AdjustPolicyLinePopup::cancel')]")
	public static WebElement przyciskAnulujDLP;

	//Odnowienie
	@FindBy(xpath = "//a[contains(@id, '0:ViewPolicyLinesAgrLineNo')]")
	public static WebElement podgladLiniiPolisowej;

	@FindBy(xpath = "//button[contains(@id, 'PolicyLineCustomSaveButton')]")
	public static WebElement przyciskZapiszPoOdnowieniu;

	@FindBy(xpath = "//button[contains(@id, 'PolicyLineSaveAs')]")
	public static WebElement przyciskZatwierdzPoOdnowieniu;

	@FindBy(xpath = "//button[contains(@id, 'ActionsAllowedRegionContainer::yes')]")
	public static WebElement przyciskWystawPoliseTAK;

	@FindBy(xpath = "//button[contains(@id, 'ActionsAllowedRegionContainer::no')]")
	public static WebElement przyciskWystawPoliseNIE;

    @FindBy(xpath = "//button[contains(@id, 'CompletePopup::ok')]")
    public static WebElement przyciskWystawPoliseDokumentyOK;


	//-------------------
    @FindBy(xpath = "//button[contains(text(), 'Tak')]")
    public static WebElement przyciskTakZapisaneZmiany;

    @FindBy(xpath = "//button[contains(text(), 'Nie')]")
    public static WebElement przyciskNieZapisaneZmiany;

    @FindBy(id = "//select[contains(@id, 'PartyInfoDocumentDeliveryMethodRegionTab')]")
    public static WebElement listaSposobDostarczeniaDokumentow;
}
