package tia7.pageobjects;

import com.gargoylesoftware.htmlunit.javascript.host.canvas.ext.WEBGL_compressed_texture_s3tc;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Tia7NowyKlient {

    // Szczegóły podmiotów
    @FindBy(xpath = "//input[contains(@id, 'PartyInfoForenameP')]")
    public static WebElement poleTekstoweImie;

    @FindBy(xpath = "//input[contains(@id, 'PartyInfoNameP')]")
    public static WebElement poleTekstoweNazwisko;

    @FindBy(xpath = "//input[contains(@id, 'PartyInfoCivilRegCodeP')]")
    public static WebElement poleTekstowePESEL;

    @FindBy(xpath = "//input[contains(@id, 'PartyInfoBirthDateP')]")
    public static WebElement poleTekstoweDataUrodzenia;

    // Personal Information
    @FindBy(xpath = "//select[contains(@id, 'socCustomerPerPartySex')]")
    public static WebElement listaPlec;

    // Ubezpieczenie komunikacyjne
    @FindBy(xpath = "//select[contains(@id, 'CustomerPerPartyChildrenLOV')]")
    public static WebElement listaLiczbaDzieci;

    @FindBy(xpath = "//select[contains(@id, 'socCustomerPerPartyMaritalState')]")
    public static WebElement listaStanCywilny;

    @FindBy(xpath = "//select[contains(@id, 'CustomerPerPartyDriversLicenseLOV')]")
    public static WebElement listaRokUzyskaniaPrawaJazdyKatB;

    // Zgody marketingowe
    //TODO: DODAC OBSLUGE TAK / NIE ! ! !

    @FindBy(xpath = "//input[contains(@id, 'CustomerPerPartyMarketingApprovalRadio1:_1')]")
    public static WebElement przyciskWyboruZgodaPrzetwarzanieWewnatrzAviva;

    @FindBy(xpath = "//input[contains(@id, 'CustomerPerPartyMarketingApprovalRadio2:_1')]")
    public static WebElement przyciskWyboruZgodaPrzetwarzaniePozaAviva;

    @FindBy(xpath = "//input[contains(@id, 'CustomerPerPartyMarketingApprovalRadio3:_1')]")
    public static WebElement przyciskWyboruZgodaPrzetwarzanieEmailSms;

    // Adres
    @FindBy(xpath = "//a[contains(@id, 'RunSearchPostCodePopup')]")
    public static WebElement przyciskLupka;

    @FindBy(xpath = "//input[contains(@id, 'value00')]")
    public static WebElement poleTekstoweKodPocztowy;

    @FindBy(xpath = "//div[contains(@id, 'pt:SearchPostAreaDialog')]//button[contains(@id, 'search')]")
    public static WebElement przyciskSzukaj;

    @FindBy(xpath = "//button[contains(@id, 'SearchPostAreaDialog::ok')]")
    public static WebElement przyciskWybierz;

    @FindBy(xpath = "//input[contains(@id, 'PartyInfoStreetNo')]")
    public static WebElement poleTekstoweNrBudynku;

    @FindBy(xpath = "//input[contains(@id, 'PartyInfoFloorExt')]")
    public static WebElement poleTekstoweNrMieszkania;

    // Dane kontaktowe
    @FindBy(xpath = "//td[contains(@id, 'PartyInfoPartyInformationRegionContainerContactInformationGroupRegionTab')]")
    public static WebElement listaKlientDaneKontaktowe;

    @FindBy(xpath = "//a[contains(@id, 'ContactsPerPartyPC:ContactsPerPartyArl')]")
    public static WebElement przyciskDodaj;

    public static final By przyciskDodajBy = By.xpath("//a[contains(@id, 'ContactsPerPartyPC:ContactsPerPartyArl')]");

    @FindBy(id = "pageTemplate1:sf_c:r2:1:pt:ContactsPerPartyPC:ContactsPerPartyTab:0:ContactsPerPartyTelephoneType::content")
    public static WebElement listaDaneKontaktowe;

    @FindBy(id = "pageTemplate1:sf_c:r2:1:pt:ContactsPerPartyPC:ContactsPerPartyTab:1:ContactsPerPartyTelephoneType::content")
    public static WebElement listaDaneKontaktowe2;

    @FindBy(id = "pageTemplate1:sf_c:r2:1:pt:ContactsPerPartyPC:ContactsPerPartyTab:0:ContactsPerPartyDetails::content")
    public static WebElement poleTekstoweSzczegoly;

    @FindBy(id = "pageTemplate1:sf_c:r2:1:pt:ContactsPerPartyPC:ContactsPerPartyTab:1:ContactsPerPartyDetails::content")
    public static WebElement poleTekstoweSzczegoly2;

    @FindBy(xpath = "//td[contains(@id, 'PartyInfoDocumentDeliveryMethodRegionTab')]")
    public static WebElement listaSposobDostarczeniaDokumentow;

    @FindBy(id = "pageTemplate1:sf_c:r2:1:pt:ssbc6::content")
    public static WebElement poleOpcjiPoczta;

    public static final By poleOpcjiPocztaBy = By.id("pageTemplate1:sf_c:r2:1:pt:ssbc6::content");

    @FindBy(id = "pageTemplate1:sf_c:r2:1:pt:ssbc7::content")
    public static WebElement poleOpcjiEmail;

    // Zapis
    @FindBy(id = "pageTemplate1:sf_c:r2:1:pt:PartyInfoSaveButton2")
    public static WebElement przyciskZapisz;

    // Podgląd podmiotu
    @FindBy(id = "pageTemplate1:sf_c:r2:1:pt:PartyInfoGotoPartyOverviewGL")
    public static WebElement przyciskPodgladPodmiotu;

    @FindBy(xpath = "//*[contains(@id, 'CustomerWorkplaceIdNoAlt2')]")
    public static WebElement poleTekstoweIdPodmiotu;
}
