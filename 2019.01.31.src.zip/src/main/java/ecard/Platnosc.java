package ecard;

import myaviva.pageobjects.MyAvivaCommonPageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ecard.Ecard.przyciskDalej;
import static ecard.Ecard.przyciskWyboruKartaVisa;
import static helpers.common.Common.*;
import static myaviva.MyAvivaHelpers.obslugaBleduSprawdzeniaElementu;

public class Platnosc {
    /**
     * Funkcja do płatności eCard mBank
     * @param czyPowodzenie - czy płatność ma się powieść
     */
    public static String platnoscEcard(boolean czyPowodzenie, WebDriver driver) {
        String urlEcard = "";
        String numerPolisy = null;
        reporter().logPass("########### PLATNOSC ###########");
        PageFactory.initElements(driver, Ecard.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        obslugaBleduSprawdzeniaElementu(Ecard.tekstTytulPlatnosci,
                "Pomyślnie otworzono stronę płatności eCard.",
                "Nie otworzyła się strona płatności eCard.");
        if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Trwa przekierowanie do bramki płatniczej...')]"), 10) != null)
            urlEcard = driver.getCurrentUrl();
        for (int i = 1; i < 5; i++) {
            if (waitUntilElementPresent(Ecard.przyciskWyboruMBank, 60) != null) {
                break;
            } else {
                if (i == 4)
                    reporter().logFail("Problem z wyswietleniem strony platnosci. Ilosc prób: " + i);
                reporter().logPass("Problem z wyswietleniem strony platnosci. Próba: " + i);
                if (urlEcard.equals("")) {
                    driver.navigate().refresh();
                } else {
                    driver.get(urlEcard);
                }
            }
        }
        String tytulPlatnosci = getElementProperty(Ecard.tekstTytulPlatnosci, "textContent");
        Pattern pattern = Pattern.compile("[0-9]+$");
        Matcher m = pattern.matcher(tytulPlatnosci);
        if (m.find()) {
            numerPolisy = m.group();
        }
        clickElement(Ecard.przyciskWyboruMBank);
        clickButton(Ecard.przyciskDalej);
        if (czyPowodzenie) {
            clickElement(Ecard.przyciskPotwierdzeniaPlatnosci);
        } else {
            clickElement(Ecard.przyciskOdrzuceniaPlatnosci);
        }
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        reporter().logPass("###############################");
        return numerPolisy;
    }

    /**
     * Funkcja do płatności eCard Visa
     * @param czyPowodzenie - czy płatność ma się powieść
     */
    private void platnoscEcardVisa(boolean czyPowodzenie, WebDriver driver) {
        String urlEcard = "";
        reporter().logPass("########### PLATNOSC ###########");
        PageFactory.initElements(driver, Ecard.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Trwa przekierowanie do bramki płatniczej...')]"), 10) != null)
            urlEcard = driver.getCurrentUrl();

        for (int i = 1; i < 5; i++) {
            if (waitUntilElementPresent(Ecard.przyciskWyboruKartaVisa, 60) != null) {
                clickElement(przyciskWyboruKartaVisa);
                waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
                waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
                break;
            } else {
                if (i == 4)
                    reporter().logFail("Problem z wyswietleniem strony platnosci. Ilosc prób: " + i);
                reporter().logPass("Problem z wyswietleniem strony platnosci. Próba: " + i);
                if (urlEcard.equals("")) {
                    driver.navigate().refresh();
                } else {
                    driver.get(urlEcard);
                }
            }
        }
        clickButton(Ecard.przyciskDalej);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        String nr;
        if (waitUntilElementPresent(By.name("card-number"), 30) != null) {
            Ecard.poleTekstoweNumerKartyPlatniczej.click();
            Ecard.poleTekstoweNumerKartyPlatniczej.clear();
            Ecard.poleTekstoweNumerKartyPlatniczej.click();
            if (czyPowodzenie) {
                nr = "4444 4444 4444 4000";
                Ecard.poleTekstoweNumerKartyPlatniczej.sendKeys(nr);
                reporter().logPass("Wpisano wartość " + nr);
            } else {
                nr = "4444 4444 4444 4117";
                Ecard.poleTekstoweNumerKartyPlatniczej.sendKeys(nr);
                reporter().logPass("Wpisano wartość " + nr);
            }
        } else {
            reporter().logFail("Problem z wyświetleniem platnosci VISA");
        }
        nr = "12";
        Ecard.poleTekstoweDataWaznosciMiesiac.sendKeys(nr);
        reporter().logPass("Wpisano wartość " + nr);
        nr = "2033";
        Ecard.poleTekstoweDataWaznosciRok.sendKeys(nr);
        reporter().logPass("Wpisano wartość " + nr);
        nr = "123";
        Ecard.poleTekstoweCvc2.sendKeys(nr);
        reporter().logPass("Wpisano wartość " + nr);
        clickButton(przyciskDalej);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        if (!czyPowodzenie) {
            clickElement(Ecard.linkPowrot);
        }
        reporter().logPass("###############################");
    }
}
