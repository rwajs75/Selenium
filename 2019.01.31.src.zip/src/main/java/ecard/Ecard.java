package ecard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Ecard {
    public static By przyciskWyboruKartaVisa = By.xpath("//*[@name='payment' and @value='VISA']/..");
    public static By przyciskWyboruMBank = By.xpath("//div[@title = 'mTransfer']");
    @FindBy(xpath = "//*[@class='title seller-orderdescription']")
    public static WebElement tekstTytulPlatnosci;
    @FindBy(xpath = "(//*[@class='active']/..)[1]")
    public static WebElement przyciskDalej;
    @FindBy(xpath = "//button[@value = '1']")
    public static WebElement przyciskPotwierdzeniaPlatnosci;
    @FindBy(xpath = "//button[@value = '2']")
    public static WebElement przyciskOdrzuceniaPlatnosci;
    @FindBy(name = "card-number")
    public static WebElement poleTekstoweNumerKartyPlatniczej;
    @FindBy(xpath = "//*[@name='card-expiration-month']")
    public static WebElement poleTekstoweDataWaznosciMiesiac;
    @FindBy(xpath = "//*[@name='card-expiration-year']")
    public static WebElement poleTekstoweDataWaznosciRok;
    @FindBy(xpath = "//*[@name='card-cvv2']")
    public static WebElement poleTekstoweCvc2;
    @FindBy(xpath = "//*[@href='?finished']")
    public static WebElement linkPowrot;
}
