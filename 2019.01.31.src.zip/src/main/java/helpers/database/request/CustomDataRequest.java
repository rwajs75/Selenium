package helpers.database.request;

import helpers.dictionary.testdata.DataRowStatus;
import lombok.*;

import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class CustomDataRequest {

    private final String testName;
    private final String appName;
    private final String env;
    private final DataRowStatus status;
    private final String stage;
    private String creationDate;

    @Singular("withParam")
    private Map<String, String> requiredParams;
}
