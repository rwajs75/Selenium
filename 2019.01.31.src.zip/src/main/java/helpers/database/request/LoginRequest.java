package helpers.database.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoginRequest {
    private String app;
    private String login;
    private String env;
}
