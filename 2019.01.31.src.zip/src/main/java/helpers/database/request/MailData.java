package helpers.database.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MailData {

    String mail;
    String app;
    String env;
    boolean used;
}
