package helpers.database.request;

import lombok.Data;

@Data
public class OANData {
    private String oan;
    private String partyId;
}
