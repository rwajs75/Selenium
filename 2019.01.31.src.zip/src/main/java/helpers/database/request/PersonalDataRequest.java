package helpers.database.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PersonalDataRequest {

    private int policeNumber;
    private String name;
    private String surname;
    private String pesel;
    private String telefon;
}
