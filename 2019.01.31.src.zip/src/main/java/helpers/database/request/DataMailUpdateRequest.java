package helpers.database.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DataMailUpdateRequest {

    private int id;
    private String mail;
}
