package helpers.database;

import lombok.Builder;
import lombok.Data;

/**
 * Klasa definiująca zapotrzebowanie na dane przez biznes.
 */
@Data
@Builder
public class TestDataRequest {

    private String typ_polisy;
    private String status_polisy;
    private String rola_wlasc;
    private String telefon;

    private int il_sztuk;
    private String env;

}
