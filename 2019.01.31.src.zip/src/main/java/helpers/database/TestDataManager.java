package helpers.database;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import helpers.database.dto.CustomTestDTO;
import helpers.database.dto.LoginCredentialsDTO;
import helpers.database.dto.TestDTO;
import helpers.database.request.*;
import helpers.dictionary.testdata.*;
import helpers.restapi.Rest;
import helpers.throwables.DataUpdateError;
import helpers.throwables.NoTestDataException;
import io.restassured.response.Response;
import lombok.Builder;
import lombok.Data;
import lombok.extern.log4j.Log4j;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.*;

import static helpers.common.Common.reporter;
import static helpers.dictionary.DBQueries.SELECT_COUNT_DATA;
import static helpers.dictionary.DBQueries.SELECT_MONITOR_DATA;
import static helpers.excel.ExcelManager.*;

/**
 * Klasa zarządzająca komunikacją z DH oraz bazą danych testowych.
 */
@Log4j
public class TestDataManager { //TODO: sprawdzić poprawność działania wszystkich dokończonych funkcji

    private static String TDBUrl;
    private static String TDBLogin;
    private static String TDBPassword;
    private static Connection TDBConn;

    private static ObjectMapper mapper;

    public TestDataManager(String env) {
        TDBConn = null;
        mapper = new ObjectMapper();
        Properties config;
        try {
            config = new Properties();
            config.load(new FileInputStream(new File(System.getProperty("user.dir") + "/src/main/resources/database.properties")));
        } catch (IOException e) {
            log.error("Failed to load .properties file: ", e);
            throw new RuntimeException(e);
        }

        readProperties(config);
    }

    private void readProperties(Properties config) {
        TDBUrl = config.getProperty("testdb.url");
        TDBLogin = config.getProperty("testdb.login");
        TDBPassword = config.getProperty("testdb.password");
    }

    private void connectToTDB() {
        try {
            Driver d = (Driver) Class.forName("org.postgresql.Driver").newInstance();
            DriverManager.registerDriver(d);
            TDBConn = DriverManager.getConnection(TDBUrl, TDBLogin, TDBPassword);
        } catch (SQLException e) {
            log.error("TDB connection error: ", e);
            throw new RuntimeException(e);
        } catch (ClassNotFoundException ex) {
            log.error("Failed to load class", ex);
            throw new RuntimeException("Failed to initialize PostgreSQL driver: ", ex);
        } catch (IllegalAccessException ex) {
            log.error(ex);
            throw new RuntimeException("Failed to initialize PostgreSQL driver: ", ex);
        } catch (InstantiationException ex) {
            log.error("Failed to instantiate driver", ex);
            throw new RuntimeException("Failed to initialize PostgreSQL driver: ", ex);
        }
    }

    private void closeConnection(Connection conn) {
        try {
            conn.close();
        } catch (SQLException e) {
            log.error("Could not close TDB connection: ", e);
        }
    }

    public String getDictValueOf(String dictType, int id) {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("field", dictType);
        queryParams.put("index", "" + id);
        return Rest.sendGetRequestToDBManager("/get/dictValueOf", queryParams)
                .body().asString();
    }

    /**
     * Pobiera pojedynczą daną testową z TDB po ID.
     *
     * @param id ID danej testowej (odpowiada kolumnie <strong>lp</strong>)
     * @return pojedynczy rekord z daną testową jako instancja {@link TestDTO}
     */
    public TestDTO getRowById(int id) {

        try {
            Map<String, String> queryParams = new HashMap<>();
            queryParams.put("id", "" + id);
            String resp = Rest.sendGetRequestToDBManager("/get/row", queryParams)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, TestDTO.class);
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    /**
     * Pobiera pierwszą dostępną daną testową z TDB.
     *
     * @return pojedynczy rekord z daną testową jako instancja {@link TestDTO}
     */
    public TestDTO getRow(String env) {
        try {
            Map<String, String> queryParams = new HashMap<>();
            queryParams.put("env", "" + env);
            String resp = Rest.sendGetRequestToDBManager("/get/rowForTesting", queryParams)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, TestDTO.class);
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    /**
     * Pobiera rekord z bazy na podstawie danch klienta. <strong>Ta metoda nie dezaktywuje rekordu</strong>
     * - należy pamiętać o ręcznej deaktywacji rekordu.
     * @param policeNumber numer polisy
     * @param name imię
     * @param surname nazwisko
     * @param pesel numer PESEL
     * @param telefon numer telefonu
     * @return pobrany rekord jako {@link TestDTO}
     */
    public TestDTO getRowByPersonalData(int policeNumber, String name, String surname, String pesel, String telefon) {
        PersonalDataRequest req = PersonalDataRequest.builder()
                .name(name)
                .surname(surname)
                .policeNumber(policeNumber)
                .pesel(pesel)
                .telefon(telefon)
                .build();

        try {
            String resp = Rest.sendPostRequestToDBManager("/get/rowByPersonalData", new HashMap<>(), req)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, TestDTO.class);
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    /**
     * Pobiera jeden rekord do przeprocesowania.
     * @return pojedynczy rekord z daną testową jako instancja {@link TestDTO}
     */
    public TestDTO getRowForProcessing(String env) {
        try {
            Map<String, String> queryParams = new HashMap<>();
            queryParams.put("env", "" + env);
            String resp = Rest.sendGetRequestToDBManager("/get/rowForProcessing", queryParams)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, TestDTO.class);
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    public TestDTO getRowByIdForProcessing(int id) {
        try {
            Map<String, String> queryParams = new HashMap<>();
            queryParams.put("id", "" + id);
            String resp = Rest.sendGetRequestToDBManager("/get/rowForProcessingById", queryParams)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, TestDTO.class);
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    /**
     * Aktualizuje mail danej o podanym id.
     * @param mail Mail do przypisania danej testowej.
     * @param id ID danej testowej (odpowiada kolumnie <strong>lp</strong>)
     */
    public void updateMailForData(String mail, int id) {

        DataMailUpdateRequest req = DataMailUpdateRequest.builder()
                .id(id)
                .mail(mail)
                .build();

        Rest.sendPostRequestToDBManager("/update/dataMail", new HashMap<>(), req).then().statusCode(200);
    }

    /**
     * Aktualizuje status danej o podanym id.
     * @param status Status zdefiniowany w klasie {@link DataRowStatus}.
     * @param id ID danej testowej (odpowiada kolumnie <strong>lp</strong>)
     * @throws DataUpdateError jeżeli zmiana statusu się nie powiodła
     */
    public void updateDataStatus(DataRowStatus status, int id) { //założenie: połączenie jest aktywne
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("id", "" + id);
        queryParams.put("status", ""  + status.getStatusId());


        Rest.sendPutRequestToDBManager("/update/dataMail", queryParams).then().statusCode(200);
    }

    /**
     * Ustawia status maila jako 'wykorzystany' na TRUE.
     * @param mail Mail, którego status zmieniamy
     * @return 1 jeżeli status został zmieniony, 0 jeżeli nie
     * @throws DataUpdateError jeżeli zmiana statusu się nie powiodła
     */
    public int updateMailStatus(String mail) {
        return updateMailStatus(mail, true);
    }

    /**
     * Zmienia status wykorzystania podanego maila.
     * @param mail Mail, którego status zmieniamy
     * @return 1 jeżeli status został zmieniony, 0 jeżeli nie
     * @throws DataUpdateError jeżeli zmiana statusu się nie powiodła
     */
    public int updateMailStatus(String mail, boolean used) {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("mail", mail);
        queryParams.put("used", ""  + used);


        if (Rest.sendPutRequestToDBManager("/update/mailStatus", queryParams).statusCode() == 200)
            return 1;
        else return 0;
    }

    /**
     * Pobiera dostępny mail (jeżeli istnieje) i ustawia jego status na 'wykorzystany'.
     * @return ostatni mail z bazy maili testowych
     */
    public String getAvailableMail(String app, String env) {
        Map<String, String> args = new HashMap<>();
        args.put("app", app);
        args.put("env", env);

        return Rest.sendGetRequestToDBManager("/get/availableMail", args).body().asString();
    }

    /**
     * @deprecated Zamiast tej funkcji należy używać {@link TestDataManager#registerNewMailForApp(String, String)}.
     *
     * Pobiera ostatniego maila <strong>bez zmiany statusu</strong>.
     * @return ostatni mail z bazy maili testowych
     */
    @Deprecated
    public String checkLastMail() {
        return Rest.sendGetRequestToDBManager("/get/lastMail", new HashMap<>()).body().asString();
    }

    public String registerNewMailForApp(String app, String env) {
        reporter().logPass("Rejestrowanie nowego maila w TDB...");
        MailData mailData = MailData.builder()
                .app(app)
                .env(env)
                .build();
        Response resp = Rest.sendPostRequestToDBManager("/add/newMail", new HashMap<>(), mailData);
        if (resp.statusCode() != 200)
            reporter().logFail("Niepowodzenie rejestracji maila\n" + resp.body().asString());
        reporter().logPass("Zarejestrowano maila: " + resp.body().asString());
        return resp.body().asString();
    }

    /**
     * Pobiera ostatniego niewykorzystanego maila
     * <strong>bez zmiany statusu</strong>.
     * @return ostatni mail z bazy maili testowych
     */
    public String checkLastUnusedMail() {
        return Rest.sendGetRequestToDBManager("/get/lastUnusedMail", new HashMap<>()).body().asString();
    }

    /**
     * Pobiera dane testowe <strong>bez maila</strong> z DH na podstawie
     * zapotrzebowania i wprowadza do TDB.
     *
     * @param dataRequest obiekt {@link TestDataRequest} definiujący zapotrzebowanie
     * @return identyfikatory wprowadzonych rekordów
     */
    public List<Integer> retrieveDataWithPoliceNumberFromDH(TestDataRequest dataRequest) {
        try {
            String resp = Rest.sendPostRequestToDBManager("/retrieve/byPolice", new HashMap<>(), dataRequest)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, new TypeReference<List<Integer>>(){});
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    /**
     * Pobiera dane testowe z numerem grupy oraz <strong>bez maila</strong> z DH na podstawie
     * zapotrzebowania i wprowadza do TDB.
     *
     * @param dataRequest obiekt {@link TestDataRequest} definiujący zapotrzebowanie
     * @return identyfikatory wprowadzonych rekordów
     */
    public List<Integer> retrieveDataWithGroupNumberFromDH(TestDataRequest dataRequest) {
        try {
            String resp = Rest.sendPostRequestToDBManager("/retrieve/byGroup", new HashMap<>(), dataRequest)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, new TypeReference<List<Integer>>(){});
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    /**
     * Pobiera dane testowe z numerem grupy oraz <strong>bez maila</strong> z DH na podstawie
     * zapotrzebowania i wprowadza do TDB.
     *
     * @param dataRequest obiekt {@link TestDataRequest} definiujący zapotrzebowanie
     * @return identyfikatory wprowadzonych rekordów
     */
    public List<Integer> retrieveDataWithGroupNumberForBusiness(TestDataRequest dataRequest) {
        try {
            String resp = Rest.sendPostRequestToDBManager("/retrieve/byGroupBizUnbound", new HashMap<>(), dataRequest)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych");
            return mapper.readValue(resp, new TypeReference<List<Integer>>(){});
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    /**
     * Rezerwuje dane z TDB dla biznesu i zwraca do excela.
     * @param dataRequestFile excel z zapotrzebowaniem
     * @return ścieżka do pliku z danymi dla biznesu
     */
    public String getDataForBusiness(String dataRequestFile, String env) {
        List<TestDataRequest> reqs = getDataRequests(dataRequestFile,env);

        int i = 0;
        String reportPath;
        Response resp;
        List<TestDTO> inserted;

        try {
            File reportSpreadsheet = new File(".\\target\\business\\dataRequestResponse.xlsx");
            if (!reportSpreadsheet.exists())
                if (!reportSpreadsheet.createNewFile())
                    throw new IOException("Failed to create report file");

            for (TestDataRequest req : reqs) {
                resp = Rest.sendPostRequestToDBManager("/get/forBusinessPartial", new HashMap<>(), req);
                if (resp.statusCode() != 200) {
                    reporter().logWarn("Niepowodzenie rezerwacji danych: " + req);
                    continue;
                }
                inserted = mapper.readValue(resp.body().asString(), new TypeReference<List<TestDTO>>(){});

                prepareReportFile(reportSpreadsheet, "Set" + i);
                for (TestDTO item: inserted) {
                    try {
                        updateDataStatus(DataRowStatus.BIZNES, item.getLp());
                        writeValuesToNewColumn(reportSpreadsheet, "Set" + i,
                                getDictValueOf("policeType", item.getTyp_polisy()), //typ
                                getDictValueOf("policeStatus", item.getStatus_polisy()), //status
                                getDictValueOf("role", item.getRola_wlasc()), //rola
                                item.getTelefon(), //telefon
                                item.getMail());//mail
                        i++;
                    } catch (DataUpdateError e) {
                        log.error("Nie udało się zablokować danych dla biznesu", e);
                        throw e;
                    }
                }
                i++;
            }
            reportPath = reportSpreadsheet.getAbsolutePath();
        } catch (IOException e) {
            log.error("Exception while building business data report");
            throw new RuntimeException(e);
        }

        log.info("Wyniki zapisano w pliku " + reportPath);
        return reportPath;
    }

    /**
     * Rezerwuje dane <strong>bez maili</strong> z TDB dla biznesu i zwraca do excela.
     * @param dataRequestFile excel z zapotrzebowaniem
     * @return ścieżka do pliku z danymi dla biznesu
     */
    public String getDataForBusinessWithoutBinding(String dataRequestFile, String env) {
        List<TestDataRequest> reqs = getDataRequests(dataRequestFile, env);

        Response resp;
        String reportPath;
        int i = 0;
        List<TestDTO> inserted;

        try {
            File reportSpreadsheet = new File(".\\target\\business\\dataRequestResponse.xlsx");
            if (!reportSpreadsheet.exists())
                if (!reportSpreadsheet.createNewFile())
                    throw new IOException("Failed to create report file");

            for (TestDataRequest req : reqs) {
                resp = Rest.sendPostRequestToDBManager("/get/forBusinessUnboundPartial", new HashMap<>(), req);
                if (resp.statusCode() != 200) {
                    reporter().logWarn("Niepowodzenie rezerwacji danych: " + req);
                    continue;
                }
                inserted = mapper.readValue(resp.body().asString(), new TypeReference<List<TestDTO>>(){});

                prepareReportFile(reportSpreadsheet, "Set" + i);
                for (TestDTO item: inserted) {
                    try {
                        updateDataStatus(DataRowStatus.BIZNES, item.getLp());
                        writeValuesToNewColumn(reportSpreadsheet, "Set" + i,
                                getDictValueOf("policeType", item.getTyp_polisy()), //typ
                                getDictValueOf("policeStatus", item.getStatus_polisy()), //status
                                getDictValueOf("role", item.getRola_wlasc()), //rola
                                item.getTelefon(), //telefon
                                item.getMail());//mail
                        i++;
                    } catch (DataUpdateError e) {
                        log.error("Failed to lock data for business", e);
                        throw e;
                    }
                }
                i++;
            }
            reportPath = reportSpreadsheet.getAbsolutePath();
        } catch (IOException e) {
            log.error("Exception while building business data report");
            return null;
        }
        log.info("Wyniki zapisano w pliku " + reportPath);
        return reportPath;
    }

    /**
     * Pobiera dane logowania do żądanej aplikacji z TDB.
     * @param appName nazwa aplikacji, do której chcemy się zalogować
     * @param login login do aplikacji
     * @param env środowisko aplikacji
     * @return dane logowania w formie {@link List<String>}: url, login, hasło
     */
    public List<String> getLoginCredentials(String appName, String login, String env) {

        LoginRequest req = LoginRequest.builder()
                .app(appName)
                .login(login)
                .env(env)
                .build();

        try {
            String resp = Rest.sendPostRequestToDBManager("/get/login", new HashMap<>(), req)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            LoginCredentialsDTO res = mapper.readValue(resp, LoginCredentialsDTO.class);
            List<String> out = new ArrayList<>();
            out.add(res.getUrl());
            out.add(res.getLogin());
            out.add(res.getPass());
            return out;
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    void executeCustomTDBUpdate(String query) {
        connectToTDB();
        try {
            Statement stmt = TDBConn.createStatement();
            stmt.executeUpdate(query);
            stmt.close();
            closeConnection(TDBConn);
        } catch (SQLException e) {
            log.error(e);
            throw new RuntimeException(e);
        }
    }

    ResultSet executeCustomTDBQuery(String query) {
        connectToTDB();
        try {
            Statement stmt = TDBConn.createStatement();
            ResultSet result = stmt.executeQuery(query);
            closeConnection(TDBConn);
            return result;
        } catch (SQLException e) {
            log.error(e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Wysyła dane wynikowe z testu do bazy testowej.
     * @param data obiekt {@link CustomTestDTO} definiujący dane wynikowe
     * @return czy dane zostały wysłane poprawnie
     */
    public boolean sendCustomTestData(CustomTestDTO data) {
       return Rest.sendPostRequestToDBManager("/insert/customTestData", new HashMap<>(), data).statusCode() == 200;
    }

    /**
     * Pobiera dane wynikowe z bazy i ustawia ich status na 'wykorzystane'.
     * @param id ID rekordu z danymi testowymi w bazie
     * @return pobrany {@link CustomTestDTO obiekt} definiujący dane wynikowe
     */
    public CustomTestDTO getCustomTestData(int id) {
        Map<String, String> args = new HashMap<>();
        args.put("id", "" + id);
        String resp;

        try {
            resp = Rest.sendGetRequestToDBManager("/get/customTestData", args)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logError("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, CustomTestDTO.class);
        } catch (IOException e) {
            reporter().logFail("Failed to read response || There is no data to run the test", e);
            return null;
        }
    }

    /**
     * Pobiera dane wynikowe z bazy na podstawie zdefiniowanych wymagań i ustawia
     * ich status na 'wykorzystane'.
     * @param req obiekt {@link CustomDataRequest} opisujący wymaganie.
     *            Należy w nim zawrzeć: nazwę aplikacji, nazwę testu, opis testu,
     *            środowisko, żądany status.
     * @return pobrany {@link CustomTestDTO obiekt} definiujący dane wynikowe
     */
    public CustomTestDTO getCustomTestData(CustomDataRequest req) {
        String resp;
        try {
            resp = Rest.sendPostRequestToDBManager("/get/customTestDataFromRequest", new HashMap<>(), req)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logError("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, CustomTestDTO.class);
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    /**
     * Pobiera liczbę danych zgodnych z wysłanym wymaganiem.
     * @param req obiekt {@link CustomDataRequest} opisujący wymaganie.
     *      Należy w nim zawrzeć: nazwę aplikacji, nazwę testu, opis testu,
     *      środowisko, żądany status.
     * @return liczba zgodnych rekordów z danymi wynikowymi
     */
    public int getCustomTestDataCount(CustomDataRequest req) {
        return Integer.valueOf(Rest.sendPostRequestToDBManager("/get/customTestDataCount", new HashMap<>(), req)
                .body().asString());
    }

    /**
     * Pobiera dane wynikowe z bazy na podstawie zdefiniowanych wymagań i ustawia
     * ich status na 'wykorzystane'.
     * @param req obiekt {@link CustomDataRequest} opisujący wymaganie.
     *            Należy w nim zawrzeć nazwę testu, oraz środowisko.
     *            Pozostałe parametry są opcjonalne.
     * @return pobrany {@link CustomTestDTO obiekt} definiujący dane wynikowe
     */
    public CustomTestDTO getCustomTestDataWithParams(CustomDataRequest req) {
        String resp;
        try {
            resp = Rest.sendPostRequestToDBManager("/get/customTestDataWithParams", new HashMap<>(), req)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logError("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, CustomTestDTO.class);
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    public Map<String, String> getUsersOanAndPartyId(String email, String env) {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("mail", email);
        queryParams.put("env", env);
        OANData oanData;

        try {
            String resp = Rest.sendGetRequestToDBManager("/retrieve/oanAndPartyId", queryParams)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            oanData = mapper.readValue(resp, OANData.class);
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
        Map<String, String> out = new HashMap<>();
        out.put("oan", oanData.getOan());
        out.put("partyId", oanData.getPartyId());
        return out;
    }

    public List<TestDTO> getRowsAfterUpgrading(List<Integer> upgradedIds) {
        try {
            String resp = Rest.sendPostRequestToDBManager("/get/upgradedRowList", new HashMap<>(), upgradedIds)
                    .body().asString();

            if (resp == null || resp.equals(""))
                reporter().logFail("Brak wymaganych danych testowych", new NoTestDataException());
            return mapper.readValue(resp, new TypeReference<List<TestDTO>>(){});
        } catch (IOException e) {
            reporter().logFail("Failed to read response", e);
            return null;
        }
    }

    public String getPin(int offerId, String env) {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("offerId", "" + offerId);
        queryParams.put("env", env);

        return Rest.sendGetRequestToDBManager("/retrieve/pin", queryParams).body().asString();
    }

    public int getTestDataCount(String testName, String env, String stage) {
        connectToTDB();
        try {
            PreparedStatement statement = TDBConn.prepareStatement(SELECT_COUNT_DATA);
            statement.setString(1, testName);
            statement.setString(2, env);
            statement.setString(3, stage);
            ResultSet res = statement.executeQuery();

            if (!res.next()) {
                log.error("Failed to get response for testName: " + testName + ", stage: " + stage + ", env: " + env);
                return -1;
            }

            int count = res.getInt(1);

            statement.close();
            closeConnection(TDBConn);
            return count;
        } catch (SQLException e) {
            log.error("Failed to get testDataCount", e);
            return -1;
        }
    }

    public List<MonitorDTO> getMinTestDataCount(String env) {
        connectToTDB();
        try {
            PreparedStatement statement = TDBConn.prepareStatement(SELECT_MONITOR_DATA);
            statement.setString(1, env);

            ResultSet res = statement.executeQuery();

            if (!res.next()) {
                log.error("getMinTestDataCount: Empty response");
                statement.close();
                closeConnection(TDBConn);
                return null;
            }

            List<MonitorDTO> out = new ArrayList<>();

            do {
                MonitorDTO m = MonitorDTO.builder()
                        .testName(res.getString("testName"))
                        .etap(res.getString("stage"))
                        .endpoint(res.getString("endpoint"))
                        .required(res.getInt("req"))
                        .enabled(res.getBoolean("enabled"))
                        .env(res.getString("env"))
                        .build();
                out.add(m);
            } while (res.next());
            statement.close();
            closeConnection(TDBConn);
            return out;
        } catch (SQLException e) {
            log.error("Failed to get testDataCount", e);
            return null;
        }
    }

    @Data
    @Builder
    public static class MonitorDTO {
        private final String testName;
        private final String etap;
        private final String endpoint;
        private final int required;
        private final boolean enabled;
        private final String env;
    }
}

