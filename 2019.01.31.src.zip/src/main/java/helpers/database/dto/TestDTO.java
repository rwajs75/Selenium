package helpers.database.dto;

import helpers.dictionary.testdata.DataRowStatus;
import lombok.Data;

import java.sql.Date;
import java.sql.Timestamp;

@Data
public class TestDTO { //TODO: przerobić zbyt liczne tabele na stringi

    private int lp;
    private int nr_polisy;
    private int nr_potwierdzenia_grupowego; //nullable
    private int typ_polisy;
    private int status_polisy;
    private int rola_wlasc;
    private int typ_umowy;
    private String telefon;
    private String imie;
    private String nazwisko;
    private String pesel;
    private String mail;                    //nullable
    private Date data_rozp_polisy;
    private Date data_zak_polisy;           //nullable
    private Timestamp data_wprow_danych;
    private DataRowStatus status_danej;     //definiowane w zapytaniach
}
