package helpers.database.dto;

import lombok.Data;

@Data
public class LoginCredentialsDTO {

    private String login;
    private String pass;
    private String url;
}
