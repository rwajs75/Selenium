package helpers.database.dto;

import helpers.dictionary.testdata.DataRowStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomTestDTO {

    public static final int PARAM_AMOUNT = 8;

    private int lp;
    private String nazwaTestu;
    private String nazwaAplikacji;
    private String env;
    private Date creationDate;
    private DataRowStatus status;
    private String etap;
    private String param1;
    private String param2;
    private String param3;
    private String param4;
    private String param5;
    private String param6;
    private String param7;
    private String param8;
}
