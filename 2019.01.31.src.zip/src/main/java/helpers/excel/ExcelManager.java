package helpers.excel;

import helpers.database.TestDataRequest;
import lombok.extern.log4j.Log4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Klasa zarządzająca I/O z plików arkuszy kalkulacyjnych.
 */
@Log4j
public class ExcelManager {

    /**
     * Zapisuje wartość do podanej komórki w arkuszu.
     *
     * @param filepath ścieżka do pliku .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param row numer rzędu (logicznego)
     * @param cell numer komórki w rzędzie
     * @param value wartość do zapisania
     */
    public static void writeToCell(String filepath, String sheetName, int row, int cell, String value){
        File file = new File(filepath);
        writeToCell(file, sheetName, row, cell, value);
    }

    /**
     * Zapisuje wartość do podanej komórki w arkuszu.
     *
     * @param file {@link File plik} raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param row numer rzędu (logicznego)
     * @param cell numer komórki w rzędzie
     * @param value wartość do zapisania
     */
    public static void writeToCell(File file, String sheetName, int row, int cell, String value){

        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis)) {
            Sheet s = w.getSheet(sheetName);

            if (s.getRow(row) == null) {
                s.createRow(row);
            }
            if (s.getRow(row).getCell(cell) == null){
                s.getRow(row).createCell(cell);
            }
            s.getRow(row).getCell(cell).setCellValue(value);

            FileOutputStream fos = new FileOutputStream(file);
            w.write(fos);
            fos.close();
        } catch (IOException e) {
            log.info("Failed to write value to file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Zapisuje wartość do podanej komórki w nowym rzędzie (logicznym) w arkuszu.
     *
     * @param filepath ścieżka do pliku .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param cell numer komórki w nowym rzędzie
     * @param value wartość do zapisania
     */
    public static void writeToCellInNewRow(String filepath, String sheetName, int cell, String value) {
        File file = new File(filepath);
        writeToCellInNewRow(file, sheetName, cell, value);
    }

    /**
     * Zapisuje wartość do podanej komórki w nowym rzędzie w arkuszu.
     *
     * @param file {@link File plik} raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param cell numer komórki w nowym rzędzie
     * @param value wartość do zapisania
     */
    public static void writeToCellInNewRow(File file, String sheetName, int cell, String value) {
        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis)) {
            Sheet s = w.getSheet(sheetName);
            int rows = s.getLastRowNum()+1;

            if (s.getRow(rows) == null) {
                s.createRow(rows);
            }
            if (s.getRow(rows).getCell(cell) == null){
                s.getRow(rows).createCell(cell);
            }
            s.getRow(rows).getCell(cell).setCellValue(value);

            FileOutputStream fos = new FileOutputStream(file);
            w.write(fos);
            fos.close();
        } catch (IOException e) {
            log.info("Failed to write value to file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Odczytuje wartość z podanej komórki w arkuszu.
     *
     * @param filepath ścieżka do pliku .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param row numer rzędu (logicznego)
     * @param cell numer komórki w rzędzie
     * @return wartość podanej komórki
     */
    public static String readFromCell(String filepath, String sheetName, int row, int cell) {
        File file = new File(filepath);
        return readFromCell(file, sheetName, row, cell);
    }

    /**
     * Odczytuje wartość z podanej komórki w arkuszu.
     *
     * @param file plik raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param row numer rzędu (logicznego)
     * @param cell numer komórki w rzędzie
     * @return wartość podanej komórki
     */
    public static String readFromCell(File file, String sheetName, int row, int cell) {
        String value;

        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis)) {
            Sheet s = w.getSheet(sheetName);

            if (s.getRow(row) == null || s.getRow(row).getCell(cell) == null)
                throw new IndexOutOfBoundsException("Given row or cell does not exist: r " + row + ", c " + cell);
            value = new DataFormatter().formatCellValue(s.getRow(row).getCell(cell));
            return value;
        } catch (IOException e) {
            log.info("Failed to read value from file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Usuwa podany rząd (logiczny) z arkusza.
     *
     * @param filepath ścieżka do pliku .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param row numer rzędu (logicznego)
     */
    public static void deleteRow(String filepath, String sheetName, int row) {
        File file = new File(filepath);
        deleteRow(file, sheetName, row);
    }

    /**
     * Usuwa podany rząd (logiczny) z arkusza.
     *
     * @param file {@link File plik} raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param row numer rzędu (logicznego)
     */
    public static void deleteRow(File file, String sheetName, int row) {

        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis)) {
            Sheet s = w.getSheet(sheetName);

            s.removeRow(s.getRow(row));
            if (s.getPhysicalNumberOfRows() != 1) {
                s.shiftRows(row, s.getLastRowNum(), -1);
            }

            FileOutputStream fos = new FileOutputStream(file);
            w.write(fos);
            fos.close();
        } catch (IOException e) {
            log.info("Failed to delete row from file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Kopiuje wartości z jednej komórki do drugiej.
     * @param r1 {@link Row rząd} docelowy
     * @param r2 {@link Row rząd} wejściowy
     * @param i kolumna docelowa
     * @param j kolumna wejściowa
     */
    private static void copyCellValue(Row r1, Row r2, int i, int j) {
        switch (r1.getCell(j).getCellTypeEnum()) {
            case STRING:
                r1.getCell(i).setCellValue(r2.getCell(j).getStringCellValue()); break;
            case NUMERIC:
                r1.getCell(i).setCellValue(r2.getCell(j).getNumericCellValue()); break;
            case BOOLEAN:
                r1.getCell(i).setCellValue(r2.getCell(j).getBooleanCellValue()); break;
            case FORMULA:
                r1.getCell(i).setCellValue(r2.getCell(j).getCellFormula()); break;
            case ERROR:
                r1.getCell(i).setCellValue(r2.getCell(j).getErrorCellValue()); break;
        }
    }

    /**
     * Kopiuje wartości z jednej komórki do drugiej w danym arkuszu.
     * @param r1 {@link Row rząd} docelowy
     * @param r2 {@link Row rząd} wejściowy
     * @param i kolumna docelowa
     * @param j kolumna wejściowa
     */
    public static void copyCellValue(File file, String sheetName, int r1, int r2, int i, int j) {
        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis))
        {
            Sheet s = w.getSheet(sheetName);
            Row row1, row2;
            if ((row2 = s.getRow(r2)) == null)
                throw new IndexOutOfBoundsException("Source row is null: " + r2);
            else if (row2.getCell(j) == null)
                throw new IndexOutOfBoundsException("Source cell is null: " + r2 + ", " + j);

            if ((row1 = s.getRow(r1)) == null)
                row1 = s.createRow(r1);
            if (row1.getCell(i) == null)
                row1.createCell(i);
            copyCellValue(row1, row2, i, j);

            FileOutputStream fos = new FileOutputStream(file);
            w.write(fos);
            fos.close();
        } catch (IOException e) {
            log.info("Failed to delete row from file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Kopiuje wartości z jednej komórki do drugiej w danym arkuszu.
     * @param r1 {@link Row rząd} docelowy
     * @param r2 {@link Row rząd} wejściowy
     * @param i kolumna docelowa
     * @param j kolumna wejściowa
     */
    public static void copyCellValue(String filepath, String sheetName, int r1, int r2, int i, int j) {
        File file = new File(filepath);
        copyCellValue(file, sheetName, r1, r2, i, j);
    }

    /**
     * Wpisuje wartości do kolejnych komórek w nowej kolumnie (logicznej, numerowanych od 0).
     *
     * @param filepath ścieżka do pliku .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param values wartości do wpisania
     */
    public static void writeValuesToNewColumn(String filepath, String sheetName, String... values) {
        File file = new File(filepath);
        writeValuesToNewColumn(file, sheetName, values);
    }

    /**
     * Wpisuje wartości do kolejnych komórek w nowej kolumnie (logicznej, numerowanych od 0).
     *
     * @param file {@link File plik} raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param values wartości do wpisania
     */
    public static void writeValuesToNewColumn(File file, String sheetName, String... values) { //TODO: sprawdzić
        if (values.length == 0) {
            log.info("Brak danych do wpisania.");
            return;
        }

        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis)) {
            Sheet s = w.getSheet(sheetName);
            int col = s.getRow(0).getLastCellNum();
            for (int i = 0; i < values.length; i++) {
                if (s.getRow(i) == null)
                    s.createRow(i).createCell(col).setCellValue(values[i]);
                s.getRow(i).createCell(col).setCellValue(values[i]);
            }
            FileOutputStream fos = new FileOutputStream(file);
            w.write(fos);
            fos.close();
        } catch (IOException e) {
            log.info("Failed to write to column from file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Wpisuje wartości do kolejnych komórek w nowej kolumnie (logicznej, numerowanych od 0).
     *
     * @param filepath ścieżka do pliku .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param values wartości do wpisania
     */
    public static void writeValuesToNewRow(String filepath, String sheetName, String... values) {
        File file = new File(filepath);
        writeValuesToNewRow(file, sheetName, values);
    }

    /**
     * Wpisuje wartości do kolejnych komórek w nowej kolumnie (logicznej, numerowanych od 0).
     *
     * @param file {@link File plik} raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param values wartości do wpisania
     */
    public static void writeValuesToNewRow(File file, String sheetName, String... values) { //TODO: sprawdzić
        if (values.length == 0) {
            log.info("Brak danych do wpisania.");
            return;
        }

        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis)) {
            Sheet s = w.getSheet(sheetName);
            Row r = s.createRow(s.getLastRowNum()+1);
            for (int i = 0; i < values.length; i++) {
                r.createCell(i).setCellValue(values[i]);
            }
            FileOutputStream fos = new FileOutputStream(file);
            w.write(fos);
            fos.close();
        } catch (IOException e) {
            log.info("Failed to write to row from file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Weryfikuje istnienie kolumny (logicznej) o danym numerze.
     * @param filepath ścieżka do pliku .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param col numer kolumny (logicznej)
     * @return {@code true} jeśli kolumna istnieje, {@code false} jeśli nie istnieje
     */
    public static boolean doesColumnExist(String filepath, String sheetName, int col) {
        File file = new File(filepath);
        return doesColumnExist(file, sheetName, col);
    }

    /**
     * Weryfikuje istnienie kolumny (logicznej) o danym numerze.
     * @param file {@link File plik} raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param col numer kolumny (logicznej)
     * @return {@code true} jeśli kolumna istnieje, {@code false} jeśli nie istnieje
     */
    public static boolean doesColumnExist(File file, String sheetName, int col) { //TODO: sprawdzić
        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis)) {

            Sheet s = w.getSheet(sheetName);

            return s.getRow(0).getCell(col) != null;
        } catch (IOException e) {
            log.info("Failed to open file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Weryfikuje istnienie komórki o danych współrzędnych.
     * @param filepath ścieżka do pliku .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param col numer kolumny (logicznej)
     * @param row numer wiersza (logicznego)
     * @return {@code true} jeśli komórka istnieje, {@code false} jeśli nie istnieje
     */
    public static boolean doesCellExist(String filepath, String sheetName, int col, int row) {
        File file = new File(filepath);
        return doesCellExist(file, sheetName, col, row);
    }

    /**
     * Weryfikuje istnienie komórki o danych współrzędnych.
     * @param file {@link File plik} raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param col numer kolumny (logicznej)
     * @param row numer wiersza (logicznego)
     * @return {@code true} jeśli komórka istnieje, {@code false} jeśli nie istnieje
     */
    public static boolean doesCellExist(File file, String sheetName, int col, int row) { //TODO: sprawdzić
        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis)) {

            Sheet s = w.getSheet(sheetName);

            return (s.getRow(row) != null && s.getRow(row).getCell(col) != null);
        } catch (IOException e) {
            log.info("Failed to open file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Przygotowuje wstępną strukturę arkusza wynikowego dla biznesu.
     *
     * @param filepath lokalizacja nowego raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     */
    public static void prepareReportFile(String filepath, String sheetName) {
        File file = new File(filepath);
        prepareReportFile(file, sheetName);
    }

    /**
     * Przygotowuje wstępną strukturę arkusza wynikowego dla biznesu.
     *
     * @param file nowy {@link File plik} raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     */
    public static void prepareReportFile(File file, String sheetName) { //TODO zweryfikować z wymaganiami
        try {
            if (!file.exists() && !file.createNewFile()) {
                throw new RuntimeException("Failed to create report file");
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to create report file", e);
        }
        try(FileOutputStream fos = new FileOutputStream(file);
            Workbook w = new XSSFWorkbook()) {
            Sheet s = w.createSheet(sheetName);
            s.createRow(0).createCell(0).setCellValue("Numer polisy");
            s.getRow(0).createCell(1).setCellValue("Typ polisy");
            s.getRow(0).createCell(2).setCellValue("Status polisy");
            s.getRow(0).createCell(3).setCellValue("Rola właściciela");
            s.getRow(0).createCell(4).setCellValue("Imię");
            s.getRow(0).createCell(5).setCellValue("Nazwisko");
            s.getRow(0).createCell(6).setCellValue("Telefon");
            s.getRow(0).createCell(7).setCellValue("Mail");

            w.write(fos);
        } catch (IOException e) {
            log.info("Failed to init report file " + file.getAbsolutePath() + ": ", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Usuwa wskazaną komórkę z arkusza.
     * @param filepath ścieżka do pliku .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param row numer rzędu (logicznego)
     * @param cell numer komórki w rzędzie
     */
    public static void deleteCell(String filepath, String sheetName, int row, int cell) {
        File file = new File(filepath);
        deleteCell(file ,sheetName, row, cell);
    }

    /**
     * Usuwa wskazaną komórkę z arkusza.
     * @param file plik raportu w formacie .xls / .xlsx
     * @param sheetName nazwa arkusza
     * @param row numer rzędu (logicznego)
     * @param cell numer komórki w rzędzie
     */
    public static void deleteCell(File file, String sheetName, int row, int cell) {
        try(FileInputStream fis = new FileInputStream(file);
            Workbook w = new XSSFWorkbook(fis)) {
            Sheet s = w.getSheet(sheetName);
            Row r = s.getRow(row);
            if (r == null || r.getCell(cell) == null)
                return;

            r.removeCell(r.getCell(cell));
            FileOutputStream fos = new FileOutputStream(file);
            w.write(fos);
            fos.close();
        } catch (IOException e) {
            log.error("Failed to clear cell (logical): " + row + ", " + cell);
        }
    }

    public static List<TestDataRequest> getDataRequests(String dataRequestFile, String env) {
        List<TestDataRequest> dataRequestList = new ArrayList<>();

        int i = 1;
        do {
            dataRequestList.add(TestDataRequest.builder() //TODO: ustandaryzowanie nazw arkuszy?
                    .typ_polisy(readFromCell(dataRequestFile, "data", i, 0))
                    .status_polisy(readFromCell(dataRequestFile, "data", i, 1))
                    .rola_wlasc(readFromCell(dataRequestFile, "data", i, 2))
                    .telefon(readFromCell(dataRequestFile, "data", i, 3))
                    .il_sztuk(Integer.parseInt(readFromCell(dataRequestFile, "data", i, 4)))
                    .env(env)
                    .build());
            i++;
        } while (doesCellExist(dataRequestFile, "data", 0, i));

        return dataRequestList;
    }
}
