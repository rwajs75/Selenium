package helpers.common;

import formularz.house.pageobjects.HouseStronaGlowna;
import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.dictionary.Browser;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManager;
import helpers.reporter.ReportManagerFactory;
import helpers.throwables.FalseActionExecutionException;
import helpers.throwables.GeneralStepException;
import helpers.urls.CommonUrls;
import lombok.extern.log4j.Log4j;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.ConnectionClosedException;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;
import tia7.pageobjects.Tia7Common;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static helpers.login.Login.url;
import static helpers.reporter.ReportManagerFactory.*;

/**
 * Klasa zawierająca często wykorzystywane funkcje.
 */
@Log4j
public class Common {

    //TODO: w każdej funkcji - weryfikacja typu elementu, scroll, sprawdzenie dostępności w inputach, raportowanie
    //TODO: dodać wersje funkcji dla lokatorów By zamiast WebElement

    public static String[] nazwaPakietu;
    private static final String CHROMEPATH = ".\\driver\\chromedriver.exe";
    private static final String EDGEPATH = "";
    private static final String OPERAPATH = "";
    private static final String IEPATH = "";

    private static ReportManager reporter;

    public static WebDriver driver;
    private static StopWatch stopWatch;
    public static int timeoutInSeconds = 60;

    /**
     * Uruchamia nowy sterownik Selenium dla podanej przeglądarki.
     *
     * @param browser      przeglądarka, dla której ma być uruchomiony sterownik
     * @param reporterType żądany format raportu
     * @param asIncognito czy uruchomić w trybie incognito
     * @return instancja wybranego sterownika
     */
    public static WebDriver initLocalDriver(Browser browser, ReportManagerFactory.ReporterType reporterType, boolean asIncognito) {
        try {
            String getClass = Thread.currentThread().getStackTrace()[2].getClassName();
            nazwaPakietu = getClass.split("[.]");
            if (nazwaPakietu[0].equals("smoketests"))
                nazwaPakietu[0] = nazwaPakietu[1];
            log.info("Pobrano nazwe pakietu głównego: "+nazwaPakietu[0]);
            DesiredCapabilities caps = new DesiredCapabilities();
            switch (browser) {
                case CHROME:
                    System.setProperty("webdriver.chrome.driver", CHROMEPATH);
                    if (asIncognito) {
                        ChromeOptions options = new ChromeOptions();
                        options.addArguments("-incognito");
                        driver = new ChromeDriver(options);
                    }
                    else driver = new ChromeDriver();
                    break;
                case FIREFOX:
                    if (asIncognito) {
                        FirefoxOptions options = new FirefoxOptions();
                        options.addArguments("-private");
                        driver = new FirefoxDriver(options);
                    }
                    else driver = new FirefoxDriver();
                    break;
                case EDGE:
                    System.setProperty("webdriver.edge.driver", EDGEPATH);
                    driver = new EdgeDriver();
                    break;
                case OPERA:
                    System.setProperty("webdriver.opera.driver", OPERAPATH);
                    driver = new OperaDriver();
                    break;
                case SAFARI:
                    driver = new SafariDriver();
                    break;
                case IE:
                    System.setProperty("webdriver.ie.driver", IEPATH);
                    driver = new InternetExplorerDriver();
                    break;
                default:
                    throw new IllegalArgumentException("Unknown browser: " + browser);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(timeoutInSeconds, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(timeoutInSeconds, TimeUnit.SECONDS);
        driver.manage().timeouts().setScriptTimeout(timeoutInSeconds, TimeUnit.SECONDS);
        reporter = buildReporter(reporterType, driver);

        return driver;
    }

    public static void initReporter(ReportManagerFactory.ReporterType reporterType, Object driver) {
        reporter = buildReporter(reporterType, driver);
    }

    public static void initSkippingReporter(ReportManagerFactory.ReporterType reporterType) {
        reporter = buildSkippingReporter(reporterType);
    }

    /**
     * Otwiera połączenie ze zdalną instancją sterownika Selenium.
     *
     * @param browser      przeglądarka, dla której ma być uruchomiony sterownik
     * @param platform     {@link Platform platforma} na której ma być uruchomiony sterownik
     * @param reporterType żądany format raportu
     * @param asIncognito czy uruchomić w trybie incognito
     * @return instancja {@link RemoteWebDriver} dla podanych wymagań
     */
    public static WebDriver initRemoteDriver(Browser browser, Platform platform, ReportManagerFactory.ReporterType reporterType, boolean asIncognito) {
        try {
            String getClass = Thread.currentThread().getStackTrace()[2].getClassName();
            nazwaPakietu = getClass.split("[.]");
            if (nazwaPakietu[0].equals("smoketests"))
                nazwaPakietu[0] = nazwaPakietu[1];
            log.info("Pobrano nazwe pakietu głównego: "+nazwaPakietu[0]);
            String driverPath = "http://10.3.134.118:4444/wd/hub";
            DesiredCapabilities caps = new DesiredCapabilities();
            caps.setPlatform(platform);
            caps.setBrowserName(browser.toString());
            caps.setJavascriptEnabled(true);
            if (asIncognito) {
                switch (browser) {
                    case CHROME:
                        ChromeOptions chromeOptions = new ChromeOptions();
                        chromeOptions.addArguments("-incognito");
                        caps.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
                        break;
                    case FIREFOX:
                        FirefoxOptions firefoxOptions = new FirefoxOptions();
                        firefoxOptions.addArguments("-private");
                        caps.setCapability("moz.firefoxOptions", firefoxOptions);
                        break;
                    default:
                        //throw new IllegalArgumentException("Unknown browser: " + browser);
                }
            }
            driver = new RemoteWebDriver(new URL(driverPath), caps);
            reporter = buildReporter(reporterType, driver);

            return driver;
        } catch (MalformedURLException e) {
            RuntimeException re = new RuntimeException("Failed to create URL", e);
            log.error(re);
            throw re;
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
        return null;
    }

    public static WebElement getElement(By by) {
        WebElement element = null;
        try {
            element = driver.findElement(by);
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }

        return element;
    }

    /**
     * Klika w dowolny {@link WebElement}.
     *
     * @param element element do kliknięcia
     */
    public static void clickElement(WebElement element) {
        String el = getElementDescription(element);
        try {
            if (!element.isEnabled()) {
                reporter.logFail("Element o lokatorze [" + el + " jest wyłączony");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                String text = getElementTextValueNameAriaLabel(element);
                pauseFor(1);
                element.click();
                waitTillSpinnerDisable();
                reporter.logPass("Kliknięto w element " + text + " o lokatorze [" + el);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Klika w dowolny {@link WebElement}
     *
     * @param by lokator elementu w formie {@link By}
     */
    public static void clickElement(By by) {
        String el = getElementDescription(by);
        try {
            WebElement element = driver.findElement(by);
            if (!element.isEnabled()) {
                reporter.logFail("Element o lokatorze [" + el + " jest wyłączony");
            }
            if (element.isDisplayed()) {
                String text = getElementTextValueNameAriaLabel(element);
                pauseFor(1);
                clickElement(element);
                waitTillSpinnerDisable();
                reporter.logPass("Kliknięto w element " + text + " o lokatorze [" + el);
            }

        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Klika w {@link WebElement} o tagu {@code button}.
     *
     * @param element element do kliknięcia
     */
    public static void clickButton(WebElement element) {
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("button"))
                handleWebDriverExceptions(new UnexpectedTagNameException("button", element.getTagName()));
            if (!element.isEnabled()) {
                reporter.logFail("Przycisk o lokatorze [" + el + " jest wyłączony");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                String text = getElementTextValueNameAriaLabel(element);
                pauseFor(1);
                element.click();
                waitTillSpinnerDisable();
                reporter.logPass("Kliknięto w przycisk " + text + " o lokatorze [" + el);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Klika w {@link WebElement} o tagu {@code button}.
     *
     * @param element         element do kliknięcia
     * @param ladowanieDanych - spinner po każdym kliknięciu
     */
    public static void clickButton(WebElement element, By ladowanieDanych) {
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("button"))
                handleWebDriverExceptions(new UnexpectedTagNameException("button", element.getTagName()));
            if (!element.isEnabled()) {
                reporter.logFail("Przycisk o lokatorze [" + el + " jest wyłączony");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                String text = getElementTextValueNameAriaLabel(element);
                pauseFor(1);
                element.click();
                waitTillSpinnerDisable();
                reporter.logPass("Kliknięto w przycisk " + text + " o lokatorze [" + el);
                waitTillSpinnerDisable1(ladowanieDanych);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Wpisuje tekst w {@link By} o tagu {@code input} i typie {@code text}.
     *
     * @param by element do wpisania tekstu
     */
    public static void enterIntoTextField(By by, String value) {
        String el = getElementDescription(by);
        try {
            WebElement element = driver.findElement(by);
            if (!element.getTagName().equals("input") ||
                    !(element.getAttribute("type").equals("text") ||
                            element.getAttribute("type").equals("password") ||
                            element.getAttribute("type").equals("number")))
                handleWebDriverExceptions(new UnexpectedTagNameException(
                        "input / text, input / password or input / number",
                        element.getTagName() + " / " + element.getAttribute("type")
                ));
            if (!element.isEnabled()) {
                reporter.logFail("Pole tekstowe o lokatorze [" + el + " jest wyłączone");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                element.clear();
                pauseFor(1);
                element.sendKeys(value);
                waitTillSpinnerDisable();
                if (!(element.getAttribute("value").equals(value.trim()) || element.getText().equals(value.trim())))
                    reporter.logFail("Nie wpisano tekstu w pole tekstowe o lokatorze [" + el,
                            new FalseActionExecutionException("enterIntoTextField([" + el + ")"));
                if (!element.getAttribute("type").equals("password"))
                    reporter.logPass("W pole tekstowe o lokatorze [" + el + " wpisano wartość " + value);
                else
                    reporter.logPass("Uzupełniono hasło o lokatorze [" + el);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Wpisuje tekst w {@link WebElement} o tagu {@code input} i typie {@code text}.
     *
     * @param element element do wpisania tekstu
     */
    public static void enterIntoTextField(WebElement element, String value) {
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("input") ||
                    !(element.getAttribute("type").equals("text") ||
                            element.getAttribute("type").equals("password") ||
                            element.getAttribute("type").equals("number")))
                handleWebDriverExceptions(new UnexpectedTagNameException(
                        "input / text, input / password or input / number",
                        element.getTagName() + " / " + element.getAttribute("type")
                ));
            scrollToElement(element);
            if (element.isDisplayed()) {
                pauseFor(1);
                if (!element.isEnabled()) {
                    reporter.logFail("Pole tekstowe o lokatorze [" + el + " jest wyłączone");
                } else {
                    element.clear();
                    pauseFor(1);
                    element.sendKeys(value);
                    waitTillSpinnerDisable();
                    if (!(element.getAttribute("value").equals(value.trim()) || element.getText().equals(value.trim())))
                        reporter.logFail("Nie wpisano tekstu w pole tekstowe o lokatorze [" + el,
                                new FalseActionExecutionException("enterIntoTextField([" + el + ")"));
                    if (!element.getAttribute("type").equals("password"))
                        reporter.logPass("W pole tekstowe o lokatorze [" + el + " wpisano wartość " + value);
                    else
                        reporter.logPass("Uzupełniono hasło o lokatorze [" + el);
                }

            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Wpisuje tekst w {@link WebElement} o tagu {@code textarea} (pole edycji).
     *
     * @param element element do wpisania tekstu
     */
    public static void enterIntoTextArea(WebElement element, String value) {
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("textarea"))
                handleWebDriverExceptions(new UnexpectedTagNameException("textarea", element.getTagName()));
            if (!element.isEnabled()) {
                reporter.logFail("Pole edycyjne o lokatorze " + el + " jest wyłączone");
                handleWebDriverExceptions(new ElementNotInteractableException("Pole edycyjne o lokatorze " + el + " jest wyłączone"));
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                element.clear();
                element.sendKeys(value);
                waitTillSpinnerDisable();
                if (!(element.getAttribute("value").equals(value.trim()) || element.getText().equals(value.trim())))
                    reporter.logFail("Nie wpisano tekstu w pole edycyjne o lokatorze [" + el,
                            new FalseActionExecutionException("enterIntoTextArea([" + el + ")"));
                reporter.logPass("W pole edycyjne o lokatorze " + el + " wpisano wartość " + value);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Wpisuje tekst w dowolny {@link WebElement}.
     *
     * @param element element do wpisania tekstu
     */
    public static void enterIntoElement(WebElement element, String value) {
        String el = getElementDescription(element);
        try {
            if (!element.isEnabled()) {
                reporter.logFail("Element o lokatorze " + el + " jest wyłączony");
                handleWebDriverExceptions(new ElementNotInteractableException("Element o lokatorze " + el + " jest wyłączony"));
            }
            scrollToElement(element);
            element.clear();
            pauseFor(1);
            element.sendKeys(value);
            waitTillSpinnerDisable();
            if (!(element.getAttribute("value").equals(value.trim()) || element.getText().equals(value.trim())))
                reporter.logFail("Nie wpisano tekstu w element o lokatorze [" + el,
                        new FalseActionExecutionException("enterIntoElement([" + el + ")"));
            if (element.getTagName().equals("input") && element.getAttribute("type").equals("password"))
                reporter.logPass("Uzupełniono hasło o lokatorze [" + el);
            else
                reporter.logPass("W element o lokatorze " + el + " wpisano wartość " + value);
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Klika w {@link WebElement} o tagu {@code input} i typie {@code checkbox}.
     *
     * @param element element do kliknięcia
     */
    public static void clickCheckBox(WebElement element) {
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("input") || !element.getAttribute("type").equals("checkbox"))
                handleWebDriverExceptions(new UnexpectedTagNameException(
                        "tag: input / checkbox",
                        element.getTagName() + " / " + element.getAttribute("type")
                ));

            if (!element.isEnabled()) {
                reporter.logFail("Przycisk wyboru o lokatorze " + el + " jest wyłączony");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                String text = getElementTextValueNameAriaLabel(element);
                boolean t = element.getAttribute("checked") != null;
                element.click();
                waitTillSpinnerDisable();
                pauseFor(1);
                if ((element.getAttribute("checked") != null) == t)
                    reporter.logFail("Nie zaznaczono przycisku wyboru " + text + " o lokatorze [" + el,
                            new FalseActionExecutionException("clickCheckBo x([" + el + ")"));
                reporter.logPass("Kliknięto przycisk wyboru " + text + " o lokatorze " + el);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    public static void selectDateInCalendar(WebElement element, Date date) {
        //TODO
    }

    /**
     * Klika w podaną opcję z listy rozwijanej.
     *
     * @param element opcja ({@link WebElement} o tagu {@code option}) do kliknięcia
     */
    public static void selectDropdownListOption(WebElement element, String option) { //AKA combobox
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("select"))
                handleWebDriverExceptions(new UnexpectedTagNameException("select", element.getTagName()));

            if (!element.isEnabled()) {
                reporter.logFail("Lista rozwijana [" + el + " jest wyłączona");
                throw new ElementNotInteractableException("Lista rozwijana " + el + " jest wyłączona");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                element.click();
                pauseFor(1);
                element.findElement(By.xpath("option[text()=\"" + option + "\"]")).click();
                waitTillSpinnerDisable();
                reporter.logPass("Wybrano opcję " + option +
                        " z listy o lokatorze " + el);
                pauseFor(1);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Klika w podaną opcję z listy rozwijanej.
     *
     * @param by     element
     * @param option element z listy
     */
    public static void selectDropdownListOption(By by, String option) { //AKA combobox
        String el = getElementDescription(by);

        try {
            WebElement element = driver.findElement(by);
            if (!element.getTagName().equals("select"))
                handleWebDriverExceptions(new UnexpectedTagNameException("select", element.getTagName()));

            if (!element.isEnabled()) {
                reporter.logFail("Lista rozwijana [" + el + " jest wyłączona");
                throw new ElementNotInteractableException("Lista rozwijana " + el + " jest wyłączona");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                element.click();
                pauseFor(1);
                element.findElement(By.xpath("option[text()=\"" + option + "\"]")).click();
                waitTillSpinnerDisable();
                reporter.logPass("Wybrano opcję " + option +
                        " z listy o lokatorze " + el);
                pauseFor(1);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Klika w podaną opcję z listy rozwijanej (md-select-menu).
     *
     * @param element opcja ({@link WebElement} o tagu {@code md-option}) do kliknięcia
     */
    public static void selectMDDropdownListOption(WebElement element, String option) { //AKA combobox
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("md-select"))
                handleWebDriverExceptions(new UnexpectedTagNameException("md-select", element.getTagName()));

            if (!element.isEnabled()) {
                reporter.logFail("Lista rozwijana [" + el + " jest wyłączona");
                throw new ElementNotInteractableException("Lista rozwijana " + el + " jest wyłączona");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                element.click();
                waitTillSpinnerDisable();
                //pauseFor(1);
                //md-option//*[contains(text(), 'Prospekt')]
                element.findElement(By.xpath("//md-option//*[contains(text(), \"" + option + "\")]")).click();
                waitTillSpinnerDisable();
                reporter.logPass("Wybrano opcję " + option +
                        " z listy o lokatorze " + el);
                pauseFor(1);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Klika w podany {@link WebElement} o tagu {@code input} i typie {@code radio}.
     *
     * @param element element do kliknięcia
     */
    public static void selectRadioOption(WebElement element) {
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("input") || !element.getAttribute("type").equals("radio"))
                handleWebDriverExceptions(new UnexpectedTagNameException("input / radio",
                        element.getTagName() + " / " + element.getAttribute("type")
                ));


            if (!element.isEnabled()) {
                reporter.logFail("Przycisk opcji o lokatorze " + el + " jest wyłączony");
            }
            scrollToElement(element);
            if (element.isDisplayed()) {
                String text = getElementTextValueNameAriaLabel(element);
                element.click();
                waitTillSpinnerDisable();
                //pauseFor(1);
                reporter.logPass("Kliknięto w przycisk opcji: " + text + " o lokatorze " + el);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Klika w przycisk opcji z podanej grupy.
     *
     * @param radioGroup grupa opcji odpowiadająca atrybutowi {@code name}
     * @param option     wybrana opcja z grupy
     */
    public static void selectRadioOption(String radioGroup, String option) {
        try {
            WebElement radio = driver.findElement(By.xpath("//input[@type=\"radio\" " +
                    "and @name=\"" + radioGroup + "\" and text()=\"" + option + "\"]"));
            scrollToElement(radio);
            if (!radio.isEnabled()) {
                reporter.logFail("Przycisk opcji z grupy " + radioGroup + " oraz o tekście " + option + " jest wyłączony.");
            }
            radio.click();
            waitTillSpinnerDisable();
            reporter.logPass("Zaznaczono opcję " + option);
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }


    /**
     * Klika w przycisk opcji z podanej grupy.
     *
     * @param radioGroup grupa opcji odpowiadająca atrybutowi {@code name}
     * @param value      wybrana opcja z grupy
     */
    public static void selectRadioOptionByValue(String radioGroup, String value) {
        try {
            WebElement radio = driver.findElement(By.xpath("//input[@type=\"radio\" " +
                    "and @name=\"" + radioGroup + "\" and @value=\"" + value + "\"]"));
            scrollToElement(radio);
            if (!radio.isEnabled()) {
                reporter.logFail("Przycisk opcji z grupy " + radioGroup + " oraz o wartości " + value + " jest wyłączony.");
            }
            pauseFor(1);
            radio.click();
            waitTillSpinnerDisable();
            reporter.logPass("Zaznaczono przycisk opcji o wartości " + value);
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    /**
     * Przesuwa ekran do danego elementu.
     *
     * @param element niewidoczny element
     */
    public static void scrollToElement(WebElement element) {
        JavascriptExecutor je = (JavascriptExecutor) driver;
        je.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    /**
     * Odczytuje tekst z dowolnego {@link WebElement WebElementu}
     *
     * @param element sprawdzany element
     */
    public static String getElementText(WebElement element) {
        String value;
        String el = getElementDescription(element);
        try {
            scrollToElement(element);
            if (element.isDisplayed()) {
                value = element.getAttribute("value");
                if (value == null)
                    value = element.getText();
                reporter.logPass("Odczytano tekst " + value + " z elementu o lokatorze [" + el);
                return value;
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
        return "";
    }

    /**
     * Odczytuje tekst z dowolnego {@link WebElement WebElementu}
     *
     * @param element sprawdzany element
     */
    public static String getElementTextValueNameAriaLabel(WebElement element) {
        String el = getElementDescription(element);
        try {
            scrollToElement(element);
            if (element.isDisplayed()) {
                String text = "";
                text = element.getAttribute("text");
                if (text == null || (text.equals("")))
                    text = element.getAttribute("value");
                if (text == null || (text.equals("")))
                    text = element.getAttribute("name");
                if (text == null || (text.equals("")))
                    text = element.getAttribute("aria-label");
                if (text == null || (text.equals(""))) {
                    text = "";
                } else {
                    text = "'" + text + "'";
                }

                //reporter.logPass("Odczytano tekst " + opis + " z elementu o lokatorze [" + el);
                return text;
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
        return "";
    }

    /**
     * Odczytuje tekst z dowolnego {@link By by}
     *
     * @param by element
     */
    public static String getElementText(By by) {
        String value;
        String el = getElementDescription(by);
        try {
            WebElement element = driver.findElement(by);
            scrollToElement(element);
            if (element.isDisplayed()) {
                value = element.getAttribute("value");
                if (value == null)
                    value = element.getText();
                reporter.logPass("Odczytano tekst " + value + " z elementu o lokatorze [" + el);
                return value;
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
        return "";
    }


    public static String getElementProperty(WebElement element, String wlasciwosc) {
        String value;
        String el = getElementDescription(element);
        try {
            scrollToElement(element);
            if (element.isDisplayed()) {
                value = element.getAttribute(wlasciwosc);
                reporter.logPass("Odczytano wartosc obiektu: " + wlasciwosc + " : " + value + " z elementu o lokatorze [" + el);
                return value;
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
        return "";
    }


    /**
     * Odczytuje wartosc z danej wlasciwosci obiektu z dowolnego
     *
     * @param by
     * @param wlasciwosc
     * @return
     */
    public static String getElementProperty(By by, String wlasciwosc) {
        String text;
        String byS = getElementDescription(by);
        try {
            WebElement element = driver.findElement(by);
            scrollToElement(element);
            if (element.isDisplayed()) {
                text = element.getAttribute(wlasciwosc);
                reporter.logPass("Odczytano wartosc obiektu: " + wlasciwosc + " : " + text + " z elementu o lokatorze [" + element);
                return text;
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
        return "";
    }


    /**
     * Pobiera listę dostępnych opcji dla konkretnel listy rozwijalnej.
     *
     * @param element {@link WebElement} definiujący litę rozwijalną
     * @return lista opcji danej grupy radio
     */
    public static List<String> getDropdownListOptions(WebElement element) { //AKA combobox
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("select"))
                handleWebDriverExceptions(new UnexpectedTagNameException("select", element.getTagName()));
            List<String> optionsList = new ArrayList<>();

            List<WebElement> options = new Select(element).getOptions();
            for (WebElement option : options) {
                optionsList.add(option.getText());
            }
            return optionsList;
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
            return null;
        }
    }

    /**
     * Pobiera aktualnie wybraną opcję z listy rozwijanej.
     *
     * @param element {}
     * @return obecnie wybrana opcja
     */
    public static String getSelectedDropdownListOption(WebElement element) { //AKA combobox
        String el = getElementDescription(element);
        try {
            if (!element.getTagName().equals("select"))
                handleWebDriverExceptions(new UnexpectedTagNameException("select", element.getTagName()));

            return new Select(element).getFirstSelectedOption().getText();
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
        return null;
    }

    /**
     * Pobiera listę opcji z danej grupy (na podstawie atrybutów {@code value})
     *
     * @param radioGroup grupa opcji (atrybut {@code name})
     * @return lista dostępnych opcji
     */
    public static List<String> getRadioGroupOptions(String radioGroup) {
        List<WebElement> radios = driver.findElements(By.xpath("//input[@type=\"radio\" and @name=\"" + radioGroup + "\"]"));
        List<String> options = new ArrayList<>();
        for (WebElement radio : radios) {
            options.add(radio.getAttribute("value"));
        }
        return options;
    }

    public static boolean getCheckBoxState(WebElement element) {
        try {
            if (!element.getTagName().equals("input") || !element.getAttribute("type").equals("checkbox"))
                handleWebDriverExceptions(new UnexpectedTagNameException("input / checkbox",
                        element.getTagName() + " / " + element.getAttribute("type")));
            return element.getAttribute("checked").equals("true") ||
                    element.getAttribute("checked").equals("checked");
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
            return false;
        }
    }

    /**
     * Oczekuje na pojawienie się {@link WebElement WebElementu} o podanym lokatorze
     * przez określony czas.
     *
     * @param by               lokator elementu
     * @param timeoutInSeconds czas oczekiwania w sekundach
     * @return znaleziony element
     */
    public static WebElement waitUntilElementPresent(By by, int timeoutInSeconds) {
        WebElement found;
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
        try {
            found = new WebDriverWait(driver, timeoutInSeconds).until(ExpectedConditions.presenceOfElementLocated(by));
        } catch (NoSuchElementException | TimeoutException e) {
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            return null;
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return found;
    }

    /**
     * Oczekuje na pojawienie się danego {@link WebElement WebElementu} na ekranie
     * przez określony czas. Element <strong>musi</strong> być już obecny w dokumencie.
     *
     * @param element          oczekiwany element
     * @param timeoutInSeconds czas oczekiwania w sekundach
     * @return widoczny element
     */
    public static WebElement waitUntilElementVisible(WebElement element, int timeoutInSeconds) {
        WebElement found;
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
        try {
            found = new WebDriverWait(driver, timeoutInSeconds).until(ExpectedConditions.visibilityOf(element));
        } catch (NoSuchElementException | TimeoutException e) {
            return null;
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return found;
    }

    /**
     * Oczekuje na pojawienie się danego {@link WebElement WebElementu} na ekranie
     * przez określony czas. Element <strong>musi</strong> być już obecny w dokumencie.
     * Jeżeli nie ma zostaje zarejestrowany wyjatek.
     *
     * @param element          oczekiwany element
     * @param timeoutInSeconds czas oczekiwania w sekundach
     * @return widoczny element
     */
    public static WebElement waitUntilElementVisibleFail(WebElement element, int timeoutInSeconds) {
        WebElement found;
        String el = getElementDescription(element);
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
        try {
            found = new WebDriverWait(driver, timeoutInSeconds).until(ExpectedConditions.visibilityOf(element));
            reporter.logPass("Obiekt zostal zlokalizowany: [" + el);
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
            found = null;
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return found;
    }

    /**
     * Funkcja oczekuje na pojawienie się elementu o podanej nazwie (Text).
     * W momencie nie znalezienia obiektu metoda generuj logFail
     *
     * @param nazwa
     * @param timeoutInSeconds
     */
    public static void waitUntilElementVisibleFail(String nazwa, int timeoutInSeconds) {
        By element = By.xpath("//*[contains(text(),'" + nazwa + "')]");
        String el = getElementDescription(element);
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
        try {
            new WebDriverWait(driver, timeoutInSeconds).until(ExpectedConditions.visibilityOfElementLocated(element));
            reporter.logPass("Obiekt zostal zlokalizowany: [" + el);
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    /**
     * Oczekuje na zniknięcie danego {@link WebElement WebElementu} z dokumentu
     * przez określony czas.
     *
     * @param element          dany element
     * @param timeoutInSeconds czas oczekiwania w sekundach
     * @return czy element zniknął w oczekiwanym czasie
     */
    public static boolean waitUntilElementStale(WebElement element, int timeoutInSeconds) {
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
        boolean isStale;
        try {
            isStale = new WebDriverWait(driver, timeoutInSeconds).until(ExpectedConditions.stalenessOf(element));
        } catch (TimeoutException e) {
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            return false;
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return isStale;
    }

    /**
     * Oczekuje na zniknięcie danego {@link WebElement WebElementu} z ekranu
     * <strong>(nie z dokumentu)</strong> przez określony czas.
     *
     * @param element          dany element
     * @param timeoutInSeconds czas oczekiwania w sekundach
     * @return czy element zniknął w oczekiwanym czasie
     */
    public static boolean waitUntilElementNotVisible(WebElement element, int timeoutInSeconds) {
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
        boolean isNotVisible;
        try {
            isNotVisible = new WebDriverWait(driver, timeoutInSeconds).until(ExpectedConditions.invisibilityOf(element));
        } catch (TimeoutException e) {
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            return false;
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return isNotVisible;
    }

    /**
     * Oczekuje na zniknięcie {@link WebElement WebElementu} o danym lokatorze
     * z ekranu <strong>(nie z dokumentu)</strong> przez określony czas.
     *
     * @param by lokator elementu
     * @param timeoutInSeconds czas oczekiwania w sekundach
     * @return czy element zniknął w oczekiwanym czasie
     */
    public static boolean waitUntilElementNotVisible(By by, int timeoutInSeconds) {
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
        boolean isNotVisible;
        try {
            isNotVisible = new WebDriverWait(driver, timeoutInSeconds).until(ExpectedConditions.invisibilityOfElementLocated(by));
        } catch (TimeoutException e) {
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            return false;
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return isNotVisible;
    }

    public static void verifyElementDisplayed(WebElement element, String logPassMsg, String logFailMsg) {
        try {
            if(element.isDisplayed()) {
                reporter.logPass(logPassMsg);
            } else {
                reporter.logFail(logFailMsg);
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }
    }

    public static boolean isElementPresent(By by, int timeoutInSeconds) {
        return waitUntilElementPresent(by, timeoutInSeconds) != null;
    }

    public static boolean isElementVisible(WebElement element, int timeoutInSeconds) {
        return waitUntilElementVisible(element, timeoutInSeconds) != null;
    }

    /**
     * Udostępnia instancję {@link ReportManager} w celu manualnego
     * umieszczenia kroku w raporcie.
     *
     * @return instancja {@link ReportManager}
     */
    public static ReportManager reporter() {
        if (reporter == null) initSkippingReporter(ReporterType.ALLURE);
        return reporter;
    }

    /**
     * Funkcja uruchamiajaca licznik czasu
     */
    public static void startTimeCounter() {
        stopWatch = new StopWatch();
        stopWatch.start();
    }

    /**
     * Funkcja zatrzymujaca licznik czasu i wyswietlajaca wynik w logu
     */
    public static void stopTimeCounter() {
        if (!stopWatch.isStarted()) {
            reporter.logWarn("Problem z licznikiem czasu");
        } else {
            stopWatch.stop();
            long pageLoadTime_ms = stopWatch.getTime();
            long pageLoadTime_Seconds = pageLoadTime_ms / 1000;
            reporter.logPass("Całkowity czas wczytywania strony: " + pageLoadTime_Seconds + " sek");
        }
    }

    /**
     * Funkcja weryfikujaca poprawnosc aktualnego urla z urlem wpisanym w trakcie logowania
     * Funckaj wyrzuca fail i konczy test
     */
    public static void checkUrl() {
        String[] logowanieurlSplit = url.split("/");
        String aktualnyURL = driver.getCurrentUrl();
        String[] aktualnyurlSplit = aktualnyURL.split("/");

        if (aktualnyurlSplit[2].equals(logowanieurlSplit[2])) {
            reporter.logPass("Adres URL jest zgodny z adresem logowania do aplikacji");
        } else {
            reporter.logFail("Adres URL jest niezgodny z adresem logowania do aplikacji. Adres logowania: " + logowanieurlSplit[2] + " Aktualny adres: " + aktualnyurlSplit[2]);
        }
    }

    /**
     * Funkcja weryfikujaca poprawnosc aktualnego urla z urlem wpisanym w trakcie logowania.
     * Funkcja nie wyrzuca fail tylko error i oznacza w tescie.
     * @param czyRaportowac
     */
    public static Boolean checkUrlVerify(boolean czyRaportowac) {
        String[] logowanieurlSplit = url.split("/");
        String aktualnyURL = driver.getCurrentUrl();
        String[] aktualnyurlSplit = aktualnyURL.split("/");

        //Wyjatek
        if (aktualnyurlSplit[2].equals("ikonto-dev1.cu.com.pl")) {
            reporter.logPass("Adres URL jest inny niż logowania, jest to adres do środowiska 'DEV'. Adres logowania: " + logowanieurlSplit[2] + " Aktualny adres: " + aktualnyurlSplit[2]);
            return true;
        }
        if (aktualnyurlSplit[2].equals(logowanieurlSplit[2])) {
            reporter.logPass("Adres URL jest zgodny z adresem logowania do aplikacji");
            return true;
        } else {
            if (czyRaportowac) {
                try {
                    reporter.logPass("############################");
                    reporter.logError("Adres URL jest niezgodny z adresem logowania do aplikacji. Adres logowania: " + logowanieurlSplit[2] + " Aktualny adres: " + aktualnyurlSplit[2]);
                } catch (GeneralStepException e) {
                    reporter.logPass("############################");
                }
                return false;
            }else {
                return false;
            }
        }


    }

    /**
     * Funkcja weryfikująca poprawność domeny w obecnym URLu.
     * @param app obecna aplikacja
     * @param env środowisko
     * @param isCritical czy niepoprawność maila powoduje przerwanie testu
     * @return czy domena jest poprawna
     */
    public static boolean verifyDomainUrl(String app, String env, boolean isCritical) {
        StringBuilder domain = new StringBuilder();
        switch (app) {
            case "Aplikacja Grupa":
            case "aplikacjaGrupa":
            case "AGrupa":
                domain.append("AGRUPA");
                break;
            case "SalesCloud":
            case "SalesTool":
            case "MyAgent":
                domain.append("SC"); //MYA_DOMAIN_CP
                break;
            case "MyAviva":
            case "MojaAviva":
                domain.append("MYA");
                break;
            case "House":
            case "Formularz House":
                domain.append("HOUSE");
                break;
            case "Moto":
            case "Formularz Moto":
                domain.append("MOTO");
                break;
            case "TIA7":
                domain.append("TIA7");
                break;
            case "WebPortal Agent":
                domain.append("WPA");
                break;
            case "WebPortal JV":
                domain.append("WPJV");
                break;
            default:
                reporter.logFail("Nie moża zweryfikować domeny: nierozpoznana aplikacja (" + app + ")");
        }
        domain.append("_DOMAIN_").append(env.toUpperCase());
        try {
            String[] urlSplit = driver.getCurrentUrl().split("/");
            String actualDomain = urlSplit[0]+"/"+urlSplit[1]+"/"+urlSplit[2],
               expectedDomain = CommonUrls.class.getField(domain.toString()).get(null).toString();
            boolean equals = expectedDomain.equals(actualDomain);

            if ((!equals) && (isCritical)) reporter.logFail("Niezgodność domen (wymagana: " + expectedDomain +
                    ", rzeczywista: " + actualDomain + ")");
            else if (!equals) reporter.logWarn("Niezgodność domen (wymagana: " + expectedDomain +
                    ", rzeczywista: " + actualDomain + ")");
            else reporter.logPass("Zweryfikowano poprawność domeny.");

            return equals;
        } catch (NoSuchFieldException e) {
            reporter.logFail("Nie można zweryfikować domeny: nieznana domena dla danej aplikacji i środowiska (" +
                    env + ", " + app + ")");
            return false;
        } catch (IllegalAccessException e){
            throw new RuntimeException(e);
        }
    }

    /**
     * Funkcja pobiera wycinek z URL na który było wywołane logowanie do systemu
     *
     * @return
     */
    public static String getUrlLogin() {
        String[] logowanieurlSplit = url.split("/");
        return logowanieurlSplit[2];
    }

    /**
     * Funkcja uruchamiająca URL
     * @param czyKompletnyUrl - true - uruchomienie calego adresu URL ,
     *                        false - uruchomienie z aktualnem urlem + koncowka https://moja-it.cu.com.pl/XXXX
     * @param url - koncowka lub caly url
     */
    public static void openUrl(Boolean czyKompletnyUrl, String url) {
        if (czyKompletnyUrl) {
            driver.get(url);
            reporter.logPass("Uruchomienie strony: " + url);
        }else{
            String[] logowanieurlSplit = url.split("/");
            String aktualnyURL = "https://" + logowanieurlSplit[2] + url;
            driver.get(aktualnyURL);
            reporter.logPass("Uruchomienie strony: " + aktualnyURL);
        }

    }

    /**
     * Funkcja przywracajaca poprzednia strone (URL)
     */
    public static void backUrl() {
        String aktualnyURL = driver.getCurrentUrl();
        driver.navigate().back();
        String przywroconyURL = driver.getCurrentUrl();
        reporter.logPass("Powrót do strony: " + przywroconyURL + " z strony: " + aktualnyURL);
        pauseFor(1);
        Actions action = new Actions(driver);
        action.sendKeys(Keys.ESCAPE).build().perform();
        pauseFor(5);
    }

    /**
     * Funkcja pobierajaca z URL id oferty [SalesCloud]
     * Miejsce pobrania [Dane osobowe]
     */
    public static int getOfferID() {
        reporter.logPass(driver.getCurrentUrl());
        String[] urlA = driver.getCurrentUrl().split("/package-personal");
        String[] urlB = urlA[0].split("/property-details");
        String[] url = urlB[0].split("/personal");
        String oferta = url[0].substring(url[0].length() - 6);
        int idOferty = Integer.parseInt(oferta);
        reporter.logPass("Pobrano ID Oferty: " + idOferty);
        return idOferty;
    }

    /**
     * Funkcja zmieniająca timeout implicitlyWait
     *
     * @param implicitlyWait
     */
    public static void changeTimeout(int implicitlyWait) {
        driver.manage().timeouts().implicitlyWait(implicitlyWait, TimeUnit.SECONDS);
        reporter.logPass("implicitlyWait zmieniony na: " + implicitlyWait + "s");
    }

    /**
     * Funkcja zmieniająca timeout implicitlyWait,pageLoadTimeout,setScriptTimeout
     *
     * @param implicitlyWait
     * @param pageLoadTimeout
     * @param setScriptTimeout
     */
    public static void changeTimeout(int implicitlyWait, int pageLoadTimeout, int setScriptTimeout) {
        driver.manage().timeouts().implicitlyWait(implicitlyWait, TimeUnit.SECONDS);
        driver.manage().timeouts().pageLoadTimeout(pageLoadTimeout, TimeUnit.SECONDS);
        driver.manage().timeouts().setScriptTimeout(setScriptTimeout, TimeUnit.SECONDS);
        System.out.println("implicitlyWait zmieniony na: " + implicitlyWait + "s , pageLoadTimeout zmieniony na " + pageLoadTimeout + "s , setScriptTimeout zmieniony na: " + setScriptTimeout + "s");
        //reporter.logPass("implicitlyWait zmieniony na: "+implicitlyWait+"s , pageLoadTimeout zmieniony na "+pageLoadTimeout+ "s , setScriptTimeout zmieniony na: "+setScriptTimeout+"s");
    }

    public static void restoreDefaultTimeouts() {
        driver.manage().timeouts().pageLoadTimeout(timeoutInSeconds, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(timeoutInSeconds, TimeUnit.SECONDS);
        driver.manage().timeouts().setScriptTimeout(timeoutInSeconds, TimeUnit.SECONDS);
        reporter.logPass("Przywrócono domyślne czasy implicitlyWait, pageLoadTimeout, setScriptTimeout");
    }

    public static void pauseFor(int timeoutInSeconds) {
        try {
            timeoutInSeconds = timeoutInSeconds * 1000;
            Thread.sleep(timeoutInSeconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void switchToNewTab() {
        String currentTabHandle = driver.getWindowHandle();
        String title1 = driver.getTitle();
        pauseFor(5);
        try {
            int time = 20;
            for (int i = 0; i < time; i++) {
                ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                pauseFor(1);
                if (tabs.size() > 1) {
                    String newTabHandle = driver.getWindowHandles()
                            .stream()
                            .filter(handle -> !handle.equals(currentTabHandle))
                            .findFirst()
                            .get();
                    driver.switchTo().window(newTabHandle);
                    changeTimeout(10, 10, 10);
                    try {
                        String title2 = driver.getTitle();
                        if (!title2.equals("")) {
                            reporter.logPass("Zmieniono aktywnosc zakladki z: " + currentTabHandle + " tytul: " + title1 + " na: " + newTabHandle + " tytul: " + title2);
                            break;
                        }
                    } catch (WebDriverException e) {
                        handleWebDriverExceptions(e);
                    }
                    changeTimeout(30, 30, 30);

                }

                if (i == time && (tabs.size() == 1))
                    reporter.logFail("Nowa zakladka nie zostala otwarta. Czas oczekiwania: " + time + "s");
/*                    if (driver.getTitle().equals("") && (tabs.size() > 1))
                        reporter.logFail("Po przelaczeniu zakladki strona niedostepna.");*/
            }
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
        }

    }

    /**
     * Funkcja przełączajaca się na najwyższe okno (Zmiana aktywacji okna)
     */
    public static void switchToNewPopUp() {
        pauseFor(5);
        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
        reporter.logPass(parentWindowHandler);
        String subWindowHandler = null;

        Set<String> handles = driver.getWindowHandles(); // get all window handles
        Iterator<String> iterator = handles.iterator();
        while (iterator.hasNext()) {
            subWindowHandler = iterator.next();
        }
        driver.switchTo().window(subWindowHandler); // switch to popup window
        reporter.logPass(subWindowHandler);
        // Now you are in the popup window, perform necessary actions here
        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
    }

    private static String getElementDescription(WebElement element) {
        try {
            String[] s = element.toString().split("->");
            if (s.length >= 2)
                return s[1];
            else return element.toString();
        } catch (WebDriverException e) {
            handleWebDriverExceptions(e);
            return null;
        }
    }

    private static String getElementDescription(By by) {
        String[] s = by.toString().split("->");
        if (s.length >= 2)
            return s[1];
        else return by.toString();
    }

    /**
     * Krecioly / Spinnery / Loadingi i inne cuda
     */

    public static void waitTillSpinnerDisable() {
        switch (nazwaPakietu[0]) {
            case "TIA7":
                PageFactory.initElements(driver, Tia7Common.class);
                waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
                break;
/*            case "salescloud": //TODO po naprawieniu kreciola odkomentować
                waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 1, false);
                waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
                break;*/
            case "myaviva":
            case "myaviva.life":
            case "myaviva.moto":
            case "myaviva.travel":
            case "myaviva.mojprofil":
            case "myaviva.House":
                PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
                waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
                break;
            case "formularz":
                PageFactory.initElements(driver,HouseStronaGlowna.class);
                waitTillSpinnerDisable1(HouseStronaGlowna.ladowanieDanych);
                break;
        }

    }

    /**
     * Krecioly / Spinnery / Loadingi i inne cuda
     */

    public static void waitTillSpinnerDisable1(By by) {
        pauseFor(1);
        int i = 1;
        while ((waitUntilElementPresent((by), 1)) != null) {
            reporter.logPass("## Ladowanie danych: " + i + "s ##");
            if (i == 90)
                reporter.logFail("## Przekroczony czas ładowania danych: " + i + "s ##");
            i = i + 1;
            pauseFor(1);
        }
    }

    /**
     * Oczekiwanie na zkniecie elementu ladowania danych.
     *
     * @param by           - wlasciwosc elementu
     * @param timeout      - maksymalny czas oczekiwania
     * @param czyZatrzymac - czy po przekroczeniu wygenerowac raport FAIL (true=TAK , false=NIE)
     */

    public static void waitTillSpinnerDisable2(By by, int timeout, Boolean czyZatrzymac) {

        int i = 1;
        while ((waitUntilElementPresent(by, 1)) != null) {
            reporter.logPass("## SC Ladowanie danych: " + i + "s ##");
            if (czyZatrzymac) {
                if (i == timeout)
                    reporter.logFail("## Przekroczony czas ładowania danych: " + i + "s ##");
            } else {
                if (i == timeout)
                    break;
            }
            i = i + 1;
            pauseFor(1);
        }
    }

    /**
     * Krecioly / Spinnery / Loadingi i inne cuda
     */

    public static void waitTillSpinnerDisable(By by) {
        pauseFor(1);
        int i = 1;
        while ((waitUntilElementPresent((by), 1)) != null) {
            reporter.logPass("## Ladowanie danych: " + i + "s ##");
            if (i == 90)
                reporter.logFail("## Przekroczony czas ładowania danych: " + i + "s ##");
            i = i + 1;
            pauseFor(1);
        }
    }


    /**
     * Generowanie kolejnego dostepnego maila do testu (podbicie numeru +1)
     *
     * @param oldMail
     * @return
     */
    public static String updateMailIndex(String oldMail) {
        int mailIndex = Integer.parseInt(oldMail.substring(7, oldMail.length() - 12));
        String newMailIndex;
        if (mailIndex < 9) {
            newMailIndex = "000" + (mailIndex + 1);
        } else if (mailIndex < 99) {
            newMailIndex = "00" + (mailIndex + 1);
        } else if (mailIndex < 999) {
            newMailIndex = "0" + (mailIndex + 1);
        } else if (mailIndex < 9999) {
            newMailIndex = "0" + (mailIndex + 1);
        } else newMailIndex = "" + (mailIndex + 1);
        return "autoczt" + newMailIndex + "@yopmail.com";
    }

    /**
     * Funkcja pobierająca ostatniego maila z DB i generujaca nowego z wyższym numerkiem z zapisaniem w DB
     *
     * @param env srodowisko
     * @param app aplikacja
     * @return nowyMail
     */
    public static String creationNewMailDBforImmediateUse(String env, String app) {
        TestDataManager manager;
        manager = new TestDataManager(env);
        String mail = manager.registerNewMailForApp(app, env);
        manager.updateMailStatus(mail);
        return mail;
    }

    public static void handleWebDriverExceptions(RuntimeException e) {
        if (!(e instanceof WebDriverException)) throw e;

        if (reporter == null) initSkippingReporter(ReporterType.ALLURE);

        if (e instanceof ConnectionClosedException)
            reporter.logFail("Utracono połączenie ze sterownikiem Safari.", e);
        else if (e instanceof ElementClickInterceptedException || e.getMessage().contains("Other element would receive the click"))
            reporter.logFail("Kliknięcie zostało przechwycone przez inny element.", e);
        else if (e instanceof ElementNotVisibleException)
            reporter.logFail("Element nie jest widoczny na ekranie.", e);
        else if (e instanceof ElementNotInteractableException)
            reporter.logFail("Interakcja z elementem nie jest możliwa.", e);
        else if (e instanceof ElementNotSelectableException)
            reporter.logFail("Nie jest możliwe wybranie elementu.", e);
        else if (e instanceof InvalidSelectorException)
            reporter.logFail("Selektor elementu jest nieprawidłowy.", e);
        else if (e instanceof NoSuchElementException)
            reporter.logFail("Podany element nie istnieje.", e);
        else if (e instanceof NoAlertPresentException)
            reporter.logFail("Oczekiwano ostrzeżenia, ale żadnego nie znaleziono.", e);
        else if (e instanceof JavascriptException)
            reporter.logFail("Błąd Javascriptu. Rozwiń, by zobaczyć szczegóły.", e);
        else if (e instanceof InvalidElementStateException)
            reporter.logFail("Stan elementu nie pozwala na wykonanie żądanej akcji. Rozwiń, by zobaczyć szczegóły.", e);
        else if (e instanceof StaleElementReferenceException)
            reporter.logFail("Podany element już nie istnieje. Sprawdź, czy nie zmienił się jego lokator.", e);
        else if (e instanceof UnhandledAlertException)
            reporter.logFail("Nieobsłużone ostrzeżenie: " + ((UnhandledAlertException) e).getAlertText());
        else if (e instanceof TimeoutException)
            reporter.logFail("Akcja nie została wykonana w podanym czasie. " +
                    "Jeśli oczekiwałeś na zmianę stanu elementu, " +
                    "zweryfikuj warunki zmiany stanu lub przedłuż oczekiwanie.", e);
        else if (e instanceof UnexpectedTagNameException)
            reporter.logFail("Element posiada inny tag niż oczekiwano.", e);

        else reporter.logFail("Wystąpił nieoczekiwany błąd WebDrivera. Rozwiń, by zobaczyć szczegóły.", e);

    }

    /**
     * Funkcja zliczajaca ilosc obiektow na ekranie
     *
     * @param by By
     * @return ilosc obiektow
     */
    public static int getCountObjects(By by) {
        int count = driver.findElements(by).size();
        return count;
    }

    public static String getCurentDate(String format) {
        DateFormat dateFormat;
        switch (format) {
            default:
                dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
                break;
                //TODO dodać potrzebne formaty
        }
        Date date = new Date();
        String date1 = dateFormat.format(date);
        return date1;
    }

    public static String uppercaseFirstLetter(String in) {
        return in.substring(0,1).toUpperCase() + in.substring(1);
    }

    /**
     * Wypisuje podsumowanie testu w raporcie oraz wysyła dane wynikowe
     * do bazy.
     * @param testName nazwa testu
     * @param appName nazwa testowanej aplikacji
     * @param env środowisko
     * @param status status rekordu doumieszczenia w bazie
     * @param stage etap procesu
     * @param passed czy test zakończył się sukcesem
     * @param params parametry do wypisania w podsumowaniu i przekazania do bazy
     *               (tylko pierwsze 8 parametrów jest zapisywanych)
     */
    public static void reportSummaryAndSendResults(String testName, String appName, String env, DataRowStatus status,
                                                   String stage, boolean passed, String... params) {
        reporter.logPass("###############################");
        reporter.logPass("PODSUMOWANIE");
        reporter.logPass("Data: "+getCurentDate(""));
        reporter.logPass("Nazwa testu: " + testName);
        reporter.logPass("Aplikacja: " + appName);
        reporter.logPass("Środowiko: " + env);
        reporter.logPass("Etap: " + stage);
        if (params != null) for (String param: params)
            reporter.logPass(param);
        reporter.logPass("###############################");
        if (passed) {
            CustomTestDTO data = CustomTestDTO.builder()
                    .nazwaTestu(testName.split(" ")[0])
                    .nazwaAplikacji(appName)
                    .env(env)
                    .status(status)
                    .etap(stage)
                    .param1(params != null && params.length > 0 ? params[0] : null)
                    .param2(params != null && params.length > 1 ? params[1] : null)
                    .param3(params != null && params.length > 2 ? params[2] : null)
                    .param4(params != null && params.length > 3 ? params[3] : null)
                    .param5(params != null && params.length > 4 ? params[4] : null)
                    .param6(params != null && params.length > 5 ? params[5] : null)
                    .param7(params != null && params.length > 6 ? params[6] : null)
                    .param8(params != null && params.length > 7 ? params[7] : null)
                    .build();
            new TestDataManager(env).sendCustomTestData(data);
        }
    }
    //TODO: uzupełniać w miarę potrzeby

}
