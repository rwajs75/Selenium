package helpers.common;

import org.junit.Assert;

import static helpers.common.Common.reporter;

public class Asserts {

    public static void assertTrue(String message, boolean condition) {
        if (!condition) reporter().logFail(message);
    }

    public static void assertTrue(boolean condition) {
        if (!condition) reporter().logFail("Ewaluowane wyrażenie jest fałszywe, oczekiwano prawdziwego.");
    }

    public static void assertFalse(String message, boolean condition) {
        if (condition) reporter().logFail(message);
    }

    public static void assertFalse(boolean condition) {
        if (condition) reporter().logFail("Ewaluowane wyrażenie jest prawdziwe, oczekiwano fałszywego.");
    }

    public static void assertEquals(String message, Object expected, Object actual) {
        try {
            Assert.assertEquals(message, expected, actual);
        } catch (AssertionError e) {
            String cleanMessage = message == null ? "Obiekty nie są identyczne " : message;
            failNotEqual(cleanMessage, expected.toString(), actual.toString());
        }
    }

    public static void assertEquals(Object expected, Object actual) {
        assertEquals(null, expected, actual);
    }

    public static void assertArrayEquals(String message, Object[] expected, Object[] actual) {
        try {
            Assert.assertArrayEquals(message, expected, actual);
        } catch (AssertionError e) {
            String cleanMessage = message == null ? "Niezgodność tablic " : message;
            StringBuilder expecteds = new StringBuilder("[ "), actuals = new StringBuilder("[ ");
            for (Object ex: expected) expecteds.append(ex).append(" ");
            expecteds.append("]");
            for (Object ac: actual) actuals.append(ac).append(" ");
            actuals.append("]");
            failNotEqual(cleanMessage, expecteds.toString(), actuals.toString());
        }
    }

    public static void assertNotEquals(String message, Object unexpected, Object actual) {
        try {
            Assert.assertNotEquals(message, unexpected, actual);
        } catch (AssertionError e) {
            String cleanMessage = message == null ? "Obiekty są identyczne " : message;
            failEqual(cleanMessage, actual.toString());
        }
    }

    public static void assertNotEquals(Object expected, Object actual) {
        assertNotEquals(null, expected, actual);
    }

    //assertEquals

    public static void assertEquals(String message, int expected, int actual){
        String actualMessage = message != null ? message :
                "Znaki nie są identyczne ";
        if (expected != actual)
            failNotEqual(actualMessage, "" + expected, "" + actual);
    }

    public static void assertEquals(int expected, int actual){
        assertEquals(null, expected, actual);
    }

    public static void assertEquals(String message, double expected, double actual, double delta){
        String actualMessage = message != null ? message :
                "Wartości są poza granicami dopuszczalnego błędu ";
        if (!doubleEquals(expected, actual, delta))
            failNotEqual(actualMessage, "" + expected, "" + actual);
    }

    public static void assertEquals(double expected, double actual, double delta){
        assertEquals(null, expected, actual, delta);
    }

    public static void assertEquals(String message, char expected, char actual){
        String actualMessage = message != null ? message :
                "Znaki nie są identyczne ";
        if (expected != actual)
            failNotEqual(actualMessage, "" + expected, "" + actual);
    }

    public static void assertEquals(char expected, char actual){
        assertEquals(null, expected, actual);
    }

    public static void assertEquals(String message, float expected, float actual, float delta){
        String actualMessage = message != null ? message :
                "Wartości są poza granicami dopuszczalnego błędu ";
        if (!floatEquals(expected, actual, delta))
            failNotEqual(actualMessage, "" + expected, "" + actual);
    }

    public static void assertEquals(float expected, float actual, float delta){
        assertEquals(null, expected, actual, delta);
    }

    public static void assertEquals(String message, byte expected, byte actual){
        String actualMessage = message != null ? message :
                "Wartości bajtów nie są identyczne ";
        if (expected != actual)
            failNotEqual(actualMessage, "" + expected, "" + actual);
    }

    public static void assertEquals(byte expected, byte actual){
        assertEquals(null, expected, actual);
    }

    public static void assertEquals(String message, short expected, short actual){
        String actualMessage = message != null ? message :
                "Wartości nie są identyczne ";
        if (expected != actual)
            failNotEqual(actualMessage, "" + expected, "" + actual);
    }

    public static void assertEquals(short expected, short actual){
        assertEquals(null, expected, actual);
    }

    public static void assertEquals(String message, long expected, long actual){
        String actualMessage = message != null ? message :
                "Wartości nie są identyczne ";
        if (expected != actual)
            failNotEqual(actualMessage, "" + expected, "" + actual);
    }

    public static void assertEquals(long expected, long actual){
        assertEquals(null, expected, actual);
    }

    public static void assertEquals(String message, String expected, String actual){
        String actualMessage = message != null ? message :
                "Tekst nie jest identyczny ";
        if (!expected.equals(actual))
            failNotEqual(actualMessage, "" + expected, "" + actual);
    }

    public static void assertEquals(String expected, String actual){
        assertEquals(null, expected, actual);
    }

    //assetNotEqual

    public static void assertNotEqual(String message, int expected, int actual){
        String actualMessage = message != null ? message :
                "Wartości są identyczne ";
        if (expected == actual)
            failEqual(actualMessage, "" + actual);
    }

    public static void assertNotEqual(int expected, int actual){
        assertNotEqual(null, expected, actual);
    }

    public static void assertNotEqual(String message, double expected, double actual, double delta){
        String actualMessage = message != null ? message :
                "Wartości są w granicach błędu ";
        if (doubleEquals(expected, actual, delta))
            failEqual(actualMessage, "" + actual);
    }

    public static void assertNotEqual(double expected, double actual, double delta){
        assertNotEqual(null, expected, actual, delta);
    }

    public static void assertNotEqual(String message, char expected, char actual){
        String actualMessage = message != null ? message :
                "Znaki są identyczne ";
        if (expected == actual)
            failEqual(actualMessage, "" + actual);
    }

    public static void assertNotEqual(char expected, char actual){
        assertNotEqual(null, expected, actual);
    }

    public static void assertNotEqual(String message, float expected, float actual, float delta){
        String actualMessage = message != null ? message :
                "Wartości są w granicach błędu ";
        if (floatEquals(expected, actual, delta))
            failEqual(actualMessage, "" + actual);
    }

    public static void assertNotEqual(float expected, float actual, float delta){
        assertNotEqual(null, expected, actual, delta);
    }

    public static void assertNotEqual(String message, byte expected, byte actual){
        String actualMessage = message != null ? message :
                "Bajty są identyczne ";
        if (expected == actual)
            failEqual(actualMessage, "" + actual);
    }

    public static void assertNotEqual(byte expected, byte actual){
        assertNotEqual(null, expected, actual);
    }

    public static void assertNotEqual(String message, short expected, short actual){
        String actualMessage = message != null ? message :
                "Wartości są identyczne ";
        if (expected == actual)
            failEqual(actualMessage, "" + actual);
    }

    public static void assertNotEqual(short expected, short actual){
        assertNotEqual(null, expected, actual);
    }

    public static void assertNotEqual(String message, long expected, long actual){
        String actualMessage = message != null ? message :
                "Wartości są identyczne ";
        if (expected == actual)
            failEqual(actualMessage, "" + actual);
    }

    public static void assertNotEqual(long expected, long actual){
        assertNotEqual(null, expected, actual);
    }

    public static void assertNotEqual(String message, String expected, String actual){
        String actualMessage = message != null ? message :
                "Tekst jest identyczny ";
        if (expected.equals(actual))
            failEqual(actual, "" + actual);
    }

    public static void assertNotEqual(String expected, String actual){
        assertNotEqual(null, expected, actual);
    }

    //assertNull,assertNotNull

    public static void assertNull(String message, Object o){
        assertTrue(message,o == null);
    }

    public static void assertNull(Object o){
        assertNull("Obiekt nie ma wartości null ", o);
    }

    public static void assertNotNull(String message, Object o){
        assertTrue(message, o != null);
    }

    public static void assertNotNull( Object o){
        assertNotNull("Obiekt ma wartość null", o);
    }




    private static void failNotEqual(String message, String expected, String actual) {
        reporter().logFail(message + "(oczekiwano: " + expected + ", znaleziono: " + actual +")");
    }

    private static void failEqual(String message, String actual) {
        reporter().logFail(message + "(znaleziono: " + actual +")");
    }

    private static boolean doubleEquals(double d1, double d2, double delta) {
        if (Double.compare(d1, d2) == 0) {
            return true;
        }
        return (Math.abs(d1 - d2) <= delta);

    }

    private static boolean floatEquals(float f1, float f2, float delta) {
        if (Float.compare(f1, f2) == 0) {
            return true;
        }
        return (Math.abs(f1 - f2) <= delta);

    }
}
