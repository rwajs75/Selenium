package helpers.robot;

import helpers.reporter.ReportManager;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;

import static helpers.common.Common.reporter;
import static java.awt.event.KeyEvent.*;

public class RobotHelpers {
//
//    private static ReportManager manager;
//
//    static{
//        manager = reporter();
//    }
//
//    public static void clickKey(Robot r, int keycode) {
//        r.keyPress(keycode);
//        r.keyRelease(keycode);
//        r.delay(100);
//        manager.logPass("Wciśnięto przycisk " + keycode);
//    }
//
//    public static void enterText(Robot r, String text) {
//        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
//        StringSelection strSel = new StringSelection(text);
//        clipboard.setContents(strSel, strSel);
//
//        r.keyPress(VK_CONTROL);
//        r.keyPress(VK_V);
//        r.keyRelease(VK_V);
//        r.keyRelease(VK_CONTROL);
//        r.delay(200);
//
//        manager.logPass("Wpisano tekst " + text);
//    }
//
//    public static void cycleFields(Robot r, int amount) {
//        for (int i = 0; i < amount; i++)
//            clickKey(r, VK_TAB);
//    }
}
