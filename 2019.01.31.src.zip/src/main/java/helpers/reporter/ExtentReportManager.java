package helpers.reporter;

import org.openqa.selenium.WebDriver;

/**
 * Klasa odpowiadająca za tworzenie raportu w formacie ExtentReports.
 */
public class ExtentReportManager extends ReportManager { //TODO: implementacja

    public ExtentReportManager(WebDriver driver) {
        super(driver);
    }

//    public ExtentReportManager(Screen driver) {
//        super(driver);
//    }

    @Override
    public void logPass(String text, boolean takesScreenshot) {

    }

    @Override
    public void logFail(String text, Throwable t) {

    }

    @Override
    public void logWarn(String text) {

    }

    @Override
    public void logError(String text, Throwable t) {

    }

    @Override
    public void logSkip(String text) {

    }

    @Override
    public void skipTest(String text) {

    }

    @Override
    public byte[] saveScreenshot() {
        return new byte[0];
    } //TODO:
}
