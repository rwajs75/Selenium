package helpers.reporter;

import helpers.throwables.GeneralStepException;
import helpers.throwables.NoTestDataException;
import helpers.throwables.TestPendingException;
import io.qameta.allure.Allure;
import io.qameta.allure.model.Parameter;
import io.qameta.allure.model.Status;
import io.qameta.allure.model.StatusDetails;
import io.qameta.allure.model.StepResult;
import lombok.extern.log4j.Log4j;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Klasa odpowiadająca za tworzenie raportu w formacie AllureReport.
 */
@Log4j
public class AllureReportManager extends ReportManager {
    
    private String text;
    private boolean screen;

    public AllureReportManager(WebDriver driver) {
        super(driver);
    }

//    public AllureReportManager(Screen driver) {
//        super(driver);
//    }

    @Override
    public void logPass(String text, boolean takesScreenshot) {
        this.text = text;
        this.screen = takesScreenshot;
        addStepToReport("pass", null);
    }

    @Override
    public void logFail(String text, Throwable t) {
        this.text = text;
        addStepToReport("fail", t);
    }

    public void logFail(String text, Throwable t, boolean setAsSkipped) {
        if (setAsSkipped) skipTest(text);
        else logFail(text, t);
    }

    @Override
    public void logWarn(String text) {
        this.text = text;
        addStepToReport("warn", null);
    }

    @Override
    public void logError(String text, Throwable t) {
        if (t instanceof TestPendingException) return;
        this.text = text;
        addStepToReport("error", t);
    }

    @Override
    public void logSkip(String text) {
        this.text = text;
        addStepToReport("skip", null);
    }

    @Override
    public void skipTest(String text) {
        logSkip(text);
        setReportStatus(Status.SKIPPED, text);
        throw new TestPendingException();
    }

    public void logError(String text, Throwable t, boolean setAsSkipped) {
        if (setAsSkipped) skipTest(text);
        else logError(text, t);
    }

    @Override
    public byte[] saveScreenshot() {
        if (manager == null) {
            log.error("Failed to take screenshot: driver is null");
            return null;
        }
        else try {
            return manager.takeScreenshot();
        } catch (IOException | WebDriverException e) {
            log.error("Failed to take screenshot: ", e);
            return null;
        }
    }

    private void addStepToReport(String type, Throwable t) {
        try {
            switch (type) {
                case "pass":
                    runStepWithDescription(AllureReportManager.class.getDeclaredMethod("reportPassStep")); break;
                case "warn":
                    runStepWithDescription(AllureReportManager.class.getDeclaredMethod("reportWarnStep")); break;
                case "fail":
                    runStepWithDescription(AllureReportManager.class.getDeclaredMethod("reportFailStep", Throwable.class), t); break;
                case "error":
                    runStepWithDescription(AllureReportManager.class.getDeclaredMethod("reportErrorStep", Throwable.class), t); break;
                case "skip":
                    runStepWithDescription(AllureReportManager.class.getDeclaredMethod("reportSkippedStep")); break;
                default:
                    throw new IllegalStateException("Illegal reporting method type: " + type);
            }
        } catch (NoSuchMethodException e) {
            log.error("Failed to add step to report", e);
        }
    }
    
    private void runStepWithDescription(@Nonnull Method m, Object... args){

        try {
            m.invoke(this, args);
        } catch (IllegalAccessException | InvocationTargetException e) {
            if (e.getCause() == null || !(e.getCause() instanceof AssertionError || e.getCause() instanceof GeneralStepException)) {
                throw new AssertionError("Nie udało się zrobić zrzutu ekranu.", e);
            }
            else if (e.getCause() instanceof  AssertionError) throw (AssertionError) e.getCause();
            else {
                if (e.getCause().getCause() == null) {
                        if (e.getCause() instanceof GeneralStepException) throw (GeneralStepException) e.getCause();
                        else throw new RuntimeException(e.getCause());
                }
                else if (RuntimeException.class.isAssignableFrom(e.getCause().getCause().getClass())) {
                    throw (RuntimeException) e.getCause().getCause();
                } else throw new RuntimeException(e.getCause().getCause());
            }
        }
    }

    private void setReportStatus(Status s, String text) {
        Allure.getLifecycle().updateTestCase(exec -> {
            exec.setStatus(s);
            exec.setStatusDetails(new StatusDetails().withMessage(text != null ? text : "Test skipped"));
        });
        Allure.getLifecycle().stopTestCase(Allure.getLifecycle().getCurrentTestCase().orElseThrow(RuntimeException::new));
    }

    private void reportPassStep() {
        String uuid = UUID.randomUUID().toString();
        StepResult sr = new StepResult().withStatus(Status.PASSED);

        log.info(text);
        sr.withName(text);

        Allure.getLifecycle().startStep(uuid, sr);
        if (screen && manager != null)
            Allure.getLifecycle().addAttachment("Screenshot", "image/png", null, saveScreenshot());
        Allure.getLifecycle().stopStep(uuid);
    }

    private void reportFailStep(Throwable t) {
        String uuid = UUID.randomUUID().toString();
        StepResult sr = new StepResult().withStatus(Status.FAILED);

        if (text == null || text.equals("")) {
            log.error(t.toString());
            sr.withName(t.toString());
        } else {
            log.error(text);
            sr.withName(text);
        }

        if (t != null) {
            Parameter p = new Parameter().withName("Thrown").withValue(t.getMessage());
            sr.withParameters(p);
        }

        Allure.getLifecycle().startStep(uuid, sr);
        if (manager != null && !(t instanceof NoTestDataException)) Allure.getLifecycle().addAttachment("Screenshot", "image/png", null, saveScreenshot());
        Allure.getLifecycle().stopStep(uuid);

        throw new AssertionError(text, t);
    }

    private void reportErrorStep(Throwable t) {
        String uuid = UUID.randomUUID().toString();
        StepResult sr = new StepResult().withStatus(Status.BROKEN);

        if (text == null || text.equals("")) {
            log.error(t.toString());
            sr.withName(t.toString());
        } else {
            log.error(text);
            sr.withName(text);
        }
        if (t != null) {
            Parameter p = new Parameter().withName("Thrown").withValue(t.getMessage());
            sr.withParameters(p);
        }

        Allure.getLifecycle().startStep(uuid, sr);
        if (manager != null && !(t instanceof NoTestDataException)) Allure.getLifecycle().addAttachment("Screenshot", "image/png", null, saveScreenshot());
        Allure.getLifecycle().stopStep(uuid);

        throw new GeneralStepException(text, t);
    }

    private void reportWarnStep() {
        String uuid = UUID.randomUUID().toString();
        StepResult sr = new StepResult().withStatus(Status.BROKEN);

        log.warn("WARN: " + text);
        sr.withName("WARN: " + text);

        Allure.getLifecycle().startStep(uuid, sr);
        Allure.getLifecycle().stopStep(uuid);
    }

    private void reportSkippedStep() {
        String uuid = UUID.randomUUID().toString();
        StepResult sr = new StepResult().withStatus(Status.SKIPPED);

        log.info("SKIPPED: " + text);
        sr.withName("SKIPPED: " + text);

        Allure.getLifecycle().startStep(uuid, sr);
        Allure.getLifecycle().stopStep(uuid);
    }
}
