package helpers.reporter.screenshot;

import java.io.IOException;

public interface ScreenshotManager {

    byte[] takeScreenshot() throws IOException;

    String takeScreenshotWithSource() throws IOException;

}
