package helpers.reporter.screenshot;

import lombok.extern.log4j.Log4j;
import org.openqa.selenium.*;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.SimpleShootingStrategy;
import ru.yandex.qatools.ashot.shooting.ViewportPastingDecorator;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

@Log4j
public class SeleniumScreenshotManager implements ScreenshotManager {

    private WebDriver driver;

    public SeleniumScreenshotManager(WebDriver driver) {
        this.driver = driver;
    }

    public byte[] takeScreenshot() throws IOException {
        try {
            Screenshot screenshot = new AShot().shootingStrategy(new ViewportPastingDecorator(new SimpleShootingStrategy()))
                    .takeScreenshot(driver);
            final BufferedImage image = screenshot.getImage();
            String filename = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(new Date()) + ".png";
            String dest = ".\\target\\screenshots\\" + filename;
            File screen = new File(dest);
            if (!screen.exists()) {
                File par = new File(screen.getParent());
                if (!par.exists()) par.mkdirs();
                screen.createNewFile();
            }
            ImageIO.write(image, "PNG", screen);
            log.info("Zrzut ekranu umieszczony w pliku " + dest);

            byte[] out;
            try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                ImageIO.write(image, "png", baos);
                baos.flush();
                out = baos.toByteArray();
            }
            return out;
        } catch (WebDriverException e){
            log.error("\u001B[31mFailed to take screenshot\u001B[0m", e);
            return null;
        }
    }

    @Override
    public String takeScreenshotWithSource() throws IOException {
        Screenshot screenshot = new AShot().shootingStrategy(new ViewportPastingDecorator(new SimpleShootingStrategy()))
                .takeScreenshot(driver);
        final BufferedImage image = screenshot.getImage();
        String filename = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(new Date()) + ".png";
        String dest = ".\\target\\screenshots\\" + filename;
        File screen = new File(dest);
        if (!screen.exists()) {
            File par = new File(screen.getParent());
            if (!par.exists()) par.mkdirs();
            screen.createNewFile();
        }
        ImageIO.write(image, "PNG", screen);
        log.info("Zrzut ekranu umieszczony w pliku " + dest);

        return dest;
    }
}
