package helpers.reporter;

import helpers.reporter.screenshot.ScreenshotManager;
import helpers.reporter.screenshot.SeleniumScreenshotManager;
import org.openqa.selenium.WebDriver;

public abstract class ReportManager {

    protected ScreenshotManager manager;

    public ReportManager(WebDriver driver) {
        manager = new SeleniumScreenshotManager(driver);
    }

    public abstract void logPass(String text, boolean takesScreenshot);

    public void logPass(String text){
        logPass(text,false);
    }

    public abstract void logFail(String text, Throwable t);

    public void logFail(String text){
        logFail(text, null);
    }

    public abstract void logWarn(String text);    //oznaczanie rzeczy nietypowych, ale potencjalnie destabilizujących

    public abstract void logError(String text, Throwable t); //poważne błędy

    public void logError(String text){
        logError(text, null);
    }

    public abstract void logSkip(String text);

    public abstract byte[] saveScreenshot();

    public abstract void skipTest(String text);

    public ScreenshotManager getScreenshotManager() {
        return manager;
    }

}
