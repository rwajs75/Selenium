package helpers.restapi;

import helpers.database.TestDataManager;
import io.restassured.RestAssured;
import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;

import java.util.List;
import java.util.Map;

import static helpers.common.Common.reporter;
import static helpers.urls.CommonUrls.DBMANAGER_URL;
import static io.restassured.RestAssured.*;

@Log4j
public class Rest {

    public static String getActivationLink(String email, String env) {
        String activationCode = null;
        String user = env.equals("CP") ? "plapiadminu" : "plapiadmini";
        List<String> creds = new TestDataManager(env).getLoginCredentials("RestConfirmationLink", user, env);
        for(int i = 0; i < 3; i++) {
            try {
                reporter().logPass("Pobieranie linku aktywacyjnego dla " + email + ", próba nr " + (i + 1) + "...");
                Thread.sleep(60000);
            } catch (InterruptedException e) {
                reporter().logFail("Błąd w pobieraniu linku aktywacyjnego", e);
            }
            RestAssured.authentication = basic(creds.get(1), creds.get(2));
            RestAssured.baseURI = creds.get(0) + "/avivasecurityapi/v1/users/" + email + "/activationcode";
            RestAssured.useRelaxedHTTPSValidation();

            Response response = given().when().put();

            handleStatusCodes(response);

            try {
                activationCode = response.jsonPath().getString("activationCode");
            } catch (JsonPathException e) {
                log.error(response.asString());
                reporter().logFail("Błąd w pobieraniu linku aktywacyjnego: nie można odczytać odpowiedzi");
            }
            reporter().logPass(" Otrzymano odpowiedź: " + activationCode);
            if(activationCode != null) {
                break;
            }
        }
        return activationCode;
    }

    public static String getTwoFAPin(String userId, String oan, String numer, String env) {
        String user = env.equals("CP") ? "plapiadminu" : "plapiadmini";
        List<String> creds = new TestDataManager(env).getLoginCredentials("RestConfirmationLink", user, env);
        String req = "{\n" +
                "\t\"extendedAttributes\": [\n" +
                "                {\"name\": \"mobile\",\n" +
                "                 \"value\": \"" + numer + "\"},\n" +
                "                {\"name\": \"customerId\",\n" +
                "                 \"value\": \"" + userId + "\"},\n" +
                "                {\"name\": \"context\",\n" +
                "                 \"value\": \"funds_switch\" } ]\n" +
                "}";

        RestAssured.authentication = basic(creds.get(1), creds.get(2));
        RestAssured.baseURI = creds.get(0) + "/avivasecurityapi/v1/account/" + oan + "/mfa/SMS";
        RestAssured.useRelaxedHTTPSValidation();
        Response response = given()
                .contentType("application/json").
                        body(req).
                        when().
                        post("");

        if (response.statusCode() == 500)
            reporter().logFail("Nie udało się pobrać numeru PIN: " + response.body().jsonPath().getString("responseMessage"));

        handleStatusCodes(response);

        return response.body().jsonPath().getString("extendedAttributes.value[0]");
    }

    public static Response sendGetRequestToDBManager(String endpoint, Map<String, String> queryParams) {

        return given()
                .baseUri(DBMANAGER_URL + endpoint)
                .queryParams(queryParams)
                .when()
                .get();
    }

    public static Response sendPostRequestToDBManager(String endpoint, Map<String, String> queryParams, Object body) {

        return given()
                .baseUri(DBMANAGER_URL + endpoint)
                .queryParams(queryParams)
                .contentType("application/json")
                .body(body)
                .when()
                .post();
    }

    public static Response sendPutRequestToDBManager(String endpoint, Map<String, String> queryParams) {

        return given()
                .baseUri(DBMANAGER_URL + endpoint)
                .queryParams(queryParams)
                .when()
                .put();
    }

    private static void handleStatusCodes(Response r) {
        switch(r.statusCode()) {
            case 400: reporter().logError("Błędna składnia zapytania REST. (HTTP 400)"); break;
            case 401: reporter().logError("Błąd REST: wymagana autentykacja. (HTTP 401)"); break;
            case 403: reporter().logError("Błąd REST: dostęp do zasobu zabroniony. (HTTP 403)"); break;
            case 404: reporter().logError("Błąd REST: zasób nie istnieje. (HTTP 404)"); break;
            case 405: reporter().logError("Błąd REST: niedozwolona metoda HTTP. (HTTP 405)"); break;
            case 406: reporter().logError("Błąd REST: nieakceptowany format odpowiedzi. (HTTP 406)"); break;
            case 408: reporter().logError("Błąd REST: przekroczono limit czasu oczekiwania. (HTTP 408)"); break;
            case 409: reporter().logError("Błąd REST: konflikt stanu zasobu. (HTTP 409)"); break;
            case 410: reporter().logError("Błąd REST: zasób nie jest już dostępny. (HTTP 410)"); break;
            case 414: reporter().logError("Błąd REST: zbyt długi URI. (HTTP 414)"); break;

            case 500: reporter().logFail("Błąd REST: wewnętrzny błąd serwera. (HTTP 500)"); break;
            case 502: reporter().logFail("Błąd REST: błąd bramy sieciowej. (HTTP 502)"); break;
            case 503: reporter().logFail("Błąd REST: usługa niedostępna. (HTTP 503)"); break;
            case 504: reporter().logFail("Błąd REST: przekroczono limit czasu oczekiwania na bramie sieciowej. (HTTP 504)"); break;
            case 505: reporter().logFail("Błąd REST: nieobsługiwana wersja HTTP. (HTTP 505)"); break;
            case 507: reporter().logFail("Błąd REST: brak miejsca na przechowanie zapytania. (HTTP 507)"); break;
            case 508: reporter().logFail("Błąd REST: pętla nieskończona. (HTTP 508)"); break;
            case 511: reporter().logFail("Błąd REST: wymagana autentykacja w sieci. (HTTP 511)"); break;
        }
    }
}
