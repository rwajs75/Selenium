package helpers.throwables;

public class NoTestDataException extends RuntimeException {
    public NoTestDataException() {
    }

    public NoTestDataException(String message) {
        super(message);
    }

    public NoTestDataException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoTestDataException(Throwable cause) {
        super(cause);
    }
}
