package helpers.throwables;

public class PoliceUpgradeFailureException extends RuntimeException{

    public PoliceUpgradeFailureException(int id) {
        super("Failed to upgrade row with id: " + id);
    }

    public PoliceUpgradeFailureException(Throwable cause) {
        super(cause);
    }
}
