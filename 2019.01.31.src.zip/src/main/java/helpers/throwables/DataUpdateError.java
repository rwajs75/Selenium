package helpers.throwables;

public class DataUpdateError extends Error{
    public DataUpdateError() {
        super();
    }

    public DataUpdateError(Throwable t) {
        super(t);
    }
}
