package helpers.login;

import formularz.house.pageobjects.HouseStronaGlowna;
import formularz.moto.pageobjects.Samochod;
import helpers.database.TestDataManager;
import helpers.urls.MyAvivaURL;
import myaviva.pageobjects.MyAvivaStronaLogowania;
import myaviva.pageobjects.MyAvivaAktualizacjaZU;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import salescloud.pageobjects.SalesCloudStronaLogowania;
import eDirect.pageobjects.eDirectStronaLogowania;
import tia7.pageobjects.Tia7StronaLogowania;
import webportal.pageobjects.WpaStronaLogowania;

import java.util.List;

import static helpers.common.Common.*;
import static helpers.dictionary.StaticStrings.ERR_503;
import static myaviva.pageobjects.MyAvivaAktualizacjaZU.*;


public class Login {

    public static String url;

    /**
     * Funkcja do logowania aplikacji WEB
     * @param Aplikacja - nazwa aplikacji np. SalesCloud , MyAviva
     * @param Srodowisko - nazwa środowiska np. CP , UT
     * @param Login - login użytkownika
     * @param driver
     */

    public static void LoginWeb(String Aplikacja, String Srodowisko, String Login, WebDriver driver){

        PageFactory.initElements(driver, SalesCloudStronaLogowania.class);
        PageFactory.initElements(driver, MyAvivaStronaLogowania.class);
        PageFactory.initElements(driver, Samochod.class);
        PageFactory.initElements(driver, HouseStronaGlowna.class);
        PageFactory.initElements(driver, Tia7StronaLogowania.class);
        PageFactory.initElements(driver, eDirectStronaLogowania.class);
        PageFactory.initElements(driver, WpaStronaLogowania.class);
        driver.manage().window().maximize();
        String loginSave=Login;
        if (Aplikacja.equals("SalesCloud") || Aplikacja.equals("MyAviva") )
            Login = "";
        List<String> daneLogowania = new TestDataManager(Srodowisko).getLoginCredentials(Aplikacja,Login,Srodowisko);
        url = daneLogowania.get(0);
        String pass = daneLogowania.get(2);

        switch (Aplikacja)
        {
            case "SalesCloud": {
/*                switch (Srodowisko){
                    case "UT": url = "https://salescloud-uat.aviva.pl/sales-application/"; pass = "Aviva123";break;
                    case "CP": url = "https://salescloud-uat2.aviva.pl/sales-application/";pass = "Aviva123";break;
                }*/
                driver.navigate().to(url);
                if (waitUntilElementPresent(SalesCloudStronaLogowania.poleTekstoweLogin, 30)!=null) {
                    enterIntoTextField(SalesCloudStronaLogowania.poleTekstoweLogin, loginSave);
                    enterIntoTextField(SalesCloudStronaLogowania.poleTekstoweHaslo, pass);
                }else{
                    reporter().logFail("Problem z wyświetleniem strony logowania");
                }
                startTimeCounter();
                clickElement(SalesCloudStronaLogowania.przyciskZaloguj);

                if (waitUntilElementPresent(By.xpath("//*[@aria-label='Twoi klienci']"), 30)!=null
                        || (waitUntilElementPresent(By.xpath("//*[@aria-label='Klienci']"), 30)!=null))   {
                    checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z zalogowaniem: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                break;
            }

            case "MyAviva": {
               /* if ("CP".equals(Srodowisko) || "UT".equals(Srodowisko)){
                    url = MyAvivaURL.loginPageUrl(Srodowisko);
                    pass = "Aviva123";
                }
                else
                    throw new IllegalArgumentException("Nieprawidłowe środowisko:" + Srodowisko);*/
                changeTimeout(90,90,90);
                driver.navigate().to(url);
                startTimeCounter();
                if (!Login.equals("MyAviva")) {
                    enterIntoTextField(MyAvivaStronaLogowania.poleTekstoweLogin, loginSave);
                    enterIntoTextField(MyAvivaStronaLogowania.poleTekstoweHaslo, pass);
                    startTimeCounter();
                    clickElement(MyAvivaStronaLogowania.przyciskZaloguj);
                    if ((waitUntilElementPresent(By.xpath("//*[@aria-label='Ubezpieczenia']"), 30)) != null
                    || (waitUntilElementPresent(By.xpath("//*[@aria-controls='loggedin']"), 30)) != null) {
                        checkUrl();
                        reporter().logPass("Poprawnie zalogowano do: " + Aplikacja + " Srodowisko: " + Srodowisko + " URL: " + url);
                        if (driver.getTitle().contains("503")) {
                            reporter().logFail(ERR_503);
                        }
                    } else {
                        reporter().logFail("Problem z zalogowaniem: " + Aplikacja + " Srodowisko: " + Srodowisko + " URL: " + url);
                    }
                }
                changeTimeout(60, 60, 60);
                break;
            }

            case "Moto": {
/*                switch (Srodowisko){
                    case "CP": url = "https://ikonto-dev.cu.com.pl/web/pweb/samochod";break;
                    case "UT": url = "https://ikonto-dev1.cu.com.pl/web/pweb/samochod";break;
                }*/
                changeTimeout(90,90,90);
                startTimeCounter();
                driver.navigate().to(url);
                WebElement belkaMoto;
                if ((belkaMoto = waitUntilElementPresent(By.id("steps"), 30))!=null) {
                    checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z zalogowaniem: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                changeTimeout(60,60,60);
                break;
            }

            case "Travel": {
/*                switch (Srodowisko){
                    case "CP": url = "https://travel-ing-uat.aviva.pl/start";break;
                    case "UT": url = "https://travel-ing-ut.aviva.pl/start";break;
                }*/
                changeTimeout(90,90,90);
                startTimeCounter();
                driver.navigate().to(url);
                WebElement belkaTravel;
                if ((belkaTravel = waitUntilElementPresent(By.xpath("//*[contains(text(), 'Ubezpieczenie podróżne online')]"), 30))!=null) {
                    checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z zalogowaniem: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                changeTimeout(60,60,60);
                break;
            }

            case "House": {
/*                switch (Srodowisko){
                    case "CP": url = "https://dom-uat2.aviva.pl/";break;
                    case "UT": url = "https://dom-uat.aviva.pl/";break;
                }*/
                changeTimeout(90,90,90);
                startTimeCounter();
                driver.navigate().to(url);
                WebElement belkaMoto;
                if ((belkaMoto = waitUntilElementPresent(By.xpath("//*[@id='hero']//*[contains(text(), 'Sprawdź cenę')]"), 30))!=null) {
                    checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z zalogowaniem: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                changeTimeout(60,60,60);
                break;
            }

            case "TIA7": {
                /*switch (Srodowisko){
                    case "CP": url = "https://tia-app-d04.cu.com.pl";pass = "Aviva1234";break;
                    case "UT": url = "https://tia-app-d03.cu.com.pl";    pass = "Aviva1234";break;
                }*/

                driver.navigate().to(url);
                if (waitUntilElementPresent(Tia7StronaLogowania.poleTekstoweLogin, 30)!=null) {
                    enterIntoTextField(Tia7StronaLogowania.poleTekstoweLogin, Login);
                    enterIntoTextField(Tia7StronaLogowania.poleTekstoweHaslo, pass);
                    clickElement(Tia7StronaLogowania.przyciskLogin);
                }else{
                    reporter().logFail("Problem z wyświetleniem strony logowania");
                }
                startTimeCounter();

                WebElement logout;
                if ((logout = waitUntilElementPresent(By.id("pageTemplate1:sf_c:r0:0:pt:userTB:logout"), 30))!=null) {
                    checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z załadowaniem strony: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                break;
            }

            case "WebPortal Agent": {
/*                switch (Srodowisko){
                    case "CP": url = "https://www.moja-test.aviva.pl";pass = "Aviva123";break;
                    case "UT": url = "https://www.moja-ut.aviva.pl";    pass = "Aviva123";break;
                }*/
                driver.navigate().to(url);
                clickElement(WpaStronaLogowania.przyciskJestemAgentem);
                enterIntoTextField(SalesCloudStronaLogowania.poleTekstoweLogin, Login);
                enterIntoTextField(SalesCloudStronaLogowania.poleTekstoweHaslo, pass);
                startTimeCounter();
                clickElement(SalesCloudStronaLogowania.przyciskZaloguj);
                WebElement logout;
                if ((logout = waitUntilElementPresent(By.id("gwt-uid-20"), 30))!=null) {
                    checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z zalogowaniem: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                break;
            }

            case "WebPortal JV": {
 /*               switch (Srodowisko){
                    case "CP": url = "http://test.ubezpieczeniaportal.pl";pass = "Aviva123";break;
                    case "UT": url = "http://ut.ubezpieczeniaportal.pl";    pass = "Aviva123";break;
                }*/
                driver.navigate().to(url);
                /*waitUntilElementVisibleFail(SalesCloudStronaLogowania.poleTekstoweLogin, 30);*/
                enterIntoTextField(SalesCloudStronaLogowania.poleTekstoweLogin, Login);
                enterIntoTextField(SalesCloudStronaLogowania.poleTekstoweHaslo, pass);
                startTimeCounter();
                clickElement(SalesCloudStronaLogowania.przyciskZaloguj);

                WebElement logout;
                if ((logout = waitUntilElementPresent(By.xpath("//*[@id='headerSubNav']//*[@class='gwt-Button btnLogout']"), 30))!=null) {
                    //checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z zalogowaniem: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                break;
            }

            case "eDirect": {
                switch (Srodowisko){
                    case "CP": url = "https://modus.cu.com.pl:8583/eDirect/";pass = "Czas123!";break;
                    case "UT": url = "https://modus.cu.com.pl:8383/eDirect/";pass = "";break;
                }
                driver.navigate().to(url);
                enterIntoTextField(eDirectStronaLogowania.poleTekstoweLogin, Login);
                enterIntoTextField(eDirectStronaLogowania.poleTekstoweHaslo, pass);
                startTimeCounter();
                clickElement(eDirectStronaLogowania.przyciskLogin);

                WebElement yourAccount;
                if ((yourAccount = waitUntilElementPresent(By.xpath("//*[@name='sub9']"), 30))!=null) {
                    checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z zalogowaniem: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                break;
            }

            case "aplikacjaGrupa": {
/*                switch (Srodowisko){
                    case "CP": url = "https://bal.cu.com.pl:18643/aviva-int-cp/";pass = "Aviva123";break;
                    case "UT": url = "https://bal.cu.com.pl:18743/aviva-int-ut/";pass = "Aviva123";break;
                }*/
                driver.navigate().to(url);
                startTimeCounter();

                WebElement jestesZalogowany;
                if ((jestesZalogowany = waitUntilElementPresent(By.xpath("//*[contains(text(), 'Jesteś zalogowany jako:')]"), 30))!=null) {
                    checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z zalogowaniem: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                break;
            }

            case "CAS": {
 /*               switch (Srodowisko){
                    case "CP": url = "https://cas-uat2.aviva.pl";pass = "Aviva123";break;
                    case "UT": url = "https://cas-test.aviva.pl/cas/login";pass = "Aviva123";break;
                }*/
                driver.navigate().to(url);
                enterIntoTextField(SalesCloudStronaLogowania.poleTekstoweLogin, Login);
                enterIntoTextField(SalesCloudStronaLogowania.poleTekstoweHaslo, pass);
                startTimeCounter();
                clickElement(SalesCloudStronaLogowania.przyciskZaloguj);
                String czyZalogowano = driver.getTitle();

                WebElement logout;
                if (czyZalogowano.equals("Udane logowanie")) {
                    checkUrl();
                    reporter().logPass("Poprawnie zalogowano do: "+Aplikacja+ " Srodowisko: " +Srodowisko+ " URL: "+url);
                }else{
                    reporter().logFail("Problem z zalogowaniem: "+Aplikacja+ " Srodowisko: " +Srodowisko+" URL: "+url);
                }
                break;
            }
        }
        stopTimeCounter();
    }

    public static void loginToAccountMyAviva(String env, String login, WebDriver driver) {
        loginToAccountMyAviva(env, login, "Aviva123", driver);
    }

    public static void loginToAccountMyAviva(String env, String login, String pass, WebDriver driver) {
        if (env.equals("CP") || env.equals("UT"))
            url = MyAvivaURL.loginPageUrl(env);
        else
            throw new IllegalArgumentException("Nieprawidłowe środowisko:" + env);
        changeTimeout(90,90,90);
        driver.navigate().to(url);
        PageFactory.initElements(driver, MyAvivaStronaLogowania.class);
        if (!(login == null) && !login.equals("")) {
            enterIntoTextField(MyAvivaStronaLogowania.poleTekstoweLogin, login);
            enterIntoTextField(MyAvivaStronaLogowania.poleTekstoweHaslo, pass);
            startTimeCounter();
            clickElement(MyAvivaStronaLogowania.przyciskZaloguj);
        } else throw new IllegalArgumentException("Empty login");
        changeTimeout(60, 60, 60);
        handleTOUUpdate(driver, env);
        stopTimeCounter();
    }

    public static void LoginCLAS(String login, String env) {
//        try {
//            List<String> daneLogowania = new TestDataManager(env).getLoginCredentials("CLAS", login, env);
//            url = daneLogowania.get(0);
//            File file = new File(System.getProperty("user.home") + "\\Desktop\\frmservlet.jnlp");
//            ProcessBuilder builder = new ProcessBuilder(
//                    "cmd.exe", "/c", "javaws " + file.getAbsolutePath()
//            );
//            builder.redirectErrorStream(true);
//            builder.start();
//            Robot r = new Robot();
//            Screen s = new Screen();
//
//            s.wait("clas/oracle_forms_monit.png", FOREVER);
//            clickKey(r, VK_ENTER);
//            r.delay(1000);
//            cycleFields(r, 2);
//            clickKey(r, VK_SPACE);
//            cycleFields(r, 1);
//            clickKey(r, VK_ENTER);
//            r.delay(3000);
//            cycleFields(r, 2);
//            clickKey(r, VK_SPACE);
//            cycleFields(r, 1);
//            clickKey(r, VK_ENTER);
//            r.delay(1000);
//
//            enterText(r, daneLogowania.get(1));
//            cycleFields(r, 1);
//            r.delay(500);
//            enterText(r, daneLogowania.get(2));
//            cycleFields(r, 1);
//            clickKey(r, VK_ENTER);
//            try {
//                s.wait("clas/brak_pyt_zdef.png", 1500);
//                clickKey(r, VK_ENTER);
//            } catch (FindFailed ignored) {}
//
//            s.wait("clas/clas_main_menu.png",2000);
//
//            reporter().logPass("Poprawnie zalogowano do: CLAS Srodowisko: " + env + " URL: " + url);
//        } catch (Exception e) {
//            reporter().logFail("Problem z zalogowaniem: CLAS  Srodowisko: " + env +" URL: " + url);
//        }
    }

    public static void handleTOUUpdate(WebDriver driver, String env) {
        if(driver.getCurrentUrl().equals(MyAvivaURL.touUpdatePage(env))) {
            PageFactory.initElements(driver, MyAvivaAktualizacjaZU.class);
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", checkbox);
            submitButton.click();
        }
    }
}