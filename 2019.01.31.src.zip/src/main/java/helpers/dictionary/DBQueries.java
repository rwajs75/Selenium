package helpers.dictionary;

public class DBQueries {

    public static final String SELECT_DATA_ROW_BY_ID =
            "SELECT * " +
            "FROM public.danetestowedh dt " +
            "INNER JOIN public.StatusDanych sd ON dt.status_danych = sd.lp " +
            "WHERE dt.lp = ? AND sd.status = 'AKTYWNY' AND NOT dt.env = 3;";

    public static final String SELECT_DATA_ROW_BY_ID_PROCESSING =
            "SELECT * " +
                    "FROM public.danetestowedh dt " +
                    "INNER JOIN public.StatusDanych sd ON dt.status_danych = sd.lp " +
                    "WHERE dt.lp = ? AND sd.status = 'NIEAKTYWNY' AND dt.mail IS NULL AND NOT dt.env = 3;";

    public static final String SELECT_DATA_ROW_BY_ID_LIST_HEAD =
            "SELECT * " +
            "FROM public.danetestowedh dt " +
            "INNER JOIN public.StatusDanych sd ON dt.status_danych = sd.lp " +
            "WHERE dt.lp IN ";

    public static final String SELECT_DATA_BY_PERSON = //nr polisy, imie, nazwisko, pesel, telefon
            "SELECT * " +
            "FROM public.danetestowedh dt " +
            "WHERE nr_polisy = ? AND imie = ? AND nazwisko = ? AND pesel = ? AND telefon = ?";

    public static final String SELECT_DATA_ROW_FIRST =
            "SELECT * " +
            "FROM public.danetestowedh dt " +
            "LEFT JOIN public.StatusDanych sd ON dt.status_danych = sd.lp " +
            "WHERE sd.status = 'AKTYWNY' AND dt.env = (" +
                "SELECT lp FROM public.srodowiska s WHERE s.env = ? " +
            ")" +
            "LIMIT 1;";

    public static final String SELECT_UNBOUND_DATA_ROW =
            "SELECT * " +
            "FROM public.DaneTestoweDH dt " +
            "INNER JOIN public.StatusDanych sd ON dt.status_danych = sd.lp " +
            "WHERE dt.mail IS NULL AND sd.status = 'NIEAKTYWNY' AND dt.env = (" +
                    "SELECT lp FROM public.srodowiska s WHERE s.env = ? " +
            ") " +
            "LIMIT 1;";

    public static final String SELECT_FOR_BUSINESS =
            "SELECT dh.lp, tp.typ_polisy, sp.status_polisy, rw.rola_wlasc, dt.telefon, dt.mail " +
            "FROM public.DaneTestoweDH dt " +
            "LEFT JOIN public.TypyPolis tp ON dt.typ_polisy = tp.lp " +
            "LEFT JOIN public.StatusyPolis sp ON dt.status_polisy = sp.lp " +
            "LEFT JOIN public.RoleWlasc rw ON dt.rola_wlasc = rw.lp " +
            "LEFT JOIN public.StatusDanych sd ON dt.status_danych = sd.lp " +
            "WHERE tp.typ_polisy = ? AND sp.status_polisy = ? AND rw.rola_wlasc = ? AND sd.status = 'AKTYWNY' AND NOT dt.env = 3 " +
            "LIMIT ?;";

    public static final String SELECT_UNBOUND_FOR_BUSINESS =
            "SELECT dh.lp, tp.typ_polisy, sp.status_polisy, rw.rola_wlasc, dt.telefon " +
            "FROM public.DaneTestoweDH dt " +
            "LEFT JOIN public.TypyPolis tp ON dt.typ_polisy = tp.lp " +
            "LEFT JOIN public.StatusyPolis sp ON dt.status_polisy = sp.lp " +
            "LEFT JOIN public.RoleWlasc rw ON dt.rola_wlasc = rw.lp " +
            "LEFT JOIN public.StatusDanych sd ON dt.status_danych = sd.lp " +
            "WHERE tp.typ_polisy = ? AND sp.status_polisy = ? AND rw.rola_wlasc = ? AND sd.status = 'NIEAKTYWNY' AND dt.mail = NULL AND NOT dt.env = 3 " +
            "LIMIT ?;";

    public static final String SELECT_LAST_MAIL =
            "SELECT zm.mail " +
            "FROM public.zarejestrowanemaile zm " +
            "ORDER BY zm.lp DESC " +
            "LIMIT 1";

    public static final String SELECT_FIRST_AVAILABLE_MAIL =
            "SELECT zm.mail " +
            "FROM public.zarejestrowanemaile zm " +
            "WHERE zm.wykorzystany = FALSE "+
            "ORDER BY zm.lp ASC " +
            "LIMIT 1";

    public static final String SELECT_DATA_FROM_DH_GROUP_NUMBER =
            "WITH emails AS (\n" +
            "\tSELECT DISTINCT ct.policy_number, pt.participant_code, num.value AS pesel\n" +
            "\tFROM ods.contract ct\n" +
            "\tINNER JOIN ods.participant pt ON ct.contract_id = pt.contract_id AND ct.contract_own_id = pt.contract_own_id\n" +
            "\tINNER JOIN ods.identity_number num ON num.party_id = pt.party_id AND num.party_own_id = pt.party_own_id\n" +
            "\tINNER JOIN ods.party_app_user pau ON pt.party_id = pau.party_id AND pt.party_own_id = pau.party_own_id\n" +
            "\tWHERE ct.product = ? AND ct.status = ? AND LENGTH(num.value) = 11 AND pau.login_name LIKE '%@%'\n" +
            ")\n" +
            "SELECT ct.policy_number AS nr_polisy, ct.product AS typ_polisy, ct.status AS status_polisy, \n" +
            "\tpat.client_description AS rola_wlasc, co.coverage_type AS typ_umowy, \n" +
            "\tpt.participant_code AS nr_potwierdzenia_grupowego, per.first_name AS imie, per.last_name AS nazwisko, \n" +
            "\tnum.value AS pesel, ct.cover_start_date AS data_rozp_polisy, ct.cover_end_date AS data_zak_polisy,\n" +
            "\tpau.login_name AS mail\n" +
            "FROM ods.contract ct\n" +
            "LEFT JOIN ods.participant pt ON ct.contract_id = pt.contract_id AND ct.contract_own_id = pt.contract_own_id\n" +
            "LEFT JOIN ods.person per ON pt.party_id = per.party_id AND pt.party_own_id = per.party_own_id\n" +
            "LEFT JOIN ods.identity_number num ON num.party_id = pt.party_id AND num.party_own_id = pt.party_own_id \n" +
            "LEFT JOIN ods.coverage co ON pt.coverage_id = co.coverage_id AND pt.coverage_own_id = co.coverage_own_id \n" +
            "LEFT JOIN ods.participant_type pat ON pt.participant_type = pat.dict_id AND pt.coverage_own_id = pat.dict_own_id\n" +
            "LEFT JOIN ods.party_app_user pau ON pt.party_id = pau.party_id AND pt.party_own_id = pau.party_own_id\n" +
            "WHERE ct.product = ? AND ct.status = ? \n" +
            "\tAND NOT EXISTS (\n" +
            "\t\tSELECT 1\n" +
            "\t\tFROM emails\n" +
            "\t\tWHERE emails.policy_number = ct.policy_number \n" +
            "\t\t\tAND ((pt.participant_code IS NULL AND emails.participant_code IS NULL) \n" +
            "\t\t\t\t OR emails.participant_code = pt.participant_code)\n" +
            "\t\t\tAND\temails.pesel = num.value\n" +
            "\t) AND pau.login_name NOT LIKE '%@%' \n" +
            "\tAND LENGTH(num.value) = 11--AND num.identity_number_type = 1 \n" +
            "LIMIT ?;"; /*  parametryzacja:
                                      ct.product = typ polisy
                                      ct.status = status polisy
                                      num.identity_number_type '1' = PESEL (argument stały)
                                      LIMIT określany przez ilość sztuk
                                  */

//            "SELECT ct.policy_number AS nr_polisy, ct.product AS typ_polisy, ct.status AS status_polisy, \n" +
//                    "pat.client_description AS rola_wlasc, co.coverage_type AS typ_umowy, \n" +
//                    "pt.participant_code AS nr_potwierdzenia_grupowego, per.first_name AS imie, per.last_name AS nazwisko, \n" +
//                    "num.value AS pesel, ct.cover_start_date AS data_rozp_polisy, ct.cover_end_date AS data_zak_polisy,\n" +
//                    "pau.login_name AS mail\n" +
//                    "FROM ods.contract ct\n" +
//                    "JOIN ods.participant pt ON ct.contract_id = pt.contract_id AND ct.contract_own_id = pt.contract_own_id\n" +
//                    "JOIN ods.person per ON pt.party_id = per.party_id AND pt.party_own_id = per.party_own_id\n" +
//                    "JOIN ods.identity_number num ON num.party_id = pt.party_id AND num.party_own_id = pt.party_own_id \n" +
//                    "JOIN ods.coverage co ON pt.coverage_id = co.coverage_id AND pt.coverage_own_id = co.coverage_own_id \n" +
//                    "JOIN ods.participant_type pat ON pt.participant_type = pat.dict_id AND pt.coverage_own_id = pat.dict_own_id\n" +
//                    "JOIN ods.party_app_user pau ON pt.party_id = pau.party_id AND pt.party_own_id = pau.party_own_id\n" +
//                    "WHERE ct.product = ? AND ct.status = ? AND pau.login_name NOT LIKE '%@%' --AND num.identity_number_type = 1 \n" +
//                    "LIMIT ?";

    public static final String SELECT_DATA_FROM_DH_GROUP_NUMBER_BIZ =
            "WITH emails AS (\n" +
                    "\tSELECT DISTINCT ct.policy_number, pt.participant_code, num.value AS pesel\n" +
                    "\tFROM ods.contract ct\n" +
                    "\tINNER JOIN ods.participant pt ON ct.contract_id = pt.contract_id AND ct.contract_own_id = pt.contract_own_id\n" +
                    "\tINNER JOIN ods.identity_number num ON num.party_id = pt.party_id AND num.party_own_id = pt.party_own_id\n" +
                    "\tINNER JOIN ods.party_app_user pau ON pt.party_id = pau.party_id AND pt.party_own_id = pau.party_own_id\n" +
                    "\tINNER JOIN ods.participant_type pat ON pt.participant_type = pat.dict_id AND pt.coverage_own_id = pat.dict_own_id\n" +
                    "\tWHERE ct.product = ? AND ct.status = ? AND LENGTH(num.value) = 11 AND pat.client_description = ? AND  pau.login_name LIKE '%@%'\n" +
                    ")\n" +
                    "SELECT ct.policy_number AS nr_polisy, ct.product AS typ_polisy, ct.status AS status_polisy, \n" +
                    "\tpat.client_description AS rola_wlasc, co.coverage_type AS typ_umowy, \n" +
                    "\tpt.participant_code AS nr_potwierdzenia_grupowego, per.first_name AS imie, per.last_name AS nazwisko, \n" +
                    "\tnum.value AS pesel, ct.cover_start_date AS data_rozp_polisy, ct.cover_end_date AS data_zak_polisy,\n" +
                    "\tpau.login_name AS mail\n" +
                    "FROM ods.contract ct\n" +
                    "LEFT JOIN ods.participant pt ON ct.contract_id = pt.contract_id AND ct.contract_own_id = pt.contract_own_id\n" +
                    "LEFT JOIN ods.person per ON pt.party_id = per.party_id AND pt.party_own_id = per.party_own_id\n" +
                    "LEFT JOIN ods.identity_number num ON num.party_id = pt.party_id AND num.party_own_id = pt.party_own_id \n" +
                    "LEFT JOIN ods.coverage co ON pt.coverage_id = co.coverage_id AND pt.coverage_own_id = co.coverage_own_id \n" +
                    "LEFT JOIN ods.participant_type pat ON pt.participant_type = pat.dict_id AND pt.coverage_own_id = pat.dict_own_id\n" +
                    "LEFT JOIN ods.party_app_user pau ON pt.party_id = pau.party_id AND pt.party_own_id = pau.party_own_id\n" +
                    "WHERE ct.product = ? AND ct.status = ? \n" +
                    "\tAND pat.client_description = ? \n" +
                    "\tAND NOT EXISTS (\n" +
                    "\t\tSELECT 1\n" +
                    "\t\tFROM emails\n" +
                    "\t\tWHERE emails.policy_number = ct.policy_number \n" +
                    "\t\t\tAND ((pt.participant_code IS NULL AND emails.participant_code IS NULL) \n" +
                    "\t\t\t\t OR emails.participant_code = pt.participant_code)\n" +
                    "\t\t\tAND\temails.pesel = num.value\n" +
                    "\t) AND pau.login_name NOT LIKE '%@%' \n" +
                    "\tAND LENGTH(num.value) = 11--AND num.identity_number_type = 1 \n" +
                    "LIMIT ?"; /*  parametryzacja:
                                      ct.product = typ polisy
                                      ct.status = status polisy
                                      pat.client_description = rola właściciela
                                      num.identity_number_type '1' = PESEL (argument stały)
                                      LIMIT określany przez ilość sztuk
                                  */

    public static final String SELECT_DATA_FROM_DH_POLICE_NUMBER =
            "WITH emails AS (\n" +
                    "\tSELECT DISTINCT ct.policy_number, pt.participant_code, num.value AS pesel\n" +
                    "\tFROM ods.contract ct\n" +
                    "\tINNER JOIN ods.participant pt ON ct.contract_id = pt.contract_id AND ct.contract_own_id = pt.contract_own_id\n" +
                    "\tINNER JOIN ods.identity_number num ON num.party_id = pt.party_id AND num.party_own_id = pt.party_own_id\n" +
                    "\tINNER JOIN ods.party_app_user pau ON pt.party_id = pau.party_id AND pt.party_own_id = pau.party_own_id\n" +
                    "\tWHERE ct.product = ? AND ct.status = ? AND LENGTH(num.value) = 11 AND pau.login_name LIKE '%@%'\n" +
                    ")\n" +
                    "SELECT ct.policy_number AS nr_polisy, ct.product AS typ_polisy, ct.status AS status_polisy, \n" +
                    "\tpt.participant_type AS rola_wlasc, co.coverage_type AS typ_umowy, \n" +
                    "\tper.first_name AS imie, per.last_name AS nazwisko, \n" +
                    "\tnum.value AS pesel, ct.cover_start_date AS data_rozp_polisy, ct.cover_end_date AS data_zak_polisy,\n" +
                    "\tpau.login_name AS mail\n" +
                    "FROM ods.contract ct\n" +
                    "LEFT JOIN ods.participant pt ON ct.contract_id = pt.contract_id AND ct.contract_own_id = pt.contract_own_id\n" +
                    "LEFT JOIN ods.person per ON pt.party_id = per.party_id AND pt.party_own_id = per.party_own_id\n" +
                    "LEFT JOIN ods.identity_number num ON num.party_id = pt.party_id AND num.party_own_id = pt.party_own_id \n" +
                    "LEFT JOIN ods.coverage co ON pt.coverage_id = co.coverage_id AND pt.coverage_own_id = co.coverage_own_id \n" +
                    "LEFT JOIN ods.party_app_user pau ON pt.party_id = pau.party_id AND pt.party_own_id = pau.party_own_id\n" +
                    "WHERE ct.product = ? AND ct.status = ? \n" +
                    "\tAND NOT EXISTS (\n" +
                    "\t\tSELECT 1\n" +
                    "\t\tFROM emails\n" +
                    "\t\tWHERE emails.policy_number = ct.policy_number \n" +
                    "\t\t\tAND ((pt.participant_code IS NULL AND emails.participant_code IS NULL) \n" +
                    "\t\t\t\t OR emails.participant_code = pt.participant_code)\n" +
                    "\t\t\tAND\temails.pesel = num.value\n" +
                    "\t) AND pau.login_name NOT LIKE '%@%' \n" +
                    "\tAND LENGTH(num.value) = 11--AND num.identity_number_type = 1 \n" +
                    "LIMIT ?;"; /*  parametryzacja:
                                      ct.product = typ polisy
                                      ct.status = status polisy
                                      num.identity_number_type '1' = PESEL (argument stały)
                                      LIMIT określany przez ilość sztuk
                                  */

//            "SELECT ct.policy_number AS nr_polisy, ct.product AS typ_polisy, ct.status AS status_polisy,  \n" +
//                    "pt.participant_type AS rola_wlasc, co.coverage_type AS typ_umowy, \n" +
//                    "per.first_name AS imie, per.last_name AS nazwisko, num.value AS pesel,   \n" +
//                    "ct.cover_start_date AS data_rozp_polisy, ct.cover_end_date AS data_zak_polisy,\n" +
//                    "pau.login_name AS mail\n"+
//                    "FROM ods.contract ct\n" +
//                    "JOIN ods.participant pt ON ct.contract_id = pt.contract_id AND ct.contract_own_id = pt.contract_own_id\n" +
//                    "JOIN ods.person per ON pt.party_id = per.party_id AND pt.party_own_id = per.party_own_id\n" +
//                    "JOIN ods.identity_number num ON num.party_id = pt.party_id AND num.party_own_id = pt.party_own_id \n" +
//                    "JOIN ods.coverage co ON pt.coverage_id = co.coverage_id AND pt.coverage_own_id = co.coverage_own_id \n" +
//                    "JOIN ods.party_app_user pau ON pt.party_id = pau.party_id AND pt.party_own_id = pau.party_own_id\n" +
//                    "WHERE ct.product = ? AND ct.status = ? AND num.identity_number_type = '1' AND pau.login_name NOT LIKE '%@%'\n" +
//                    "--AND pt.participant_type = 1 \n" +
//                    "LIMIT ?\n";

    public static final String SELECT_OAN_PARTY_ID =
            "SELECT app_user_id AS oan, party_id AS partyId FROM ods.party_app_user\n" +
                    "WHERE login_name = UPPER(?)";

    public static final String SELECT_APP_LOGIN_CREDENTIALS =
            "SELECT url, login,pass " +
            "FROM public.danelogowania " +
            "WHERE app = ? AND login = ? AND env = ?";

    public static final String UPDATE_MAIL =
            "UPDATE public.danetestowedh " +
            "SET mail = ? " +
            "WHERE lp = ?";

    public static final String UPDATE_DATA_ROW_STATUS =
            "UPDATE public.danetestowedh " +
            "SET status_danych = (" +
                    "SELECT sd.lp " +
                    "FROM public.StatusDanych sd " +
                    "WHERE sd.status = ?" +
                    ")" +
            "WHERE lp = ?";

    public static final String UPDATE_MAIL_STATUS =
            "UPDATE public.zarejestrowanemaile " +
            "SET wykorzystany = TRUE " +
            "WHERE mail = ?";

    public static final String INSERT_DATA_FROM_DH_BASE =
            "INSERT INTO public.danetestowedh(" +
                    "nr_polisy, nr_potwierdzenia_grupowego, typ_polisy, status_polisy, rola_wlasc, typ_umowy, telefon, imie, nazwisko, pesel, data_rozp_polisy, data_zak_polisy, status_danych, env) " +
                    "VALUES "; //tu doklejać grupy argumentów

    public static final String INSERT_DATA_FROM_DH_ARG_STRING = //13 argumentów
            "(?, ?, (" +
                "SELECT tp.lp " +
                "FROM public.typypolis tp " +
                "WHERE tp.typ_polisy = ? " +
            "), (" +
                "SELECT sp.lp " +
                "FROM public.statusypolis sp " +
                "WHERE sp.status_polisy = ? " +
            "), (" +
                "SELECT rw.lp " +
                "FROM public.rolewlasc rw " +
                "WHERE rw.rola_wlasc = ? " +
            "), (" +
                "SELECT ud.lp " +
                "FROM public.umowydodatkowe ud " +
                "WHERE ud.typ_krotki = ? " +
            "), ?, ?, ?, ?, ?, ?, 2, (" +
                "SELECT s.lp " +
                "FROM public.srodowiska s " +
                "WHERE s.env = ?" +
            ")) RETURNING lp";

    /**
     * Insert do bazy maila z oznaczeniem jako 'NIEWYKORZYSTANY' = FALSE
     */
    public static final String INSERT_NEW_MAIL =
            "INSERT INTO public.zarejestrowanemaile (mail, wykorzystany, env, app) " +
                    "VALUES (?, ?, ?, ?)";

    public static final String INSERT_SALESCLOUD_DATA =
            "INSERT INTO public.danesalescloud (" +
                    "nazwa_testu, nazwa_aplikacji, status, etap, param1, param2, param3, param4, param5, param6, param7, param8" +
                    ") VALUES (?, 'SalesCloud', (" +
                        "SELECT sp.lp " +
                        "FROM public.statusypolis sp " +
                        "WHERE sp.status_polisy = ? " +
                    "), ?, ?, ?, ?, ?, ?, ?, ?, ?)";




    public static final String SELECT_PIN_QUOT =
            "SELECT pin AS smsPin\n" +
                    "FROM quotationapp.pin_verification_audit_log pal\n" +
                    "WHERE pal.offer_id = ? \n" +
                    "ORDER BY date DESC\n" +
                    "LIMIT 1";

    public static final String SELECT_COUNT_DATA =
            "SELECT COUNT(*) " +
                    "FROM public.danewynikowe " +
                    "WHERE nazwa_testu = ? AND env = (" +
                        "SELECT lp FROM srodowiska WHERE env = ?" +
                    ") AND etap = ? AND status = 1 AND data_utworzenia::date = CURRENT_DATE";

    public static final String SELECT_MONITOR_DATA =
            "SELECT md.nazwa_testu AS testName, md.etap AS stage, sr.env AS env, " +
            "md.endpoint AS endpoint, md.min_ilosc AS req, md.wlaczony AS enabled " +
                    "FROM public.monitordanych md " +
                    "INNER JOIN public.srodowiska sr ON md.env = sr.lp " +
                    "WHERE sr.env = ?";
}
