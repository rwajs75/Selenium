package helpers.dictionary.testdata;

public enum DataRowStatus {
    AKTYWNY (1),
    NIEAKTYWNY (2),
    BIZNES (3),
    PROCESOWANIE (4);

    private int id;

    private DataRowStatus (int id){
        this.id = id;
    }

    public int getStatusId() {
        return this.id;
    }

    public static DataRowStatus[] statuses = {AKTYWNY, NIEAKTYWNY, BIZNES, PROCESOWANIE};
}
