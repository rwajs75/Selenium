package helpers.dictionary;

public class StaticStrings {

    public static final String NO_SUCH_PRODUCT = "Nie znaleźliśmy żadnych produktów";
    public static final String REGISTRATON_ERROR = "Podczas rejestracji wystąpił błąd...";
    public static final String TASK_CANCELLED = "A task was cancelled";
    public static final String TECHNICAL_PROBLEMS = "Technical problems";
    public static final String UNDER_18 = "Osoba poniżej 18 r.ż.";
    public static final String ERR_503 = "503 Usługa niedostępna.";
    public static final String NRTEL = "784088672";
    public static final String PLIK_PNG = "G:\\Sekcja Zarządzania Testami\\autoCZT\\PlikiTestowe\\upload.png";
    public static final String TEST_SKIP = "Skrypt w trakcie przebudowy";
}
