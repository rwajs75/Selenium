package helpers.urls;

public class MyAvivaURL {

    private static final String BASE_URL_CP = "https://moja-uat.cu.com.pl";
    private static final String BASE_URL_UT = "https://moja-it.cu.com.pl";

    public static String getBaseUrl(String env) {
        return env.equals("CP") ? BASE_URL_CP  : BASE_URL_UT ;
    }

    public static String registrationPageUrl(String env) {
        return getBaseUrl(env) + "/Konto/Rejestracja/Krok1";
    }

    public static String loginPageUrl(String env) {
        return getBaseUrl(env) + "/Konto/logowanie/";
    }

    public static String touUpdatePage(String env) {
        return getBaseUrl(env) + "/Profil/PotwierdzenieRegulaminu";
    }

    public static String guestHomePage(String env) {
        return getBaseUrl(env) + "/Profil/Gosc";
    }

    public static String userHomePage(String env) {return getBaseUrl(env) + "/Profil/Polisy"; }

    public static String myProfilePage(String env) {
        return getBaseUrl(env) + "/Profil/MojProfil";
    }

    public static String mojeWnioski(String env) {
        return env.equals("CP") ? BASE_URL_CP + "/Portal/Wnioski" : BASE_URL_UT + "/Portal/Wnioski";
    }

    public static String szkodyRoszczenia(String env) {
        return env.equals("CP") ? BASE_URL_CP + "/Portal/SzkodyRoszczenia" : BASE_URL_UT + "/Portal/SzkodyRoszczenia";
    }

    public static String mojProfil(String env) {
        return env.equals("CP") ? BASE_URL_CP + "/Profil/MojProfil" : BASE_URL_UT + "/Profil/MojProfil";
    }

    public static String wyloguj(String env) {
        return env.equals("CP") ? BASE_URL_CP + "/Profil/Wylogowanie" : BASE_URL_UT + "/Profil/Wylogowanie";
    }

    public static String przypomnienieLoginuZnaleziono (String env) {
        return getBaseUrl(env) + "/Konto/PrzypomnienieDanych/Znaleziono";
    }

    public static String przypomnienieLoginu(String env) {
        return getBaseUrl(env) + "/Konto/PrzypomnienieDanych/PrzypomnienieLoginu";
    }

    public static String przypomnienieLoginuDane(String env) {
        return getBaseUrl(env) + "/Konto/PrzypomnienieDanych/PrzypomnienieDanychFormularz";
    }
}


