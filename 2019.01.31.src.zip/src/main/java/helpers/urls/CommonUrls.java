package helpers.urls;

public class CommonUrls {

    public static final String DBMANAGER_URL = "http://10.3.134.118:25001";
    public static final String YOPMAIL_URL = "http://www.yopmail.com/pl/";

    //CP
    public static final String AGRUPA_DOMAIN_CP = "https://bal.cu.com.pl:18643";
    public static final String MYA_DOMAIN_CP = "https://moja-uat.cu.com.pl";
    public static final String SC_DOMAIN_CP = "https://salescloud-uat2.aviva.pl";
    public static final String HOUSE_DOMAIN_CP = "https://dom-uat2.aviva.pl";
    public static final String MOTO_DOMAIN_CP = "https://ikonto-dev.cu.com.pl";
    public static final String TIA7_DOMAIN_CP = "https://tia-app-d04.cu.com.pl";
    public static final String WPA_DOMAIN_CP = "https://www.moja-test.aviva.pl";
    public static final String WPJV_DOMAIN_CP = "https://test.ubezpieczeniaportal.pl";
    public static final String CAS_DOMAIN_CP = "https://cas-uat2.aviva.pl";

    //UT
    public static final String AGRUPA_DOMAIN_UT = "https://bal.cu.com.pl:18743";
    public static final String MYA_DOMAIN_UT = "https://moja-it.cu.com.pl";
    public static final String SC_DOMAIN_UT = "https://salescloud-uat.aviva.pl";
    public static final String HOUSE_DOMAIN_UT = "https://dom-uat.aviva.pl";
    public static final String MOTO_DOMAIN_UT = "https://ikonto-dev1.cu.com.pl";
    public static final String TIA7_DOMAIN_UT = "https://tia-app-d03.cu.com.pl";
    public static final String WPA_DOMAIN_UT = "https://www.moja-ut.aviva.pl";
    public static final String WPJV_DOMAIN_UT = "https://ut.ubezpieczeniaportal.pl";
    public static final String CAS_DOMAIN_UT = "https://cas-test.aviva.pl";
}
