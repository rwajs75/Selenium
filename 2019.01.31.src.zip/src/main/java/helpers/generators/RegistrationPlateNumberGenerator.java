package helpers.generators;

import java.security.SecureRandom;

/**
 * Klasa generująca przypadkowe numery tablic rejestracyjnych.
 */
public class RegistrationPlateNumberGenerator {

    private static final String NUM = "0123456789";
    private static final String tab = "XX";
    private static SecureRandom rnd = new SecureRandom();

    public static String tablica(){

        String a, NR1, NR2, NR3;

        NR1 = tab;
        NR2 = randomNumString(4);
        NR3 = randomNonZeroNumString(1);
        a = NR1 + NR2 + NR3;

        return (a);
    }

    public static String randomNumString(int len ){
        StringBuilder sb = new StringBuilder( len );
        for( int i = 0; i < len; i++ )
            sb.append( NUM.charAt( rnd.nextInt(10) ) );
        return sb.toString();
    }

    public static String randomNonZeroNumString(int len ){
        StringBuilder sb = new StringBuilder( len );
        for( int i = 0; i < len; i++ )
            sb.append( NUM.charAt( rnd.nextInt(9) + 1 ) );
        return sb.toString();
    }
}
