package helpers.generators;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Random;

public class IBANGenerator {

    private static final String NUM = "0123456789";

    public static String generateIBAN() {
        StringBuilder iban = new StringBuilder("PL00");
        Random rand = new SecureRandom();
        for (int i = 0; i < 24; i++) {
            iban.append(NUM.charAt(rand.nextInt(10)));
        }

        String mid = iban.toString();
        mid =  generateControl(mid);
        mid = mid.substring(0, 4) + " " + mid.substring(4, 8) + " " +  mid.substring(8, 12) + " " +
                mid.substring(12, 16) + " " + mid.substring(16, 20) + " " + mid.substring(20, 24) + " " +
                mid.substring(24, 28);
        return mid;
    }

    private static String generateControl(String ibanMid) {
        BigInteger sum = new BigInteger(ibanMid.substring(4) + "252100");
        int ctrl = 98 - sum.mod(new BigInteger("97")).intValue();
        String iban = "PL";
        if (ctrl < 10) iban += "0" + ctrl;
        else iban += ctrl;
        iban += ibanMid.substring(4);
        return iban;
    }
}
