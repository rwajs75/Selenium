package helpers.generators;

import java.security.SecureRandom;

/**
 * Klasa generująca przypadkowe numery VIN.
 */
public class VINGenerator {

    private static final String ANUM = "0123456789ABCDEFGHJKLMNPRSTUVWXYZ";
    private static final String NUM = "0123456789";
    private static SecureRandom rnd = new SecureRandom();

    /**
     * Generuje przypadkowy formalnie poprawny numer VIN.
     * <br><br>
     * - Litery I, O oraz Q nie są dozwolone.<br>
     * - Ostatnie cztery znaki stanowią zawsze cyfry.<br>
     * - format: 3/6/8  WMI/VDS/VIS
     */
    public static String vin() {

        String a, WMI, VDS, VIS1, VIS2;
        WMI = randomANumString(3);
        VDS = randomANumString(6);
        VIS1 = randomANumString(4);
        VIS2 = randomNumString(4);

        a = WMI + VDS + VIS1 + VIS2;

        return (a);
    }

    public static String randomANumString(int len ){
        StringBuilder sb = new StringBuilder( len );
        for( int i = 0; i < len; i++ )
            sb.append( ANUM.charAt( rnd.nextInt(ANUM.length()) ) );
        return sb.toString();
    }

    public static String randomNumString(int len ){
        StringBuilder sb = new StringBuilder( len );
        for( int i = 0; i < len; i++ )
            sb.append( NUM.charAt( rnd.nextInt(NUM.length()) ) );
        return sb.toString();
    }

}
