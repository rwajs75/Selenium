package helpers.generators;

import java.util.Random;

public class RandomStringGenerator {

    public static String generateCharsSequence() {
        int minimumCharSequenceLength = 10;
        int maximumCharSequenceLength = 15;
        Random random = new Random();
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i <= generateRandomNumberFromRange(random, maximumCharSequenceLength, minimumCharSequenceLength); i++) {
            stringBuilder.append(getRandomCharacter(random));
        }
        return stringBuilder.toString();
    }

    private static char getRandomCharacter(Random random) {
        char[] chars = "aąbcdefghijkłmoópzźżĄBCDEFGHIJKŁMNOÓQYŻŹ".toCharArray();
        return chars[random.nextInt(chars.length)];
    }

    private static int generateRandomNumberFromRange(Random random, int maximumCharSequenceLength, int minimumCharSequenceLength) {
        return random.nextInt((maximumCharSequenceLength - minimumCharSequenceLength) + 1) + minimumCharSequenceLength;
    }
}
