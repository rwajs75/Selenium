package helpers.generators;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

/**
 * Klasa generująca numery PESEL.
 */
public class PESELGenerator {

    private static String calculateMonthNumber(int month, int year) {
        if (year >= 1800 && year < 1900)
            return Integer.toString(month + 80);
        else if (year < 2000)
            return (month < 10 ? "0" + month : "" + month);
        else if (year < 2100)
            return Integer.toString(month + 20);
        else if (year < 2200)
            return Integer.toString(month + 40);
        else if (year < 2300)
            return Integer.toString(month + 60);
        else
            throw new IllegalArgumentException("Podany rok nie jest obejmowany numerem PESEL");
    }

    /**
     * Generuje przypadkowy numer PESEL dla daty z zakresu 01.01.1930 - 31.12.1999.
     * @param p litera określająca płeć (m = mężczyzna, k = kobieta)
     * @return wygenerowany numer PESEL
     */
    public static String generatePESEL(char p) {
        if (p != 'm' && p != 'k') throw new IllegalArgumentException();

        String rok = genarateXXCentYear(), miesiac = generateMonth(), dzien = generateDay(), liczba = serial(p);

        if (miesiac.equals("00")){
            do{
                miesiac = generateMonth();
            } while(miesiac.equals("00"));

        }

        int dz = Integer.parseInt(dzien);
        if (miesiac.equals("02") && (dz > 28 || dzien.equals("00"))){
            do{
                dz = Integer.parseInt(generateDay());
                dzien = generateDay();
            } while(dz > 28 || dzien.equals("00"));

        }

        if(miesiac.equals("04") || miesiac.equals("06") || miesiac.equals("09") || miesiac.equals("11")) {
            while (dzien.equals("00") || dzien.equals("31")){
                dzien = generateDay();
            }
        }

        if (dzien.equals("00")){
            do{
                dzien = generateDay();
            } while(dzien.equals("00"));

        }

        /*int kontrola = Integer.parseInt(miesiac), rok_sp = Integer.parseInt(rok);
        if (kontrola <10)
        {
            miesiac = "0" + Integer.toString(kontrola);
        }

        rok = rok.substring(2);
        String wejscie = rok+miesiac+dzien+liczba;
        String str = controlDigit(wejscie);
        String pesel = rok+miesiac+dzien+liczba+str;

        return (pesel);*/

        return generatePESELForDate(Integer.parseInt(rok), Integer.parseInt(miesiac), Integer.parseInt(dzien), p);

    }

    /**
     * Generuje numer PESEL dla osoby urodzonej o podanej {@link Date dacie}.
     * @param date data urodzenia
     * @param p litera określająca płeć (m = mężczyzna, k = kobieta)
     * @return wygenerowany numer PESEL
     */
    public static String genaratePESELForDate(Date date, char p) {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        return  generatePESELForDate(year, month, day, p);
    }

    /**
     * Generuje numer PESEL dla osoby urodzonej o podanej dacie.
     * @param year rok urodzenia
     * @param month miesiąc urodzenia
     * @param day dzień urodzenia
     * @param p litera określająca płeć (m = mężczyzna, k = kobieta)
     * @return wygenerowany numer PESEL
     */
    public static String generatePESELForDate(int year, int month, int day, char p){
        int yearAbbrev = year % 100;

        StringBuilder pesel = new StringBuilder("" + yearAbbrev);
        pesel.append(calculateMonthNumber(month, year));
        pesel.append(day < 10 ? "0" + day : day);
        pesel.append(serial(p));
        pesel.append(controlDigit(pesel.toString()));

        return pesel.toString();
    }

    public static String genarateXXCentYear() {
        Random rand = new Random();
        int wynik, x = 1930, y = 1999;
        wynik = rand.nextInt(y-x+1)+x;
        return "" + wynik;
    }

    public static String generateMonth() {
        Random rand = new Random();
        int a, b;

        a = rand.nextInt(2);

        if (a == 0) {
            b = rand.nextInt(9) + 1;
        }
        else {
            b = rand.nextInt(3);
        }

        return "" + a + "" + b;
    }

    public static String generateDay() {
        Random rand = new Random();
        int a, b;

        a = rand.nextInt(3);

        if (a == 0)
            b = rand.nextInt(9) + 1;
        else if(a == 1 || a == 2) {
            b = rand.nextInt(10);
        }
        else {
            b = rand.nextInt(2);
        }

        return "" + a + "" + b;
    }

    public static String serial(char p) {
        //m = nieparzysta, k = parzysta

        String serial = null;

        if(p == 'k') {
            Random rand = new Random();
            int a = rand.nextInt(1000);
            serial = "" + a;
            int b = serial.length();
            if (b == 1) {
                serial = "00" + serial;
            } else if (b == 2) {
                serial = "0" + serial;
            }
            int c = rand.nextInt(5);
            c = c*2;
            serial = serial + c;
        }

        if(p == 'm') {
            Random rand = new Random();
            int a = rand.nextInt(1000);
            serial = Integer.toString(a);
            int b = serial.length();
            if (b == 1) {
                serial = "00" + serial;
            } else if (b == 2) {
                serial = "0" + serial;
            }
            int c = rand.nextInt(5);
            c = c*2+1;
            serial = serial + c;
        }

        return serial;
    }

    public static String controlDigit(String str){
        int edycja;
        int wynik = 0;
        int[] digit = new int[10];
        int[] weight= new int[10];
        for (int i = 0; i < 10; ++i){
            edycja = Character.getNumericValue(str.charAt(i));
            digit[i] = edycja;
        }
        weight[0]=1;
        weight[1]=3;
        weight[2]=7;
        weight[3]=9;
        weight[4]=1;
        weight[5]=3;
        weight[6]=7;
        weight[7]=9;
        weight[8]=1;
        weight[9]=3;

        for(int x = 0; x < 10 ; x++){
            wynik += digit[x] * weight[x];
        }

        wynik = wynik % 10;

        wynik = 10 - wynik;

        wynik = wynik % 10;
        str = Integer.toString(wynik);
        return(str);
    }

    public static char getGender(String pesel){
        if((Integer.parseInt(pesel.substring(9,10)) % 2) == 0) return 'k';
        else return 'm';
    }

    public static String getBirthDate(String pesel, DateTimeFormatter format){
        int year, month, day;
        year = Integer.parseInt(pesel.substring(0, 2));
        month = Integer.parseInt(pesel.substring(2, 4));
        day = Integer.parseInt(pesel.substring(4, 6));

        if (month < 13) year += 1900;
        else if (month < 33) {year += 2000; month -= 20;}
        else if (month < 53) {year += 2100; month -= 40;}
        else if (month < 73) {year += 2200; month -= 60;}
        else {year += 1800; month -= 80;}

        return LocalDate.of(year, month, day).format(format);
    }

}
