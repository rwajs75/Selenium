package helpers.generators;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * Klasa generująca daty z przyszłości i przeszłości
 * */

public class DataGenerator {

    /**
     * Funcja zwraca datę w przyszłości
     * @param liczbaDni za ile dni od dziś
     * @return [0] rok w formacie rrrr
     * @return [1] nazwę miesiąca słownie z dużej litery
     * @return [2] dzień miesiąca liczbowo d
     * */
    public static String[] dateInFuture (int liczbaDni) {
        String rok = LocalDate.now().plusDays(liczbaDni).format(DateTimeFormatter.ofPattern("yyyy"));
        String miesiac = LocalDate.now().plusDays(liczbaDni).getMonth().getDisplayName(TextStyle.FULL_STANDALONE, Locale.forLanguageTag("pl-PL"));
        String Miesiac = miesiac.substring(0, 1).toUpperCase() + miesiac.substring(1);
        String dzien = LocalDate.now().plusDays(liczbaDni).format(DateTimeFormatter.ofPattern("d"));
        return new String[] {rok, Miesiac, dzien};
    }

    /**
     * Funcja zwraca datę z przeszłości
     * @param liczbaDni ile dni temu
     * @return [0] rok w formacie rrrr
     * @return [1] nazwę miesiąca słownie z dużej litery
     * @return [2] dzień miesiąca liczbowo d
     * */
    public static String[] dateFromPast (int liczbaDni) {
        String rok = LocalDate.now().minusDays(liczbaDni).format(DateTimeFormatter.ofPattern("yyyy"));
        String miesiac = LocalDate.now().minusDays(liczbaDni).getMonth().getDisplayName(TextStyle.FULL_STANDALONE, Locale.forLanguageTag("pl-PL"));
        String Miesiac = miesiac.substring(0, 1).toUpperCase() + miesiac.substring(1);
        String dzien = LocalDate.now().minusDays(liczbaDni).format(DateTimeFormatter.ofPattern("d"));
        return new String[] {rok, Miesiac, dzien};
    }

    /**
     * Funcja zwraca datę z przeszłości
     * @param liczbaDni ile dni temu
     * @return [0] rok w formacie rrrr
     * @return [1] miesiąc liczbow mm
     * @return [2] dzień miesiąca liczbowo dd
     * */
    public static Integer[] dateFromPastInt (int liczbaDni) {
        int rok = Integer.parseInt(LocalDate.now().minusDays(liczbaDni).format(DateTimeFormatter.ofPattern("yyyy")));
        int miesiac = Integer.parseInt(LocalDate.now().minusDays(liczbaDni).format(DateTimeFormatter.ofPattern("MM")));
        int dzien = Integer.parseInt(LocalDate.now().minusDays(liczbaDni).format(DateTimeFormatter.ofPattern("dd")));
        return new Integer[] {rok, miesiac, dzien};
    }
}
