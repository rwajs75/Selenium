package helpers.generators;

import java.util.Random;

public class RandomIntGenerator {

    public static int liczbaLosowa(int od, int zakres) {
        Random generator = new Random();
        int liczba = generator.nextInt(zakres) + od;
        return liczba;
    }
}
