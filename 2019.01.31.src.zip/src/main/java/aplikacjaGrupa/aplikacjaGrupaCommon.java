package aplikacjaGrupa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class aplikacjaGrupaCommon {

    public static void clickRandomPoliceNumber(WebDriver driver) {

        List<WebElement> items = driver.findElements(By.xpath("//div[@id='submenu']/ul/li"));
        for (WebElement e : items) {
            System.out.print(e.getText());
            if (e.getText().startsWith("1") || e.getText().startsWith("2") || e.getText().startsWith("3")) {
                System.out.println(" > Polisa zaczyna się od 1,2 lub 3");
            } else {
                System.out.println(" > Polisa NIE zaczyna się od 1,2 lub 3");
            }
        }
        int size = items.size();
        int randnMumber = ThreadLocalRandom.current().nextInt(0, size);
        items.get(randnMumber).click();
    }
}
