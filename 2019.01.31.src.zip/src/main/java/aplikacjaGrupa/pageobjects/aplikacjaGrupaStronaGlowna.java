package aplikacjaGrupa.pageobjects;

import helpers.common.Common;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import java.util.NoSuchElementException;
import static helpers.common.Common.scrollToElement;

public class aplikacjaGrupaStronaGlowna {

    //ZADANIA
    @FindBy(xpath = "//*[@id='submenu']/*[contains(text(),'Zadania')]")
    public static WebElement menuZadania;

    @FindBy(xpath = "//*[@id='submenu']/*[contains(text(),'Formularze')]")
    public static WebElement menuFormularze;

    @FindBy(xpath = "//*[@id='submenu']/*[contains(text(),'Komunikaty')]")
    public static WebElement menuKomunikaty;

    @FindBy(xpath = "//*[@id='submenu']/*[contains(text(),'Administracja')]")
    public static WebElement menuAdministracja;

    @FindBy(xpath = "//*[@id='submenu']/*[contains(text(),'Pomoc')]")
    public static WebElement menuPomoc;




    /**
     * Funkcja klikająca po Menu / SubMenu aplikacji Grupa
     * @wyborMenu : menu (belka górna) / submenu (pasek boczny)
     * @pozycjaMenu : Polisy / Pre-zadania / Zadania / Formularze / Komunikaty / Administracja / Pomoc
     */

    public static void AGMenu(String wyborMenu, String pozycjaMenu, WebDriver driver) {

        WebElement element = driver.findElement(By.xpath("//*[@id='"+wyborMenu+"']//a[@title='\t"+pozycjaMenu+"\t']"));
        try{
            if (!element.isEnabled()){
                Common.reporter().logPass("Pozycja menu o lokatorze " + element + " jest włączona");
            }
            scrollToElement(element);
            if (element.isDisplayed()){
                element.click();
                Common.reporter().logPass("Kliknięto w pozycję menu o lokatorze " + element);
            }
        } catch (NoSuchElementException e){
            Common.reporter().logFail("Nie znaleziono pozycji menu o lokatorze " + element);
        } catch (ElementClickInterceptedException e){
            Common.reporter().logFail("Pozycja menu o lokatorze " + element + " jest niewidoczna");
        }
    }

    @FindBy(xpath = "//*[@id=\"location\"]/a")
    public static WebElement przyciskStronaGlowna;


}
