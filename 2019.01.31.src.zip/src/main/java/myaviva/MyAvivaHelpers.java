package myaviva;

import formularz.life.pageobjects.Life;
import formularz.moto.pageobjects.MotoTwojaOferta;
import helpers.database.dto.TestDTO;
import helpers.database.TestDataManager;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.generators.RandomIntGenerator;
import helpers.generators.RandomStringGenerator;
import helpers.login.Login;
import helpers.restapi.Rest;
import helpers.throwables.PoliceUpgradeFailureException;
import helpers.urls.MyAvivaURL;
import myaviva.pageobjects.*;
import myaviva.pageobjects.gosc.MyAvivaStronaGlownaGoscia;
import myaviva.pageobjects.gosc.MyAvivaZnajdzProdukt;
import myaviva.pageobjects.life.LifeSzczegoly;
import myaviva.pageobjects.life.LifeUposazeni;
import myaviva.pageobjects.life.LifeZmianaFunduszy;
import myaviva.pageobjects.mojProfil.MojProfil;
import myaviva.pageobjects.moto.*;
import myaviva.pageobjects.travel.TravelDokumenty;
import myaviva.pageobjects.travel.TravelSzczegoly;
import myaviva.pageobjects.travel.kupPolise.TravelDaneDoUbezpieczenia;
import myaviva.pageobjects.travel.kupPolise.TravelOferta;
import myaviva.pageobjects.travel.kupPolise.TravelPodsumowanie;
import myaviva.pageobjects.travel.kupPolise.TravelSprawdzCeneUbezpieczenia;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static helpers.common.Common.*;
import static helpers.dictionary.StaticStrings.*;
import static helpers.login.Login.handleTOUUpdate;
import static myaviva.pageobjects.MyAvivaRejestracjaKrok1.*;
import static myaviva.pageobjects.MyAvivaStronaLogowania.przyciskZalozKonto;
import static myaviva.pageobjects.MyAvivaZmienHaslo.*;
import static myaviva.pageobjects.gosc.MyAvivaStronaGlownaGoscia.*;
import static myaviva.pageobjects.gosc.MyAvivaZnajdzProdukt.*;

public class MyAvivaHelpers {

    private static final int PIN_WAIT_TIME = 60000;

    private static WebDriver driver;
    private static TestDataManager manager;

    public static void upgradeDataRow(int id, WebDriver driver, TestDataManager manager, String env) { //env = CP / UT
        MyAvivaHelpers.driver = driver;
        MyAvivaHelpers.manager = manager;
        TestDTO toBind;
        try {
            //pobranie ostatniego dostępnego maila
            String newMail = manager.checkLastUnusedMail();
            if (newMail == null) {//jak nie ma to rejestrujemy nowy
                registerMailMyAviva(driver, manager, env);
                newMail = manager.checkLastUnusedMail();
            } else {
                Login.loginToAccountMyAviva(env, newMail, driver);
            }
            if (driver.getTitle().contains("503")) {
                reporter().logFail(ERR_503);
            }
            try {
                driver.findElement(By.xpath("//*[contains(text(), 'Ustawianie hasła')]"));
                changeAccountPassword(env);
                Login.loginToAccountMyAviva(env, newMail, driver);
            } catch (NoSuchElementException ignored) {
            } //TODO obsługa zmiany hasła

            while (true) {
                //if (toBind != null && id > 0) throw new PoliceUpgradeFailureException(id);

                if (!driver.getCurrentUrl().equals(MyAvivaURL.guestHomePage(env))) {
                    driver.get(MyAvivaURL.guestHomePage(env));
                }

                PageFactory.initElements(driver, MyAvivaStronaGlownaGoscia.class);
                handlePopUps();
                clickElement(myProductsButton);
                try {
                    if (id > 0) {
                        toBind = manager.getRowByIdForProcessing(id);
                    } else {
                        toBind = manager.getRowForProcessing(env);
                    }
                    while (!verifyState(toBind)) {
                        if (id > 0) {
                            throw new IllegalStateException("Błędny status danej: " + toBind.getStatus_polisy());
                        } else {
                            toBind = manager.getRowForProcessing(env);
                        }
                    }
                } catch (IndexOutOfBoundsException e) {
                    reporter().logError("Brak danych dostępnych do procesowania." +
                            " Pobierz dodatkowe dane lub sprawdź statusy obecnych.");
                    throw new PoliceUpgradeFailureException(e);
                }
                reporter().logPass("Upgrade rekordu o id " + toBind.getLp());
                String pesel = toBind.getPesel();
                reporter().logPass("Użyty PESEL: " + pesel);
                pauseFor(2);
                PageFactory.initElements(driver, MyAvivaZnajdzProdukt.class);
                clickElement(peselButton);
                enterIntoElement(peselInputField, pesel);

            /* Wyciąganie daty z numeru PESEL

             Common.getWebElement(driver, dayOfBirthInputField).sendKeys(pesel.substring(4, 6));
             monthOfBirthInputField.sendKeys(pesel.substring(2, 4));
             yearOfBirthInputField.sendKeys("19" + pesel.substring(0, 2));

             */
                // Dane z wiersza BD
                enterIntoElement(productNumberInputField, Integer.toString(toBind.getNr_polisy()));

                if (waitUntilElementPresent(under18, 3) != null) {
                    manager.updateMailForData(UNDER_18, toBind.getLp());
                    continue;
                }
                enterIntoElement(mobileNumberInputField, toBind.getTelefon());
                enterIntoElement(firstNameInputField, toBind.getImie());
                enterIntoElement(lastNameInputField, toBind.getNazwisko());
                clickElement(upgradeSubmitButton); //pauseFor(15);
                if (waitUntilElementPresent(alreadyRegistered, 15) != null) {
//                    reporter().logWarn("Mail posiada już zarejestrowaną polisę; pobieranie nowego maila...");
//                    newMail = manager.checkLastUnusedMail();
//                    if (newMail == null) {
//                        logout();
//                        registerMailMyAviva(driver, manager);
//                    }

                    handleAlreadyRegistered(toBind, env);
                    //newMail = changeMail(); TODO przenieść
                    continue;

                } else if (waitUntilElementPresent(aTaskWasCancelledMsg, 15) != null) {
                    manager.updateMailForData(TASK_CANCELLED, toBind.getLp());
                    reporter().logWarn(TASK_CANCELLED);
                    continue;
                } else if (waitUntilElementPresent(errorMsg, 15) != null) {
                    manager.updateMailForData(REGISTRATON_ERROR, toBind.getLp());
                    reporter().logWarn(REGISTRATON_ERROR);
                    continue;
                } else if (waitUntilElementPresent(productNotFoundMsg, 15) != null) {
                    manager.updateMailForData(NO_SUCH_PRODUCT, toBind.getLp());
                    reporter().logWarn(NO_SUCH_PRODUCT);
                    continue;
                } else if (waitUntilElementPresent(technicalProblemsMsg, 15) != null) {
                    manager.updateMailForData(TECHNICAL_PROBLEMS, toBind.getLp());
                    reporter().logWarn(TECHNICAL_PROBLEMS);
                    continue;
                } else { //TODO: czy da się wywalić weryf. dwuetapową?; przenieść na górę
                    PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
                    if (handleTwoFA(newMail, env)) {
                        manager.updateMailStatus(newMail);
                        manager.updateMailForData(newMail, toBind.getLp());
                        manager.updateDataStatus(DataRowStatus.AKTYWNY, toBind.getLp());
                    } else {
                        manager.updateMailForData(TECHNICAL_PROBLEMS, toBind.getLp());
                        reporter().logWarn(TECHNICAL_PROBLEMS);
                        continue;
                    }
                }

                waitTillSpinnerDisable2(MyAvivaCommonPageObjects.ladowanieDanych, 300, true);
                waitTillSpinnerDisable2(MyAvivaCommonPageObjects.ladowanieDanych1, 300, true);

/*
                if (waitUntilElementVisible(kreciol, 10)!=null &&
                        !waitUntilElementStale(kreciol,300))
                    reporter().logFail("Ładowanie trwa zbyt długo (300s)");
*/

//                logout(env);
//                Logowanie.loginToAccountMyAviva(env, newMail, driver);
                break;
            }
            reporter().logPass("Upgrade przeszedł pomyślnie.");
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    private static void logout(String env) {
        PageFactory.initElements(driver, MyAvivaStronaLogowania.class);
        PageFactory.initElements(driver, MyAvivaStronaGlownaGoscia.class);
        clickElement(myAccountButton);
        try {
            waitUntilElementVisible(logoutButton, 30).click();
            if (!driver.getCurrentUrl().equals(MyAvivaURL.loginPageUrl(env))) {
                driver.get(MyAvivaURL.loginPageUrl(env));
            }
        } catch (NullPointerException e) {
            reporter().logFail("Nie udało się wylogować - nadal widoczna jest strona startowa.");
        }
    }

    private static boolean handleTwoFA(String email, String env) {
        try {
            Map<String, String> map = manager.getUsersOanAndPartyId(email, env);
            reporter().logPass("Oczekiwanie na PIN - " + (PIN_WAIT_TIME / 1000) + " s...");
            pauseFor(PIN_WAIT_TIME / 1000);
            enterIntoElement(smsInputField, Rest.getTwoFAPin(map.get("partyId"), map.get("oan"), StaticStrings.NRTEL, env));
            clickElement(saveButton);
            PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
            waitTillSpinnerDisable2(MyAvivaCommonPageObjects.ladowanieDanych, 30, true);
            waitTillSpinnerDisable2(MyAvivaCommonPageObjects.ladowanieDanych1, 30, true);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    private static boolean verifyState(TestDTO data) {
        return data.getStatus_danej() == DataRowStatus.NIEAKTYWNY &&
                data.getMail() == null;
    }

    public static String [] registerMailMyAviva(WebDriver driver, TestDataManager manager, String env) {
        PageFactory.initElements(driver, MyAvivaStronaLogowania.class);
        PageFactory.initElements(driver, MyAvivaRejestracjaKrok1.class);
        try {
            String daneKonta[];
            driver.get(MyAvivaURL.loginPageUrl(env));
            String newMail = manager.registerNewMailForApp("MyAviva", env);
            daneKonta = registerAccountForMail(newMail, env);
            if (waitUntilElementPresent(messageProblemyKomunkcyjne,5) != null)
                reporter().logFail("Niepowodzenie rejestracji maila: problemy komunikacyjne");
            try {
                driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
                if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Ustawianie hasła')]"), 15) != null) {
                    reporter().logPass("Wykryto monit zmiany hasła");
                    changeAccountPassword(env);
                }
                String activationUrl = Rest.getActivationLink(newMail, env);
                if (activationUrl == null)
                    reporter().logFail("Niepowodzenie aktywacji maila: nie udało się pobrać linku aktywacyjnego.");
                else driver.get(activationUrl);
                reporter().logPass("Mail " + newMail + " jest gotowy do użytku.");
                return new String[] {daneKonta[0],daneKonta[1],daneKonta[2]};
            } catch (Exception e) {
                manager.updateMailStatus(newMail);
                reporter().logFail("Niepowodzenie aktywacji maila");
            }
            //logout(env);
        } catch (Exception e) {
            reporter().logError("Niepowodzenie rejestracji maila", e);
        }
        return null;
    }

    private static String [] registerAccountForMail(String mail, String env) {
        TestDataManager manager = new TestDataManager(env);
        clickElement(przyciskZalozKonto);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
        String imie = "IMIE"+RandomStringGenerator.generateCharsSequence().toUpperCase();
        String nazwisko = "NAZWISKO"+RandomStringGenerator.generateCharsSequence().toUpperCase();
        enterIntoTextField(poleTekstoweImie, imie);
        enterIntoTextField(poleTekstoweNazwisko, nazwisko);

        do {
            if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Istnieje już konto')]"),5) != null)
                manager.updateMailStatus(mail);
            //mail = updateMailIndex(mail);
            enterIntoTextField(poleTekstoweEMAIL, mail);
            enterIntoTextField(poleTekstowePotwierdzEMAIL, mail);
        } while (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Istnieje już konto')]"),5) != null);
        enterIntoTextField(poleTekstoweHaslo, "Aviva123");
        clickElement(poleOpcjiAkceptuj);
        clickElement(przyciskZalozKontoRej);
        return new String[]{imie, nazwisko, mail};
    }

    public static void handlePopUps() {
        PageFactory.initElements(driver, MyAvivaStronaGlowna.class);
        if (waitUntilElementVisible(MyAvivaStronaGlowna.ramkaPopUp, 5) != null) {
            clickElement(MyAvivaStronaGlowna.ramkaZamknij);
        }
        pauseFor(3);
    }

    private static void changeAccountPassword(String env) {
        PageFactory.initElements(driver, MyAvivaZmienHaslo.class);
        String pass = manager.getLoginCredentials("MyAviva", "", env).get(2);
        enterIntoElement(poleTekstoweNoweHaslo, pass);
        enterIntoElement(poleTekstowePotwierdzHaslo, pass);
        clickElement(przyciskZmienHaslo);
        if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Ustawianie hasła')]"), 10) == null) {
            reporter().logPass("Ustawiono standardowe hasło");
            return;
        }
        enterIntoElement(poleTekstoweNoweHaslo, "Aviva1234");
        enterIntoElement(poleTekstowePotwierdzHaslo, "Aviva1234");
        clickElement(przyciskZmienHaslo);
        reporter().logPass("Ustawiono drugorzędne hasło");
    }

    private static void handleAlreadyRegistered(TestDTO dataRow, String env) {
        PageFactory.initElements(driver, MyAvivaZmienHaslo.class);
        String login = MyAvivaStronaLogowania.poleTekstoweLogin.getAttribute("value");
        //String doubleLoginValue = doubleLogin.getAttribute("value");

        // Ostatnia wartość mailowa z BD

        if (login.startsWith("cztmya") || login.startsWith("autoczt")) {
            manager.updateMailForData(login, dataRow.getLp());
            return;
        }
        /*else if (doubleLoginValue.startsWith(Dictionary.EMAIL_PREFIX)){
            ExcelHelper.writeValueToExcel(Dictionary.FILE_WITH_USERS, Dictionary.UPGRADE_DATA_EXCEL_FILE_SHEET_NAME, i, MAIL_COL_NUM, login);
            i++;
            continue;
        }*/
        /*if (doubleLogin.isDisplayed()) {
            ExcelHelper.writeValueToExcel(Dictionary.FILE_WITH_USERS, Dictionary.UPGRADE_DATA_EXCEL_FILE_SHEET_NAME, i, MAIL_COL_NUM, login);
            i++;
            continue;
        */
        driver.get(Rest.getActivationLink(login, env));
        String pass = manager.getLoginCredentials("MyAviva", "", env).get(2);
        waitUntilElementVisible(MyAvivaZmienHaslo.poleTekstoweNoweHaslo, 15).sendKeys(pass);
        MyAvivaZmienHaslo.poleTekstowePotwierdzHaslo.sendKeys(pass);

        // <><><><><><><>
        // - Zaznaczone na fioletowo w pliku (błąd danych - nie można zmienić hasła / loginu)

        MyAvivaZmienHaslo.przyciskZmienHaslo.click();
        handleTOUUpdate(driver, "CP");
        driver.get(MyAvivaURL.myProfilePage("CP"));
    }


    public static void zmianaPodzialuZgromadzonychSrodkow(WebDriver driver) {
        String procentAllokacjiZgromadzonychSrodkow =
                "//*[contains(text(), 'podział zgromadzonych środków')]/../*//input";
        List<WebElement> polaTekstowe = driver.findElements(By.xpath(procentAllokacjiZgromadzonychSrodkow));
        reporter().logPass("Liczba posiadanych funduszy: " + polaTekstowe.size());
        List<WebElement> funduszeZgromadzonychSrodkow = driver.findElements(
                By.xpath("//*[contains(text(), 'podział zgromadzonych środków')]/..//*[@scope='row']"));
        if (Integer.parseInt(getElementProperty(polaTekstowe.get(0), "value")) == 100) {
            clickElement(LifeZmianaFunduszy.przyciskDodajFunduszPodzialSrodkow);
            if (getElementProperty(funduszeZgromadzonychSrodkow.get(0), "outerText").equals("Pieniężny")) {
                selectDropdownListOption(LifeZmianaFunduszy.listaFunduszyZgromadzonychSrodkow, "Zrównoważony");
            } else {
                selectDropdownListOption(LifeZmianaFunduszy.listaFunduszyZgromadzonychSrodkow, "Pieniężny");
            }
        }
        zmianaAllokacjiFunduszy(procentAllokacjiZgromadzonychSrodkow, driver);
    }

    public static void zmianaPodzialuPrzyszlychWplatNaRachunekPodstawowy(WebDriver driver) {
        String procentAllokacjiRachunekPodstawowy =
                "//*[contains(text(), 'Podstawowy: podział przyszłych wpłat')]/../*//input";
        WebElement podzialWplatPodstawowy = driver.findElement(By.xpath(procentAllokacjiRachunekPodstawowy));
        if (podzialWplatPodstawowy.isEnabled()) {
            List<WebElement> polaTekstowe = driver.findElements(By.xpath(procentAllokacjiRachunekPodstawowy));
            reporter().logPass("Liczba posiadanych funduszy: " + polaTekstowe.size());
            List<WebElement> funduszeRachunekPodstawowy = driver.findElements(
                    By.xpath("//*[contains(text(), 'Podstawowy: podział przyszłych wpłat')]/..//*[@scope='row']"));
            if (Integer.parseInt(getElementProperty(polaTekstowe.get(0), "value")) == 100) {
                clickElement(LifeZmianaFunduszy.przyciskDodajFunduszPodstawowyPodzialWplat);
                if (getElementProperty(funduszeRachunekPodstawowy.get(0), "outerText").equals("Pieniężny ")) {
                    selectDropdownListOption(LifeZmianaFunduszy.listaFunduszyRachunekPodstawowy, "Zrównoważony ");
                } else {
                    selectDropdownListOption(LifeZmianaFunduszy.listaFunduszyRachunekPodstawowy, "Pieniężny ");
                }
            }
            zmianaAllokacjiFunduszy(procentAllokacjiRachunekPodstawowy, driver);
        }
    }

    public static void zmianaPodzialuPrzyszlychWplatNaRachunekLokacyjny(WebDriver driver) {
        String procentAllokacjiRachunekLokacyjny =
                "//*[contains(text(), 'Lokacyjny: podział przyszłych wpłat')]/../*//input";
        WebElement podzialWplatLokacyjny = driver.findElement(By.xpath(procentAllokacjiRachunekLokacyjny));
        if (podzialWplatLokacyjny.isEnabled()) {
            List<WebElement> polaTekstowe = driver.findElements(By.xpath(procentAllokacjiRachunekLokacyjny));
            reporter().logPass("Liczba posiadanych funduszy: " + polaTekstowe.size());
            List<WebElement> funduszeRachunekLokacyjny = driver.findElements(
                    By.xpath("//*[contains(text(), 'Lokacyjny: podział przyszłych wpłat')]/..//*[@scope='row']"));
            if (Integer.parseInt(getElementProperty(polaTekstowe.get(0), "value")) == 100) {
                clickElement(LifeZmianaFunduszy.przyciskDodajFunduszLokacyjnyPodzialWplat);
                if (getElementProperty(funduszeRachunekLokacyjny.get(0), "outerText").equals("Pieniężny ")) {
                    selectDropdownListOption(LifeZmianaFunduszy.listaFunduszyRachunekLokacyjny, "Zrównoważony ");
                } else {
                    selectDropdownListOption(LifeZmianaFunduszy.listaFunduszyRachunekLokacyjny, "Pieniężny ");
                }
            }
            zmianaAllokacjiFunduszy(procentAllokacjiRachunekLokacyjny, driver);
        }
    }

    private static void zmianaAllokacjiFunduszy(String procentAllokacji, WebDriver driver) {
        List<WebElement> nowePolaTekstowe = driver.findElements(By.xpath(procentAllokacji));
        List<String> srodkiNaFunduszu = new ArrayList<>();
        int noweSrodkiNaPierszymFunduszu;
        pauseFor(3);
        if (Integer.parseInt(getElementProperty(nowePolaTekstowe.get(0), "value")) > 20) {
            noweSrodkiNaPierszymFunduszu = Integer.parseInt(getElementProperty(nowePolaTekstowe.get(0), "value")) - 10;
        } else {
            noweSrodkiNaPierszymFunduszu = Integer.parseInt(getElementProperty(nowePolaTekstowe.get(0), "value")) + 10;
        }
        waitUntilElementVisible(nowePolaTekstowe.get(0), 15);
        enterIntoTextField(nowePolaTekstowe.get(0), Integer.toString(noweSrodkiNaPierszymFunduszu));
        int sumaSrodkowNaFunduszach = 0;
        for (WebElement nowePoleTekstowe : nowePolaTekstowe) {
            srodkiNaFunduszu.add(nowePoleTekstowe.getAttribute("value"));
            reporter().logPass("Środki na funduszu: " + nowePoleTekstowe.getAttribute("value"));
            sumaSrodkowNaFunduszach =
                    sumaSrodkowNaFunduszach + Integer.parseInt(nowePoleTekstowe.getAttribute("value"));
        }
        if (sumaSrodkowNaFunduszach != 100) {
            int noweSrodkiNaOstatnimFunduszu =
                    Integer.parseInt(getElementProperty(nowePolaTekstowe.get(nowePolaTekstowe.size() - 1), "value"))
                            + 100 - sumaSrodkowNaFunduszach;
            clickElement(nowePolaTekstowe.get(nowePolaTekstowe.size() - 1));
            waitUntilElementVisible(nowePolaTekstowe.get(nowePolaTekstowe.size() - 1), 15);
            enterIntoTextField(nowePolaTekstowe.get(nowePolaTekstowe.size() - 1),
                    Integer.toString(noweSrodkiNaOstatnimFunduszu));
            nowePolaTekstowe.get(nowePolaTekstowe.size() - 1).sendKeys(Keys.TAB);
        }
    }

    public static void zmianaUposazonychGlownych(WebDriver driver) {
        String udzialProcentowy = "//*[contains(text(), 'Uposażeni główni')]/../..//*[@name='splitViewReadonly']";
        List<WebElement> poleUdzialProcentowy = driver.findElements(By.xpath(udzialProcentowy));
        int liczbaUposazonychGlownych = poleUdzialProcentowy.size();
        reporter().logPass("Liczba głównych uposażonych: " + liczbaUposazonychGlownych);
        switch (liczbaUposazonychGlownych) {
            case 0:
                reporter().logPass(Integer.toString(liczbaUposazonychGlownych));
                break;
            case 1:
                clickElement(LifeUposazeni.przyciskDodajUposazonegoGlowni);
                waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
                daneUposazonego();
                int udzialProcentowyUposazonego = RandomIntGenerator.liczbaLosowa(30, 50);
                enterIntoTextField(LifeUposazeni.poleTekstoweUdzialProcentowy,
                        Integer.toString(udzialProcentowyUposazonego));
                clickElement(LifeUposazeni.linkEdytujDaneOsoboweGlowni);
                waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
                enterIntoTextField(LifeUposazeni.poleTekstoweUdzialProcentowy,
                        Integer.toString(100 - udzialProcentowyUposazonego));
                LifeUposazeni.poleTekstoweUdzialProcentowy.sendKeys(Keys.TAB);
                break;
            case 2:
                clickElement(LifeUposazeni.linkEdytujDaneOsoboweGlowni);
                waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
                enterIntoTextField(LifeUposazeni.poleTekstoweUdzialProcentowy, "100");
                clickElement(LifeUposazeni.linkUsunUposazonegoGlowni2);
                break;
            default:
                reporter().logPass(Integer.toString(liczbaUposazonychGlownych));
        }
    }

    private static void daneUposazonego() {
        enterIntoTextField(LifeUposazeni.poleTekstoweImie,
                "Tomasz" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(LifeUposazeni.poleTekstoweNazwisko,
                "Testowy" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(LifeUposazeni.poleTekstoweDzien, Integer.toString(RandomIntGenerator.liczbaLosowa(1, 28)));
        enterIntoTextField(LifeUposazeni.poleTekstoweMiesiac, Integer.toString(RandomIntGenerator.liczbaLosowa(1, 12)));
        enterIntoTextField(LifeUposazeni.poleTekstoweRok, Integer.toString(RandomIntGenerator.liczbaLosowa(1950, 50)));
    }

    public static void sprawdzenieMojeProduktyLife() {
        obslugaBleduSprawdzeniaElementu(MyAvivaOfertaDlaCiebie.zycieIZdrowie,
                "Pomyślnie zostały wyświetlone produkty użytkownika",
                "Nie działa wyświetlanie produktów użytkownika");
    }

    public static void sprawdzenieSzczegolowPolisy() {
        obslugaBleduSprawdzeniaElementu(LifeSzczegoly.linkZlecenia,
                "Pomyślnie zostały wyświetlone szczegóły polisy",
                "Nie działa wyświetlanie szczegółów polisy");
    }

    public static void sprawdzeniePotwierdzZmiane() {
        obslugaBleduSprawdzeniaElementu(LifeSzczegoly.poleTekstowePodajKodSMS,
                "Pomyślnie udało się wyświetlić stronę potwierdź zmianę SMS-em",
                "Nie udało się wyświetlić strony potwierdź zmianę SMS-em");
    }

    public static void sprawdzenieZatwierdzeniaSMS() {
        obslugaBleduSprawdzeniaElementu(LifeSzczegoly.przyciskWrocDoPolisy,
                "Pomyślnie udało się zatwierdzić zmianę kodem SMS.",
                "Nie działa usługa potwierdzania zmian SMS-em.");
    }

    public static void sprawdzenieHistoriiOperacji() {
        obslugaBleduSprawdzeniaElementu(LifeSzczegoly.tekstHistioraZlecen,
                "Pomyślnie udało się wyświetlić historię operacji.",
                "Nie działa wyświetlanie historii operacji.");
    }

    public static void sprawdzenieSzczegolowPolisyLife() {
        obslugaBleduSprawdzeniaElementu(LifeSzczegoly.linkHistoria,
                "Pomyślnie udało się wyświetlić szczegóły polisy.",
                "Nie działa wyświetlanie szczegółów polisy.");
    }

    public static void sprawdzenieWyslaniaZgloszeniaSzkodyMoto() {
        obslugaBleduSprawdzeniaElementu(MotoDziekujemy.tekstNumerSzkody,
                "Pomyślnie zostało przyjęte zgłoszenie szkody.",
                "Nie działa wyświetlanie potwierdzenia przyjęcia szkody.");
    }

    public static void sprawdzenieWyboruRodzajuZgloszeniaMoto() {
        obslugaBleduSprawdzeniaElementu(MotoWyborSzkody.linkAcUszkodzenie,
                "Wyświetliła się strona wyboru rodzaju zgłoszenia.",
                "Nie wyświetliła się strona wyboru rodzaju zgłoszenia.");
    }

    public static void sprawdzenieCaptchaMoto() {
        obslugaBrokenSprawdzeniaElementu(MotoTwojaOferta.reklama,
                "Capctha jest wyłączona i skrypt może być kontynuowany.",
                "Captcha nie jest wyłączona i skrypt automatyczny nie może być kontynuowany.");
    }

    public static void sprawdzenieStronyPolisyMoto() {
        obslugaBleduSprawdzeniaElementu(MotoDaneSamochodu.przyciskSzczegoly,
                "Pomyślnie otworzono stronę moje produkty polisy moto.",
                "Nie otworzyła się strona moje produkty polisy moto.");
    }

    public static void sprawdzenieStronySzczegolyMoto() {
        obslugaBleduSprawdzeniaElementu(MotoSzczegoly.numerpolisy,
                "Pomyślnie otworzono stronę szczegóły polisy moto.",
                "Nie otworzyła się strona szczegóły polisy moto.");
    }

    public static void sprawdzenieStronyDokumentyMoto() {
        obslugaBleduSprawdzeniaElementu(MotoDokumenty.tekstDokumentyPolisy,
                "Pomyślnie otworzono stronę dokumenty polisy moto.",
                "Nie otworzyła się strona dokumenty polisy moto.");
    }

    public static void sprawdzenieStronyZakupuUbezpieczeniaTravel() {
        obslugaBleduSprawdzeniaElementu(TravelSprawdzCeneUbezpieczenia.przyciskPolska,
                "Pomyślnie otworzono stronę zakupu ubezpieczenia travel.",
                "Nie otworzyła się strona zakupu ubezpieczenia travel.");
    }

    public static void sprawdzenieStronyOfertaTravel() {
        obslugaBleduSprawdzeniaElementu(TravelOferta.przyciskWybierzPakietElastyczny,
                "Pomyślnie otworzono stronę oferta travel.",
                "Nie otworzyła się strona oferta travel.");
    }

    public static void sprawdzenieStronyDaneDoUbezpieczeniaTravel() {
        obslugaBleduSprawdzeniaElementu(TravelDaneDoUbezpieczenia.tekstDaneDoUbezpieczenia,
                "Pomyślnie otworzono stronę dane do ubezpezpieczenia travel.",
                "Nie otworzyła się strona dane do ubezpieczenia travel.");
    }

    public static void sprawdzenieStronyPodsumowanieTravel() {
        obslugaBleduSprawdzeniaElementu(TravelPodsumowanie.przyciskZaplacOnline,
                "Pomyślnie otworzono stronę podsumowanie travel.",
                "Nie otworzyła się strona podsumowania travel.");
    }

    public static void sprawdzenieStronyGratulujemyTravel() {
        obslugaBleduSprawdzeniaElementu(TravelPodsumowanie.gratulejmy,
                "Pomyślnie otworzono stronę gratulujemy travel.",
                "Nie otworzyła się strona gratulejemy travel.");
    }

    public static void sprawdzenieStronySzczegolyTravel() {
        obslugaBleduSprawdzeniaElementu(TravelSzczegoly.numerPolisy,
                "Pomyślnie otworzono stronę szczegóły polisy travel.",
                "Nie otworzyła się strona szczegóły polisy travel.");
    }

    public static void sprawdzenieStronyDokumentyTravel() {
        obslugaBleduSprawdzeniaElementu(TravelDokumenty.ogolneWarunkiUbezpieczenia,
                "Pomyślnie otworzono stronę dokumenty polisy travel.",
                "Nie otworzyła się strona dokumenty polisy travel.");
    }

    public static void sprawdzenieStronySzkodyIRoszczenia() {
        obslugaBleduSprawdzeniaElementu(MyAvivaSzkodyIRoszczenia.przyciskZglosZdarzenie,
                "Pomyślnie otworzono stronę szkody i roszczenia.",
                "Nie otworzyła się strona szkody i roszczenia.");
    }

    public static void sprawdzenieStronyCzegoDotyczyZdarzenie() {
        obslugaBleduSprawdzeniaElementu(MyAvivaSzkodyIRoszczenia.tekstCzegoDotyczyZdarzenie,
                "Pomyślnie otworzono stronę czego dotyczy zdarzenie.",
                "Nie otworzyła się strona czego dotyczy zdarzenie.");
    }

    public static void sprawdzenieStronySzkodaPodrozna() {
        obslugaBleduSprawdzeniaElementu(MyAvivaSzkodyIRoszczenia.tekstSzkodaPodrozna,
                "Pomyślnie otworzono stronę szkoda podróżna.",
                "Nie otworzyła się strona szkoda podróżna.");
    }

    public static void obslugaBleduSprawdzeniaElementu(WebElement webElement, String sukces, String porazka) {
        if (waitUntilElementVisible(webElement, 5) != null) {
            reporter().logPass(sukces);
        } else {
            reporter().logFail(porazka);
        }
    }

    public static void obslugaBrokenSprawdzeniaElementu(WebElement webElement, String sukces,
                                                        String porazka) {
        if (waitUntilElementVisible(webElement, 5) != null) {
            reporter().logPass(sukces);
        } else {
            reporter().logError(porazka);
        }
    }

    public static void historiaPolisyNaDzis() {
        selectDropdownListOption(LifeSzczegoly.listaDataOperacji, "Ustaw własny");
        clickElement(LifeSzczegoly.poleTekstoweDataOd);
        enterIntoTextField(LifeSzczegoly.poleTekstoweDataOd, LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        clickElement(LifeSzczegoly.poleTekstoweDataDo);
        enterIntoTextField(LifeSzczegoly.poleTekstoweDataDo, LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        clickElement(LifeSzczegoly.przyciskPokaz);
    }

    public static String odczytNumeruTelefonuZProfilu(String appEnv) {
        MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Mój Profil", appEnv, driver);
        String numerTelefonu = getElementProperty(MojProfil.tekstNumerTelefonu, "textContent");
        clickElement(MojProfil.tekstWroc);
        waitUntilElementVisible(MyAvivaOfertaDlaCiebie.tekstMojeProdukty, 5);
        return numerTelefonu;
    }

    public static void wylogowaniePrzezLink(WebDriver driver) {
        String aktualnyURL = driver.getCurrentUrl();
        String[] aktualnyurlSplit = aktualnyURL.split("/");
        driver.get("https://" + aktualnyurlSplit[2] + "/Profil/Wylogowanie");
        obslugaBleduSprawdzeniaElementu(MyAvivaStronaLogowania.przyciskZalogujPonownie,
                "Użytkownik został poprawnie wylogowany.",
                "Nie udało się poprawnie wylogować użytkownika.");
        clickElement(MyAvivaStronaLogowania.przyciskZalogujPonownie);
        obslugaBleduSprawdzeniaElementu(MyAvivaStronaLogowania.poleTekstoweLogin,
                "Pomyślnie otworzono stronę logowania do MyAviva.",
                "Nie otworzyła się strona logowania do MyAviva.");
    }

    public static String pobierzNumerSzkody(WebElement element) {
        String tekstNumerSzkody = getElementProperty(element, "innerText");
        String numerSzkody = null;
        Pattern pattern = Pattern.compile("[0-9]+$");
        Matcher m = pattern.matcher(tekstNumerSzkody);
        if (m.find()) {
            numerSzkody = m.group();
        }
        return numerSzkody;
    }
}
