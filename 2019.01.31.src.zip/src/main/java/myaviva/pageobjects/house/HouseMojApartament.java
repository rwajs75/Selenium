package myaviva.pageobjects.house;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HouseMojApartament {

    //Mapowanie elementow na stronie szczegółów polisy mój apartament
    @FindBy(xpath = "//*[contains(text(), 'Mój Apartament')]/../../..//li[1]/p")
    public static WebElement numerPolisy;
    @FindBy(xpath = "//*[contains(text(), 'Mój Apartament')]/../../..//li[2]/p")
    public static WebElement sumaUbezpieczenia;
    @FindBy(xpath = "//*[contains(text(), 'Mój Apartament')]/../../..//li[3]/p")
    public static WebElement dataZakonczeniaOchrony;
    @FindBy(xpath = "//*[contains(text(), 'Mój Apartament')]/../../..//*[contains(text(), 'Szczegóły')]")
    public static WebElement przyciskSzczegoly;
    @FindBy(xpath = "//*[contains(text(), 'Mój Apartament')]/../../..//*[contains(text(), 'Zgłoś zdarzenie')]")
    public static WebElement przyciskZglosZdarzenie;
    @FindBy(xpath = "//*[contains(text(), 'Mój Apartament')]/../../..//*[contains(text(), 'Przejdź do odnowienia')]")
    public static WebElement przyciskPrzejdzDoOdnowienia;
}
