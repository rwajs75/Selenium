package myaviva.pageobjects.house;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HousePotwierdzenie {

    //Mapowanie elementow na stronie potwierdzenia szkody mieszkaniowej
    @FindBy(xpath = "//*[contains(text(), ' Dziękujemy! ')]")
    public static WebElement dziekujemy;
    @FindBy(xpath = "//*[contains(text(), 'Przejdź do strony głównej')]")
    public static WebElement przyciskPrzejDoStronyGlownej;
}
