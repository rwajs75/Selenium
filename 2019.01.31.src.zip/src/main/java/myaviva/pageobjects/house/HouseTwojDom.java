package myaviva.pageobjects.house;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HouseTwojDom {

    //Mapowanie elementow na stronie szczegółów polisy twój dom
    @FindBy(xpath = "//*[contains(text(), 'Twój Dom')]/../../..//li[1]/p")
    public static WebElement numerPolisy;
    @FindBy(xpath = "//*[contains(text(), 'Twój Dom')]/../../..//li[2]/p")
    public static WebElement sumaUbezpieczenia;
    @FindBy(xpath = "//*[contains(text(), 'Twój Dom')]/../../..//li[3]/p")
    public static WebElement wysokoscSkladki;
    @FindBy(xpath = "//*[contains(text(), 'Twój Dom')]/../../..//li[4]/p")
    public static WebElement dataZakonczeniaOchrony;
    @FindBy(xpath = "//*[contains(text(), 'Twój Dom')]/../../..//*[contains(text(), 'Szczegóły')]")
    public static WebElement przyciskSzczegoly;
    @FindBy(xpath = "//*[contains(text(), 'Twój Dom')]/../../..//*[contains(text(), 'Zgłoś zdarzenie')]")
    public static WebElement przyciskZglosZdarzenie;
    @FindBy(xpath = "//*[contains(text(), 'Twój Dom')]/../../..//*[contains(text(), 'Przejdź do odnowienia')]")
    public static WebElement przyciskPrzejdzDoOdnowienia;
}
