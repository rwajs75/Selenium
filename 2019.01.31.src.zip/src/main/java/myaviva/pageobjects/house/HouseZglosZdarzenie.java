package myaviva.pageobjects.house;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HouseZglosZdarzenie {

    //Mapowanie elementow na stronie zgłaszanie szkody mieszkaniowej
    @FindBy(id = "firstName")
    public static WebElement poleTekstoweImie;
    @FindBy(id = "lastName")
    public static WebElement poleTekstoweNazwisko;
    @FindBy(id = "email")
    public static WebElement poleTekstoweEmail;
    @FindBy(name = "policyOwnerType")
    public static WebElement przyciskWyboruWlascicielaPolisy;
    @FindBy(id = "policyNumber")
    public static WebElement poleTekstoweNumerPolisy;
    @FindBy(id = "eventDate")
    public static WebElement poleTekstoweDataZdarzenia;
    @FindBy(id = "hours")
    public static WebElement poleTekstoweGodzina;
    @FindBy(id = "minutes")
    public static WebElement poleTekstoweMinuty;
    @FindBy(id = "eventLocation")
    public static WebElement poleEdycyjneMiejsceZdarzenia;
    @FindBy(id = "eventDescription")
    public static WebElement poleEdycyjneOpisZdarzenia;
    @FindBy(id = "phoneNumber")
    public static WebElement poleTekstoweNumerTelefonu;
    @FindBy(name = "preferredContactTime")
    public static WebElement przyciskWyboruGodzinaKontaktu;
    @FindBy(id = "termsAndConditions")
    public static WebElement poleOpcjiAkceptuje;
    @FindBy(id = "electronicCorrespondence")
    public static WebElement poleOpcjiZgoda;
    @FindBy(id = "submitBtn")
    public static WebElement przyciskDalej;
}
