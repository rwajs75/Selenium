package myaviva.pageobjects.house;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaHouse {

    @FindBy (xpath = "//*[@id='loggedin']//*[contains(text(), 'Moje Wnioski')]" )
    public static WebElement przycsikMojeWnioski;

    @FindBy (xpath = "//*[@id='main']//*[contains(text(), 'Ubezpieczenie mieszkania lub domu')]")
    public static WebElement przycsikFormularzHouse;

    @FindBy (xpath = "//*[contains(text(), 'Oblicz składkę')]")
    public static WebElement przycsikObliczSkladke;







}
