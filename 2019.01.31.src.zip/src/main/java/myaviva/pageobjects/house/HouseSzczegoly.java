package myaviva.pageobjects.house;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HouseSzczegoly {

    //Mapowanie elementow na stronie szczegółów polisy dom
    @FindBy(xpath = "//*/a[contains(text(), 'Wróć do produktów')]")
    public static WebElement linkWrocDoProduktow;
    @FindBy(xpath = "//*[contains(text(), 'Mój Apartament')]")
    public static WebElement mojApartament;
    @FindBy(xpath = "//*[contains(text(), 'Twój Dom')]")
    public static WebElement twojDom;
    @FindBy(xpath = "//*[contains(text(), 'Numer polisy')]/../p")
    public static WebElement numerpolisy;
    @FindBy(xpath = "//*[contains(text(), 'Data zakończenia ochrony')]/../p")
    public static WebElement dataZakonczeniaOchrony;
    @FindBy(xpath = "//*[contains(text(), 'Wysokość składki')]/../p")
    public static WebElement wysokoscSkladki;
    @FindBy(xpath = "//*[contains(text(), 'Rachunek do wpłaty')]/../p")
    public static WebElement rachunekDoWplaty;
    @FindBy(xpath = "//*[contains(text(), 'Harmonogram płatności')]")
    public static WebElement harmonogramPlatnosci;
    @FindBy(xpath = "//*[contains(text(), 'I rata składki')]/../..//p")
    public static WebElement IRataSkladki;
    @FindBy(xpath = "//*[contains(text(), 'I rata składki')]/../../..//li[2]/p")
    public static WebElement IRataPlatneDo;
    @FindBy(xpath = "//*[contains(text(), 'I rata składki')]/../../..//li[3]/p")
    public static WebElement IRataSaldoRaty;
    @FindBy(xpath = "//*[contains(text(), 'I rata składki')]/../../..//li[4]/p")
    public static WebElement IRataStatusPlatnosci;
    @FindBy(xpath = "//*[contains(text(), 'II rata składki')]/../..//p")
    public static WebElement IIRataSkladki;
    @FindBy(xpath = "//*[contains(text(), 'II rata składki')]/../../..//li[2]/p")
    public static WebElement IIRataPlatneDo;
    @FindBy(xpath = "//*[contains(text(), 'II rata składki')]/../../..//li[3]/p")
    public static WebElement IIRataSaldoRaty;
    @FindBy(xpath = "//*[contains(text(), 'II rata składki')]/../../..//li[4]/p")
    public static WebElement IIRataStatusPlatnosci;
    @FindBy(xpath = "//*[contains(text(), 'III rata składki')]/../..//p")
    public static WebElement IIIRataSkladki;
    @FindBy(xpath = "//*[contains(text(), 'III rata składki')]/../../..//li[2]/p")
    public static WebElement IIIRataPlatneDo;
    @FindBy(xpath = "//*[contains(text(), 'III rata składki')]/../../..//li[3]/p")
    public static WebElement IIIRataSaldoRaty;
    @FindBy(xpath = "//*[contains(text(), 'III rata składki')]/../../..//li[4]/p")
    public static WebElement IIIRataStatusPlatnosci;
    @FindBy(xpath = "//*[contains(text(), 'Odnów polisę')]")
    public static WebElement przyciskOdnowPolise;
}
