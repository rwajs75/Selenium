package myaviva.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaMojeProdukty {

    //Mapowanie elementow na stronie szczegółów polisy moto
    @FindBy(xpath = "//*[(@alt='Samochód')]/../../..//li[1]/p")
    public static WebElement numerPolisy;
    @FindBy(xpath = "//*[(@alt='Samochód')]/../../..//li[2]/p")
    public static WebElement zakresUbezpieczenia;
    @FindBy(xpath = "//*[(@alt='Samochód')]/../../..//li[3]/p")
    public static WebElement dataZakonczeniaOchrony;
    @FindBy(xpath = "//*[(@alt='Samochód')]/../../..//*[contains(text(), 'Szczegóły')]")
    public static WebElement przyciskSzczegoly;
    @FindBy(xpath = "//*[(@alt='Samochód')]/../../..//*[contains(text(), 'Zgłoś zdarzenie')]")
    public static WebElement przyciskZglosZdarzenie;
    @FindBy(xpath = "//*[(@alt='Samochód')]/../../..//*[contains(text(), 'Przejdź do odnowienia')]")
    public static WebElement przyciskPrzejdzDoOdnowienia;

}
