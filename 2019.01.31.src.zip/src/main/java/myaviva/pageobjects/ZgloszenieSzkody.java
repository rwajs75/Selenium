package myaviva.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ZgloszenieSzkody {

    //Mapowanie elementow na stronie wybierz kategorię szkody
    @FindBy(id = "gdzie_ubezpieczenie_Towarzystwo Ubezpieczeń Ogólnych SA")
    public static WebElement majatek;
    @FindBy(name = "rodzaj_szkody")
    public static WebElement rodzajSzkody;
    //Warianty rodzaju szkody według id
    @FindBy(id = "rodzaj_szkody_Szkoda osobowa")
    public static WebElement szkodaOsobowa;
    @FindBy(id = "rodzaj_szkody_Szkoda mieszkaniowa")
    public static WebElement szkodaMieszkaniowa;
    @FindBy(id = "rodzaj_szkody_OC (pojazd sprawcy w Aviva)")
    public static WebElement ocWAviva;
    @FindBy(id = "rodzaj_szkody_OC (pojazd sprawcy w innym towarzystwie)")
    public static WebElement ocWInnymTowarzystwie;
    @FindBy(id = "rodzaj_szkody_AC")
    public static WebElement ac;
    @FindBy(id = "rodzaj_szkody_AC/Kradzież")
    public static WebElement acKradziez;

    //Dane dotyczące zdarzenia
    @FindBy(id = "rodzaj_zdarzenia")
    public static WebElement rodzajZdarzenia;
    @FindBy(id = "przyczyna_zdarzenia")
    public static WebElement przyczynaZdarzenia;
    @FindBy(id = "nr_polisy_sprawcy")
    public static WebElement nrPolisySprawcy;
    @FindBy(id = "nr_rejestracyjny")
    public static WebElement nrRejestracyjnySprawcy;
    @FindBy(id = "nr_polisy")
    public static WebElement nrPolisyAviva;
    @FindBy(id = "sprawca_zaklad")
    public static WebElement zakladUbezpieczenSprawcy;
    @FindBy(id = "sprawca_dane")
    public static WebElement daneKierujacegoPojazdemSprawcy;
    @FindBy(id = "data_zdarzenia_y")
    public static WebElement dataZdarzeniaRok;
    @FindBy(id = "data_zdarzenia_m")
    public static WebElement dataZadarzeniaMiesiac;
    @FindBy(id = "data_zdarzenia_d")
    public static WebElement dataZdarzeniaDzien;
    @FindBy(id = "godz_zdarzenia")
    public static WebElement godzinaZdarzenia;
    @FindBy(id = "opis_miejscezdarzenia")
    public static WebElement miejsceZdarzenia;
    @FindBy(id = "opis_zdarzenia")
    public static WebElement opisZdarzenia;
    @FindBy(id = "opis_uszkodzen")
    public static WebElement rodzajUszkodzen;
    @FindBy(name = "pojazd_holowany")
    public static WebElement czypojazdBylHolowany;
    @FindBy(name = "policja_powiadomiona")
    public static WebElement czyPowiadomionoPolicje;
    @FindBy(id = "policja_nazwa_jednostki")
    public static WebElement nazwaJednostki;

    //Dane pojazdu poszkodowanego
    @FindBy(id = "poszkodowany_pojazd_nr")
    public static WebElement nrRejestracyjnyPoszkodowanego;
    @FindBy(id = "poszkodowany_pojazd_vin")
    public static WebElement nrVIN;
    @FindBy(id = "poszkodowany_pojazd_rok")
    public static WebElement rokProdukcji;
    @FindBy(id = "poszkodowany_pojazd_marka")
    public static WebElement markaPojazdu;
    @FindBy(id = "poszkodowany_pojazd_model")
    public static WebElement modelPojazdu;
    @FindBy(id = "poszkodowany_pojazd_miejsce")
    public static WebElement miejsceOgledzin;

    //Dane właściciela pojazdu poszkodowanego
    @FindBy(name = "wlasciciel_typ")
    public static WebElement typWlasciciela;
    @FindBy(id = "wlasciciel_imie")
    public static WebElement imie;
    @FindBy(id = "wlasciciel_nazwisko")
    public static WebElement nazwisko;
    @FindBy(id = "wlasciciel_pesel")
    public static WebElement pesel;
    @FindBy(id = "wlasciciel_data_urodzenia")
    public static WebElement dataUrodzenia;
    @FindBy(id = "wlasciciel_nazwa_firmy")
    public static WebElement nazwaFirmy;
    @FindBy(id = "wlasciciel_regon")
    public static WebElement regon;
    @FindBy(id = "wlasciciel_kod_pocztowy")
    public static WebElement kodPocztowy;
    @FindBy(id = "wlasciciel_miejscowosc")
    public static WebElement miejscowaosc;
    @FindBy(id = "wlasciciel_ulica")
    public static WebElement ulica;
    @FindBy(id = "wlasciciel_nr_domu")
    public static WebElement nrDomu;
    @FindBy(id = "wlasciciel_nr_mieszkania")
    public static WebElement nrMieszknia;
    @FindBy(id = "wlasciciel_telefon")
    public static WebElement telefon;
    @FindBy(id = "wlasciciel_email")
    public static WebElement email;
    @FindBy(name = "zglaszajacy_jest_wlascicielem")
    public static WebElement czyZglaszajacyJestWlascicielem;
    @FindBy(name = "poszkodowany_jest_kierujacym")
    public static WebElement czyPoszkodowanyJestKierujacym;

    //Zgody i oświadczenia
    @FindBy(id = "zgoda1_client_autocomplete")
    public static WebElement zgoda1;
    @FindBy(id = "zgoda2_client_autocomplete")
    public static WebElement zgoda2;
    @FindBy(id = "button_next")
    public static WebElement dalej;

    //Potwierdzenie wysłania formularza
    @FindBy(xpath = "//*[contains(text(), ' Dziękujemy za wypełnienie formularza')]")
    public static WebElement potwierdzenieWypelnieniaFormularza;
}
