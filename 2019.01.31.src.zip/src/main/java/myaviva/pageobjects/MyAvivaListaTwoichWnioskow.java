package myaviva.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaListaTwoichWnioskow {
    @FindBy(xpath = "//*[contains(text(), 'Ubezpieczenie turystyczne')]/../..//*[contains(text(), 'Sprawdź cenę')]")
    public static WebElement linkSprawdzCeneTurystyczne;
    @FindBy(xpath = "//*[contains(text(), 'Ubezpieczenie samochodu')]/../..//*[contains(text(), 'Sprawdź cenę')]")
    public static WebElement linkSprawdzCeneSamochodu;
    @FindBy(xpath = "//*[contains(text(), 'Ubezpieczenie mieszkania lub domu')]/../..//*[contains(text(), 'Sprawdź cenę')]")
    public static WebElement linkSprawdzCeneMieszkania;
}
