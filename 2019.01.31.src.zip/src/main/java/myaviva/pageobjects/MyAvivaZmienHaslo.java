package myaviva.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaZmienHaslo {

    @FindBy(id = "password")
    public static WebElement poleTekstoweNoweHaslo;

    @FindBy(id = "confirmPassword")
    public static WebElement poleTekstowePotwierdzHaslo;

    @FindBy(xpath = "//button[text() = 'Zmień hasło']")
    public static WebElement przyciskZmienHaslo;

    public static By wpiszNoweInneHasloMsg = By.xpath("//p[text() = 'Wpisz nowe hasło inne niż obecne.']");

    //Aktywacja maila + pin
    public static final By poleTekstoweHasloRej = By.xpath("//*[@type='password']");
    public static final By poleTekstoweHasloRejPotworz = By.xpath("//*[@id='confirmPassword']");
    @FindBy(xpath = "//*[@for='TermsOfUseAccepted']")
    public static WebElement checkboxAkceptuje;
    @FindBy(xpath = "//button[@type='submit']")
    public static WebElement przyciskZalozKonto;
    public static final By poleTekstoweKodSMS = By.id("PinPadText");
    @FindBy(xpath = "//button[@type='submit'][contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapiszSMS;


}
