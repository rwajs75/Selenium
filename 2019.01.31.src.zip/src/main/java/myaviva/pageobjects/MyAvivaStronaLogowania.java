package myaviva.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaStronaLogowania {

    @FindBy(id = "forgotten-username-link")
    public static WebElement linkNiePamietamLoginu;

    @FindBy(id = "forgotten-password-link")
    public static WebElement linkNiePamietamHasla;

    @FindBy(id="username")
    public static WebElement poleTekstoweLogin;

    @FindBy(id="password")
    public static WebElement poleTekstoweHaslo;

    @FindBy(id="loginButton")
    public static WebElement przyciskZaloguj;

    @FindBy(id="register-link")
    public static WebElement przyciskZalozKonto;

    @FindBy(xpath = "//a[text() = 'Zaloguj się ponownie']")
    public static WebElement przyciskZalogujPonownie;

    @FindBy(xpath = "//p[contains(text(), 'Twoje konto zostało zablokowane.')]")
    public static WebElement kontoZablokowaneMsg;

    public static By nieprawidloweDaneLogowaniaMsg = By.xpath("//p[text() = 'Wprowadzone dane nie są prawidłowe']");
}
