package myaviva.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaRejestracjaKrok1 {

    @FindBy(id="Firstname")
    public static WebElement poleTekstoweImie;

    @FindBy(id="Lastname")
    public static WebElement poleTekstoweNazwisko;

    @FindBy(id="Email")
    public static WebElement poleTekstoweEMAIL;

    @FindBy(id="ConfirmEmail")
    public static WebElement poleTekstowePotwierdzEMAIL;

    @FindBy(id="Password")
    public static WebElement poleTekstoweHaslo;

    @FindBy(xpath="//input[@id='TermsOfUseAccepted']/..")
    public static WebElement poleOpcjiAkceptuj;

    @FindBy(name="SubmitButton")
    public static WebElement przyciskZalozKontoRej;


    public static By messageProblemyKomunkcyjne = By.xpath("//p[contains(text(), 'Przepraszamy, aktualnie występują problemy komunikacyjne')]");

}
