package myaviva.pageobjects.travel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TravelDokumenty {

    //Mapowanie elementow na stronie szczegółów polisy moto w zakładce dokumenty
    @FindBy(xpath = "//*[contains(text(), 'Polisa')]")
    public static WebElement polisa;
    @FindBy(xpath = "//*[contains(text(), 'Ogólne Warunki Ubezpieczenia')]")
    public static WebElement ogolneWarunkiUbezpieczenia;
}
