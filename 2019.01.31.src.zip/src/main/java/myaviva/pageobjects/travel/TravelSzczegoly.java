package myaviva.pageobjects.travel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TravelSzczegoly {

    //Mapowanie elementow na stronie szczegółów polisy podróże
    @FindBy(xpath = "//*/a[contains(text(), 'Wróć do produktów')]")
    public static WebElement linkWrocDoProduktow;
    @FindBy(xpath = "//*[@class='a-heading u-margin--top-none']")
    public static WebElement twojaPodroz;
    @FindBy(xpath = "//*[contains(text(), 'Twoja podróż')]/../../../..//*[contains(text(), 'Dokumenty')]")
    public static WebElement dokumenty;
    @FindBy(xpath = "//*[contains(text(), 'Numer polisy')]/../p")
    public static WebElement numerPolisy;
    @FindBy(xpath = "//*[contains(text(), 'Data rozpoczęcia ochrony')]/../p")
    public static WebElement dataRozpoczeciaOchrony;
    @FindBy(xpath = "//*[contains(text(), 'Data zakończenia ochrony')]/../p")
    public static WebElement dataZakonczeniaOchrony;
    @FindBy(xpath = "//*[contains(text(), 'Status')]/../p")
    public static WebElement status;
    @FindBy(xpath = "//*[contains(text(), 'Cel podróży')]/../p")
    public static WebElement celPodrozy;
    @FindBy(xpath = "//*[contains(text(), 'Cena ubezpieczenia')]/../p")
    public static WebElement cenaUbezpieczenia;
    @FindBy(xpath = "(//*[contains(text(), 'Zakres')]/../p)[1]")
    public static WebElement zakre1;
    @FindBy(xpath = "(//*[contains(text(), 'Suma ubezpieczenia')]/../p)[1]")
    public static WebElement sumaUbezpieczenia1;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż więcej')])[1]")
    public static WebElement pokazWiecej1;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż mniej')])[1]")
    public static WebElement pokazMniej1;
    @FindBy(xpath = "(//*[contains(text(), 'Zakres')]/../p)[2]")
    public static WebElement zakre2;
    @FindBy(xpath = "(//*[contains(text(), 'Suma ubezpieczenia')]/../p)[2]")
    public static WebElement sumaUbezpieczenia2;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż więcej')])[2]")
    public static WebElement pokazWiecej2;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż mniej')])[2]")
    public static WebElement pokazMniej2;
    @FindBy(xpath = "(//*[contains(text(), 'Zakres')]/../p)[3]")
    public static WebElement zakre3;
    @FindBy(xpath = "(//*[contains(text(), 'Suma ubezpieczenia')]/../p)[3]")
    public static WebElement sumaUbezpieczenia3;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż więcej')])[3]")
    public static WebElement pokazWiecej;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż mniej')])[3]")
    public static WebElement pokazMniej3;
    @FindBy(xpath = "(//*[contains(text(), 'Zakres')]/../p)[4]")
    public static WebElement zakre4;
    @FindBy(xpath = "(//*[contains(text(), 'Suma ubezpieczenia')]/../p)[4]")
    public static WebElement sumaUbezpieczenia4;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż więcej')])[4]")
    public static WebElement pokazWiecej4;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż mniej')])[4]")
    public static WebElement pokazMniej4;
    @FindBy(xpath = "(//*[contains(text(), 'Zakres')]/../p)[5]")
    public static WebElement zakre5;
    @FindBy(xpath = "(//*[contains(text(), 'Suma ubezpieczenia')]/../p)[5]")
    public static WebElement sumaUbezpieczenia5;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż więcej')])[5]")
    public static WebElement pokazWiecej5;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż mniej')])[5]")
    public static WebElement pokazMniej5;
    @FindBy(xpath = "(//*[contains(text(), 'Zakres')]/../p)[6]")
    public static WebElement zakre6;
    @FindBy(xpath = "(//*[contains(text(), 'Suma ubezpieczenia')]/../p)[6]")
    public static WebElement sumaUbezpieczenia6;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż więcej')])[6]")
    public static WebElement pokazWiecej6;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż mniej')])[6]")
    public static WebElement pokazMniej6;
    @FindBy(xpath = "(//*[contains(text(), 'Zakres')]/../p)[7]")
    public static WebElement zakre7;
    @FindBy(xpath = "(//*[contains(text(), 'Suma ubezpieczenia')]/../p)[7]")
    public static WebElement sumaUbezpieczenia7;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż więcej')])[7]")
    public static WebElement pokazWiecej7;
    @FindBy(xpath = "(//*[contains(text(), 'Pokaż mniej')])[7]")
    public static WebElement pokazMniej7;
    @FindBy(className = "a-heading a-heading--semibold a-heading-bottom-10")
    public static WebElement dodatkoweOpcjeOchrony;
    @FindBy(xpath = "(//*[@class='a-heading a-heading--light'])[1]")
    public static WebElement dodatkoweOpcjeOchrony1;
    @FindBy(xpath = "(//*[@class='a-heading a-heading--light'])[2]")
    public static WebElement dodatkoweOpcjeOchrony2;
    @FindBy(xpath = "(//*[@class='a-heading a-heading--light'])[3]")
    public static WebElement dodatkoweOpcjeOchrony3;
    @FindBy(xpath = "//*[contains(text(), 'Imię i nazwisko')]/../p")
    public static WebElement imieNazwisko;
    @FindBy(xpath = "//*[contains(text(), 'Data urodzenia')]/../p")
    public static WebElement dataUrodzenia;
    @FindBy(className = "a-button a-button--primary")
    public static WebElement kupNowaPolise;

}
