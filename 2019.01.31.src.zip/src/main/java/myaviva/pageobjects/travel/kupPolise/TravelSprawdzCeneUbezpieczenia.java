package myaviva.pageobjects.travel.kupPolise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.security.cert.X509Certificate;

public class TravelSprawdzCeneUbezpieczenia {

    //Mapowanie elementow na stronie Sprawdź cenę ubezpieczenia
    @FindBy(name = "undefined")
    public static WebElement przyciskWyboruDokadWyjezdzasz;
    @FindBy(xpath = "//*[contains(text(), 'Europa i Kraje Basenu Morza Śródziemnego')]")
    public static WebElement przyciskEU;
    @FindBy(xpath = "//*[contains(text(), 'Świat')]")
    public static WebElement przyciskSwiat;
    @FindBy(xpath = "//*[contains(text(), 'Polska')]")
    public static WebElement przyciskPolska;
    @FindBy(className = "a-textbox a-plusminus__minus")
    public static WebElement przyciskMinus;
    @FindBy(className = "a-textbox a-plusminus__plus")
    public static WebElement przyciskPlus;
    @FindBy(name = "atLeastOneInsuredCurrentlyAbroad")
    public static WebElement poleOpcjiPrzynajmniejJednaZaGranica;
    @FindBy(id = "awf-date-range-start-date-0")
    public static WebElement poleTekstoweOkresOchronyOd;
    @FindBy(id = "awf-date-range-end-date-0")
    public static WebElement poleTekstoweOkresOchronyDo;
    @FindBy(xpath = "//*[contains(text(), 'Narciarstwo')]")
    public static WebElement poleOpcjiNarciarstwo;
    @FindBy(xpath = "//*[contains(text(), 'Sporty ekstremalne')]")
    public static WebElement poleOpcjiSportEkstremalne;
    @FindBy(xpath = "//*[contains(text(), 'Ciężka praca fizyczna')]")
    public static WebElement poleOpcjiCiezkaPracaFizyczna;
    @FindBy(xpath = "//*[contains(text(), 'Leczenie na wypadek')]")
    public static WebElement poleOpcjiLeczenieNaWypadek;
    @FindBy(xpath = "//*[contains(text(), 'Leczenie skutków')]")
    public static WebElement poleOpcjiLeczenieSkutkow;
    @FindBy(xpath = "//*[contains(text(), 'Narciarstwo')]/a")
    public static WebElement linkNarciarstwo;
    @FindBy(xpath = "//*[contains(text(), 'Sporty ekstremalne')]/a")
    public static WebElement linkSportEkstremalne;
    @FindBy(xpath = "//*[contains(text(), 'Ciężka praca fizyczna')]/a")
    public static WebElement linkCiezkaPracaFizyczna;
    @FindBy(xpath = "//*[contains(text(), 'Leczenie na wypadek')]/a")
    public static WebElement linkLeczenieNaWypadek;
    @FindBy(xpath = "//*[contains(text(), 'Leczenie skutków')]/a")
    public static WebElement linkLeczenieSkutkow;
    @FindBy(xpath = "//*[contains(text(), 'Sprawdź szczegóły')]")
    public static WebElement przyciskSprawdzSzczegoly;
    @FindBy(xpath = "//*[contains(text(), 'Kontynuuj bez kodu promocyjnego')]")
    public static WebElement przyciskKontynuujBezKodu;
}
