package myaviva.pageobjects.travel.kupPolise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TravelPodsumowanie {

    //Mapowanie elementow na stronie Podsumowanie
    @FindBy(xpath = "//*[contains(text(), 'Wniosek')]")
    public static WebElement linkWniosek;
    @FindBy(xpath = "//*[contains(text(), 'Ogólne warunki')]")
    public static WebElement linkOgolneWarunki;
    @FindBy(xpath = "//*[contains(text(), 'Regulamin')]")
    public static WebElement linkRegulamin;
    @FindBy(xpath = "//*[contains(text(), 'Informacje')]")
    public static WebElement linkInformacje;
    @FindBy(xpath = "//*[contains(text(), 'Zapłać online')]")
    public static WebElement przyciskZaplacOnline;
    @FindBy(xpath = "//*[contains(text(), 'Gratulujemy!')]")
    public static WebElement gratulejmy;
    @FindBy(xpath = "//*[contains(text(), 'Problem z płatnością')]")
    public static WebElement problemZPlatnoscia;

    //ścieżka z SalesCloud
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;
}
