package myaviva.pageobjects.travel.kupPolise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TravelDaneDoUbezpieczenia {

    //Mapowanie elementow na stronie Oferta
    @FindBy(xpath = "//*[contains(text(), 'Dane do ubezpieczenia')]")
    public static WebElement tekstDaneDoUbezpieczenia;
    @FindBy(xpath = "//*[contains(text(), 'Twoje dane')]/../../..//*[@formcontrolname='firstName']")
    public static WebElement poleTekstoweImie;
    @FindBy(xpath = "//*[contains(text(), 'Twoje dane')]/../../..//*[@formcontrolname='lastName']")
    public static WebElement poleTekstoweNazwisko;
    @FindBy(xpath = "//*[contains(text(), 'Nie jestem obywatelem Polski')]")
    public static WebElement poleOpcjiNieJestemObywatelemPolski;
    @FindBy(xpath = "//*[@formcontrolname='pesel']")
    public static WebElement poleTekstowePesel;
    @FindBy(name = "//*[@name='undefined']")
    public static WebElement przyciskWyboruTypDokumentu;
    @FindBy(xpath = "//*[@formcontrolname='identityNumber']")
    public static WebElement poleTekstoweSeriaINumerDokumentu;
    @FindBy(xpath = "//*[@formcontrolname='originCountryName']")
    public static WebElement poleTekstoweKrajPochodzenia;
    @FindBy(xpath = "//*[contains(text(), 'Twoje dane')]/../../..//*[contains(text(), 'Dzień')]/../input")
    public static WebElement poleTekstoweDzien;
    @FindBy(xpath = "//*[contains(text(), 'Twoje dane')]/../../..//*[contains(text(), 'Miesiąc')]/../input")
    public static WebElement poleTekstoweMiesiac;
    @FindBy(xpath = "//*[contains(text(), 'Twoje dane')]/../../..//*[contains(text(), 'Rok')]/../input")
    public static WebElement poleTekstoweRok;
    @FindBy(xpath = "//*[@formcontrolname='emailAddress']")
    public static WebElement poleTekstoweEmail;
    @FindBy(xpath = "//*[@formcontrolname='mobilePhoneNumber']")
    public static WebElement poleTekstoweNumerTelefonu;
    @FindBy(xpath = "//*[@formcontrolname='postCode']//li[1]/input")
    public static WebElement poleTekstoweKodPocztowy1;
    @FindBy(xpath = "//*[@formcontrolname='postCode']//li[2]/input")
    public static WebElement poleTekstoweKodPocztowy2;
    @FindBy(xpath = "//*[@formcontrolname='city']")
    public static WebElement poleTekstoweMiejscowosc;
    @FindBy(xpath = "//*[@formcontrolname='street']")
    public static WebElement poleTekstoweUlica;
    @FindBy(xpath = "//*[@formcontrolname='houseNumber']")
    public static WebElement poleTekstoweNumerDomu;
    @FindBy(xpath = "//*[@formcontrolname='flatNumber']")
    public static WebElement poleTekstoweNumerMIeszkania;
    @FindBy(xpath = "//*[contains(text(), 'Skopiuj moje dane')]")
    public static WebElement poleOpcjiSkopiujMojeDane;
    @FindBy(xpath = "//*[contains(text(), 'Pierwszy')]/../../..//*[@formcontrolname='firstName']")
    public static WebElement poleTekstoweImiePierszyUbezpieczony;
    @FindBy(xpath = "//*[contains(text(), 'Pierwszy')]/../../..//*[@formcontrolname='lastName']")
    public static WebElement poleTekstoweNazwiskoPierszyUbezpieczony;
    @FindBy(xpath = "//*[contains(text(), 'Pierwszy')]/../../..//*[contains(text(), 'Dzień')]/../input")
    public static WebElement poleTekstoweDzienPierszyUbezpieczony;
    @FindBy(xpath = "//*[contains(text(), 'Pierwszy')]/../../..//*[contains(text(), 'Miesiąc')]/../input")
    public static WebElement poleTekstoweMiesiacPierszyUbezpieczony;
    @FindBy(xpath = "//*[contains(text(), 'Pierwszy')]/../../..//*[contains(text(), 'Rok')]/../input")
    public static WebElement poleTekstoweRokPierszyUbezpieczony;
    @FindBy(xpath = "//*[contains(text(), 'Osoba jest przewlekle chora')]")
    public static WebElement poleOpcjiOsobaJestPrzewlekleChora;
    @FindBy(xpath = "//*[contains(text(), 'Akceptuję wszystkie')]")
    public static WebElement poleOpcjiAkceptujeWszystkie;
    @FindBy(xpath = "//*[contains(text(), 'Pobierz')]/..")
    public static WebElement poleOpcjiOswiadczam;
    @FindBy(xpath = "//*[contains(text(), 'Pobierz')][1]")
    public static WebElement linkPobierzOswiadczenie1;
    @FindBy(xpath = "//*[contains(text(), 'Pobierz')][2]")
    public static WebElement linkPobierzOswiadczenie2;
    @FindBy(xpath = "(//*[contains(text(), 'Więcej')]/../..)[1]")
    public static WebElement przyciskOpcjiZgodaNaPrzekazywanie;
    @FindBy(xpath = "(//*[contains(text(), 'Więcej')])[1]")
    public static WebElement linkZgodaNaPrzekazywanie;
    @FindBy(xpath = "(//*[contains(text(), 'Więcej')]/../..)[2]")
    public static WebElement przyciskOpcjiZgodaNaPrzetwarzanie;
    @FindBy(xpath = "(//*[contains(text(), 'Więcej')])[2]")
    public static WebElement linkZgodaNaPrzetwarzanie;
    @FindBy(xpath = "(//*[contains(text(), 'Więcej')]/../..)[3]")
    public static WebElement przyciskOpcjiZgodaNaPrzesylanie;
    @FindBy(xpath = "(//*[contains(text(), 'Więcej')])[3]")
    public static WebElement linkZgodaNaPrzesylanie;
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]/..")
    public static WebElement przyciskDalej;
}
