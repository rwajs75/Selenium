package myaviva.pageobjects.travel.kupPolise;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TravelOferta {

    //Mapowanie elementow na stronie Oferta
    @FindBy(xpath = "//*[@packagename='Pakiet podstawowy']//*[contains(text(), 'Wybierz')]")
    public static WebElement przyciskWybierzPakietPodstawowy;
    @FindBy(xpath = "//*[@packagename='Pakiet uniwersalny']//*[contains(text(), 'Wybierz')]")
    public static WebElement przyciskWybierzPakietUniwersalny;
    @FindBy(xpath = "//*[@packagename='Pakiet elastyczny']//*[contains(text(), 'Wybierz')]")
    public static WebElement przyciskWybierzPakietElastyczny;
    @FindBy(xpath = "//*[contains(text(), 'Zdrowie Twoje')]/..//a")
    public static WebElement linkWiecejZdrowieTwoje; //jak będzie trzeba to można dopisać kolejne co chronimy
}
