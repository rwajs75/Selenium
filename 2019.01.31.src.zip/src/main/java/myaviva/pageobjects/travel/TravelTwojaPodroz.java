package myaviva.pageobjects.travel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TravelTwojaPodroz {

    //Mapowanie elementow na stronie szczegółów polisy towja podróz
    @FindBy(xpath = "//*[contains(text(), 'Twoja podróż')]/../../..//li[1]/p")
    public static WebElement numerPolisy;
    @FindBy(xpath = "//*[contains(text(), 'Twoja podróż')]/../../..//li[2]/p")
    public static WebElement dataRozpoczeciaOchrony;
    @FindBy(xpath = "//*[contains(text(), 'Twoja podróż')]/../../..//li[3]/p")
    public static WebElement dataZakonczeniaOchrony;
    @FindBy(xpath = "//*[contains(text(), 'Twoja podróż')]/../../..//li[4]/p")
    public static WebElement statusPolisy;
    @FindBy(xpath = "//*[contains(text(), 'Twoja podróż')]/../../..//*[contains(text(), 'Szczegóły')]")
    public static WebElement przyciskSzczegoly;
    @FindBy(xpath = "(//*[contains(text(), 'Twoja podróż')]/../../..//*[contains(text(), 'Szczegóły')])[2]")
    public static WebElement przyciskSzczegoly2;
    @FindBy(xpath = "//*[contains(text(), 'Twoja podróż')]/../../..//*[contains(text(), 'Kup nową polisę')]")
    public static WebElement przyciskKupNowaPolise;
    @FindBy(xpath = "//*[contains(text(), 'Twoja podróż')]/../../..//*[contains(text(), 'Kup nową polisę dla tych samych osób')]")
    public static WebElement przyciskKupNowaPoliseDlaTychSamychOsob;
}
