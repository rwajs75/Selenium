package myaviva.pageobjects.gosc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaZnajdzProdukt {

    @FindBy(xpath = "//span[@class='a-radio__label']/*[contains(text(),'Numeru PESEL')]")
    public static WebElement peselButton;

    @FindBy(id = "Pesel")
    public static WebElement peselInputField;
    @FindBy(id = "PolicyNumber")
    public static WebElement productNumberInputField;
    @FindBy(id = "MobileNumber")
    public static WebElement mobileNumberInputField;
    @FindBy(id = "FirstName")
    public static WebElement firstNameInputField;
    @FindBy(id = "LastName")
    public static WebElement lastNameInputField;
    @FindBy(xpath = "//button[@type = 'submit']")
    public static WebElement upgradeSubmitButton;

    @FindBy(id = "PinPadText")
    public static WebElement smsInputField;
    @FindBy(id = "submit")
    public static WebElement saveButton;

    //komunikaty błędu
    public static By under18 = By.xpath("//p[@class = 'm-form-row__error-message' and contains(text(), 'Wiek nie powinien być mniejszy niż 18 lat')]");
    public static By productNotFoundMsg = By.xpath("//div[@class = 'm-card-content']/p[contains(text(), 'Nie znaleźliśmy żadnych produktów')]");
    public static By technicalProblemsMsg = By.xpath("//div[@class = 'm-card-content']/p[contains(text(), 'Przepraszamy, ale aktualnie mamy problemy techniczne')]");
    public static By aTaskWasCancelledMsg = By.xpath("//h2/i[text() = 'A task was canceled.']");
    public static By errorMsg = By.xpath("//h3[text() = 'Podczas rejestracji wystąpił błąd, prosimy o kontakt z naszą infolinią.']");
    public static By alreadyRegistered = By.xpath("//h1[text() = 'Jesteś już zarejestrowany']");
}
