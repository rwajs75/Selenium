package myaviva.pageobjects.gosc;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaStronaGlownaGoscia {

    @FindBy(xpath = "//a[text() = 'Moje produkty']")
    public static WebElement myProductsButton;

    @FindBy(xpath = "//a[@href = '#loggedin']")
    public static WebElement myAccountButton;
    @FindBy(xpath = "//a[text() = 'Wyloguj']")
    public static WebElement logoutButton;

    //Produkty

    @FindBy(xpath = "//*[@aria-label='Mieszkanie']")
    public static WebElement przyciskProduktMieszkanie;

}
