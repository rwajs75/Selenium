package myaviva.pageobjects.inne;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PrzypomnienieLoginuKrok2 {
    @FindBy(xpath = "//h3[text() = 'Wpisz hasło aby się zalogować']") public static WebElement nagłówekH3;
}
