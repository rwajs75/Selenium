package myaviva.pageobjects.inne;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PrzypomnienieLoginuDane {
    @FindBy(id = "FirstName") public static WebElement poleTekstoweImie;
    @FindBy(id = "LastName") public static WebElement poleTekstoweNazwisko;
    @FindBy(xpath = "//input[@id = 'PESELRadio']/..") public static WebElement przyciskPesel;
    @FindBy(id = "Pesel") public static WebElement getPoleTekstowePesel;
    @FindBy(id = "DateOfBirth_Day") public static WebElement poleTekstoweDzienUrodzenia;
    @FindBy(id = "DateOfBirth_Month") public static WebElement poleTekstoweMiesiacUrodzenia;
    @FindBy(id = "DateOfBirth_Year") public static WebElement poleTekstoweRokUrodzenia;
    @FindBy(id = "PolicyNumber") public static WebElement poleTekstoweNumerPolisy;
    @FindBy(xpath = "//button[@type = 'submit']") public static WebElement przyciskWyslij;
}
