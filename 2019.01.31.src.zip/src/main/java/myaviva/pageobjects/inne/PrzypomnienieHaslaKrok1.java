package myaviva.pageobjects.inne;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PrzypomnienieHaslaKrok1 {
    @FindBy(xpath = "//h1[text() = 'Przypomnienie hasła']") public static WebElement naglowek;
    @FindBy(id = "username") public static WebElement poleTekstoweMail;
    @FindBy(tagName = "button") public static WebElement przyciskWyslij;
}
