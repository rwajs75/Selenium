package myaviva.pageobjects.inne;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PrzypomnienieLoginuKrok1 {
    @FindBy(xpath = "//h1[text() = 'Przypomnienie loginu']") public static WebElement naglowek;
    @FindBy(id = "Email") public static WebElement poleTekstoweMail;
    @FindBy(xpath = "//input[@type = 'submit']") public static WebElement przyciskSprawdz;
    @FindBy(xpath = "//p[text() = 'Nie znaleziono loginu']") public static WebElement nieZnalezionoLoginuMsg;
    @FindBy(xpath = "//p[text() = 'Wpisz e-mail']") public static WebElement wpiszEmailMsg;
    @FindBy(id = "forgotten-username-details-link") public static WebElement linkOdzyskajLoginPoDanychOs;
}
