package myaviva.pageobjects.inne;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PrzypomnienieHaslaKrok2 {
    @FindBy(xpath = "//h1[text() = 'Dziękujemy']") public static WebElement naglowek;
}
