package myaviva.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Yopmail {
    public static final String FRAME_ID_SKRZYNKA_ODBIORCZA = "ifinbox";
    public static final String FRAME_ID_PODGLAD_MAILA = "ifmail";

    @FindBy(id = "lrefr") public static WebElement przyciskOdswiez;
    @FindBy(id = "nbmail") public static WebElement licznikMaili;
    @FindBy(id = "affim") public static WebElement przyciskPokazdZdjecia;
    @FindBy(className = "lmen_all") public static WebElement przyciskWyczyscWszystkieSkrzynki;
    @FindBy(xpath = "//img[contains(@src, 'new_password')]") public static WebElement przyciskKliknijAbyUstawicNoweHaslo;

    public static By przyciskUsun = By.className("lmenudelall");
}
