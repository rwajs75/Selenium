package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeNarodziny {

    //Mapowanie elementow na stronie narodziny lub adopcja
    @FindBy(name = "eventType")
    public static WebElement przyciskWyboruRodzajZdarzenia;
    @FindBy(id = "aggrievedPersonFirstName")
    public static WebElement poleTekstoweImie;
    @FindBy(id = "aggrievedPersonLastName")
    public static WebElement poleTekstoweNazwisko;
    @FindBy(id = "aggrievedPersonPesel")
    public static WebElement poleTekstowePesel;
    @FindBy(id = "personMaidenName")
    public static WebElement poleTekstoweNazwiskoRodowe;
    @FindBy(xpath = "//*/input[@id='phoneNumber']")
    public static WebElement poleTekstoweNumerTelefonu;
    @FindBy(id = "submitBtn")
    public static WebElement przyciskPrzejdzDoPodsumowania;

    //Mapowanie elementów na stronie podsumowanie
    @FindBy(xpath = "//*[@id='GOOD_WILL']/../span")
    public static WebElement poleOpcjiOswiadczam;
    @FindBy(id = "confirmBtn")
    public static WebElement przyciskWyslijWniosek;

    //Mapowanie elementów na stronie Dziękujemy
    @FindBy(xpath = "//*[contains(text(), 'Przejdź do produktów')]")
    public static WebElement przyciskPrzejdzDoProduktow;
}
