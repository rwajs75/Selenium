package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeChoroba {

    //Mapowanie elementow na stronie roszczenia z tytułu choroby
    @FindBy(xpath = "//*[contains(text(), 'Formularz zgłoszenia roszczenia - pobyt w szpitalu')]/..")
    public static WebElement linkPobytWSzpitalu;
    @FindBy(xpath = "//*[contains(text(), 'Formularz zgłoszenia roszczenia - poważne zachorowanie')]/..")
    public static WebElement linkPowazneZachorowanie;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
