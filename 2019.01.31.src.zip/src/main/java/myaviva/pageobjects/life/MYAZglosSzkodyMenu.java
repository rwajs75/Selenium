package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYAZglosSzkodyMenu {


    @FindBy(xpath = "//*[@id=\"product-1emqj\"]//li[2]/a")
    public static WebElement Zgloszdarzenie;




}
