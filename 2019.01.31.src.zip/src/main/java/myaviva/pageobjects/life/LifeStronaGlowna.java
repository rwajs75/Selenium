package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeStronaGlowna {

    //Mapowanie elementow na stronie głownej dla ubezpieczenia life
    @FindBy(xpath = "//*[@alt='Życie i zdrowie']/../../..//*[contains(text(), 'Szczegóły')]")
    public static WebElement przyciskSzczegoly;
    @FindBy(xpath = "//*[@alt='Życie i zdrowie']/../../..//*[contains(text(), 'Zgłoś zdarzenie')]")
    public static WebElement przyciskZglosZdarzenie;
    @FindBy(xpath = "//*[@alt='Życie i zdrowie']/../../..//*[contains(text(), 'Zmień fundusze')]")
    public static WebElement przyciskZmienFundusze;
}
