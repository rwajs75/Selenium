package myaviva.pageobjects.life;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeSzczegoly {

    //Mapowanie elementow na stronie szczegółów polisy life
    @FindBy(xpath = "//*[contains(text(), 'Wróć do produktów')]")
    public static WebElement linkWrocDoProduktow;
    @FindBy(xpath = "//*[contains(text(), 'Ochrona')][@aria-expanded='true']")
    public static WebElement linkOchrona;
    @FindBy(xpath = "//*[contains(text(), 'Zgromadzone środki')][@aria-expanded='true']")
    public static WebElement linkZgromadzoneSrodki;
    @FindBy(xpath = "//*[contains(text(), 'Płatności')][@aria-expanded='true']")
    public static WebElement linkPlatnosci;
    @FindBy(xpath = "//*[contains(text(), 'Historia')][@aria-expanded='true']")
    public static WebElement linkHistoria;
    @FindBy(xpath = "//*[contains(text(), 'Dokumenty')][@aria-expanded='true']")
    public static WebElement linkDokumenty;
    @FindBy(xpath = "//*[contains(text(), 'Uposażeni')][@aria-expanded='true']")
    public static WebElement linkUposazeni;
    @FindBy(xpath = "//*[contains(text(), 'Zlecenia')][@aria-expanded='true']")
    public static WebElement linkZlecenia;

    //Zakładka płatności
    @FindBy(id = "more-payments-button")
    public static WebElement przyciskPokazKolejnePozycje;

    //Zakładka historia
    @FindBy(id = "history-date-range")
    public static WebElement listaDataOperacji;
    @FindBy(id = "history-operation-type")
    public static WebElement listaTypOperacji;
    @FindBy(id = "awf-date-range-start-date-0")
    public static WebElement poleTekstoweDataOd;
    @FindBy(id = "awf-date-range-end-date-0")
    public static WebElement poleTekstoweDataDo;
    @FindBy(xpath = "//*[contains(text(), 'Pokaż')]")
    public static WebElement przyciskPokaz;
    @FindBy(xpath = "//*[contains(text(), 'Historia zleceń')]")
    public static WebElement tekstHistioraZlecen;
    @FindBy(xpath = "//*[@data-th='Data operacji']/span")
    public static WebElement tekstDataOperacji;
    @FindBy(xpath = "//*[@aria-label='Szczegóły']")
    public static WebElement linkSzczegoly;
    @FindBy(xpath = "//*[contains(text(), 'Po zmianie')]")
    public static WebElement tekstPoZmianie;
    @FindBy(xpath = "//*[contains(text(), 'Zmiana nazwiska/adresu')]")
    public static WebElement tekstZmianaNazwiska;
    @FindBy(xpath = "//*[contains(text(), 'Zmiana funduszy na wartości polisy')]")
    public static WebElement tekstZmianaFunduszy;
    @FindBy(xpath = "//*[contains(text(), 'Zmiana uposażonego')]")
    public static WebElement tekstZminaUposazonego;
    @FindBy(xpath = "//*/span[contains(text(), 'Płatności na polisie czynnej')]")
    public static WebElement tekstPlatnoscNaPolisie;
    @FindBy(xpath = "//*[contains(text(), 'Zawieszenie płatności')]")
    public static WebElement tekstZawieszniePlatnosci;
    @FindBy(xpath = "//*[contains(text(), 'Odwieszenie płatności')]")
    public static WebElement tekstOdwieszeniePlatnosci;
    @FindBy(xpath = "//*[contains(text(), 'Rocznica')]")
    public static WebElement tekstRocznica;
    @FindBy(xpath = "//*[contains(text(), 'Częściowa wypłata wartości polisy')]")
    public static WebElement tekstCzesciowaWyplata;
    @FindBy(xpath = "//*[contains(text(), 'Wypłata wartości')]")
    public static WebElement tekstWyplataCalosci;
    @FindBy(xpath = "//*[contains(text(), 'Zmiana agenta')]")
    public static WebElement tekstZmianaAgenta;

    //Zakładka dokumenty
    public static final By linkPobierz = By.xpath("//*[@class='m-card-download-list-item']");
    @FindBy(xpath = "//*[@class='m-card-download-list-item']")
    public static WebElement linkPobierzDokumenty;
    @FindBy(xpath = "//*[contains(text(), ' Rozpocznij pobieranie ')]")
    public static WebElement przyciskRozpocznijPobieranie;

    //Zakładka uposażeni
    @FindBy(xpath = "//*[contains(text(), 'Zmień uposażonych ')]")
    public static WebElement przyciskZmienUposazonych;

    //Zakładka zlecenia
    public static final By poleOpcjiZgody = By.xpath("//span[@class='a-checkbox__label']");
    @FindBy(xpath = "//span[@class='a-checkbox__label']")
    public static WebElement poleOpcjiZgoda;
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;
    @FindBy(id = "order-type")
    public static WebElement listaRodzajZlecenia;
    @FindBy(id = "description")
    public static WebElement poleEdycyjneOpisZlecenia;
    @FindBy(id = "file")
    public static WebElement poleTekstoweZalaczPlik;
    @FindBy(xpath = "//*[contains(text(), 'Wyślij zgłoszenie')]")
    public static WebElement przyciskWyslijZgloszenie;
    @FindBy(xpath = "//*[contains(text(), 'Wróć do polisy')]")
    public static WebElement przyciskWrocDoPolisy;
    @FindBy(xpath = "//*[contains(text(), 'o stanie zdrowia')]")
    public static WebElement linkOStanieZdrowia;
    @FindBy(xpath = "//*[contains(text(), 'Formularz_odejscia')]")
    public static WebElement linkFormularzOdejscia;
    @FindBy(xpath = "//*[contains(text(), 'wniosek o wypłatę częściową')]")
    public static WebElement linkWniosekOWyplateCzesciowa;
    @FindBy(xpath = "//*[contains(text(), 'wniosek o wypłatę całkowitą')]")
    public static WebElement linkWniosekOWyplateCalkowita;
    @FindBy(xpath = "//*[contains(text(), 'dla polis grupowych')]")
    public static WebElement linkDlaPolisGrupowych;
    @FindBy(xpath = "//*[contains(text(), 'z listy doradców')]")
    public static WebElement linkListaDoradcow;

    //Wybór agenta
    @FindBy(id = "location")
    public static WebElement poleTekstoweLokalizacja;
    @FindBy(xpath = "//*[@value='Znajdź']")
    public static WebElement przyciskZnajdz;
    @FindBy(xpath = "//*[contains(text(), 'Pokaż mapę')]")
    public static WebElement przyciskPokazMape;

    //Potwierdzenie SMS
    @FindBy(id = "code")
    public static WebElement poleTekstowePodajKodSMS;
    @FindBy(xpath = "//*[contains(text(), 'Kod PIN jest ważny 3 minuty')]")
    public static WebElement tekstWyslanySMS;
    @FindBy(xpath = "//*[contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapisz;
}
