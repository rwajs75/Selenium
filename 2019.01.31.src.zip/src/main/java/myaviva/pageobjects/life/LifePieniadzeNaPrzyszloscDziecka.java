package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifePieniadzeNaPrzyszloscDziecka {

    //Mapowanie elementow na stronie roszczenia z tytułu choroby
    @FindBy(xpath = "//*[contains(text(), 'Formularz zgłoszenia roszczenia - dożycie')]/..")
    public static WebElement linkDozycie;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
