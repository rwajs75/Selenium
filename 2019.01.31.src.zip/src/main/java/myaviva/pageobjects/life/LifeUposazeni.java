package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeUposazeni {

    //Mapowanie elementow na stronie uposażeni
    @FindBy(xpath = "//*[contains(text(), 'Zmień uposażonych')]")
    public static WebElement przyciskZmienUposazonych;

    //Zmiana uposażonych
    @FindBy(xpath = "//*[contains(text(), 'Uposażeni główni')]/../..//*[@name='splitViewReadonly']")
    public static WebElement tekstUdzialProcentowyGlowni;
    @FindBy(xpath = "//*[contains(text(), 'Uposażeni główni')]/../..//*[contains(text(), 'Edytuj dane osobowe')]")
    public static WebElement linkEdytujDaneOsoboweGlowni;
    @FindBy(xpath = "//*[contains(text(), 'Uposażeni główni')]/../..//*[contains(text(), 'Usuń uposażonego')]")
    public static WebElement linkUsunUposazonegoGlowni;
    @FindBy(xpath = "(//*[contains(text(), 'Uposażeni główni')]/../..//*[contains(text(), 'Usuń uposażonego')])[2]")
    public static WebElement linkUsunUposazonegoGlowni2;
    @FindBy(xpath = "//*[contains(text(), 'Uposażeni główni')]/../..//*[contains(text(), 'Dodaj uposażonego')]")
    public static WebElement przyciskDodajUposazonegoGlowni;

    //Edycja uposażonego
    @FindBy(name = "splitView")
    public static WebElement poleTekstoweUdzialProcentowy;

    //Dodaj uposażonego
    @FindBy(id = "firstName")
    public static WebElement poleTekstoweImie;
    @FindBy(id = "lastName")
    public static WebElement poleTekstoweNazwisko;
    @FindBy(xpath = "//*[contains(text(), 'Dzień')]/../input")
    public static WebElement poleTekstoweDzien;
    @FindBy(xpath = "//*[contains(text(), 'Miesiąc')]/../input")
    public static WebElement poleTekstoweMiesiac;
    @FindBy(xpath = "//*[contains(text(), 'Rok')]/../input")
    public static WebElement poleTekstoweRok;
}
