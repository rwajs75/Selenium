package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeZmianaFunduszy {

    //Mapowanie elementow na stronie zmiana funduszy
    @FindBy(xpath = "//*[contains(text(), 'podział zgromadzonych środków')]/..//*[contains(text(), 'Dodaj fundusz')]")
    public static WebElement przyciskDodajFunduszPodzialSrodkow;
    @FindBy(xpath = "//*[contains(text(), 'Podstawowy: podział przyszłych wpłat')]/..//*[contains(text(), 'Dodaj fundusz')]")
    public static WebElement przyciskDodajFunduszPodstawowyPodzialWplat;
    @FindBy(xpath = "//*[contains(text(), 'Lokacyjny: podział przyszłych wpłat')]/..//*[contains(text(), 'Dodaj fundusz')]")
    public static WebElement przyciskDodajFunduszLokacyjnyPodzialWplat;
    @FindBy(xpath = "//*[contains(text(), 'podział zgromadzonych środków')]/../*//select")
    public static WebElement listaFunduszyZgromadzonychSrodkow;
    @FindBy(xpath = "//*[contains(text(), 'Podstawowy: podział przyszłych wpłat')]/../*//select")
    public static WebElement listaFunduszyRachunekPodstawowy;
    @FindBy(xpath = "//*[contains(text(), 'Lokacyjny: podział przyszłych wpłat')]/../*//select")
    public static WebElement listaFunduszyRachunekLokacyjny;
    @FindBy(xpath = "//*[contains(text(), 'podział zgromadzonych środków')]/../*//input")
    public static String poleTekstoweSrodkiNafunduszuPodzialSrodkow;
    @FindBy(xpath = "//*[contains(text(), 'Przejdź do podsumowania')]")
    public static WebElement przyciskPrzejdzDoPodsumowania;

    //Podsumowanie
    @FindBy(xpath = "//*[contains(text(), 'Zapisz zmiany')]")
    public static WebElement przyciskZapiszZmiany;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;

    //Podsumowanie - dziękujemy
    @FindBy(xpath = "//*[contains(text(), 'Dziękujemy, zlecenie zostało przesłane do realizacji.')]")
    public static WebElement tekstDziekujemy;
}
