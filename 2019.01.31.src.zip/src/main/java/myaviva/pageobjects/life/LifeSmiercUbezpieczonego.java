package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeSmiercUbezpieczonego {

    //Mapowanie elementow na stronie roszczenia z tytułu choroby
    @FindBy(xpath = "//*[contains(text(), 'Formularz zgłoszenia roszczenia - śmierć')]/..")
    public static WebElement linkSmierc;
    @FindBy(xpath = "//*[contains(text(), 'Formularz zgłoszenia roszczenia - śmierć dla najbliższych')]/..")
    public static WebElement linkSmiercDlaNajblizszych;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
