package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeRodzajSzkody {

    //Mapowanie elementow na stronie wyboru szkody dla ubezpieczenia life
    @FindBy(xpath = "//*[contains(text(), 'Narodziny dziecka')]")
    public static WebElement linkNarodzinyDziecka;
    @FindBy(xpath = "//*[contains(text(), 'Choroba')]")
    public static WebElement linkChoroba;
    @FindBy(xpath = "//*[contains(text(), 'Następstwa')]")
    public static WebElement linkNNW;
    @FindBy(xpath = "//*[contains(text(), 'Śmierć bliskich')]")
    public static WebElement linkSmiercBliskich;
    @FindBy(xpath = "//*[contains(text(), 'Śmierć ubezpieczonego')]")
    public static WebElement linkSmiercUbezpieczonego;
    @FindBy(xpath = "//*[contains(text(), 'Pieniądze na przyszłość dziecka')]")
    public static WebElement linkPieniadzeNaPrzyszloscDziecka;
}
