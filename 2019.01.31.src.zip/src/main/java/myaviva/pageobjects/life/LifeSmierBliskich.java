package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeSmierBliskich {

    //Mapowanie elementow na stronie roszczenia śmierć bliskich
    @FindBy(name = "notificationType")
    public static WebElement listaKtoZmarl;
    @FindBy(xpath = "//*[@id='deathDate']/input")
    public static WebElement poleTekstoweDataSmierci;
    @FindBy(id = "aggrievedPersonFirstName")
    public static WebElement poleTekstoweImie;
    @FindBy(id = "aggrievedPersonLastName")
    public static WebElement poleTekstoweNazwisko;
    @FindBy(id = "aggrievedPersonPesel")
    public static WebElement poleTekstowePesel;
    @FindBy(xpath = "//*[@id='phoneNumber']/input")
    public static WebElement poleTekstoweTelefon;
    @FindBy(id = "submitBtn")
    public static WebElement przyciskPrzejdzDoPodsumowania;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;

    //Strona podsumowanie 2z2
    @FindBy(xpath = "//*[@id='GOOD_WILL']/..")
    public static WebElement przyciskWyboruOswiadczenie;
    @FindBy(id = "confirmBtn")
    public static WebElement przyciskWyslijWniosek;

    //Przesłanie dokumentów
    @FindBy(id = "sendLaterBtn")
    public static WebElement przyciskPrzeslijDokumentyPozniej;

    //Czekamy na Twoje dokumenty
    @FindBy(xpath = "//*/a[contains(text(), 'Podaj numer rachunku')]")
    public static WebElement przyciskPodajNumerRachunku;

    //Dane do wypłaty świadczenia
    @FindBy(xpath = "//*[@id='bankAccountNo']/input")
    public static WebElement poleTekstoweNumerRachunku;
    @FindBy(xpath = "//*[contains(text(), 'Zatwierdź')]")
    public static WebElement przyciskZatwierdz;

    //Strona dziękujemy
    @FindBy(xpath = "//*[contains(text(), 'Przejdź do produktów')]")
    public static WebElement przyciskPrzejdzDoProduktow;
}
