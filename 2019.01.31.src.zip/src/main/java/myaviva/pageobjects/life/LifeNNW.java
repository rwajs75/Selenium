package myaviva.pageobjects.life;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LifeNNW {

    //Mapowanie elementow na stronie roszczenia z tytułu wypadku
    @FindBy(xpath = "//*[contains(text(), 'Formularz zgłoszenia roszczenia - wypadek')]/..")
    public static WebElement linkWypadek;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
