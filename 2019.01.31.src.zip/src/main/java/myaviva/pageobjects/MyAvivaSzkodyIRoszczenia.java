package myaviva.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaSzkodyIRoszczenia {

    //Mapowanie elementow na stronie szkody i roszczenia
    @FindBy(xpath = "//*[contains(text(), 'Zgłoś zdarzenie')]")
    public static WebElement przyciskZglosZdarzenie;

    //Mapowanie elementów na stronie czego dotyczy zdarzenie
    @FindBy(xpath = "//*[contains(text(), 'Czego dotyczy zdarzenie?')]")
    public static WebElement tekstCzegoDotyczyZdarzenie;
    @FindBy(xpath = "//*[contains(text(), 'Życie i zdrowie')]/../a")
    public static WebElement linkWybierzZycieIZdrowie;
    @FindBy(xpath = "//*[contains(text(), 'Dom i mieszkanie')]/../a")
    public static WebElement linkWybierzDomIMieszkanie;
    @FindBy(xpath = "//*[contains(text(), 'Samochód')]/../a")
    public static WebElement linkWybierzSamochod;
    @FindBy(xpath = "//*[contains(text(), 'Podróż')]/../a")
    public static WebElement linkWybierzPodroz;

    //Mapowanie elementów na stronie szkoda podróżna
    @FindBy(xpath = "//*[contains(text(), 'Szkoda podróżna')]")
    public static WebElement tekstSzkodaPodrozna;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
