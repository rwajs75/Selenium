package myaviva.pageobjects.mojProfil;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MojProfil {
    @FindBy(id = "edit-email-button") public static WebElement przyciskEdytujMail;
    @FindBy(id = "EMail") public static WebElement poleTekstoweMail;
    @FindBy(id = "edit-contactPref-button") public static WebElement przyciskEdytujPreferencjeKontaktu;
    @FindBy(xpath = "//input[@id = 'ByEmail']/..") public static WebElement checkboxEmail;
    @FindBy(xpath = "//li[@class = 'a-list-unordered__item--cross' and text() = 'E-mail']") public static WebElement emailCross;
    @FindBy(id = "edit-marketingPerm-button") public static WebElement getPrzyciskEdytujZgodyMarketingowe;
    @FindBy(xpath = "//input[@id = 'MarketingPreferences_OtherAvivaProducts']/..") public static WebElement checkboxMarketingConsentInAvivaGroup;
    @FindBy(xpath = "//li[@id = 'm-marketingPreferences-wrapper']//li[1]") public static WebElement marketingConsentInAvivaGroupCross;
    @FindBy(xpath = "//button[text() = 'Zapisz']") public static WebElement przyciskZapisz;
    @FindBy(id = "edit-password-button") public static WebElement przyciskZmienHaslo;
    @FindBy(className = "m-card-notification--success") public static WebElement successMsg;
    @FindBy(xpath = "//*[contains(text(), 'Numer telefonu komórkowego')]/../p")
    public static WebElement tekstNumerTelefonu;
    @FindBy(xpath = "//*[contains(text(), 'Wróć')]")
    public static WebElement tekstWroc;

    public static By emailTick = By.xpath("//li[@class = 'a-list-unordered__item--tick' and text() = 'E-mail']");
    public static By marketingConsentInAvivaGroupTick = By.xpath("//li[@id = 'm-marketingPreferences-wrapper']//li[1]");
}
