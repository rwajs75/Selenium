package myaviva.pageobjects.mojProfil;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ZmienHaslo {
    @FindBy(id = "Password") public static WebElement poleTekstoweObecneHaslo;
    @FindBy(id = "NewPassword") public static WebElement poleTekstoweNoweHaslo;
    @FindBy(xpath = "//button[@type = 'submit']") public static WebElement przyciskZmien;
}
