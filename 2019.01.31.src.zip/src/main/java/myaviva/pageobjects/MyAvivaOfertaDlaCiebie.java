package myaviva.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaOfertaDlaCiebie {

    //Mapowanie elementów na podstronie Moje produkty
    @FindBy(xpath = "//*[contains(text(), 'Moje produkty')]")
    public static WebElement tekstMojeProdukty;
    @FindBy(xpath = "//*[@alt='Życie i zdrowie']")
    public static WebElement zycieIZdrowie;
    @FindBy(xpath = "//*[@alt='Dom']")
    public static WebElement dom;
    @FindBy(xpath = "//*[@alt='Samochód']")
    public static WebElement linkSamochod;
    @FindBy(xpath = "//*[@alt='Podróże']")
    public static WebElement podroze;
    //Dopisać IKZE i inwestycje

    //Mapowanie elementow na podstronie Oferta dla Ciebie
    public static By mieszkanie = By.xpath("//*[@aria-label='Mieszkanie']");
    @FindBy(xpath = "//*[@aria-label='Podróż']")
    public static WebElement podroz;
    public static By samochod = By.xpath("//*[@aria-label='Samochód']");
    @FindBy(xpath = "//*[@aria-label='NWP']")
    public static WebElement zobaczOferteZdrowieIZycie;
    @FindBy(xpath = "//*[@aria-label='TRAVEL']")
    public static WebElement zobaczOfertePodroze;
    @FindBy(xpath = "//*[@aria-label='HOUSE']")
    public static WebElement zobaczOferteDom;
    @FindBy(xpath = "//*[@aria-label='MOTOR']")
    public static WebElement zobaczOferteMoto;
    @FindBy(xpath = "//*[@aria-label='IKE']")
    public static WebElement zobaczOferteEmerytura;
    @FindBy(xpath = "//*[@aria-label='API']")
    public static WebElement zobaczOferteInwestycje;
    @FindBy(xpath = "//*[contains(text(), 'Kup Online')]")
    public static WebElement przyciskKupOnline;
    @FindBy(xpath = "//*[contains(text(), 'Kup ze zniżką')]")
    public static WebElement przyciskKupZeZnizka;
    @FindBy(xpath = "//*[contains(text(), 'Kup teraz')]")
    public static WebElement przyciskKupTeraz;
    @FindBy(xpath = "//*[contains(text(), 'Oblicz składkę')]")
    public static WebElement przyciskObliczSkladke;

}
