package myaviva.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaAktualizacjaZU {

    @FindBy(id = "Agreed")
    public static WebElement checkbox;

    @FindBy(xpath = "//button[text()='Kontynuuj']")
    public static WebElement submitButton;

}
