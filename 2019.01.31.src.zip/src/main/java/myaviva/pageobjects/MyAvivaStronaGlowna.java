package myaviva.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyAvivaStronaGlowna {

    @FindBy(xpath = "//*[contains(text(), 'Moje Wnioski')]")
    public static WebElement linkMojeWnioski;
    @FindBy(xpath = "//*[contains(text(), 'Moje Szkody i Roszczenia')]")
    public static WebElement linkMojeSzkodyIRoszczenia;


    @FindBy(id="modal-overlay")
    public static WebElement ramkaPopUp;

    @FindBy(className = "close")
    public static WebElement ramkaZamknij;

    public static By przyciskZaplac = By.xpath("//*[contains(text(), 'Zapłać')]");
    public static By przyciskSzczegoly = By.xpath("//*[@class='m-button-group__item']//*[contains(text(), 'Szczegóły')]");
    public static By przyciskHarmonogram = By.xpath("//*[contains(text(), 'Harmonogram płatności')]");
    public static By poleTekstoweStatus = By.xpath("//*[@role='status']");
}
