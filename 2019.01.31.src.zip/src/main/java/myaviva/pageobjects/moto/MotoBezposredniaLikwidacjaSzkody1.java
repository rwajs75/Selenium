package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoBezposredniaLikwidacjaSzkody1 {

    //Mapowanie przycisków na stronie zgłaszania Bezpośredniej Likwidacji Szkody 1 z 2
    @FindBy(xpath = "//*[@ng-reflect-name='insuranceCompany']")
    public static WebElement listaZakladowUbezpieczenSprawcy;
    @FindBy(xpath = "//*[@name='polandTeritory']/..")
    public static WebElement przyciskWyboruCzyNaTereniePolski;
    @FindBy(xpath = "//*[@name='statementWritten']/..")
    public static WebElement przyciskWyboruCzyZostaloSpisaneOswiadczenie;
    @FindBy(xpath = "(//*[@name='collisionMoreThanTwoVehicles']/..)[2]")
    public static WebElement przyciskWyboruCzyWicejNizDwaPojazdy;
    @FindBy(xpath = "(//*[@name='injury']/..)[2]")
    public static WebElement przyciskWyboruCzyObrazeniaCiala;
    @FindBy(xpath = "(//*[@name='damagePropertyOutside']/..)[2]")
    public static WebElement przyciskWyboruCzyUszkodzoneMieniePozaPojazdem;
    @FindBy(xpath = "(//*[@name='reportedToAnotherInsuranceCompany']/..)[2]")
    public static WebElement przyciskWyboruCzySzkodaZgloszonaWInnymZakladzieUpezpieczen;
    @FindBy(xpath = "//*[@ng-reflect-name='motoEventType']")
    public static WebElement listaRodzajZdarzenia;
    @FindBy(xpath = "//*[@ng-reflect-name='motoEventCause']")
    public static WebElement listaPrzyczynaZdarzenia;
    @FindBy(id = "policyNumber")
    public static WebElement poleTekstoweNumerPolisySprawcy;
    @FindBy(id = "registryNumber")
    public static WebElement poleTekstoweNumerRejestracyjnySprawcy;
    @FindBy(id = "policyNumberCauser")
    public static WebElement poleTekstoweNumerPolisyAviva;
    @FindBy(id = "deliquentdata")
    public static WebElement poleEdycyjneDaneSprawcyWypadku;
    @FindBy(xpath = "//*[@name='incidentDate']/input")
    public static WebElement poleTekstoweDataZdarzenia;
    @FindBy(id = "timeHours")
    public static WebElement poleTekstoweGodzina;
    @FindBy(id = "timeMinutes")
    public static WebElement poleTekstoweMinuty;
    @FindBy(id = "eventLocation")
    public static WebElement poleTekstoweMiejsceZdarzenia;
    @FindBy(xpath = "//*[contains(text(), 'Pokaż więcej')]")
    public static WebElement linkPokazWiecej;
    @FindBy(xpath = "//*[contains(text(), 'Pokaż mniej')]")
    public static WebElement linkPokazMniej;
    @FindBy(id = "claimDescription")
    public static WebElement poleEdycyjneOpisZdarzenia;
    @FindBy(id = "damageData")
    public static WebElement poleEdycyjneRodzajUszkodzen;
    @FindBy(xpath = "//*[@name='vehicleTowed-radio']/..")
    public static WebElement przyciskWyboruCzyPojazdHolowany;
    @FindBy(xpath = "//*[@name='policeNotified-radio']/..")
    public static WebElement przyciskWyboruCzyPowiadomionoPolicje;
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
