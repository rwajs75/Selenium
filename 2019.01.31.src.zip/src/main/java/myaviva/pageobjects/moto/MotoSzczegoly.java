package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoSzczegoly {

    //Mapowanie elementow na stronie szczegółów polisy moto
    @FindBy(xpath = "//*/a[contains(text(), 'Wróć do produktów')]")
    public static WebElement linkWrocDoProduktow;
    @FindBy(xpath = "//*[@class='m-tabs__control ']")
    public static WebElement dokumenty;
    @FindBy(xpath = "//*[contains(text(), 'Numer polisy')]/../p")
    public static WebElement numerpolisy;
    @FindBy(xpath = "//*[contains(text(), 'Data zakończenia ochrony')]/../p")
    public static WebElement dataZakonczeniaOchrony;
    @FindBy(xpath = "//*[contains(text(), 'Wysokość składki')]/../p")
    public static WebElement wysokoscSkladki;
    @FindBy(xpath = "//*[contains(text(), 'Rachunek do wpłaty')]/../p")
    public static WebElement rachunekDoWplaty;
    @FindBy(xpath = "//*[contains(text(), 'Harmonogram płatności')]")
    public static WebElement harmonogramPlatnosci;
    @FindBy(xpath = "//*[contains(text(), 'Składka')]/../../p")
    public static WebElement skladka;
    @FindBy(xpath = "//*[contains(text(), 'Płatna do')]/../../p")
    public static WebElement platnaDo;
    @FindBy(xpath = "//*[contains(text(), 'Saldo składki')]/../../p")
    public static WebElement saldoSkladki;
    @FindBy(xpath = "//*[contains(text(), 'Status płatności')]/../p")
    public static WebElement statusPlatnosci;
    @FindBy(xpath = "//*[@href='#m-form-row__help--0']")
    public static WebElement linkPokazWiecejOC;
    @FindBy(xpath = "//*[@href='https://www.aviva.pl/ubezpieczenia/samochodowe/ubezpieczenie-oc.html']")
    public static WebElement linkDowiedzSieWiecejOC;
    @FindBy(xpath = "//*[@id='m-form-row__help--0']/div/a/span")
    public static WebElement linkPokazMniejOC;
    @FindBy(xpath = "//*[@href='#m-form-row__help--1']")
    public static WebElement linkPokazWiecejNNW;
    @FindBy(xpath = "//*[@href='https://www.aviva.pl/ubezpieczenia/samochodowe/ubezpieczenie-nnw.html']")
    public static WebElement linkDowiedzSieWiecejNNW;
    @FindBy(xpath = "//*[@id='m-form-row__help--0']/div/a/span")
    public static WebElement linkPokazMniejNNW;
    @FindBy(xpath = "//*[@href='#m-form-row__help--2']")
    public static WebElement linkPokazWiecejASS;
    @FindBy(xpath = "//*[@href='https://www.aviva.pl/ubezpieczenia/samochodowe/assistance.html']")
    public static WebElement linkDowiedzSieWiecejASS;
    @FindBy(xpath = "//*[@id='m-form-row__help--0']/div/a/span")
    public static WebElement linkPokazMniejASS;
    @FindBy(xpath = "//*[@href='#m-form-row__help--3']")
    public static WebElement linkPokazWiecejABJ;
    @FindBy(xpath = "//*[@href='https://www.aviva.pl/ubezpieczenia/samochodowe/szkola-bezpiecznej-jazdy.html']")
    public static WebElement linkDowiedzSieWiecejABJ;
    @FindBy(xpath = "//*[@id='m-form-row__help--0']/div/a/span")
    public static WebElement linkokazMniejABJ;
    @FindBy(xpath = "//*[contains(text(), 'Nr rejestracyjny')]/../p")
    public static WebElement NrRejestracyjny;
    @FindBy(xpath = "//*[contains(text(), 'Marka')]/../p")
    public static WebElement marka;
    @FindBy(xpath = "//*[contains(text(), 'Wersja modelu')]/../p")
    public static WebElement wersjaModelu;
    @FindBy(xpath = "//*[contains(text(), 'Typ nadwozia')]/../p")
    public static WebElement typNadwozia;
    @FindBy(xpath = "//*[contains(text(), 'Rok produkcji pojazdu')]/../p")
    public static WebElement rokProdukcjiPojazdu;
    @FindBy(xpath = "//*[contains(text(), 'Rok nabycia pojazdu')]/../p")
    public static WebElement rokNabyciaPojazdu;
    @FindBy(xpath = "//*[contains(text(), 'Pojemność silnika')]/../p")
    public static WebElement pojemnoscSilnika;
    @FindBy(xpath = "//*[contains(text(), 'Rodzaj paliwa')]/../p")
    public static WebElement rodzajPaliwa;
    @FindBy(xpath = "//*[contains(text(), 'Numer VIN')]/../p")
    public static WebElement numerVIN;
}
