package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoOCZgloszenieSzkody1 {

    //Mapowanie przycisków na stronie zgłaszania szkody samochodowej OC 1 z 2
    @FindBy(xpath = "//*[@ng-reflect-name='motoEventType']")
    public static WebElement listaRodzajZdarzenia;
    @FindBy(xpath = "//*[@ng-reflect-name='motoEventCause']")
    public static WebElement listaPrzyczynaZdarzenia;
    @FindBy(id = "policyNumber")
    public static WebElement poleTekstoweNumerPolisySprawcy;
    @FindBy(id = "registryNumber")
    public static WebElement poleTekstoweNumerRejestracyjnySprawcy;
    @FindBy(id = "deliquentdata")
    public static WebElement poleEdycyjneDaneSprawcyWypadku;
    @FindBy(xpath = "//*[@id='incidentDate']/input")
    public static WebElement poleTekstoweDataZdarzenia;
    @FindBy(id = "timeHours")
    public static WebElement poleTekstoweGodzina;
    @FindBy(id = "timeMinutes")
    public static WebElement poleTekstoweMinuty;
    @FindBy(id = "eventLocation")
    public static WebElement poleTekstoweMiejsceZdarzenia;
    @FindBy(xpath = "//*[contains(text(), 'Pokaż więcej')]")
    public static WebElement linkPokazWiecej;
    @FindBy(xpath = "//*[contains(text(), 'Pokaż mniej')]")
    public static WebElement linkPokazMniej;
    @FindBy(id = "claimDescription")
    public static WebElement poleEdycyjneOpisZdarzenia;
    @FindBy(id = "damageData")
    public static WebElement poleEdycyjneRodzajUszkodzen;
    @FindBy(xpath = "//*[@name='vehicleTowed-radio']/..//*[contains(text(), 'Tak')]")
    public static WebElement przyciskWyboruCzyPojazdHolowany;
    @FindBy(xpath = "//*[@name='policeNotified-radio']/..//*[contains(text(), 'Tak')]")
    public static WebElement przyciskWyboruCzyPowiadomionoPolicje;
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
