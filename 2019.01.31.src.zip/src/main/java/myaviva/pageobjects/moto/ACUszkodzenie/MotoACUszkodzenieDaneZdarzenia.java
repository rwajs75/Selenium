package myaviva.pageobjects.moto.ACUszkodzenie;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoACUszkodzenieDaneZdarzenia {

    //Mapowanie elementow na stronie Dane zdarzenia dla AC Uszkodzenie
    @FindBy(xpath = "//*[@id='eventDate']/input")
    public static WebElement poleTekstoweDataZdarzenia;
    @FindBy(id = "timeHours")
    public static WebElement poleTekstoweGodzina;
    @FindBy(id = "timeMinutes")
    public static WebElement poleTekstoweMinuty;
    @FindBy(xpath = "//*[contains(text(), 'Nie znam adresu zdarzenia')]/..")
    public static WebElement poleOpcjiNieZnamAdresuZdarzenia;
    @FindBy(id = "localization")
    public static WebElement poleEdycyjneLokalizacja;
    @FindBy(name = "policeAtPlace")
    public static WebElement przyciskWyboruCzyBylaPolicja;
    @FindBy(xpath = "//*[@name='carParked']/../span")
    public static WebElement przyciskWyboruCzyPojazdBylZaparkowany;
    @FindBy(xpath = "//*[@name='phoneNumber']/input")
    public static WebElement poleTekstoweNumerTelefonu;
    @FindBy(xpath = "//*[@name='damageCause']/../span")
    public static WebElement przyciskWyboruPrzyczynaUszkodzenia;
    @FindBy(xpath = "//*[@name='assistance']/../span")
    public static WebElement przyciskWyboruCzyPojazdBylHolowany;
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
