package myaviva.pageobjects.moto.ACUszkodzenie;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoZdjeciaIDokumenty {

    //Mapowanie elementów na stronie Zdjęcia i Dokumenty
    @FindBy(xpath = "//*[contains(text(), 'Dodaj zdjęcie')]")
    public static WebElement przyciskDodajZdjeciaUszkodzen;
    @FindBy(xpath = "//*[contains(text(), 'Dodaj plik')]")
    public static WebElement przyciskDodajOswiadczenieSprawcy;
    @FindBy(xpath = "//*[contains(text(), 'Przejdź do podsumowania')]")
    public static WebElement przyciskPrzejdzDoPodsumowania;
}
