package myaviva.pageobjects.moto.ACUszkodzenie;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoDaneUczestnikowZdarzenia {

    //Mapowanie elementów na stronie Dane uczetników zdarzenia
    @FindBy(id = "firstName_perpetrator")
    public static WebElement poleTekstoweImieSprawcy;
    @FindBy(id = "lastName_perpetrator")
    public static WebElement poleTekstoweNazwiskoSprawcy;
    @FindBy(id = "pesel_perpetrator")
    public static WebElement poleTekstowePeselSprawcy;
    @FindBy(id = "missingPesel_perpetrator")
    public static WebElement poleOpcjiOsobaNiePosiadaPesel;
    @FindBy(id = "phoneNumber_perpetrator")
    public static WebElement poleTekstoweNumerTelefonuSprawcy;
    @FindBy(id = "postalCodePrefix")
    public static WebElement poleTekstoweKodPocztowy1;
    @FindBy(id = "postalCodeSuffix")
    public static WebElement poleTekstoweKodPocztowy2;
    @FindBy(id = "city_perpetrator")
    public static WebElement poleTekstoweMiejscowoscSprawcy;
    @FindBy(id = "houseNumber_perpetrator")
    public static WebElement poleTekstoweNumerDomuSprawcy;
    @FindBy(id = "flatNumber_perpetrator")
    public static WebElement poleTekstoweNumerMIeszkaniaSprawcy;
    @FindBy(id = "street_perpetrator")
    public static WebElement poleTekstoweUlicaSprawcy;
    @FindBy(id = "registrationNumber_perpetrator")
    public static WebElement poleTekstoweNumerRejestracyjnySprawcy;
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
