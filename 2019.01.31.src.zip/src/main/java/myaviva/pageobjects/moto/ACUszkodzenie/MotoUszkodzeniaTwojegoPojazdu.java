package myaviva.pageobjects.moto.ACUszkodzenie;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoUszkodzeniaTwojegoPojazdu {

    //Mapowanie elementów na stronie Uszkodzenia Twojego pojazdu
    @FindBy(id = "tyl")
    public static WebElement uszkodzonyElementTyl;
    @FindBy(xpath = "//*[contains(text(), 'Zderzak tylny')]")
    public static WebElement poleOpcjiZderzakTylny;
    @FindBy(xpath = "//*[contains(text(), 'Lakierowany')]")
    public static WebElement przyciskWyboruCzyLakierowany;
    @FindBy(xpath = "//*[contains(text(), 'Pęknięty')]")
    public static WebElement przyciskWyboruCzyPekniety;
    @FindBy(xpath = "(//*[contains(text(), 'Czy uszkodzone zostały czujniki parkowania?')]/..//span/span)[2]")
    public static WebElement przyciskWyboruCzyUszkodzoneCzujniki;
    @FindBy(xpath = "//*[contains(text(), 'Lampa tylna prawa')]")
    public static WebElement poleOpcjiLampaTylnaLewa;
    @FindBy(xpath = "//*[contains(text(), 'Lampa tylna lewa')]")
    public static WebElement poleOpcjiLampaTylnaPrawa;
    @FindBy(xpath = "//*[contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapisz;
    @FindBy(xpath = "//*[contains(text(), 'Anuluj')]")
    public static WebElement przyciskAnuluj;
    @FindBy(id = "isOtherDamages")
    public static WebElement poleOpcjiInneUszkodzenia;
    @FindBy(id = "description")
    public static WebElement poleEdycyjneOpisUszkodzenia;
    @FindBy(xpath = "(//*[@name='isWorkshop']/../span[1])[2]")
    public static WebElement poleWyboruCzyPojazdWWarsztacie;
    @FindBy(id = "workshopName")
    public static WebElement poleTekstoweNazwaWarsztatu;
    @FindBy(className = "a-textbox a-textbox--2-character")
    public static WebElement poleTekstoweKodPocztowyWarsztatu1;
    @FindBy(className = "a-textbox a-textbox--3-character")
    public static WebElement poleTekstoweKodPocztowyWarsztatu2;
    @FindBy(id = "workshopCity")
    public static WebElement poleTekstoweMiejscowoscWarsztatu;
    @FindBy(id = "workshopHouseNumber")
    public static WebElement poleTekstoweNumerDomuWarsztatu;
    @FindBy(id = "flatNumber_")
    public static WebElement poleTekstoweNumerMieszkaniaWarsztatu;
    @FindBy(id = "workshopStreet")
    public static WebElement poleTekstoweUlicaWarsztatu;
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
