package myaviva.pageobjects.moto.ACUszkodzenie;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoACUszkodzeniePodsumowanie {

    //Mapowanie elementów na stronie Podsumowanie dla AC Uszkodzenie
    @FindBy(xpath = "//*[contains(text(), 'Zdarzenie')]/../..//*[contains(text(), 'Edytuj')]")
    public static WebElement linkEdytujZdarzenie;
    @FindBy(xpath = "//*[contains(text(), 'Przybliżone ')]/../..//*[contains(text(), 'Pokaż więcej')]")
    public static WebElement linkPokazWiecejMiejscaZdarzenia;
    @FindBy(xpath = "//*[contains(text(), 'Przybliżone ')]/../..//*[contains(text(), 'Pokaż mniej')]")
    public static WebElement linkPokazMniejMiejscaZdarzenia;
    @FindBy(xpath = "//*[contains(text(), 'Twoje dane')]/../..//*[contains(text(), 'Edytuj')]")
    public static WebElement linkEdytujTwojeDaneKontaktowe;
    @FindBy(xpath = "//*[contains(text(), 'Dane sprawcy')]/../..//*[contains(text(), 'Edytuj')]")
    public static WebElement linkEdytujDaneSprawcyZdarzenia;
    @FindBy(xpath = "//*[contains(text(), 'Uszkodzenia ')]/../..//*[contains(text(), 'Edytuj')]")
    public static WebElement linkEdytujUszkodzeniaTwojegoPojazdu;
    @FindBy(xpath = "//*[@id='COMMON_STATEMENT']/../../..")
    public static WebElement poleOpcjiPotwierdzam;
    @FindBy(xpath = "//*[contains(text(), 'Wyślij wniosek')]")
    public static WebElement przyciskWyslijWniosek;
}
