package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoDaneSamochodu {

    //Mapowanie elementow na stronie szczegółów polisy moto
    @FindBy(xpath = "//*[contains(text(), 'Zakres ubezpieczenia')]/../../..//h2")
    public static WebElement samochod;
    @FindBy(xpath = "//*[contains(text(), 'Zakres ubezpieczenia')]/../../..//p")
    public static WebElement numerRejestracyjny;
    @FindBy(xpath = "//*[contains(text(), 'Zakres ubezpieczenia')]/../../li[1]/p")
    public static WebElement numerPolisy;
    @FindBy(xpath = "//*[contains(text(), 'Zakres ubezpieczenia')]/../../li[2]/p")
    public static WebElement zakresUbezpieczenia;
    @FindBy(xpath = "//*[contains(text(), 'Zakres ubezpieczenia')]/../../li[3]/p")
    public static WebElement dataZakonczeniaOchrony;
    @FindBy(xpath = "//*[contains(text(), 'Zakres ubezpieczenia')]/../../li[4]/p")
    public static WebElement wysokoscSkladki;
    @FindBy(xpath = "//*[contains(text(), 'Zakres ubezpieczenia')]/../../..//*[contains(text(), 'Szczegóły')]")
    public static WebElement przyciskSzczegoly;
    @FindBy(xpath = "//*[contains(text(), 'Zakres ubezpieczenia')]/../../..//*[contains(text(), 'Zgłoś zdarzenie')]")
    public static WebElement przyciskZglosZdarzenie;
    @FindBy(xpath = "//*[contains(text(), 'Zakres ubezpieczenia')]/../../..//*[contains(text(), 'Zapłać')]")
    public static WebElement przyciskZaplac;
}
