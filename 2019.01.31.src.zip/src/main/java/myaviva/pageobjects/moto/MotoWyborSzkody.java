package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoWyborSzkody {

    //Mapowanie elementow na stronie wyboru rodzaju szkody moto
    @FindBy(xpath = "//*[contains(text(), 'AC uszkodzenie')]")
    public static WebElement linkAcUszkodzenie;
    @FindBy(xpath = "//*[contains(text(), 'AC kradzież')]")
    public static WebElement linkAcKradziez;
    @FindBy(xpath = "//*[contains(text(), 'Uszkodzenie szyb')]")
    public static WebElement linkUszkodzenieSzyb;
    @FindBy(xpath = "//*[contains(text(), 'OC')]")
    public static WebElement linkOc;
    @FindBy(xpath = "//*[contains(text(), 'Bezpośrednia Likwidacja Szkody')]")
    public static WebElement linkBezposredniaLikwidacjaSzkody;
    @FindBy(xpath = "//*[contains(text(), 'Szkoda osobowa')]")
    public static WebElement linkSzkodaOsobowa;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
