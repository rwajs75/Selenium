package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoDokumenty {

    //Mapowanie elementow na stronie szczegółów polisy moto w zakładce dokumenty
    @FindBy(xpath = "//*[@alt='file.png']")
    public static WebElement linkPobierzDokument;
    @FindBy(xpath = "//*[contains(text(), 'Dokumenty polisy')]")
    public static WebElement tekstDokumentyPolisy;
}
