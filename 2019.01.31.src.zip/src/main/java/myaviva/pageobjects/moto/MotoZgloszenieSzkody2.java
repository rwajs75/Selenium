package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoZgloszenieSzkody2 {

    //Mapowanie przycisków na stronie zgłaszania szkody samochodowej OC i Bezpośredniej Likwidacji Szkody 2 z 2
    @FindBy(id = "vehicleRegistrationNumber")
    public static WebElement poleTekstoweNumerRejestracyjnyPoszkodowanego;
    @FindBy(id = "vehicleVinNumber")
    public static WebElement poleTestoweNumerVinPoszkodowanego;
    @FindBy(id = "vehicleManufacturedYear")
    public static WebElement listaRokProdukcjiPoszkodowanego;
    @FindBy(name = "vehicleMake")
    public static WebElement listaMarkaPoszkodowanego;
    @FindBy(name = "vehicleModel")
    public static WebElement listaModelPoszkodowanego;
    @FindBy(id = "vehicleInspectionPlace")
    public static WebElement poleEdycyjneMiejsceOgledzin;
    @FindBy(id = "firstName_damageReporter")
    public static WebElement poleTekstoweImieZglaszajacego;
    @FindBy(id = "lastName_damageReporter")
    public static WebElement poleTekstoweNazwiskoZglaszajacego;
    @FindBy(id = "pesel_damageReporter")
    public static WebElement poleTekstowePeselZglaszajacego;
    @FindBy(id = "birthDate_damageReporter")
    public static WebElement poleTekstoweDataUrodzeniaZglaszjacego;
    @FindBy(id = "postalCodePrefix")
    public static WebElement poleTekstoweKodPocztowyZglaszajacego1;
    @FindBy(id = "postalCodeSuffix")
    public static WebElement poleTekstoweKodPocztowyZglaszajacego2;
    @FindBy(id = "city_damageReporter")
    public static WebElement poleTekstoweMiejscowoscZglaszajacego;
    @FindBy(id = "houseNumber_damageReporter")
    public static WebElement poleTekstoweNumerDomuZglaszajacego;
    @FindBy(id = "flatNumber_damageReporter")
    public static WebElement poleTekstoweNumerMieszkaniaZglaszajacego;
    @FindBy(id = "street_damageReporter")
    public static WebElement poleTekstoweUlicaZglaszajacego;
    @FindBy(id = "phoneNumber")
    public static WebElement poleTekstoweNumerTelefonuZglaszajacego;
    @FindBy(id = "email_damageReporter")
    public static WebElement poleTekstoweEmailZglaszajacego;
    @FindBy(xpath = "//*[@name='isReporterOwner-radio']/..//*[contains(text(), 'Tak')]")
    public static WebElement przyciskWyboruCzyZglaszajacyJestWlascicielem;
    @FindBy(xpath = "//*[@name='wasReporterDriver-radio']/..//*[contains(text(), 'Tak')]")
    public static WebElement przyciskWyboruCzyZglaszajacyKierowal;
    @FindBy(xpath = "//*[@name='accountNumber']/input")
    public static WebElement poleTekstoweNumerKonta;
    @FindBy(xpath = "//*[@name='accountOwnerType']/..//*[contains(text(), 'pojazdu')]")
    public static WebElement przyciskWyboruWlascicielaKonta;
    @FindBy(xpath = "//*[@name='claimHandlingType']/..//*[contains(text(), 'Kosztorys')]")
    public static WebElement przyciskWyboruSposobuRozliczeniaSzkody;
    @FindBy(xpath = "//*[@id='termsAndConditions']/../..")
    public static WebElement poleOpcjiAkceptuje;
    @FindBy(xpath = "//*[@id='electronicCorrespondence']/../..")
    public static WebElement poleOpcjiWyrazamZgode;
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
