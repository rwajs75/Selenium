package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoDziekujemy {

    //Mapowanie przycisków na podstronach zgłoszenia szkód
    @FindBy(xpath = "//*[contains(text(), 'Przejdź do strony głównej')]")
    public static WebElement przyciskPrzejdzDoStronyGlownej;
    @FindBy(xpath = "//*[contains(text(), 'Przejdź do produktów')]")
    public static WebElement przyciskPrzejdzDoProduktow;
    @FindBy(xpath = "//*[contains(text(), 'Numer szkody to:')]")
    public static WebElement tekstNumerSzkody;
    @FindBy(xpath = "//*[contains(text(), 'Trwa wyliczanie')]")
    public static WebElement kreciolTrwaWyliczenie;
}
