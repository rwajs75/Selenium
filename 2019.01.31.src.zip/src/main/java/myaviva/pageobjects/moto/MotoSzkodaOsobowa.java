package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoSzkodaOsobowa {

    //Mapowanie przycisków na stronie zgłaszania szkody osobowy
    @FindBy(id = "firstName")
    public static WebElement poleTekstoweImie;
    @FindBy(id = "lastName")
    public static WebElement poleTekstoweNazwisko;
    @FindBy(id = "email")
    public static WebElement poleTekstoweEmail;
    @FindBy(xpath = "//*[contains(text(), 'Polisa zgłaszającego')]")
    public static WebElement poleWyboruCzyjejPolisyDotyczyZgloszenie;
    @FindBy(id = "policyNumber")
    public static WebElement poleTekstoweNumerPolisyAviva;
    @FindBy(xpath = "//*[@id='eventDate']/input")
    public static WebElement poleTekstoweDataZdarzenia;
    @FindBy(id = "timeHours")
    public static WebElement poleTekstoweGodzina;
    @FindBy(id = "timeMinutes")
    public static WebElement poleTekstoweMinuty;
    @FindBy(id = "eventLocation")
    public static WebElement poleEdycyjneMiejsceZdarzenia;
    @FindBy(id = "eventDescription")
    public static WebElement poleEdycyjneOpisZdarzenia;
    @FindBy(xpath = "//*[@id='phoneNumber']/input")
    public static WebElement poleTekstoweNumerTelefonu;
    @FindBy(xpath = "//*[contains(text(), '9:00-12:00')]")
    public static WebElement poleWyboruGodzinykontaktu;
    @FindBy(xpath = "//*[@id='termsAndConditions']/../span")
    public static WebElement poleOpcjiAkceptuje;
    @FindBy(xpath = "//*[@id='electronicCorrespondence']/../span")
    public static WebElement poleOpcjiWyrazamZgode;
    @FindBy(xpath = "//*[contains(text(), 'Dalej')]")
    public static WebElement przyciskDalej;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
