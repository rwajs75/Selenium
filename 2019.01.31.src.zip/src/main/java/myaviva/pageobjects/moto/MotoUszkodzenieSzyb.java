package myaviva.pageobjects.moto;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoUszkodzenieSzyb {

    //Mapowanie elementów na stronie Uszkodzenie szyb
    @FindBy(xpath = "//*[contains(text(), 'Aby zgłosić szkodę prosimy o kontakt z infolinią')]")
    public static WebElement zgloszenieUszkodzeniaSzyb;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
