package myaviva.pageobjects.moto.ACKradziez;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoACKradziezPodsumowanie {

    //Mapowanie elementów na stronie Podsumowanie sla AC Kradzież
    @FindBy(xpath = "//*[contains(text(), 'Zdarzenie')]/../..//*[contains(text(), 'Edytuj')]")
    public static WebElement linkEdytujZdarzenie;
    @FindBy(xpath = "//*[contains(text(), 'Przybliżone ')]/../..//*[contains(text(), 'Pokaż więcej')]")
    public static WebElement linkPokazWiecejMiejscaZdarzenia;
    @FindBy(xpath = "//*[contains(text(), 'Przybliżone ')]/../..//*[contains(text(), 'Pokaż mniej')]")
    public static WebElement linkPokazMniejMiejscaZdarzenia;
    @FindBy(xpath = "//*[contains(text(), 'Opisz ')]/../..//*[contains(text(), 'Pokaż więcej')]")
    public static WebElement linkPokazWiecejOpisz;
    @FindBy(xpath = "//*[contains(text(), 'Opisz ')]/../..//*[contains(text(), 'Pokaż mniej')]")
    public static WebElement linkPokazMniejOpisz;
    @FindBy(xpath = "//*[contains(text(), 'Twoje dane')]/../..//*[contains(text(), 'Edytuj')]")
    public static WebElement linkEdytujTwojeDaneKontaktowe;
    @FindBy(xpath = "//*[@id='COMMON_STATEMENT']/../../..")
    public static WebElement poleOpcjiPotwierdzam;
    @FindBy(xpath = "//*[contains(text(), 'Wyślij wniosek')]")
    public static WebElement przyciskWyslijWniosek;
}
