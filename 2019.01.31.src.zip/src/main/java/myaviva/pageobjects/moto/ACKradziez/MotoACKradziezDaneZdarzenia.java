package myaviva.pageobjects.moto.ACKradziez;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoACKradziezDaneZdarzenia {

    //Mapowanie elementow na stronie Dane zdarzenia dla AC Kradzież
    @FindBy(xpath = "//*[@id='eventDate']/input")
    public static WebElement poleTekstoweDataZdarzenia;
    @FindBy(id = "timeHours")
    public static WebElement poleTekstoweGodzina;
    @FindBy(id = "timeMinutes")
    public static WebElement poleTekstoweMinuty;
    @FindBy(id = "localization")
    public static WebElement poleEdycyjneLokalizacja;
    @FindBy(name = "policeAtPlace")
    public static WebElement przyciskWyboruCzyBylaPolicja;
    @FindBy(xpath = "//*[@id='lastUsageDate']/input")
    public static WebElement poleTekstoweDataOstatniegoUzywania;
    @FindBy(name = "theftType")
    public static WebElement przyciskWyboruCoZostaloSkradzione;
    @FindBy(id = "eventDescription")
    public static WebElement poleEdycyjneOpisz;
    @FindBy(xpath = "//*[@name='phoneNumber']/input")
    public static WebElement poleTekstoweNumerTelefonu;
    @FindBy(xpath = "//*[contains(text(), 'Przejdź do podsumowania')]")
    public static WebElement przyciskPrzejdzDoPodsumowania;
    @FindBy(xpath = "//*[contains(text(), 'Wstecz')]")
    public static WebElement przyciskWstecz;
}
