package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_ZmianaEmailKrok2 {

    @FindBy(xpath = "//*[@id=\"EMail\"]")
    public static WebElement PoleAdresEmail;


    @FindBy(xpath = "//*[@id=\"ValidatePersonalDetailForm\"]//ul//button")
    public static WebElement Zapisz;

}
