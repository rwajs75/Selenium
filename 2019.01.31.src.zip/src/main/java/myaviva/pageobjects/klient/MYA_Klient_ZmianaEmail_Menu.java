package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_ZmianaEmail_Menu {

    @FindBy(id = "menu-toggle-button")
    public static WebElement TwojeKonto;

    @FindBy(xpath = "//*[@id=\"loggedin\"]/div//li[6]/a")
    public static WebElement MojProfil;


}
