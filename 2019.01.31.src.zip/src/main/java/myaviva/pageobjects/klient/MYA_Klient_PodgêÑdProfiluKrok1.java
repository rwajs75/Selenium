package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_PodgłądProfiluKrok1 {

    @FindBy(xpath = "//*[contains(text(), 'Pełne imię i nazwisko')]")
    public static WebElement ImieNazwisko;

    @FindBy(xpath = "//*[contains(text(), 'Data urodzenia')]")
    public static WebElement Dataurodzenia;

    @FindBy(xpath = "//*[contains(text(), 'PESEL')]")
    public static WebElement PESEL;

    @FindBy(xpath = "//*[contains(text(), 'Adres e-mail/login')]")
    public static WebElement Email;

    @FindBy(xpath = "//*[contains(text(), 'Numer telefonu komórkowego')]")
    public static WebElement Telefon;

    @FindBy(xpath = "//*[contains(text(), 'Ulica')]")
    public static WebElement Ulica;

    @FindBy(xpath = "//*[contains(text(), 'Numer domu')]")
    public static WebElement NumerDomu;

    @FindBy(xpath = "//*[contains(text(), 'Kod pocztowy')]")
    public static WebElement Kodpocztowy;

    @FindBy(xpath = "//*[contains(text(), 'Miasto')]")
    public static WebElement Miasto;

    @FindBy(xpath = "//*[contains(text(), 'E-mail')]")
    public static WebElement EmailKontakt;

    @FindBy(xpath = "//*[contains(text(), 'Telefon')]")
    public static WebElement TelefonKontakt;

    @FindBy(xpath = "//*[contains(text(), 'List')]")
    public static WebElement ListKontakt;

    @FindBy(xpath = "//*[contains(text(), 'Marketing w grupie Aviva')]")
    public static WebElement MarketingZgoda;

    @FindBy(xpath = "//*[contains(text(), 'Marketing przez telefon')]")
    public static WebElement TelefonZgoda;

    @FindBy(xpath = "//*[contains(text(), 'Marketing przez adres e-mail')]")
    public static WebElement EmailZgoda;

    @FindBy(xpath = "//*[contains(text(), 'Obecne hasło')]")
    public static WebElement Hasło;

}
