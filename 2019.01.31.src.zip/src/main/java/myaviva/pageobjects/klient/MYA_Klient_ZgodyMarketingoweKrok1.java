package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_ZgodyMarketingoweKrok1 {

    @FindBy(xpath = "//*[@id=\"edit-marketingPerm-button\"]")
    public static WebElement Edytuj;

    @FindBy(xpath = "//*[@id=\"ValidatePersonalDetailForm\"]/ul[1]/li[1]/label")
    public static WebElement Przetwarzanie;

    @FindBy(xpath = "//*[@id=\"ValidatePersonalDetailForm\"]/ul[1]/div//label")
    public static WebElement Przeztelefon;

    @FindBy(xpath = "//*[@id=\"ValidatePersonalDetailForm\"]/ul[1]/li[2]/label")
    public static WebElement Przezemail;

    @FindBy(xpath = "//*[@id=\"ValidatePersonalDetailForm\"]/ul[2]/li[1]/button")
    public static WebElement Zapisz;

}
