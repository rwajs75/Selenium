package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_ZmianaEmailKrok3 {

    @FindBy(xpath = "//*[@id=\"main\"]//div[2]/div[5]")
    public static WebElement Success;

}
