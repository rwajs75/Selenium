package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_ZmianaEmailKrok1 {

    @FindBy(xpath = "//*[@id=\"edit-email-button\"]")
    public static WebElement Edytuj;
}
