package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_SkrzynkaOdbiorczaKrok1 {


    @FindBy(xpath = "//*[@id=\"main\"]/ng-component//div[2]/ul/li")
    public static WebElement Wiadomosc;

    @FindBy(xpath = "//*[contains(text(), 'Pokaż więcej')] ")
    public static WebElement Pokazwiecej;





}
