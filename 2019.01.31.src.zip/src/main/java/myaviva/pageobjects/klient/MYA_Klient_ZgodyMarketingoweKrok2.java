package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_ZgodyMarketingoweKrok2 {


    @FindBy(xpath = "//*[@id=\"main\"]/div/div[2]/div[14]")
    public static WebElement ZmianyZostalyZapisane;

}
