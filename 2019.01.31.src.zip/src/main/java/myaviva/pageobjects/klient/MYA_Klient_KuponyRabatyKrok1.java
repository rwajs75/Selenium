package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_KuponyRabatyKrok1 {

    @FindBy(xpath = "//*[@id=\"main\"]/ng-component/div[1]")
    public static WebElement KuponyRabaty;




}
