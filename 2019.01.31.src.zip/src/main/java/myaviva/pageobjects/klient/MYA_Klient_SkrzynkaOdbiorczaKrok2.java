package myaviva.pageobjects.klient;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MYA_Klient_SkrzynkaOdbiorczaKrok2 {



    @FindBy(xpath = "//*[@id=\"m-form-row__help--0\"]/div[2]///span")
    public static WebElement Usunwiadomosc;

    @FindBy(xpath = "//*[@id=\"modalDescription\"]/ul/li[1]/button")
    public static WebElement Usun;



    ////////////////////////////////////////////////////////////////////////////




}
