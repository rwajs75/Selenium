package myaviva.pageobjects;

import helpers.urls.MyAvivaURL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.login.Login.url;

public class MyAvivaCommonPageObjects {

    private static WebDriver driver;

    //Inicjalizacja
    public static void initElement(WebDriver driver) {
        reporter().logPass("# Inicjalizacja obiektów $");
        PageFactory.initElements(driver, MyAvivaMojeProdukty.class);
        PageFactory.initElements(driver, MyAvivaAktualizacjaZU.class);
        PageFactory.initElements(driver, MyAvivaListaTwoichWnioskow.class);
        PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class);
        PageFactory.initElements(driver, MyAvivaRejestracjaKrok1.class);
        PageFactory.initElements(driver, MyAvivaStronaGlowna.class);
        PageFactory.initElements(driver, MyAvivaStronaLogowania.class);
        PageFactory.initElements(driver, MyAvivaSzkodyIRoszczenia.class);
        PageFactory.initElements(driver, MyAvivaZmienHaslo.class);
    }

    // Pozostał inicializacje
    @FindBy(id = "menu-toggle-button") public static WebElement przyciskTwojeKonto;
    @FindBy(xpath = "//a[text() = 'Mój Profil']") public static WebElement mojProfil;

    //Krecioly
    public static final By ladowanieDanych = By.xpath("//span[@class = 'a-ladowanieDanych-indicator__message spinner-fonts']");
    public static final By ladowanieDanych1 = By.xpath("//*[contains(text(), 'Proszę czekać')]");

    /**
     * Funkcja klikajaca po menu MyAviva (Belka oraz TwojeSprawy)
     * @param zakladka - pierwsze menu
     * @param podzakladka - drugie podmenu
     * @param driver
     */
     public static void clickMenuMyAviva(String zakladka, String podzakladka, String appEnv, WebDriver driver) {
         String webElementLink = null;
         boolean areUrlsDifferent = false;

         if (url==null) {
             url = driver.getCurrentUrl();
             reporter().logPass("URL = NULL. Pobrano aktualny URL: "+url);
         }
         String menu = "//*[contains(text(), '" + zakladka + "')]";
         String podmenu = "//*[contains(text(), '" + podzakladka + "')]";
         if (waitUntilElementPresent(By.xpath(menu), 30)!=null) {
             clickElement(By.xpath(menu));
             if (!podzakladka.equals("")) {
                 pauseFor(2);
                 if (waitUntilElementPresent(By.xpath(podmenu), 30) != null) {
                     webElementLink = getElement(By.xpath(podmenu)).getAttribute("href");
                 } else {
                     reporter().logFail("W menu nie została odnaleziona pozycja: " + podmenu);
                 }
             }
         } else {
             reporter().logFail("W menu nie została odnaleziona pozycja: " + menu);
         }

         waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
         waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

         if (!verifyDomainUrl("MyAviva", appEnv, false)) {
             areUrlsDifferent = true;
         }

         if (areUrlsDifferent) {
             reporter().logPass("Błędne przekierowanie linków z menu");
             switch (podzakladka) {
                 case "Moje Wnioski":
                     openUrl(true, MyAvivaURL.mojeWnioski(appEnv));
                     break;
                 case "Moje Szkody i Roszczenia":
                     openUrl(true, MyAvivaURL.szkodyRoszczenia(appEnv));
                     break;
                 case "Mój Profil":
                     openUrl(true, MyAvivaURL.mojProfil(appEnv));
                     break;
                 case "Wyloguj":
                     openUrl(true, MyAvivaURL.wyloguj(appEnv));
                     break;
                 default:
                     reporter().logFail("Link: "+podzakladka+ " nie istnieje. Należy dodać obsługę");
             }
             waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
             waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
         } else {
             clickElement(By.xpath(podmenu));
         }
     }
}
