package myaviva;

import helpers.common.Common;
import helpers.urls.CommonUrls;
import myaviva.pageobjects.Yopmail;
import org.openqa.selenium.WebDriver;

public class YopmailHelpers {

    public static void goToYopmail(WebDriver driver, String mail) {
        driver.get(CommonUrls.YOPMAIL_URL + mail);
    }

    public static void refreshInbox(WebDriver driver) {
        driver.switchTo().defaultContent();
        Common.clickElement(Yopmail.przyciskOdswiez);
    }

    public static int getNumberOfEmails(WebDriver driver) {
        driver.switchTo().defaultContent();
        return Integer.parseInt(Common.getElementText(Yopmail.licznikMaili).split(" ")[0]);
    }

    public static void showImages(WebDriver driver) {
        driver.switchTo().defaultContent();
        driver.switchTo().frame(Yopmail.FRAME_ID_PODGLAD_MAILA);
        Common.clickElement(Yopmail.przyciskPokazdZdjecia);
    }

    public static void deleteAllMessages(WebDriver driver) {
        driver.switchTo().defaultContent();
        driver.switchTo().frame(Yopmail.FRAME_ID_SKRZYNKA_ODBIORCZA);
        if(Common.waitUntilElementPresent(Yopmail.przyciskUsun, 1) != null) {
            Common.clickElement(Yopmail.przyciskUsun);
            Common.clickElement(Yopmail.przyciskWyczyscWszystkieSkrzynki);
        }
    }
}
