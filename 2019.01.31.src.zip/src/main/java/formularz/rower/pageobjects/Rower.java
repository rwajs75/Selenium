package formularz.rower.pageobjects;

public class Rower {
}
