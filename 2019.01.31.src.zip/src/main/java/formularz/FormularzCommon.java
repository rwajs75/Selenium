package formularz;

import formularz.house.pageobjects.*;
import formularz.moto.pageobjects.MotoCommon;
import formularz.moto.pageobjects.MotoDaneDoPolisy;
import formularz.moto.pageobjects.MotoKierowca;
import formularz.moto.pageobjects.MotoPodsumowanie;
import formularz.moto.pageobjects.MotoSamochod;
import formularz.moto.pageobjects.MotoTwojaOferta;
import formularz.moto.pageobjects.Samochod;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.gosc.MyAvivaStronaGlownaGoscia;
import myaviva.pageobjects.house.MyAvivaHouse;
import myaviva.pageobjects.travel.TravelTwojaPodroz;
import myaviva.pageobjects.travel.kupPolise.TravelDaneDoUbezpieczenia;
import myaviva.pageobjects.travel.kupPolise.TravelOferta;
import myaviva.pageobjects.travel.kupPolise.TravelPodsumowanie;
import myaviva.pageobjects.travel.kupPolise.TravelSprawdzCeneUbezpieczenia;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.reporter;

public class FormularzCommon {

    public static final By ladowanieDanych = By.xpath("//*[contains(text(), 'Proszę czekać')]");

    public static void initElement(WebDriver driver) {
        reporter().logPass("# Inicjalizacja obiektów $");

        //Ogólne
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);

        //House
        PageFactory.initElements(driver, HouseStronaGlowna.class);
        PageFactory.initElements(driver, HouseKrok1.class);
        PageFactory.initElements(driver, HouseKrok2.class);
        PageFactory.initElements(driver, HouseKrok3.class);
        PageFactory.initElements(driver, HouseKrok4.class);
        PageFactory.initElements(driver, MyAvivaHouse.class);
        PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class);
        PageFactory.initElements(driver, MyAvivaStronaGlownaGoscia.class);

        //Motor
        PageFactory.initElements(driver, MotoCommon.class);
        PageFactory.initElements(driver, MotoDaneDoPolisy.class);
        PageFactory.initElements(driver, MotoKierowca.class);
        PageFactory.initElements(driver, MotoPodsumowanie.class);
        PageFactory.initElements(driver, MotoSamochod.class);
        PageFactory.initElements(driver, MotoTwojaOferta.class);
        PageFactory.initElements(driver, Samochod.class);

        //Travel
        PageFactory.initElements(driver, TravelSprawdzCeneUbezpieczenia.class);
        PageFactory.initElements(driver, TravelOferta.class);
        PageFactory.initElements(driver, TravelDaneDoUbezpieczenia.class);
        PageFactory.initElements(driver, TravelPodsumowanie.class);
        PageFactory.initElements(driver, TravelTwojaPodroz.class);

    }

}
