package formularz.moto.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoTwojaOferta {

    //Mapowanie elementow na stronie Twoja oferta
    @FindBy(id = "checkCaptchaBtn")
    public static WebElement przyciskDalejCaptcha;
    @FindBy(id = "pdv4close")
    public static WebElement reklama;
    @FindBy(xpath = "//*[@value='Zaloguj się i odbierz zniżkę']")
    public static WebElement przyciskZalogujSieIOdbierzZnizke;
    @FindBy(xpath = "//*[@value='Kontynuuj bez zniżki']")
    public static WebElement przyciskKontynuujBezZnizki;
    @FindBy(xpath = "//*/a[contains(text(), 'Zapisz')]")
    public static WebElement przyciskZapisz;
    @FindBy(id = "kontakt_imie")
    public static WebElement poleTekstoweImie;
    @FindBy(id = "kontakt_nazwisko")
    public static WebElement poleTekstoweNazwisko;
    @FindBy(xpath = "//*[@value='Zapisz']")
    public static WebElement przyciskZapiszDane;
    @FindBy(xpath = "//*/a[contains(text(), 'OK')]")
    public static WebElement przyciskOK;


    //Sekcja Sposób płatności
    @FindBy(id = "sposob_platnosci")
    public static WebElement listaSposobPlatnosci;
    @FindBy(id = "forma_platnosci")
    public static WebElement listaFormaPlatnosci;
    @FindBy(id = "platnosc_imie")
    public static WebElement poleTekstoweImiePlatnik;
    @FindBy(id = "platnosc_nazwisko")
    public static WebElement poleTekstoweNazwiskoPlatnik;
    @FindBy(id = "button_payment")
    public static WebElement przyciskKupTeraz;

}
