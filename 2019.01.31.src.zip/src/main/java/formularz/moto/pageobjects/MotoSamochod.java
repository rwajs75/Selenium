package formularz.moto.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoSamochod {

    //Mapowanie elementow na stronie MotoSamochod
    @FindBy(id = "rok_produkcji")
    public static WebElement listaRokProdukcji;
    @FindBy(id = "marka")
    public static WebElement listaMarka;
    @FindBy(id = "model")
    public static WebElement listaModel;
    @FindBy(id = "rodzaj_paliwa")
    public static WebElement listaRodzajPaliwa;
    @FindBy(id = "czy_instalacja_gazowa")
    public static WebElement listaCzyInstalacjaGazowa;
    @FindBy(id = "pojemnosc_silnika")
    public static WebElement listaPojemnoscSilnika;
    @FindBy(id = "typ_nadwozia")
    public static WebElement listaTypNadwozia;
    @FindBy(id = "wersja_mod")
    public static WebElement listaWersjaModelu;
    @FindBy(name = "wypVersion")
    public static WebElement przyciskWyboruWersjaWyposazenia;
    @FindBy(name = "czy_zabezp_fabryczne")
    public static WebElement przyciskWyboruCzyZabezpieczeniaFabryczne;
    @FindBy(name = "rodzaj_zabezpieczen")
    public static WebElement przyciskWyboruRodzajZabezpieczen;
    @FindBy(id = "planowany_przebieg")
    public static WebElement listaPlanowanyPrzebieg;
    @FindBy(id = "miejsce_parkowania")
    public static WebElement listaMiejsceParkowania;
    @FindBy(id = "kod_miejsce_parkowania")
    public static WebElement poleTekstoweKodMiejscaParkowania;
    @FindBy(name = "sprowadzony_z_zagranicy")
    public static WebElement przyciskWyboruSprowadzonyZZagraniy;
    @FindBy(id = "kraj_pierwszej_rej")
    public static WebElement listaKrajPierszejRejestracji;
    @FindBy(name = "kierownica_z_prawej")
    public static WebElement przyciskWyboruKierownicaZPrawej;
    @FindBy(name = "uzywany_za_granica_wiecej_niz_30_dni")
    public static WebElement przyciskWyboruUzywanyZaGranicaWiecejNiz30Dni;
    @FindBy(name = "zarejestrowany_na_firma")
    public static WebElement przyciskWyboruZarejestrowanyNaFirme;
    @FindBy(id = "rok_nabycia_pojazdu")
    public static WebElement listaRokNabyciaPojazdu;
    @FindBy(id = "miesiac_nabycia_pojazdu")
    public static WebElement listaMiesiacNabyciaPojazdu;
    public static By komunikat = By.id("closeErrorBtn");
    @FindBy(id = "closeErrorBtn")
    public static WebElement przyciskOK;
}
