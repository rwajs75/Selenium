package formularz.moto.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoPodsumowanie {

    //Mapowanie elementow na stronie Podsumowanie
    @FindBy(xpath = "//*[contains(text(), 'Podsumowanie')]")
    public static WebElement podsumowanie;
    @FindBy(xpath = "//*[contains(text(), ' Witaj w gronie klientów Avivy! ')]")
    public static WebElement powitanie;
    @FindBy(id = "finish_payment")
    public static WebElement przyciskDalejOstatni;
    @FindBy(id ="pay_online")
    public static WebElement przyciskZaplac;
    @FindBy(xpath = "//*[@value='Zapisz kalkulację']")
    public static WebElement przyciskZapiszKalkulacje;
    @FindBy(xpath = "//*[@value='Zapisz']")
    public static WebElement przyciskZapisz;
    @FindBy(xpath = "//*/a[contains(text(), 'OK')]")
    public static WebElement przyciskOK;
    @FindBy(xpath = "//*[@value='Zamknij']")
    public static WebElement przyciskZamknij;
}
