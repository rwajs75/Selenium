package formularz.moto.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoDaneDoPolisy {

    //Mapowanie elementow na stronie Danene do polisy
    //Sekcja Dane do polisy
    @FindBy(id = "vin")
    public static WebElement poleTekstoweVin;
    @FindBy(id = "nr_rej")
    public static WebElement poleTekstoweNumerRejestracyjny;
    @FindBy(id = "bad_tech_y")
    public static WebElement poleTekstoweBadaniaTechniczneRok;
    @FindBy(id = "bad_tech_m")
    public static WebElement poleTekstoweBadaniaTechniczneMiesiac;
    @FindBy(id = "bad_tech_d")
    public static WebElement poleTekstoweBadaniaTechniczneDzien;

    //Sekcja Główny kierowca
    @FindBy(id = "osoby_0_pesel")
    public static WebElement poleTekstowePeselGlownyKierowca;
    @FindBy(id = "osoby_0_imie")
    public static WebElement poleTekstoweImieGlownyKierowca;
    @FindBy(id = "osoby_0_nazwisko")
    public static WebElement poleTekstoweNazwiskoGlownyKierowca;
    @FindBy(id = "osoby_0_miejscowosc_slownik")
    public static WebElement listaMiejscowoscGlownyKierowca;
    @FindBy(id = "osoby_0_ulica")
    public static WebElement poleTekstoweUlicaGlownyKierowca;
    @FindBy(id = "osoby_0_nr_domu")
    public static WebElement poleTekstoweNumerDomuGlownyKierowca;

    //Sekcja Dane ubezpieczającego
    @FindBy(id = "kto_jest_ubezpieczajacym")
    public static WebElement listaUbezpieczajacy;
    @FindBy(id = "osoby_4_pesel")
    public static WebElement poleTekstowePeselUbezpieczajacy;
    @FindBy(id = "osoby_4_imie")
    public static WebElement poleTekstoweImieUbezpieczajacy;
    @FindBy(id = "osoby_4_nazwisko")
    public static WebElement poleTekstoweNazwiskoUbezpieczajacy;
    @FindBy(id = "osoby_4_miejscowosc_slownik")
    public static WebElement listaMiejscowoscUbezpieczajacy;
    @FindBy(id = "osoby_4_ulica")
    public static WebElement poleTekstoweUlicaUbezpieczajacy;
    @FindBy(id = "osoby_4_nr_domu")
    public static WebElement poleTekstoweNumerDomuUbezpieczajacy;

    //Sekcja Informacje prawne
    @FindBy(id = "zaznacz_zgody")
    public static WebElement poleOpcjiZaznaczWszystkie;
}
