package formularz.moto.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoCommon {

    public static final By ladowanieDanych = By.xpath("//*[contains(text(), 'Proszę czekać')]");

    @FindBy(id = "button_prev")
    public static WebElement przyciskWstecz;
    @FindBy(id = "button_next")
    public static WebElement przyciskDalej;

    // Obiekty na belce do smoke testu
    @FindBy(xpath = "//*[@id='steps']//span[contains(text(), 'Samochód')]")
    public static WebElement obiektSamochod;
    @FindBy(xpath = "//*[@id='steps']//span[contains(text(), 'Kierowca')]")
    public static WebElement obiektKierowca;
    @FindBy(xpath = "//*[@id='steps']//span[contains(text(), 'Twoja oferta')]")
    public static WebElement obiektTwojaOferta;
    @FindBy(xpath = "//*[@id='steps']//span[contains(text(), 'Dane do polisy')]")
    public static WebElement obiektDaneDoPolisy;
    @FindBy(xpath = "//*[@id='steps']//span[contains(text(), 'Podsumowanie')]")
    public static WebElement obiektPodsumowanie;




}
