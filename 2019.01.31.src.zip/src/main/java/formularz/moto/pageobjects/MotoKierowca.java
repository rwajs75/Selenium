package formularz.moto.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MotoKierowca {

    //Mapowanie elementow na stronie MotoKierowca
    //sekcja Włąściciele
    @FindBy(name = "czy_jestes_kierowca")
    public static WebElement przyciskWyboruCzyJestesKierowca;
    @FindBy(name = "czy_jestes_wlascicielem")
    public static WebElement przyciskWyboruCzyJestesWlascicielem;
    @FindBy(name = "czy_kierowca_jest_wlascicielem")
    public static WebElement przyciskWyboruCzyKierowcaJestWlascicielem;
    @FindBy(name = "ilu_pozostalych_wlascicieli")
    public static WebElement przyciskWyboruIluPozostalychWlascicieli;
    @FindBy(name = "ilu_wlascicieli")
    public static WebElement przyciskWyboruIluWlascicieli;

    //sekcja Dane kierowcy i historia przebiegu ubezpieczenia
    @FindBy(name = "osoby[0].plec")
    public static WebElement przyciskWyboruOsoba0Plec;
    @FindBy(id = "stan_cywilny")
    public static WebElement listaStanCywilny;
    @FindBy(id = "osoby_0_data_urodzenia_y")
    public static WebElement listaOsoba0DataUrodzeniaRok;
    @FindBy(id = "osoby_0_data_urodzenia_m")
    public static WebElement listaOsoba0DataUrodzeniaMiesiac;
    @FindBy(id = "osoby_0_data_urodzenia_d")
    public static WebElement listaOsoba0DataUrodzeniaDzien;
    @FindBy(id = "czy_prawo_jazdy")
    public static WebElement poleOpcjiCzyPrawoJazdy;
    @FindBy(id = "rok_wydania")
    public static WebElement listaRokWydania;
    @FindBy(id = "liczba_dzieci")
    public static WebElement listaLiczbaDzieci;
    @FindBy(id = "liczba_samochodow")
    public static WebElement listaLiczbaSamochodow;
    @FindBy(name = "czy_kierowcy_pon_26_roku")
    public static WebElement przyciskWyboruCzyKierowcyPonizej26Roku;
    @FindBy(id = "wiek_najmlodszego")
    public static WebElement listaWiekNajmlodszego;
    @FindBy(id = "liczba_lat_pos_pj")
    public static WebElement listaIloscLatPosiadaniaPrawaJazdy;
    @FindBy(id = "osoby_0_l_lat_bezszkodowych_oc")
    public static WebElement listaOsoba0LiczbaLatBezszkodowychOC;
    @FindBy(id = "osoby_0_l_lat_bezszkodowych_ac")
    public static WebElement listaOsoba0LiczbaLatBezszkodowychAC;
    @FindBy(id = "osoby_0_l_szkod_3_lata_oc")
    public static WebElement listaOsoba0LiczbaSzkod3LataOC;
    @FindBy(id = "osoby_0_l_szkod_3_lata_ac")
    public static WebElement listaOsoba0LiczbaSzkod3LataAC;

    //Sekcja Dane pierwszego współwłaściciela i historia przebiegu ubezpieczenia
    @FindBy(id = "osoby_2_data_urodzenia_y")
    public static WebElement listaOsoba2DataUrodzeniaRok;
    @FindBy(id = "osoby_2_data_urodzenia_m")
    public static WebElement listaOsoba2DataUrodzeniaMiesiac;
    @FindBy(id = "osoby_2_data_urodzenia_d")
    public static WebElement listaOsoba2DataUrodzeniaDzien;
    @FindBy(id = "osoby_2_l_lat_bezszkodowych_oc")
    public static WebElement listaOsoba2LiczbaLatBezszkodowychOC;
    @FindBy(id = "osoby_2_l_lat_bezszkodowych_ac")
    public static WebElement listaOsoba2LiczbaLatBezszkodowychAC;
    @FindBy(id = "osoby_2_l_szkod_3_lata_oc")
    public static WebElement listaOsoba2LiczbaSzkod3LataOC;
    @FindBy(id = "osoby_2_l_szkod_3_lata_ac")
    public static WebElement listaOsoba2LiczbaSzkod3LataAC;

    //Sekcja Dane drugiego współwłaściciela i historia przebiegu ubezpieczenia
    @FindBy(id = "osoby_3_data_urodzenia_y")
    public static WebElement listaOsoba3DataUrodzeniaRok;
    @FindBy(id = "osoby_3_data_urodzenia_m")
    public static WebElement listaOsoba3DataUrodzeniaMiesiac;
    @FindBy(id = "osoby_3_data_urodzenia_d")
    public static WebElement listaOsoba3DataUrodzeniaDzien;
    @FindBy(id = "osoby_3_l_lat_bezszkodowych_oc")
    public static WebElement listaOsoba3LiczbaLatBezszkodowychOC;
    @FindBy(id = "osoby_3_l_lat_bezszkodowych_ac")
    public static WebElement listaOsoba3LiczbaLatBezszkodowychAC;
    @FindBy(id = "osoby_3_l_szkod_3_lata_oc")
    public static WebElement listaOsoba3LiczbaSzkod3LataOC;
    @FindBy(id = "osoby_3_l_szkod_3_lata_ac")
    public static WebElement listaOsoba3LiczbaSzkod3LataAC;

    //Sekcja Dane kontaktowe
    @FindBy(id = "ubezp_tel_rodz")
    public static WebElement listaTelefonRodzaj;
    @FindBy(id = "ubezp_nr_tel")
    public static WebElement poleTekstoweNumerTelefonu;
    @FindBy(id = "ubezp_email")
    public static WebElement poleTekstoweEmail;
    @FindBy(id = "zgodaMarketingowa1")
    public static WebElement poleOpcjiZgodaMarkentingowa1;
    @FindBy(id = "zgodaMarketingowa2")
    public static WebElement poleOpcjiZgodaMarkentingowa2;

    //Sekcja Nowe ubezpieczenie
    @FindBy(name = "zakres_ubezpieczenia")
    public static WebElement przyciskWyboruZakresUbezpieczenia;
    @FindBy(name = "czy_inne_ubezp_w_aviva")
    public static WebElement przyciskWyboruCzyInneUbezpieczenieAviva;
    @FindBy(id = "numer_agenta")
    public static WebElement poleTekstoweNumerAgenta;
    @FindBy(id = "ubezp_od_y")
    public static WebElement listaUbezpieczonyOdRok;
    @FindBy(id = "ubezp_od_m")
    public static WebElement listaUbezpieczonyOdMiesiac;
    @FindBy(id = "ubezp_od_d")
    public static WebElement listaUbezpieczonyOdDzien;
    @FindBy(id = "kod_promocyjny")
    public static WebElement poleTekstoweKodPromocyjny;
}
