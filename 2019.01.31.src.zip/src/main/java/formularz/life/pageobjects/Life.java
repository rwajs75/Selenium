package formularz.life.pageobjects;

public class Life {
}
