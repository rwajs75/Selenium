package formularz.house.urls;

public class HouseUrls {
}
