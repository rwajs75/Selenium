package formularz.house.pageobjects.kopia;

public class ApartmentKrok5 {

    //Ecard  //Ecard
    //
    //   // @FindBy(xpath = "//*[@id=\"blikPaymentForm\"]//div[1]/div[1]")
    //    //public static WebElement Visa;
    //
    //    //@FindBy(xpath = "//*[@id=\"blikPaymentForm\"]//button[1]/div[3]")
    //   // public static WebElement PrzyciskDalej;
    //
    //   // @FindBy(name="card-number")
    //   // public static WebElement NumerKarty;
    //
    //    //@FindBy(name="card-expiration-month")
    //   // public static WebElement MiesiacWaznosci;
    //
    //    //@FindBy(name="card-expiration-year")
    //   // public static WebElement RokWaznosci;
    //
    //   // @FindBy(name="card-cvv2")
    //   // public static WebElement CVV;
    //
    //   // @FindBy(xpath = "//section[2]//div[5]/button/div[2]")
    //   // public static WebElement Zaplac;//
}
