package formularz.house.pageobjects.kopia;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class KApartmentKrok2 {


    @FindBy(xpath = "//*[@id='main']//*[contains(text(), 'Krok 2')]")
    public static WebElement krok2;


    @FindBy(xpath = "//*[contains(text(), 'Wybierz')]/..//button")
    public static WebElement przyciskWybierz;

    @FindBy(xpath = "//*[contains(text(), 'Powrót')]/..//button")
    public static WebElement przyciskPowrot;
}
