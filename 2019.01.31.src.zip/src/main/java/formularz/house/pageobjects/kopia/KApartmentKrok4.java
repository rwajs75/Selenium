package formularz.house.pageobjects.kopia;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class KApartmentKrok4 {

    @FindBy(xpath = "//*[@id='main']//*[contains(text(), 'Krok 4')]")
    public static WebElement krok4;

    //Wazne dokumenty


    @FindBy(xpath = "//*[@id=\"main\"]//div[2]/a")
    public static WebElement DokumentOferta;

    @FindBy(xpath = "//*[@id=\"main\"]//div[3]/a")
    public static WebElement DokumentOWU;

    @FindBy(xpath = "//*[@id=\"main\"]//div[4]/a")
    public static WebElement DokumentERegulamin;

    @FindBy(xpath = "//*[contains(text(), 'Powrót')]")
    public static WebElement przyciskPowrot;

    @FindBy(xpath = "//*[contains(text(), 'Zapłać')]")
    public static WebElement przyciskZaplac;
}
