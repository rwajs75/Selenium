package formularz.house.pageobjects.kopia;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class KApartmentKrok6 {

    @FindBy(xpath = "//*[@id=\"main\"]//div/div[2]")
    public static WebElement Gratulacje;
}
