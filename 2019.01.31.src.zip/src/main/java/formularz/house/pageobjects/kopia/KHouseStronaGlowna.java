package formularz.house.pageobjects.kopia;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class KHouseStronaGlowna {

    // Strona glowna
    @FindBy(xpath = "//*[@id='hero']//*[contains(text(), 'Sprawdź cenę')]")
    public static WebElement przyciskSprawdzCene;
    @FindBy(xpath = "//*[@id='hero']//*[contains(text(), 'Zostaw')]")
    public static WebElement przyciskZostawKontaktOddzwonimy;

    //Strona z wyborem
    @FindBy(xpath = "//*[@id='main']//*[@label='Dom z kredytem']//button")
    public static WebElement przyciskWybierzDomZKredytem;

    // Proszę czekać
    @FindBy(xpath = "//app-pending-overlay-indicator/div/div/span[text()[contains('Proszę czekać...')]]")
    public static WebElement loading;

}
