package formularz.house.pageobjects.kopia;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class KApartmentKrok1 {


    @FindBy(xpath = "//*[@id='main']//*[contains(text(), 'Krok 1')]")
    public static WebElement krok1;

    @FindBy(xpath = "//*[@class='a-textbox a-textbox--2-character']")
    public static WebElement poleTekstoweKodPocztowy1;

    @FindBy(xpath = "//*[@class='a-textbox a-textbox--3-character']")
    public static WebElement poleTekstoweKodPocztowy2;

    @FindBy(xpath = "//*[@formcontrolname='city']")
    public static WebElement poleTekstoweMiejscowosc;

    @FindBy(xpath = "//*[@formcontrolname='street']")
    public static WebElement poleTekstoweUlica;

    @FindBy(xpath = "//*[@formcontrolname='homeNumber']")
    public static WebElement poleTekstoweNumerDomu;

    @FindBy(xpath = "//*[@formcontrolname='flatNumber']")
    public static WebElement poleTekstoweNumerLokalu;

    //Wybór piętra

    @FindBy(xpath = "//*[@id=\"main\"]//app-floor//li[2]/label/span[1]")
    public static WebElement poleWyboruPietroPosrednie;


    @FindBy(xpath = "//*[contains(text(), 'Powierzchnia')]/..//input")
    public static WebElement poleTekstowePowierzchnia;

    //Ile lat minęło od budowy lub remontu generalnego?

    @FindBy(xpath = "//*[@id=\"main\"]//app-construction-year//li[1]/label/span[1]")
    public static WebElement poleWyboruDo3lat;

    //Czy w ciągu ostatnich 3 lat zgłaszałeś w tym lokalu szkodę?

    @FindBy(xpath = "//*[@id=\"main\"]//app-section[1]/app-yes-no[1]//li[2]/label/span[1]")
    public static WebElement poleWyboruSzkodyNie;

    //Dodatkowe informacje
    //Czy w nieruchomości jest prowadzona działalność gospodarcza inna niż biurowa?

    @FindBy(xpath ="//*[@id=\"main\"]//app-section[2]//li[2]/label/span[1]")
    public static WebElement poleWyboruDzialanoscNie;

    @FindBy(xpath ="//*[@id=\"main\"]//app-phone-number//input")
    public static WebElement poleTekstoweNumerKomorkowy;


    @FindBy(xpath = "//*[@id=\"main\"]//div[2]/button")
    public static WebElement przyciskSprawdzCene;
}
