package formularz.house.pageobjects.kopia;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class KHouseKrok3 {

    @FindBy(xpath = "//*[@id='main']//*[contains(text(), 'Krok 3')]")
    public static WebElement krok3;

    //Dane do ubezpieczenia

    @FindBy(id = "sameCorrespondenceAddressAsProperty")
    public static WebElement poleOpcjiAdresKorespondencyjnyTak;

    //Twoje Dane

    @FindBy(xpath = "//*[@formcontrolname='firstName']")
    public static WebElement poleTekstoweImie;

    @FindBy(xpath = "//*[@formcontrolname='lastName']")
    public static WebElement poleTekstoweNazwisko;

    @FindBy(xpath = "//*[@formcontrolname='pesel']")
    public static WebElement poleTekstowePesel;

    @FindBy(xpath = "//*[@formcontrolname='email']")
    public static WebElement poleTekstoweEmail;

    @FindBy (xpath = "//*[@formcontrolname='mobilePhone']")
    public static WebElement poleTekstoweNumerTelefonu;

    @FindBy(xpath = "//*[@type='date']")
    public static WebElement listaDataRozpoczecia;

    //Cesja

    @FindBy(id = "bankCode")
    public static WebElement listaWybierzBankDoCesji;


    //Zgody i oświadczenia

    @FindBy(xpath = "//*[contains(text(), 'Akceptuję wszystkie poniższe zgody')]/..")
    public static WebElement poleOpcjiAkcetujeWszystkieZgody;

    @FindBy(xpath = "//*[contains(text(), 'Zgoda na przesyłanie dokumentów drogą elektroniczną')]/.." )
    public static WebElement poleOpcjiZgodaWysylkaElektroniczna;

    @FindBy(xpath = "//*[contains(text(), 'Zgoda na przetwarzanie moich danych osobowych przez Grupę Aviva')]/..")
    public static WebElement poleOpcjiZgodaDaneOsobowe;

    @FindBy(xpath = "//*[contains(text(), 'Zgoda na przesyłanie informacji handlowych')]/..")
    public static WebElement poleOpcjiZgodaInformacjeHandlowe;

    @FindBy(xpath = "//*[contains(text(), 'Oświadczam, że zapoznałem i akceptuję ')]/..")
    public static WebElement poleOpcjiOswiadczamZapoznalemIAkceptuje;

    @FindBy(xpath = "//*[contains(text(), 'Przejdź do podsumowania')]")
    public static WebElement przyciskPrzejdzDoPodsumowania;

    @FindBy(xpath = "//*[contains(text(), 'Powrót')]")
    public static WebElement przyciskPowrot;

}
