package formularz.house.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HouseStronaGlowna {
    
    public static final By ladowanieDanych = By.xpath("//*[@class='loader__message']");

    @FindBy(id="placeholderId")
    public static WebElement loginField;

    // Strona glowna
    @FindBy(xpath = "//*[@id='hero']//*[contains(text(), 'Sprawdź cenę')]")
    public static WebElement przyciskSprawdzCene;
    @FindBy(xpath = "//*[@id='hero']//*[contains(text(), 'Zostaw')]")
    public static WebElement przyciskZostawKontaktOddzwonimy;

    // Co chcesz ubezpieczyć ?
    @FindBy(xpath = "//*[@id='main']//*[@label='Mieszkanie']//button")
    public static WebElement przyciskWybierzMieszkanie;
    @FindBy(xpath = "//*[@id='main']//*[@label='Dom']//button")
    public static WebElement przyciskWybierzDom;
    @FindBy(xpath = "//*[@id='main']//*[@label='Mieszkanie z kredytem']//button")
    public static WebElement przyciskWybierzMieszkaniezKredytem;
    @FindBy(xpath = "//*[@id='main']//*[@label='Dom z kredytem']//button")
    public static WebElement przyciskWybierzDomzKredytem;

    // Obiekty na belce do smoke testu
    @FindBy(xpath = "//*[@id='main']//*[contains(text(), 'Krok 1')]")
    public static WebElement krok1;
    @FindBy(xpath = "//*[@id='main']//*[contains(text(), 'Krok 2')]")
    public static WebElement krok2;
    @FindBy(xpath = "//*[@id='main']//*[contains(text(), 'Krok 3')]")
    public static WebElement krok3;
    @FindBy(xpath = "//*[@id='main']//*[contains(text(), 'Krok 4')]")
    public static WebElement krok4;


}
