package formularz.house.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HouseKrok2 {

    //Oferta


/** Dom z kredytem */

    @FindBy(xpath = "//*[@variantname='Pakiet standardowy']//*[contains(text(), 'Wybierz')]")
    public static WebElement przyciskWybierzPakietStandart;

    /** Mieszkanie / z kredytem */

    @FindBy(xpath = "//*[contains(text(), 'Wybierz')]/..//button")
    public static WebElement przyciskWybierz;



    @FindBy(xpath = "//*[contains(text(), 'Powrót')]/..//button")
    public static WebElement przyciskPowrot;
}
