package formularz.house.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HouseKrok4 {



    //Wazne dokumenty


    @FindBy(xpath = "//*[@id=\"main\"]//div[2]/a")
    public static WebElement DokumentOferta;

    @FindBy(xpath = "//*[@id=\"main\"]//div[3]/a")
    public static WebElement DokumentOWU;

    @FindBy(xpath = "//*[@id=\"main\"]//div[4]/a")
    public static WebElement DokumentERegulamin;


    @FindBy(xpath = "//*[contains(text(), 'Powrót')]")
    public static WebElement przyciskPowrot;

    @FindBy(xpath = "//*[contains(text(), 'Zapłać')]")
    public static WebElement przyciskZaplac;

    //Finalizacja - Krok 6

    @FindBy(xpath = "//*[@id=\"main\"]//div/div[2]")
    public static WebElement Gratulacje;


}
