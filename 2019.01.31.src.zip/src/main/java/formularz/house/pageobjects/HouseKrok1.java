package formularz.house.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HouseKrok1 {

    /** Dane domu */


    @FindBy(xpath = "//*[@class='a-textbox a-textbox--2-character']")
    public static WebElement poleTekstoweKodPocztowy1;

    @FindBy(xpath = "//*[@class='a-textbox a-textbox--3-character']")
    public static WebElement poleTekstoweKodPocztowy2;

    @FindBy(xpath = "//*[@formcontrolname='city']")
    public static WebElement poleTekstoweMiejscowosc;

    @FindBy(xpath = "//*[@formcontrolname='street']")
    public static WebElement poleTekstoweUlica;

    @FindBy(xpath = "//*[@formcontrolname='homeNumber']")
    public static WebElement poleTekstoweNumerDomu;

    @FindBy(xpath = "//*[contains(text(), 'Powierzchnia')]/..//input")
    public static WebElement poleTekstowePowierzchnia;


    /** Mieszkanie / Mieszkanie z kredytem */


    @FindBy(xpath = "//*[@formcontrolname='flatNumber']")
    public static WebElement poleTekstoweNumerLokalu;

    //Wybór piętra
    @FindBy(xpath = "//*[@name='floorType']/..//*[contains(text(), 'Pośrednie')] ")
    public static WebElement poleWyboruPietroPosrednie;


    //Ile lat minęło od budowy lub remontu generalnego?
    @FindBy(xpath = "//*[@name='constructionYear']/..//*[contains(text(), 'Do 3 lat')] ")
    public static WebElement przyciskWyboruDo3Lat;

    //Czy w ciągu ostatnich 3 lat zgłaszałeś w tym lokalu szkodę?
    @FindBy(xpath = "//*[@name='damage']/..//*[contains(text(), 'Nie')] ")
    public static WebElement przyciskWyboruSzkodyNie;


    /**Dom*/

    //Rodzaj domu
    @FindBy(xpath = "//*[@name='buildingStyle']/..//*[contains(text(), 'Wolnostojący')]")
    public static WebElement przyciskWyboruWolnostojacy;


    //Czy ściany lub pokrycie dachu są wykonane z drewna lub słomy?
    @FindBy(xpath = "//*[@name='construction']/..//*[contains(text(), 'Nie')]")
    public static WebElement przyciskWyboruDachNie;

    //Dodatkowe informacje
    //Czy w nieruchomości jest prowadzona działalność gospodarcza inna niż biurowa?
    @FindBy(xpath ="//*[@name='realEstate']/..//*[contains(text(), 'Nie')] ")
    public static WebElement przyciskWyboruDzialalnoscNie;

    @FindBy(xpath ="//*[@id=\"main\"]//app-phone-number//input")
    public static WebElement poleTekstoweNumerKomorkowy;

    @FindBy(xpath = "//input[@formcontrolname='mobilePhone']")
    public static WebElement poleTekstoweNumerTelefonuKomorkowego;

    @FindBy(xpath = "//*[@id=\"main\"]//div[2]/button")
    public static WebElement przyciskSprawdzCene;

}
