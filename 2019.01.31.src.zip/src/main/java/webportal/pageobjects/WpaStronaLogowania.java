package webportal.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WpaStronaLogowania {

    @FindBy(xpath="//*[contains(text(), 'Jestem Klientem')]")
    public static WebElement przyciskJestemKlientem;

    @FindBy(xpath="//*[contains(text(), 'Jestem Agentem')]")
    public static WebElement przyciskJestemAgentem;
}
