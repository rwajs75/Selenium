package webportal.pageobjects;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

public class WpaCommonPageObjects {


    public static void setRadioButton(String pytanie , String checbox, WebDriver driver) {


   /*     String ankieta = "//*[contains(text(), '" + pytanie + "')]";
        String pytanieA = getElement(By.xpath(ankieta), "for");
        System.out.println(pytanieA);*/

/*        if (driver.findElement(By.xpath(ankieta)).isDisplayed()){
            String przedrostekPytania = driver.findElement(By.xpath(ankieta)).getAttribute("for");
        }*/
    }


    public static By spinner = By.xpath("//div[@class='spinner']");

    public static By smallSpinner = By.xpath("//*[@class='spinner_small']");

    public static By tekstGotowyDoPobrania = By.xpath("//*[contains(text(), 'gotowy do pobrania')]");

    @FindBy(xpath = "//button[contains(text(), 'dalej')]")
    public static WebElement przyciskDalej;

    @FindBy(xpath = "//button[contains(text(), 'Drukuj polisę')]")
    public static WebElement przyciskDrukujPolise;

    @FindBy(xpath = "//button[text()='tak']")
    public static WebElement przyciskTak;

    @FindBy(xpath = "//button[text()='Tak']")
    public static WebElement przyciskTak2;

    @FindBy(xpath = "//button[text()='nie']")
    public static WebElement przyciskNie;

    @FindBy(xpath = "//button[text()='Nie']")
    public static WebElement przyciskNie2;

}
