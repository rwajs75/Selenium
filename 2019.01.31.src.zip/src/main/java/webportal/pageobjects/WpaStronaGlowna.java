package webportal.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WpaStronaGlowna {

    @FindBy(id="gwt-uid-20")
    public static WebElement przyciskStartMenu;

    @FindBy(xpath="//*[@class='cl-search-accordion' and @style='clear:both'][1]/div[2]/div/div/table/tbody/tr[1]/td/table/tbody/tr[2]/td[3]/button")
    public static WebElement przyciskKalkulatorPartnerwBiznesie;

    @FindBy(xpath="//*[@class='cl-search-accordion' and @style='clear:both'][1]/div[2]/div/div/table/tbody/tr[1]/td/table/tbody/tr[3]/td[3]/button")
    public static WebElement przyciskKalkulatorPartnerwBiznesiePlus;

    @FindBy(xpath="//*[@class='cl-search-accordion' and @style='clear:both'][1]/div[2]/div/div/table/tbody/tr[1]/td/table/tbody/tr[4]/td[3]/button")
    public static WebElement getPrzyciskKalkulatorWdrodze;

    @FindBy(xpath="//*[@class='cl-search-accordion' and @style='clear:both'][2]/div[2]/div/div/table/tbody/tr[1]/td/table/tbody/tr[2]/td[3]/button")
    public static WebElement getPrzyciskKalkulatorFolderPotrzeb;


}
