package webportal.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WpaPartnerBiznes {

    @FindBy(id="insuranceType")
    public static WebElement listaRozwijanaRodzajUbezpieczenia;

    @FindBy(id="insuranceDateFromYear")
    public static WebElement listaRozwijanaOkresUbezpieczeniaOdRok;

    @FindBy(id="insuranceDateFromMonth")
    public static WebElement listaRozwijanaOkresUbezpieczeniaOdMiesiac;

    @FindBy(id="insuranceDateFromDay")
    public static WebElement listaRozwijanaOkresUbezpieczeniaOdDzien;

    @FindBy(id="insuranceDateToYear")
    public static WebElement listaRozwijanaOkresUbezpieczeniaDoRok;

    @FindBy(id="insuranceDateToMonth")
    public static WebElement listaRozwijanaOkresUbezpieczeniaDoMiesiac;

    @FindBy(id="insuranceDateToDay")
    public static WebElement listaRozwijanaOkresUbezpieczeniaDoDzien;

    @FindBy(id="generalQuestion_label")
    public static WebElement pytanieCzyObawiajasiePanstwoZniszczeniaMieniaFirmowego;

    @FindBy(id="lumpOrNormalTaxSettlement_label")
    public static WebElement pytanieCzyUbezpieczajacyRozliczaSieNaPodstawieKarty;

    @FindBy(id="isAvivaClient_label")
    public static WebElement pytanieCzyJestesKlientemAvivaBezOFE;

    @FindBy(id="lastOrNextYearGrossReceipts_label")
    public static WebElement pytanieKlientOWUPartnerwBiznesieSpelniaLacznieWarunki;



}
