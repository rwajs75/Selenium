package webportal.pageobjects.wdrodze;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WpaWDrodzeInfoOPojezdzie {

    @FindBy(xpath = "//*[text()='Rok produkcji']/../..//select")
    public static WebElement listaRokProdukcji;

    @FindBy(xpath = "//*[@class='gwt-DateBox']")
    public static WebElement poleDataRozpUbezpieczenia;

    @FindBy(xpath = "//*[text()='Marka']/../..//select")
    public static WebElement listaMarka;

    @FindBy(xpath = "//*[text()='Model']/../..//select")
    public static WebElement listaModel;

    @FindBy(xpath = "//*[text()='Rodzaj paliwa']/../..//select")
    public static WebElement listaRodzajPaliwa;

    @FindBy(xpath = "//*[text()='Czy instalacja gazowa']/../..//select")
    public static WebElement listaCzyInstalacjaGazowa;

    @FindBy(xpath = "//*[text()='Pojemność silnika']/../..//select")
    public static WebElement listaPojemnoscSilnika;

    @FindBy(xpath = "//*[text()='Typ nadwozia']/../..//select")
    public static WebElement listaTypNadwozia;

    @FindBy(xpath = "//*[text()='Typ']/../..//select")
    public static WebElement listaTyp;

    @FindBy(xpath = "//*[text()='Sprawne zabezpieczenia w pojeździe']/../..//select")
    public static WebElement listaSprawneZabezpieczenia;

    @FindBy(xpath = "//*[text()='Modyfikacje']/../..//label[text()='Nie']/../input")
    public static WebElement opcjaBrakModyfikacji;

    @FindBy(xpath = "//*[@name='carVersion' and @tabindex='0']")
    public static WebElement opcjaWersjaPierwsza;


    @FindBy(xpath = "//div[@class='gwt-HTML' and text()='Użytkowanie pojazdu']/../..//select")
    public static WebElement listaUzytkowaniePojazdu;

    @FindBy(xpath = "//*[text()='Czy samochód zarejestrowany na firmę']/../..//label[text()='Nie']/../input")
    public static WebElement opcjaNieNaFirme;

    @FindBy(xpath = "//*[text()='Rok nabycia pojazdu']/../..//input")
    public static WebElement poleRokNabyciaPojazdu;

    @FindBy(xpath = "//*[text()='Miesiąc nabycia pojazdu']/../..//select")
    public static WebElement listaMiesiacNabyciaPojazdu;

    @FindBy(xpath = "//*[text()='Czy pojazd zarejestrowany w Polsce']/../..//label[text()='Tak']/../input")
    public static WebElement opcjaZarejestrowanyWPolsce;

    @FindBy(xpath = "//*[text()='Kraj pierwszej rejestracji pojazdu']/../..//select")
    public static WebElement listaKrajPierwszejRejestracji;

    @FindBy(xpath = "//*[text()='Deklarowany roczny przebieg']/../..//select")
    public static WebElement listaDeklarowanyPrzebieg;

    @FindBy(xpath = "//*[contains(text(), 'Czy samochód będzie użytkowany')]/../..//*[text() = 'Nie']/../input")
    public static WebElement opcjaNieUzytkowanyZaGranicaPow30Dni;

    @FindBy(xpath = "//*[text()='Miejsce parkowania pojazdu w nocy']/../..//select")
    public static WebElement listaMiejsceParkowaniaWNocy;

    @FindBy(xpath = "//*[text()='Kod pocztowy parkowania']/../..//input")
    public static WebElement poleKodPocztowyParkowania;

    @FindBy(xpath = "//*[text()='Miejscowość parkowania']/../..//input")
    public static WebElement poleMiejscowoscParkowania;

    @FindBy(xpath = "//*[text()='Czy będą kierowcy w wieku poniżej 26 lat?']/../..//*[text() = 'Nie']/../input")
    public static WebElement opcjaBrakKirowcowPonizej26Lat;
}
