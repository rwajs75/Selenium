package webportal.pageobjects.wdrodze;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WpaWDrodzeHistoria {

    @FindBy(xpath = "//*[text()='Imię']/../..//input")
    public static WebElement poleImie;

    @FindBy(xpath = "//*[text()='Nazwisko']/../..//input")
    public static WebElement poleNazwisko;

    @FindBy(xpath = "//*[text()='Pesel']/../..//input")
    public static WebElement polePesel;


    //OC
    @FindBy(xpath = "//*[text()='Liczba lat bezszkodowści OC']/../..//select") //sic, należy zwracać uwagę na poprawienie literówki w aplikacji
    public static WebElement listaLiczbaLatBezszkodowosciOC;

    @FindBy(xpath = "//*[text()='Liczba szkód na OC']/../..//select")
    public static WebElement listaLiczbaSzkodOC;



    @FindBy(xpath = "//*[contains(text(), 'Klient potwierdza, że zapoznał się')]/../..//input")
    public static WebElement checkboxKlientSieZapoznal;

    @FindBy(xpath = "(//*[contains(text(), 'Wyrażam zgodę na otrzymywanie')]/../..//input[@type='radio'])[1]")
    public static WebElement opcjaDokumentyTylkoElektronicznie;
}
