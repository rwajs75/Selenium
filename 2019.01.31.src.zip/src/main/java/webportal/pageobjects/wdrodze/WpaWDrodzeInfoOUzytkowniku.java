package webportal.pageobjects.wdrodze;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WpaWDrodzeInfoOUzytkowniku {

    @FindBy(xpath = "(//*[@name='Płeć (user)'])[1]")
    public static WebElement opcjaKobieta;

    @FindBy(xpath = "(//*[@name='Płeć (user)'])[2]")
    public static WebElement opcjaMezczyzna;

    @FindBy(xpath = "//*[text()='Data urodzenia']/../..//input")
    public static WebElement poleDataUrodzenia;

    @FindBy(xpath = "//*[text()='Rok wydania prawa jazdy']/../..//select")
    public static WebElement listaRokWydaniaPrawaJazdy;

    @FindBy(xpath = "//*[text()='Stan cywilny']/../..//select")
    public static WebElement listaStanCywilny;

    @FindBy(xpath = "//*[text()='Dzieci poniżej 18 roku']/../..//select")
    public static WebElement listaDzieciPonizej18;

    @FindBy(xpath = "//*[text()='Liczba pojazdów w gospodarstwie domowym']/../..//select")
    public static WebElement listaLiczbaPojazdowWGospodarstwieDomowym;

    @FindBy(xpath = "(//*[@name='Ilu jest właścicieli pojazdu'])[1]")
    public static WebElement opcjaJedenWlasciciel;
}
