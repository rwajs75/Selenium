package webportal.pageobjects.wdrodze;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WpaWDrodzeInformacje {

    @FindBy(xpath = "//*[text()='Numer nadwozia (VIN)']/../../../../..//input")
    public static WebElement poleVIN;

    @FindBy(xpath = "//*[text()='Numer rejestracyjny']/../../../../..//input")
    public static WebElement poleNumerRejestracyjny;

    @FindBy(xpath = "//*[text()='Termin następnego badania technicznego']/../../../../..//input")
    public static WebElement poleNastepneBadanie;



}
