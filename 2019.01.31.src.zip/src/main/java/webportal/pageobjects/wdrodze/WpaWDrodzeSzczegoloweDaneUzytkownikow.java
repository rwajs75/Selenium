package webportal.pageobjects.wdrodze;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WpaWDrodzeSzczegoloweDaneUzytkownikow {

    @FindBy(xpath = "//input[@type='checkbox']")
    public static WebElement checkboxUbezpieczajacyUbezpieczony;

    @FindBy(xpath = "(//*[text()='Telefon']/../..//input[@type='radio'])[1]")
    public static WebElement opcjaTelefonKomorkowy;

    @FindBy(xpath = "//*[text()='Numer']/../..//input")
    public static WebElement poleNumerTelefonu;

    @FindBy(xpath = "//*[text()='E-mail']/../..//input")
    public static WebElement poleEmail;

    @FindBy(xpath = "//*[text()='Ulica']/../..//input")
    public static WebElement poleUlica;

    @FindBy(xpath = "//*[text()='Nr domu']/../..//input")
    public static WebElement poleNumerDomu;

    @FindBy(xpath = "//*[text()='Nr mieszkania']/../..//input")
    public static WebElement poleNumerMieszkania;

    @FindBy(xpath = "//*[text()='Kod pocztowy']/../..//input")
    public static WebElement poleKodPocztowy;
}
