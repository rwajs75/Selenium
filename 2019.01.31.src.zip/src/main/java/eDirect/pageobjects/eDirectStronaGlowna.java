package eDirect.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class eDirectStronaGlowna {

    @FindBy(name = "sub3")
    public static WebElement linkKalendarze;
    @FindBy(name = "sub9")
    public static WebElement linkTwojeKonto;
    @FindBy(name = "sub11")
    public static WebElement linkZgody;
    @FindBy(name = "sub15")
    public static WebElement linkPliki;
    @FindBy(name = "sub18")
    public static WebElement linkTransakcje;
    @FindBy(name = "sub20")
    public static WebElement linkProdukty;
    @FindBy(name = "sub21")
    public static WebElement linkProduktyLista;
    @FindBy(name = "sub23")
    public static WebElement linkRaporty;
    @FindBy(name = "sub28")
    public static WebElement linkAdministracja;

    // Lista kontraktów
    @FindBy(xpath = "//table/caption[contains(text(), 'Lista kontraktów')]")
    public static WebElement poleTekstoweListaKontraktów;
}
