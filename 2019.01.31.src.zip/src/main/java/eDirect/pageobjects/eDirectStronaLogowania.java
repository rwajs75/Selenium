package eDirect.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class eDirectStronaLogowania {

    @FindBy(xpath = "//*[@name='USERID']")
    public static WebElement poleTekstoweLogin;
    @FindBy(xpath = "//*[@name='PASSWD']")
    public static WebElement poleTekstoweHaslo;
    @FindBy(xpath = "//*[@name='Submit']")
    public static WebElement przyciskLogin;
}
