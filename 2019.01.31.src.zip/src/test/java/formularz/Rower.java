package formularz;

public class Rower {
}
