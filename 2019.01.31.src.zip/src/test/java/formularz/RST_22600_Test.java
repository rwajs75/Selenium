package formularz;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.generators.RandomIntGenerator;
import helpers.generators.RandomStringGenerator;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.travel.kupPolise.TravelDaneDoUbezpieczenia;
import myaviva.pageobjects.travel.kupPolise.TravelOferta;
import myaviva.pageobjects.travel.kupPolise.TravelPodsumowanie;
import myaviva.pageobjects.travel.kupPolise.TravelSprawdzCeneUbezpieczenia;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static ecard.Platnosc.platnoscEcard;
import static helpers.common.Common.*;
import static helpers.generators.PESELGenerator.generatePESELForDate;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;


/**
 * @author Roman Wajs
 */

@DisplayName("Formularz")
public class RST_22600_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String aplikacja = "MyAviva";
    private String nazwaTestu = "RST-22600 Formularz zakupu polisy Travel";
    private String appEnv;
    private String email;
    private String dataOd = LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    private String dataDo = LocalDate.now().plusDays(50).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    private String pesel = generatePESELForDate(RandomIntGenerator.liczbaLosowa(1950, 30),
            RandomIntGenerator.liczbaLosowa(1, 12),  RandomIntGenerator.liczbaLosowa(1, 28), 'm');
    private String numerPolisy;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) {
            appEnv = "CP";
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22781").env(appEnv).stage(
                "Utworzenie i aktywacja konta w MyAviva").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
        email = daneTestowe.getParam3();

        PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class);
        PageFactory.initElements(driver, TravelSprawdzCeneUbezpieczenia.class);
        PageFactory.initElements(driver, TravelOferta.class);
        PageFactory.initElements(driver, TravelDaneDoUbezpieczenia.class);
        PageFactory.initElements(driver, TravelPodsumowanie.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22600 Formularz zakupu polisy Travel")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);
            krok1();
            krok2();
            krok3();
            krok4();
            krok5();
            status = true;
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (status) {
            reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Zakup polisy w MyAviva", status, daneTestowe.getParam1(),
                    daneTestowe.getParam2(), pesel, daneTestowe.getParam3(), "Travel", numerPolisy);
        } else if (daneTestowe != null){
            status = true;
            reportSummaryAndSendResults("RST-22781", aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Utworzenie i aktywacja konta w MyAviva", status, daneTestowe.getParam1(),
                    daneTestowe.getParam2(), daneTestowe.getParam3());
        }
    }

    private void krok1() {
        LoginWeb("Travel", appEnv, "", driver);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        clickElement(TravelSprawdzCeneUbezpieczenia.przyciskEU);
        enterIntoTextField(TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyOd, dataOd);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyDo);
        enterIntoTextField(TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyDo, dataDo);
        TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyDo.sendKeys(Keys.RETURN);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiNarciarstwo);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiSportEkstremalne);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiCiezkaPracaFizyczna);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiLeczenieNaWypadek);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiLeczenieSkutkow);
        clickButton(TravelSprawdzCeneUbezpieczenia.przyciskSprawdzSzczegoly);
    }

    private void krok2() {
        sprawdzenieStronyOfertaTravel();
        clickElement(TravelOferta.przyciskWybierzPakietPodstawowy);
    }

    private void krok3() {
        sprawdzenieStronyDaneDoUbezpieczeniaTravel();
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweImie, daneTestowe.getParam1());
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweNazwisko, daneTestowe.getParam2());
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstowePesel, pesel);
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweEmail, email);
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweNumerTelefonu, StaticStrings.NRTEL);
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweKodPocztowy1, "05");
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweKodPocztowy2, "830");
        TravelDaneDoUbezpieczenia.poleTekstoweMiejscowosc.sendKeys(Keys.RETURN);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweMiejscowosc, "Urzut");
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweUlica,
                "Testowa" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweNumerDomu,
                Integer.toString(RandomIntGenerator.liczbaLosowa(1, 299)));
        clickElement(TravelDaneDoUbezpieczenia.poleOpcjiSkopiujMojeDane);
        clickElement(TravelDaneDoUbezpieczenia.poleOpcjiOsobaJestPrzewlekleChora);
        clickElement(TravelDaneDoUbezpieczenia.poleOpcjiAkceptujeWszystkie);
        waitUntilElementVisible(TravelDaneDoUbezpieczenia.przyciskDalej, 5);
        clickButton(TravelDaneDoUbezpieczenia.przyciskDalej);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
    }

    private void krok4() {
        sprawdzenieStronyPodsumowanieTravel();
        clickElement(TravelPodsumowanie.przyciskZaplacOnline);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
    }

    private void krok5() {
        numerPolisy = platnoscEcard(true, driver);
        sprawdzenieStronyGratulujemyTravel();
    }
}
