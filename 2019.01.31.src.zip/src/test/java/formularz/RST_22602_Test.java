package formularz;

import formularz.house.pageobjects.HouseKrok1;
import formularz.house.pageobjects.HouseKrok2;
import formularz.house.pageobjects.HouseKrok3;
import formularz.house.pageobjects.HouseKrok4;
import formularz.house.pageobjects.HouseStronaGlowna;
import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.generators.RandomStringGenerator;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import lombok.extern.log4j.Log4j;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.house.MyAvivaHouse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static ecard.Platnosc.platnoscEcard;
import static helpers.common.Common.*;
import static helpers.dictionary.StaticStrings.NRTEL;
import static helpers.dictionary.StaticStrings.TEST_SKIP;
import static helpers.generators.PESELGenerator.generatePESEL;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.wylogowaniePrzezLink;

/**
 * @author Maria Khabur / Krzysztof Janiak
 */

@DisplayName("Formularz")  //Stworzyc RST
@Log4j
    public class RST_22602_Test {

        public static WebDriver driver;
        private TestDataManager manager;
        CustomDataRequest select;
        CustomTestDTO daneTestowe;
        private static String numerPolisy;
        boolean status = false;
        private String nazwaTestu = "RST-22602 Formularz zakupu ubezpieczenia Dom";
        private String appEnv;
        private String aplikacja = "House";
        private static String PESEL =  generatePESEL('k');

        /**
         * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
         */
        @Before
        public void setUp() {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
                initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
                return;
            }

            appEnv = System.getProperty("appEnv");
            if (appEnv == null) appEnv = "CP";

            if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
                driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
            else if (System.getProperty("env").equals("remote"))
                driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
            manager = new TestDataManager(appEnv);
            select = CustomDataRequest.builder().appName("MyAviva").testName("RST-22781").env(appEnv).stage("Utworzenie i aktywacja konta w MyAviva").status(DataRowStatus.AKTYWNY).build();
            daneTestowe = manager.getCustomTestData(select);
            FormularzCommon.initElement(driver);
        }

        /**
         * Metoda testowa
         */
        @Test
        @DisplayName("RST-22602 Formularz zakupu ubezpieczenia Dom")
        public void testMethod() {
            try {
                if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                    reporter().skipTest(TEST_SKIP);
                StronaGlownaFormularz();
                krok1();  //oddzielne kroki zdefiniowane jako funkcje
                krok2();
                krok3(daneTestowe.getParam3(), PESEL, daneTestowe.getParam1(), daneTestowe.getParam2());
                krok4();
                krok5(driver);
                status = true;
            } catch (Exception e) {
                reporter().logError("", e);
            }
        }

        /**
         * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
         */
        @After
        public void tearDown() {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

            if (driver != null) driver.quit();
            if (daneTestowe != null) reportSummaryAndSendResults(nazwaTestu, "MyAviva", appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy w MyAviva", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(), PESEL, aplikacja, numerPolisy);
        }

        private void StronaGlownaFormularz() {
            LoginWeb(aplikacja, appEnv, "", driver);
            clickElement(HouseStronaGlowna.przyciskSprawdzCene);
            //Strona z wyborem ubiezpieczenia
            clickElement(HouseStronaGlowna.przyciskWybierzDom);
        }

        public static void krok1() {
            enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy1, "00");
            enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy2, "189");
            clickElement(HouseKrok1.poleTekstoweMiejscowosc);
            enterIntoTextField(HouseKrok1.poleTekstoweNumerDomu, "20");
            enterIntoElement(HouseKrok1.poleTekstowePowierzchnia, "200");
            clickElement(HouseKrok1.przyciskWyboruDo3Lat);
            clickElement(HouseKrok1.przyciskWyboruWolnostojacy);
            clickElement(HouseKrok1.przyciskWyboruDachNie);
            clickElement(HouseKrok1.przyciskWyboruSzkodyNie);
            clickElement(HouseKrok1.przyciskWyboruDzialalnoscNie);
            enterIntoTextField(HouseKrok1.poleTekstoweNumerKomorkowy, NRTEL);
            if (HouseKrok1.przyciskSprawdzCene.getAttribute("value").equals("")) {
                clickElement(HouseKrok1.przyciskSprawdzCene);
            } else {
                reporter().logPass("Nie ma możliwości przejścia na Krok 2");
            }
        }

        public static void krok2() {
            clickElement(HouseKrok2.przyciskWybierzPakietStandart);
        }

        public static void krok3(String nowyMail, String PESEL, String imie, String nazwisko) {
            if (HouseKrok3.poleTekstoweImie.getAttribute("value").equals("")) {
                enterIntoTextField(HouseKrok3.poleTekstoweImie, imie);
            } else {
                reporter().logPass("Pole 'Imie' jest już uzupełnione");
            }

            if (HouseKrok3.poleTekstoweNazwisko.getAttribute("value").equals("")) {
                enterIntoTextField(HouseKrok3.poleTekstoweNazwisko, nazwisko);
            } else {
                reporter().logPass("Pole 'Nazwisko' jest już uzupełnione");
            }

            enterIntoTextField(HouseKrok3.poleTekstowePesel, PESEL);

            if (HouseKrok3.poleTekstoweEmail.getAttribute("value").equals("")) {
                enterIntoElement(HouseKrok3.poleTekstoweEmail, nowyMail);
            } else {
                reporter().logPass("Pole 'Email' jest już uzupełnione");
            }

             if (HouseKrok3.poleTekstoweNumerTelefonu.getAttribute("value").equals("")) {
                enterIntoTextField(HouseKrok3.poleTekstoweNumerTelefonu, NRTEL);
            } else {
                 reporter().logPass("Pole 'Numer telefonu komórkowego' jest już uzupełnione");
            }
            if (waitUntilElementPresent(HouseKrok3.listaWybierzBankDoCesji, 5)!=null)
                selectDropdownListOption(HouseKrok3.listaWybierzBankDoCesji, "mBank SA");
            clickElement(HouseKrok3.poleOpcjiAkcetujeWszystkieZgody);
            clickElement(HouseKrok3.przyciskPrzejdzDoPodsumowania);
        }

        public static void krok4() {
            clickElement(HouseKrok4.przyciskZaplac);
        }

        public static void krok5(WebDriver driver) {
            numerPolisy = platnoscEcard(true, driver);


        }

        public static void krok6 (){
            wylogowaniePrzezLink(driver);
            clickElement(MyAvivaOfertaDlaCiebie.mieszkanie);

        }


}