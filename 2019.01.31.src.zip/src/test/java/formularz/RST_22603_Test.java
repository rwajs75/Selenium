package formularz;

import formularz.house.pageobjects.*;
import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import lombok.extern.log4j.Log4j;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.house.MyAvivaHouse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.dictionary.StaticStrings.TEST_SKIP;
import static helpers.generators.PESELGenerator.generatePESEL;
import static helpers.login.Login.LoginWeb;

/**
 * @author Maria Khabur / Krzysztof Janiak
 */
@DisplayName("Formularz")
@Log4j
public class RST_22603_Test {
    private WebDriver driver;
    private String appEnv;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    String nazwaTestu = "RST-22603 Formularz zakupu ubezpieczenia Dom z kredytem";
    boolean status = false;
    private String aplikacja = "House";
    private static String PESEL = generatePESEL('m');

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName("MyAviva").testName("RST-22781").env(appEnv).stage("Utworzenie i aktywacja konta w MyAviva").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
        FormularzCommon.initElement(driver);
    }

    @Test
    @DisplayName("RST-22603 Formularz zakupu ubezpieczenia Dom z kredytem")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            StronaGlownaFormularz();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        if (driver != null) driver.quit();
        if (daneTestowe != null) reportSummaryAndSendResults(nazwaTestu, "MyAviva", appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy w MyAviva", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(), PESEL,aplikacja);
    }

    private void StronaGlownaFormularz() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
            reporter().skipTest(TEST_SKIP);
        LoginWeb(aplikacja, appEnv, "", driver);
        clickElement(HouseStronaGlowna.przyciskSprawdzCene);
        clickElement(HouseStronaGlowna.przyciskWybierzDomzKredytem);
        //Wykorzystanie krokow z testu House_Test
        RST_22602_Test.krok1();
        RST_22602_Test.krok2();
        RST_22602_Test.krok3(daneTestowe.getParam3(), PESEL, daneTestowe.getParam1(), daneTestowe.getParam2());
        RST_22602_Test.krok4();
        RST_22602_Test.krok5(driver);
        status = true;
    }

}