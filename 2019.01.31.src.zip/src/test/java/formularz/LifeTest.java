package formularz;

import formularz.house.pageobjects.HouseStronaGlowna;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;


/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */
@DisplayName("nazwa testu")
public class LifeTest {

    private WebDriver driver;
    private String appEnv;
    private String email;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        switch (appEnv) {
            case "UT": {
                email = "CZTMYA5831@YOPMAIL.COM";
                break;
            }
            case "CP": {
                email = "CZTMYA220@YOPMAIL.COM";
                break;
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);

        driver.get("http://google.com");
        PageFactory.initElements(driver, HouseStronaGlowna.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("nazwa metody")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " );
        reporter().logPass("E-MAIL: " );
        reporter().logPass("###############################");
        if (driver != null)  driver.quit();
    }

    private void krok1() {

        LoginWeb("Life", "UT", "", driver);
        //clickButton();


    }

    private void krok2() {

    }

    private void krok3() {

    }
}
