package salescloud;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import salescloud.pageobjects.SalesCloudCommon;
import salescloud.pageobjects.SalesCloudKalendarz;
import java.text.SimpleDateFormat;
import java.util.Date;
import static salescloud.pageobjects.SalesCloudCommon.*;
import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;

/**
 * @author Przemysław Mendalka
 */
@DisplayName("SalesCloud")
public class RST_22447_Test {

    private WebDriver driver;
    private String appEnv;
    private String nazwaTestu = "RST-22447 Regresja SalesCloud - Kalendarz (Rola Agent) - Wer. widoczności spotkania prywatnego kierownika";
    private String aplikacja = "SalesCloud";
    private String loginKierownika = "64932";
    private String loginAgenta = "15847";
    private String TEST_SKIP= StaticStrings.TEST_SKIP;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "UT";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
    }

    @Test
    @DisplayName("RST-22447 Kalendarz (Rola Agent) - Wer. widoczności spotkania prywatnego kierownika")
    @Issue("RST-22447")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        //Podsumowanie
        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Nazwa testu: "+nazwaTestu);
        reporter().logPass("Login agenta: "+loginAgenta);
        reporter().logPass("Login agenta: "+loginKierownika);
        reporter().logPass("###############################");
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, loginAgenta, driver);
        salesCloudMenu("Kalendarz", driver);
        if(SalesCloudKalendarz.przyciskDodajZdarzenie.isDisplayed())
            reporter().logPass("Opcja 'Kalendarza' dostępna");
        else {
            reporter().logFail("Opcja 'Kalendarza' niedostępna");
        }
        clickButton(SalesCloudKalendarz.przyciskDodajZdarzenie);
        enterIntoTextField(SalesCloudKalendarz.poleTekstoweTytulWydarzenia, "Dodaj spot. priv - agent kierownik");
        selectMDDropdownListOption(SalesCloudKalendarz.listaWybierzRodzajZdarzenia, "Prywatne");
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
        String thisDate = dateFormat.format(date);
        enterIntoElement(SalesCloudKalendarz.przyciskDataPoczątku, thisDate);
        clickElement(SalesCloudKalendarz.poleTekstoweTytulWydarzenia);
        clickElement(SalesCloudKalendarz.przyciskWiecejOpcji);
        enterIntoElement(SalesCloudKalendarz.przyciskZapros,"robert");
        WebElement ROBERT = driver.findElement(By.xpath("//div//*[contains(text(), 'KORYCKI ROBERT ')]"));
        clickElement(ROBERT);
        if (waitUntilElementPresent(SalesCloudKalendarz.przyciskDodajBy, 2) == null) {
            clickElement(SalesCloudKalendarz.przyciskDodajAlternatywny);
        } else {
            clickElement(SalesCloudKalendarz.przyciskDodaj);
        }
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        WebElement pozycjaKalendarza = driver.findElement(By.xpath("//div//div[contains(text(), 'Dodaj spot. priv - agent kierownik')]"));
        clickElement(pozycjaKalendarza);
        WebElement meetingTitle = driver.findElement(By.xpath("//span[contains(@class, 'md-subhead ng-binding') and text() = ' Prywatne ']"));
        if(meetingTitle.isDisplayed())
            reporter().logPass("Poprawnie dodano pozycję kalendarza 'Spotkanie prywatne'");
        else {
            reporter().logFail("Nie dodano pozycji kalendarza 'Spotkanie prywatne'");
        }
        WebElement anuluj = driver.findElement(By.xpath("//*[@aria-label='Anuluj']"));
        clickElement(anuluj);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        WebElement dropDownList = driver.findElement(By.xpath("//*[@aria-label='hardware:keyboard-arrow-down']"));
        clickElement(dropDownList);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        WebElement wyloguj = driver.findElement(By.xpath("//*[@aria-label='aviva:logout']"));
        clickElement(wyloguj);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        LoginWeb(aplikacja, appEnv, loginKierownika, driver);
        salesCloudMenu("Kalendarz", driver);
        WebElement pozycjaKalendarzaPRIV = driver.findElement(By.xpath("//div[contains(@class, 'fc-title') and text() = 'PRYWATNE']"));
        clickElement(pozycjaKalendarzaPRIV);
        clickElement(SalesCloudKalendarz.przyciskSzczegoly);
        if (SalesCloudKalendarz.przyciskEdytuj.isEnabled())
            reporter().logPass("Pozycja kalendarza jest pozycją Prywatną");
        else {
            reporter().logFail("Pozycja kalendarza nie jest pozycją Prywatną");
        }
        clickElement(SalesCloudKalendarz.przyciskZamknij);
        WebElement dropDownListKIER = driver.findElement(By.xpath("//*[@aria-label='hardware:keyboard-arrow-down']"));
        clickElement(dropDownListKIER);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        WebElement wylogujKIER = driver.findElement(By.xpath("//*[@aria-label='aviva:logout']"));
        clickElement(wylogujKIER);
        LoginWeb(aplikacja, appEnv, loginAgenta, driver);
        salesCloudMenu("Kalendarz", driver);
        WebElement pozycjaKalendarzaAgent = driver.findElement(By.xpath("//div//div[contains(text(), 'Dodaj spot. priv - agent kierownik')]"));
        clickElement(pozycjaKalendarzaAgent);
        clickElement(SalesCloudKalendarz.przyciskSzczegoly);
        clickElement(SalesCloudKalendarz.przyciskUsun);
        clickElement(SalesCloudKalendarz.przyciskTAK);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
    }
}