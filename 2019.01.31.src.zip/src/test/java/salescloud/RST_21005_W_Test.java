package salescloud;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import salescloud.pageobjects.*;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudCommon.*;
import static salescloud.pageobjects.SalesCloudListaProduktowAviva.pickProduct;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;

/**
 * @author Krzysztof Janiak
 */
@DisplayName("SalesCloud")
public class RST_21005_W_Test {

    private WebDriver driver;
    private String nazwaTestu = "RST-21005 JuniorGO - Rejestracja wniosku";
    private String nazwaWniosku = "Wniosek_JuniorGo";
    private String appEnv;
    private String aplikacja = "SalesCloud";
    private String nrTel = StaticStrings.NRTEL;
    private String TEST_SKIP= StaticStrings.TEST_SKIP;
    private String [] daneKlienta;
    private int idOferty;

    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        //manager = new TestDataManager();
        initElement(driver);
    }

    @Test
    @DisplayName("RST-21005 JuniorGO - Rejestracja wniosku")
    @Issue("RST-21005")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null)  driver.quit();
        //Podsumowanie
        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Nazwa testu: "+nazwaTestu);
        reporter().logPass("###############################");
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, "10980", driver);
        salesCloudMenu("Twoi klienci", driver);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        //daneKlienta = salesCloudSearchClient(NRTEL, appEnv, aplikacja, driver);
        daneKlienta = salesCloudRegisterNewClient(nrTel, "", appEnv, aplikacja);
        //Folder potrzeb
        if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej, 2)!=null)
            clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej);
        if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz, 2)!=null)
            clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz);

        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

        for (int i = 0; i <2 ; i++) {
            if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskRozpocznij, 5)!=null)
                clickElement(SalesCloudFolderPotrzeb.przyciskRozpocznij);
            if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb, 5)!=null)
                clickElement(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        }

        clickElement(SalesCloudFolderPotrzeb.przyciskWyboruOdmawiamAnkiety);
        clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
        pickProduct(nazwaWniosku, driver);
        clickButton(SalesCloudFolderPotrzeb.przyciskOProdukcie);
        clickElement(SalesCloudFolderPotrzeb.poleOpcjiJakoAgent);
        clickButton(SalesCloudFolderPotrzeb.przyciskPrzejdzDoWniosku);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickButton(SalesCloudFolderPotrzeb.przyciskWniosekElektroniczny);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
        reporter().logPass("Wniosek został poprawnie zarejestrowany");

    }

}
