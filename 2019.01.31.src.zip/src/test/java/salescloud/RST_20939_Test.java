package salescloud;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import salescloud.pageobjects.*;

import static salescloud.pageobjects.SalesCloudCommon.*;
import static salescloud.pageobjects.SalesCloudListaProduktowAviva.*;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;
import static salescloud.pageobjects.SalesCloudWniosekInwestycje.*;
import static salescloud.pageobjects.SalesCloudWniosekAnkietaMedyczna.*;
import static salescloud.pageobjects.SalesCloudWniosekZdrowie.selectHealthRisk;
import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudWniosekZdrowie.*;
import static salescloud.pageobjects.SalesCloudWniosekZycie.*;

/**
 * @author Krzysztof Janiak
 */
@DisplayName("SalesCloud")
public class RST_20939_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String nazwaTestu = "RST-20939 SalesCloud Auto - NWP2 - Ubezpieczający = Ubezpieczony - płatność gotówką";
    private String nazwaWniosku = "Wniosek_NowaPerspektywa";
    private String appEnv;
    private String aplikacja = "SalesCloud";
    private String loginAgenta = "21060";
    private String nrTel = StaticStrings.NRTEL;
    private String TEST_SKIP= StaticStrings.TEST_SKIP;
    private int idOferty;
    private String [] daneKlienta;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
            initElement(driver);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22740").env(appEnv).stage("Utworzenie nowego klienta").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
    }

    @Test
    @DisplayName("RST-20939 Proces sprzedażowy NWP2 Nowa Perspektywa")
    @Issue("RST-20939")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (daneTestowe != null)reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(),daneTestowe.getParam4());
    }

    private void krok1() {
            LoginWeb(aplikacja, appEnv, loginAgenta, driver);
            salesCloudMenu("Twoi klienci", driver);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            
            daneKlienta = salesCloudSearchClient(daneTestowe.getParam3(), driver);

            //Folder potrzeb

            if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej, 2)!=null)
                clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej);
            if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz, 2)!=null)
                clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz);

            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

            for (int i = 0; i <2 ; i++) {
                if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskRozpocznij, 5)!=null)
                    clickElement(SalesCloudFolderPotrzeb.przyciskRozpocznij);
                if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb, 5)!=null)
                    clickElement(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb);
                waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
                waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
            }

            clickElement(SalesCloudFolderPotrzeb.przyciskWyboruOdmawiamAnkiety);
            clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
            pickProduct(nazwaWniosku, driver);
            clickButton(SalesCloudFolderPotrzeb.przyciskOProdukcie);
            clickElement(SalesCloudFolderPotrzeb.poleOpcjiJakoAgent);
            clickButton(SalesCloudFolderPotrzeb.przyciskPrzejdzDoWniosku);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            clickButton(SalesCloudFolderPotrzeb.przyciskWniosekElektroniczny);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);

            idOferty = getOfferID();

            // Zakladka 'Dane Osobowe'
            String zawod = "2008";
            enterIntoElement(SalesCloudWniosekDaneOsobowe.poleTekstoweZawod, zawod);
            clickElement(By.xpath("//*[@class='highlight'][contains(text(), '"+zawod+"')]"));
            enterIntoTextField(SalesCloudWniosekDaneOsobowe.poleTekstoweKodPocztowy, "01-022");
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            enterIntoTextField(SalesCloudWniosekDaneOsobowe.poleTekstoweNrDomu, "3b");
            enterIntoTextField(SalesCloudWniosekDaneOsobowe.poleTekstoweNrMieszkania, "13");
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            clickElement(SalesCloudWniosekDaneOsobowe.przyciskWyboruRezydentPodatkowy);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            clickElement(SalesCloudWniosekDaneOsobowe.przyciskZapisz);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);

            // Zakladka 'Zycie'
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            clickElement(przyciskZycie);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);

            // Zakladka 'Zdrowie'
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            clickElement(przyciskZdrowie);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
            selectHealthRisk("Śmierć wskutek NW",driver);
            selectHealthRisk("Poważne zachorowanie",driver);
            selectHealthRisk("Niezdolność do pracy",driver);
            selectHealthRisk("Na Zdrowie",driver);
            selectHealthRisk("Na Wypadek",driver);

            // Zakladka 'Inwestycje'
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            clickElement(przyciskInwestycje);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
            selectCapital("Gwarantowany", "50");
            selectCapital("Stabilnego Wzrostu", "50");
            clickElement(SalesCloudWniosekInwestycje.przyciskZatwierdzWyborFunduszy);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);

            // Zakladka 'Ankieta medyczna'
            clickElement(SalesCloudWniosekAnkietaMedyczna.przyciskAnkietaMedyczna);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
            selectDefaultMedicalQuestionnaire(driver);

            if (waitUntilElementPresent(By.xpath("(//button[contains(., 'Zapisz')])[2]"), 1) != null) {
                clickElement(By.xpath("(//button[contains(., 'Zapisz')])[2]"));
            }else if ((waitUntilElementPresent(By.xpath("//button[contains(., 'Zapisz')]"), 1)) != null){
                clickElement(By.xpath("//button[contains(., 'Zapisz')]"));
            }
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
            clickPopUp("Ok", 5);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

            clickPopUp("Ok", 5);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

            //TODO LADOWANIE DANYCH (NOWY KRECIAL)
            // Zakladka 'Wynik oceny ryzyka'
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 30, true);
            clickElement(SalesCloudWniosekWynikOcenyRyzyka.przyciskWynikOcenyRyzyka);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

            clickPopUp("Ok", 5);

            // Zakladka 'Zgody i oswiadczenia'
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 120, true);
            if ((waitUntilElementPresent(SalesCloudWniosekZgodyiOswiadczenia.przyciskWyboruSumaUbezpieczenia, 2)) != null)
                    clickElement(SalesCloudWniosekZgodyiOswiadczenia.przyciskWyboruSumaUbezpieczenia);
            if ((waitUntilElementPresent(SalesCloudWniosekZgodyiOswiadczenia.przyciskWyboruWniosekNie, 2)) != null)
                    clickElement(SalesCloudWniosekZgodyiOswiadczenia.przyciskWyboruWniosekNie);

            clickElement(SalesCloudWniosekZgodyiOswiadczenia.przyciskZgodyiOswiadczenia);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

            // Zakladka 'Uposazeni'
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 30, true);
            clickElement(SalesCloudWniosekUposażeni.przyciskUposazeni);

            // Zakladka 'Zakonczenie procesu sprzedazy'
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 60, true);
            clickElement(SalesCloudWniosekSprzedaz.przyciskZakonczenieProcesuSprzedazy);
            clickElement(SalesCloudWniosekSprzedaz.przyciskDalejKodSMS);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            clickElement(SalesCloudWniosekSprzedaz.przyciskWyboruPotwierdzamTak);
            clickElement(SalesCloudWniosekSprzedaz.przyciskWyboruPlatnoscGotowka);

        if (waitUntilElementPresent(SalesCloudWniosekSprzedaz.przyciskWyboruBankBZWBKBy, 5) != null) {
            clickElement(SalesCloudWniosekSprzedaz.przyciskWyboruBankBZWBK);
        }

            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            clickElement(SalesCloudWniosekSprzedaz.przyciskDalej);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            if (waitUntilElementPresent(SalesCloudWniosekSprzedaz.przyciskGenerujKodSMSPIN, 5) == null) {
                clickElement(SalesCloudWniosekSprzedaz.przyciskDalejPIN);
            } else {
                clickElement(SalesCloudWniosekSprzedaz.przyciskGenerujKodSMSPIN);
            }
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            //clickElement(SalesCloudWniosekSprzedaz.przyciskGenerujKodSMS);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 40, false);
            String pin = new TestDataManager(appEnv).getPin(idOferty, appEnv);
            if (waitUntilElementVisible(SalesCloudWniosekSprzedaz.poleTekstoweWprowadzPIN, 30)!=null) {
                enterIntoElement(SalesCloudWniosekSprzedaz.poleTekstoweWprowadzPIN, pin);
            }
            if (waitUntilElementPresent(SalesCloudWniosekSprzedaz.przyciskOkUT, 5) == null) {
                clickElement(SalesCloudWniosekSprzedaz.przyciskZakonczSprzedaz);
            } else {
                clickElement(SalesCloudWniosekSprzedaz.przyciskOkUT);
            }
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 90, true);
            if ((waitUntilElementPresent(SalesCloudWniosekSprzedaz.poleTekstoweDziekujeOtrzymalismyWniosek, 60))!=null) {
                reporter().logPass("Wniosek zostal zarejestrowany");
            }else {
                reporter().logFail("Wniosek nie został zarejestrowany");
            }
            status = true;
    }
}