package salescloud;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import salescloud.pageobjects.SalesCloudCommon;
import salescloud.pageobjects.SalesCloudSzczegolyKlienta;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudCommon.clickPopUp;
import static salescloud.pageobjects.SalesCloudCommon.initElement;
import static salescloud.pageobjects.SalesCloudCommon.salesCloudSearchClient;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;

/**
 * @author Krzysztof Janiak
 */
@DisplayName("SalesCloud")
public class RST_22401_Test {

    private WebDriver driver;
    private String nazwaTestu = "RST-22401 Profil Klienta";
    private String appEnv;
    private String aplikacja = "SalesCloud";
    private String nrTel = StaticStrings.NRTEL;
    private String TEST_SKIP= StaticStrings.TEST_SKIP;
    private int idOferty;
    private String [] daneKlienta;



    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
            initElement(driver);
    }



    @Test
    @DisplayName("RST-22401 Profil Klienta")
    @Issue("RST-22401")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        //Podsumowanie
        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Nazwa testu: "+nazwaTestu);
        reporter().logPass("###############################");
    }


    private void krok1() {
            LoginWeb(aplikacja, appEnv, "10980", driver);
            salesCloudMenu("Twoi klienci", driver);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            daneKlienta = salesCloudSearchClient(nrTel, appEnv, aplikacja, driver);
            //daneKlienta = salesCloudRegisterNewClient(NRTEL, "", appEnv, aplikacja);
            waitUntilElementVisibleFail(SalesCloudSzczegolyKlienta.przyciskProfil, 5);
            waitUntilElementVisibleFail(SalesCloudSzczegolyKlienta.przyciskPasazProduktow, 5);
            //waitUntilElementVisibleFail(SalesCloudSzczegolyKlienta.przyciskPolisyKlienta, 5); //TODO
            waitUntilElementVisibleFail(SalesCloudSzczegolyKlienta.przyciskSprzedaż, 5);
            waitUntilElementVisibleFail(SalesCloudSzczegolyKlienta.przyciskNotatki, 5);

            //Profil
            //TODO

            //Pasaz produktow
            clickElement(SalesCloudSzczegolyKlienta.przyciskPasazProduktow);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            waitUntilElementVisibleFail("Nowa Perspektywa", 1);
            waitUntilElementVisibleFail("Pakiet JA", 1);
            waitUntilElementVisibleFail("Junior GO", 1);
            waitUntilElementVisibleFail("IKE", 1);
            waitUntilElementVisibleFail("IKZE", 1);
            waitUntilElementVisibleFail("Bonus Vip", 1);
            waitUntilElementVisibleFail("Umowy dodatkowe", 1);
            waitUntilElementVisibleFail("Twój Dom", 1);
            waitUntilElementVisibleFail("Twoja Podróż", 1);

            //Sprzedaż
            clickElement(SalesCloudSzczegolyKlienta.przyciskSprzedaż);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            //TODO do zrobienia po zapisywaniu danych z innych testow

            //Notatki
            clickElement(SalesCloudSzczegolyKlienta.przyciskNotatki);
            clickElement(By.xpath("//*[contains(text(), 'Dodaj notatkę')]"));
            String notatka = "TestyAuto TestyAuto";
            enterIntoTextArea(SalesCloudSzczegolyKlienta.poleTekstoweWprowadzNotatke, notatka);
            clickElement(SalesCloudSzczegolyKlienta.przyciskZapiszNotatke);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            if (waitUntilElementPresent(By.xpath("//*[contains(text(), '"+notatka+"')]"), 10)!=null) {
                reporter().logPass("Notatka została zapisana");
            }else{
                reporter().logFail("Notatka nie została zapisana");
            }
            clickElement(SalesCloudSzczegolyKlienta.przyciskProfil);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            if (waitUntilElementPresent(By.xpath("//*[contains(text(), '"+notatka+"')]"), 10)!=null) {
                reporter().logPass("Notatka została zapisana");
            }else{
                reporter().logFail("Notatka nie została zapisana");
            }
            clickElement(SalesCloudSzczegolyKlienta.przyciskNotatki);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

            while ((waitUntilElementPresent(By.xpath("//*[contains(text(), '"+notatka+"')]"), 10)!=null)){
                clickElement(SalesCloudSzczegolyKlienta.przyciskWiecejNotatki);
                clickElement(SalesCloudSzczegolyKlienta.przyciskUsuńNotatke);
                clickPopUp("Ok", 5);
                waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            }

            if (waitUntilElementPresent(By.xpath("//*[contains(text(), '"+notatka+"')]"), 5)!=null) {
                reporter().logFail("Notatka nie została usunięta");
            }else{
                reporter().logPass("Notatka została usunięta");
            }
    }



}