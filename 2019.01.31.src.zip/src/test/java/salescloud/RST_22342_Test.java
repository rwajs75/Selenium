package salescloud;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import helpers.restapi.Rest;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import salescloud.pageobjects.*;

import static helpers.common.Common.*;
import static helpers.common.Common.reporter;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudCommon.*;
import static salescloud.pageobjects.SalesCloudListaProduktowAviva.pickProduct;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;
import static salescloud.pageobjects.SalesCloudWniosekIKE.*;
import static salescloud.pageobjects.SalesCloudWybierzProfilInwestycyjny.przyciskDalej;
import static salescloud.pageobjects.SalesCloudWybierzProfilInwestycyjny.selectInvestmentProfile;

/**
 * RST-22342 SalesCloud Auto - IKE - Ubezpieczający = Ubezpieczony - płatność gotówką
 *
 * @author Sławomir Kamiński
 */
@DisplayName("SalesCloud")
public class RST_22342_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String nazwaTestu = "RST-22342 SalesCloud Auto - IKE - Ubezpieczający = Ubezpieczony - płatność gotówką";
    private String nazwaWniosku = "Wniosek_IKE";
    private String appEnv;
    private String aplikacja = "SalesCloud";
    private String loginAgenta = "21060";
    private String nrTel = StaticStrings.NRTEL;
    private String TEST_SKIP= StaticStrings.TEST_SKIP;
    private boolean passed = false;
    private String [] daneKlienta;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22740").env(appEnv).stage("Utworzenie nowego klienta").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
    }

    @Test
    @DisplayName("RST-22342 Proces sprzedażowy IKE Indywidualne Konto Emerytalne")
    @Issue("RST-22342")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (daneTestowe != null) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(),daneTestowe.getParam4());
    }


    private void krok1() {
        LoginWeb(aplikacja, appEnv, loginAgenta, driver);
        salesCloudMenu("Twoi klienci", driver);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

        daneKlienta = salesCloudSearchClient(daneTestowe.getParam3(), driver);

        //Folder potrzeb
        if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej, 2)!=null)
            clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej);
        if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz, 2)!=null)
            clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz);

        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

        for (int i = 0; i <2 ; i++) {
            if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskRozpocznij, 2)!=null)
                clickElement(SalesCloudFolderPotrzeb.przyciskRozpocznij);
            if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb, 2)!=null)
                clickElement(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        }

        clickElement(SalesCloudFolderPotrzeb.przyciskWyboruOdmawiamAnkiety);
        clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
        pickProduct(nazwaWniosku, driver);
        clickButton(SalesCloudFolderPotrzeb.przyciskOProdukcie);
        clickElement(SalesCloudFolderPotrzeb.poleOpcjiJakoAgent);
        clickButton(SalesCloudFolderPotrzeb.przyciskPrzejdzDoWniosku);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickButton(SalesCloudFolderPotrzeb.przyciskWniosekElektroniczny);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

         int idOferty = getOfferID();

        // Zakladka 'Profil Inwestycyjny'

        clickElement(selectInvestmentProfile("Konserwatywny"));
        clickElement(przyciskDalej);

        //Zakladka 'Dane do wniosku'

        selectRadioButtonProperty("Czy chcesz przenieść środki z innego konta emerytalnego?",
                "Nie");
        selectDropdownListOption("Jak często chcesz wpłacać środki?", "co miesiąc");

        enterIntoTextField(poleKwotaWplaty, "300");
        enterIntoTextField(poleWiekRozpoczeciaUzytkowania, "60");
        clickElement(przyciskPrzeliczZysk);
        waitTillSpinnerDisable1(ladowanieDanychWniosek);
        selectRadioButtonProperty("Jestem rezydentem podatkowym w", "Polsce");

        enterIntoTextField(SalesCloudWniosekIKE.poleKodPocztowy, "00-021");
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanychWniosek);
        enterIntoTextField(poleNumerDomu, "1");
        enterIntoTextField(poleUrzadSkarbowy, "Pierwszy Urząd Skarbowy Warszawa-Śródmieście");
        clickElement(poleWyboruOswiadczeniaWymagane);
        clickElement(przyciskDalej);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

        //Finalizacja

        clickElement(SalesCloudWniosekIKE.checkboxOswiadczenieKlienta);
        clickElement(SalesCloudWniosekIKE.checkboxOswiadczenieAgenta);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 30, false);
        clickElement(SalesCloudWniosekIKE.przyciskGenerujKodSMS);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 30, false);
        if ((waitUntilElementPresent(By.xpath("//*[contains(text(), 'Wystąpił nieoczekiwany błąd')]"), 5)) != null){
            reporter().logFail("Błąd w generowaniu PINu.");
        }
        enterIntoElement(SalesCloudWniosekSprzedaz.poleTekstoweWprowadzPIN, manager.getPin(idOferty, appEnv));
        pauseFor(1);
        clickElement(SalesCloudWniosekSprzedaz.przyciskZakonczSprzedaz);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 90, true);

        if ((waitUntilElementPresent(By.xpath("//*[contains(text(), 'Dziękujemy, wniosek został przyjęty.')]"), 60))!=null) {
            reporter().logPass("Wniosek zostal zarejestrowany");
        } else {
            reporter().logFail("Wniosek nie został zarejestrowany");
        }
        passed=true;
        status = true;
    }
}
