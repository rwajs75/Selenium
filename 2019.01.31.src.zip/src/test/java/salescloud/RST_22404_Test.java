package salescloud;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import salescloud.pageobjects.SalesCloudCommon;
import salescloud.pageobjects.SalesCloudKalendarz;
import java.text.SimpleDateFormat;
import java.util.Date;
import static salescloud.pageobjects.SalesCloudCommon.*;
import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;

/**
 * @author Przemysław Mendalka
 */
@DisplayName("SalesCloud")
public class RST_22404_Test {

    private WebDriver driver;
    private String appEnv;
    private String nazwaTestu = "RST-22404 Regresja SalesCloud - Kalendarz (Rola Agent) - Dodanie pozycji 'Prywatne'";
    private String aplikacja = "SalesCloud";
    private String loginAgenta = "21060";
    private String TEST_SKIP= StaticStrings.TEST_SKIP;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "UT";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
    }

    @Test
    @DisplayName("RST-22404 Kalendarz (Rola Agent) - Dodanie pozycji 'Prywatne'")
    @Issue("RST-22404")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        //Podsumowanie
        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Nazwa testu: "+nazwaTestu);
        reporter().logPass("Login agenta: "+loginAgenta);
        reporter().logPass("###############################");
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, loginAgenta, driver);
        salesCloudMenu("Kalendarz", driver);
        if(SalesCloudKalendarz.przyciskDodajZdarzenie.isDisplayed())
            reporter().logPass("Opcja 'Kalendarza' dostępna");
        else {
            reporter().logFail("Opcja 'Kalendarza' niedostępna");
        }
        clickButton(SalesCloudKalendarz.przyciskDodajZdarzenie);
        enterIntoTextField(SalesCloudKalendarz.poleTekstoweTytulWydarzenia, "Dodaj spotkanie priv - agent");
        selectMDDropdownListOption(SalesCloudKalendarz.listaWybierzRodzajZdarzenia, "Prywatne");
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
        String thisDate = dateFormat.format(date);
        enterIntoElement(SalesCloudKalendarz.przyciskDataPoczątku, thisDate);
        clickElement(SalesCloudKalendarz.poleTekstoweTytulWydarzenia);
        clickElement(SalesCloudKalendarz.przyciskDodaj);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        WebElement pozycjaKalendarza = driver.findElement(By.xpath("//div//div[contains(text(), 'Dodaj spotkanie priv - agent')]"));
        clickElement(pozycjaKalendarza);
        WebElement meetingTitle = driver.findElement(By.xpath("//span[contains(@class, 'md-subhead ng-binding') and text() = ' Prywatne ']"));
        if(meetingTitle.isDisplayed())
            reporter().logPass("Poprawnie dodano pozycję kalendarza 'Spotkanie prywatne'");
        else {
            reporter().logFail("Nie dodano pozycji kalendarza 'Spotkanie prywatne'");
        }
        clickElement(SalesCloudKalendarz.przyciskSzczegoly);
        clickElement(SalesCloudKalendarz.przyciskUsun);
        clickElement(SalesCloudKalendarz.przyciskTAK);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        //reporter().logPass("Usunięto dodaną pozycję kalendarza");
    }
}