package salescloud;



import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import salescloud.pageobjects.SalesCloudWyszukiwarkaTwoiKlienci;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudCommon.initElement;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;

@DisplayName("SalesCloud")
public class RST_22386_Test {

    private WebDriver driver;
    private String nazwaTestu = "RST_22386 SalesCloud Auto - Twoi Klienci(Agent) - Wyszukiwarka klientów";
    private String appEnv;
    private String aplikacja = "SalesCloud";
    private String nrTel = StaticStrings.NRTEL;
    private String TEST_SKIP= StaticStrings.TEST_SKIP;
    private int idOferty;
    private String[] daneKlienta;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);

        PageFactory.initElements(driver, SalesCloudWyszukiwarkaTwoiKlienci.class);

    }



        @Test
        @DisplayName("RST-22386 Wyszukiwanie klienta w portfelu klientów Agents")
        @Issue("RST-22386")
        public void testMethod() {
            try {
                if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                    reporter().skipTest(TEST_SKIP);
                krok1();
                krok2();
                krok3();
                krok4();
            } catch (Exception e) {
                reporter().logError("", e);
            }


        }




    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        // reporter().logPass("Środowisko: "+ appEnv);
        // reporter().logPass("Aplikacja "+aplikacja);
        //reporter().logPass("PESEL: "+PESEL);
        // reporter().logPass("E-MAIL: "+nowyMail);
        reporter().logPass("###############################");
        reporter().logPass("TODO: Rozpoznawanie treści dokumentów");
        driver.quit();

    }



    private void krok1() {

        LoginWeb(aplikacja, appEnv, "12002", driver);
            salesCloudMenu("Twoi klienci", driver);
            waitUntilElementVisible(SalesCloudWyszukiwarkaTwoiKlienci.poleTekstoweKogoSzukasz, 1);
            clickElement(SalesCloudWyszukiwarkaTwoiKlienci.poleTekstoweKogoSzukasz);
            enterIntoTextField(SalesCloudWyszukiwarkaTwoiKlienci.poleTekstoweKogoSzukasz,"Magdalena");

            waitUntilElementVisible(SalesCloudWyszukiwarkaTwoiKlienci.listaRozwijalnaWarunek, 1);
            clickElement(SalesCloudWyszukiwarkaTwoiKlienci.listaRozwijalnaWarunek);
            clickElement(SalesCloudWyszukiwarkaTwoiKlienci.listaRozwiajalnaWarunekImie);
            waitUntilElementVisible(SalesCloudWyszukiwarkaTwoiKlienci.listaWybierzStatus, 2);
            selectMDDropdownListOption(SalesCloudWyszukiwarkaTwoiKlienci.listaWybierzStatus, "Prospekt");
            waitUntilElementVisible(SalesCloudWyszukiwarkaTwoiKlienci.poleTekstoweWiekOD, 2);
            enterIntoTextField(SalesCloudWyszukiwarkaTwoiKlienci.poleTekstoweWiekOD, "20");
            enterIntoTextField(SalesCloudWyszukiwarkaTwoiKlienci.poleTekstoweWiekDo, "60");
            waitUntilElementVisible(SalesCloudWyszukiwarkaTwoiKlienci.listaRozwijalnaPlec, 1);
            selectDropdownListOption(SalesCloudWyszukiwarkaTwoiKlienci.listaRozwijalnaPlec, "Kobiety");
            //clickElement(SalesCloudWyszukiwarkaTwoiKlienci.listaRozwijalnaPlec);
            //clickElement(SalesCloudWyszukiwarkaTwoiKlienci.listaRozwiajalnaPlecKobieta);
            clickElement(SalesCloudWyszukiwarkaTwoiKlienci.przyciskSzukaj);






        }


    private void krok2() {





    }



    private void krok3() {





    }



    private void krok4() {





    }

    }
