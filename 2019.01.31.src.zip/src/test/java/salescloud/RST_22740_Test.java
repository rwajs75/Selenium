package salescloud;

import helpers.database.TestDataManager;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import salescloud.pageobjects.SalesCloudCommon;
import salescloud.pageobjects.SalesCloudKalendarz;
import java.text.SimpleDateFormat;
import java.util.Date;
import static salescloud.pageobjects.SalesCloudCommon.*;
import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;

/**
 * @author Przemysław Mendalka
 */
@DisplayName("SalesCloud")
public class RST_22740_Test {

    private WebDriver driver;
    private TestDataManager manager;
    private String appEnv;
    private String nazwaTestu = "RST-22740 Regresja SalesCloud - Dodanie nowego klienta";
    private String aplikacja = "SalesCloud";
    private String loginAgenta = "21060";
    private String nrTel = StaticStrings.NRTEL;
    private String [] daneKlienta = {"NONE", "NONE", "NONE", "NONE", "NONE"};
    private String TEST_SKIP= StaticStrings.TEST_SKIP;
    boolean status = false;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
        manager = new TestDataManager(appEnv);
    }

    @Test
    @DisplayName("RST-22740 Regresja SalesCloud - Dodanie nowego klienta")
    @Issue("RST-22740")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (daneKlienta != null&& daneKlienta.length >= 5) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Utworzenie nowego klienta", status, daneKlienta[0], daneKlienta[1], daneKlienta[2],daneKlienta[3], daneKlienta[4]);

    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, loginAgenta, driver);
        salesCloudMenu("Twoi klienci", driver);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        daneKlienta = salesCloudRegisterNewClient(nrTel, "", appEnv, aplikacja);
        status = true;
    }
}