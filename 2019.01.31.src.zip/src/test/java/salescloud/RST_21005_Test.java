package salescloud;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.generators.RandomStringGenerator;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import salescloud.pageobjects.*;

import static helpers.common.Common.*;
import static helpers.common.Common.clickButton;
import static helpers.common.Common.enterIntoTextField;
import static helpers.generators.PESELGenerator.generatePESELForDate;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudCommon.*;
import static salescloud.pageobjects.SalesCloudListaProduktowAviva.pickProduct;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;
import static salescloud.pageobjects.SalesCloudWniosekAnkietaMedyczna.selectDefaultChildMedicalQuestionnaire;
import static salescloud.pageobjects.SalesCloudWniosekAnkietaMedyczna.selectDefaultMedicalQuestionnaire;
import static salescloud.pageobjects.SalesCloudWniosekZdrowie.selectHealthRisk;

/**
 * @author Krzysztof Janiak
 */
@DisplayName("SalesCloud")
public class RST_21005_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String nazwaTestu = "RST-21005 SalesCloud Auto - JuniorGO - Ubezpieczający = Ubezpieczony + Dziecko - płatność gotówką";
    private String nazwaWniosku = "Wniosek_JuniorGo";
    private String appEnv;
    private String aplikacja = "SalesCloud";
    private String loginAgenta = "21060";
    private String nrTel = StaticStrings.NRTEL;
    private String TEST_SKIP= StaticStrings.TEST_SKIP;
    private int idOferty;
    private String [] daneKlienta;

    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22740").env(appEnv).stage("Utworzenie nowego klienta").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
    }

    @Test
    @DisplayName("RST-21005 Proces sprzedażowy JuniorGO")
    @Issue("RST-21005")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null)  driver.quit();
        if (daneTestowe != null)reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(),daneTestowe.getParam4());
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, loginAgenta, driver);
        salesCloudMenu("Twoi klienci", driver);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

        daneKlienta = salesCloudSearchClient(daneTestowe.getParam3(), driver);

        //Folder potrzeb
        if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej, 2)!=null)
            clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej);
        if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz, 2)!=null)
            clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz);

        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

        for (int i = 0; i <2 ; i++) {
            if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskRozpocznij, 5)!=null)
                clickElement(SalesCloudFolderPotrzeb.przyciskRozpocznij);
            if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb, 5)!=null)
                clickElement(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
        }

        clickElement(SalesCloudFolderPotrzeb.przyciskWyboruOdmawiamAnkiety);
        clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
        pickProduct(nazwaWniosku, driver);
        clickButton(SalesCloudFolderPotrzeb.przyciskOProdukcie);
        clickElement(SalesCloudFolderPotrzeb.poleOpcjiJakoAgent);
        clickButton(SalesCloudFolderPotrzeb.przyciskPrzejdzDoWniosku);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickButton(SalesCloudFolderPotrzeb.przyciskWniosekElektroniczny);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);

        idOferty = getOfferID();

        // Zakladka 'Dane Osobowe'
        String zawod = "2008";
        enterIntoElement(SalesCloudWniosekDaneOsobowe.poleTekstoweZawod, zawod);
        clickElement(By.xpath("//*[@class='highlight'][contains(text(), '"+zawod+"')]"));
        enterIntoTextField(SalesCloudWniosekDaneOsobowe.poleTekstoweKodPocztowy, "01-022");
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        enterIntoTextField(SalesCloudWniosekDaneOsobowe.poleTekstoweNrDomu, "3b");
        enterIntoTextField(SalesCloudWniosekDaneOsobowe.poleTekstoweNrMieszkania, "13");
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickElement(SalesCloudWniosekDaneOsobowe.przyciskWyboruRezydentPodatkowy);

        //Dodaj role
        String imieDziecka = "IMIE"+RandomStringGenerator.generateCharsSequence().toUpperCase();
        String rokUrodzenia = "2015";
        String miesiacUrodzenia = "10";
        String dzienUrodzenia = "10";
        String pesel = generatePESELForDate(2015, 10, 10, 'm');

        clickElement(SalesCloudWniosekDaneOsobowe.przyciskDodajNowegoUczestnika);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        switchToNewPopUp();
        clickElement(SalesCloudNowyUczestnik.poleWyboruRola);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickElement(By.xpath("//*[@class='md-text ng-binding'][contains(text(), 'Dziecko')]"));
        enterIntoTextField(SalesCloudNowyUczestnik.poleTekstoweImie,imieDziecka);
        clickElement(SalesCloudNowyUczestnik.poleWyboruPlec);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickElement(By.xpath("//*[@class='md-text']/*[contains(text(), 'Mężczyzna')]"));
        enterIntoTextField(SalesCloudNowyUczestnik.poleTekstoweDataUrodzenia,dzienUrodzenia+"."+miesiacUrodzenia+"."+rokUrodzenia);
        enterIntoTextField(SalesCloudNowyUczestnik.poleTekstowePesel,pesel);
        clickElement(SalesCloudNowyUczestnik.przyciskZapisz);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);

        // Zakladka 'Inwestycje'
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickElement(SalesCloudWniosekInwestycje.przyciskInwestycje);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        enterIntoTextField(SalesCloudWniosekInwestycje.poleTekstoweFunduszGwarantowany, "50");
        enterIntoTextField(SalesCloudWniosekInwestycje.poleTekstoweFunduszStabilnegoWzrostu, "50");
        clickElement(SalesCloudWniosekInwestycje.przyciskZatwierdzWyborFunduszy);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);

        String zakres;

        enterIntoTextField(SalesCloudWniosekInwestycje.poleTekstoweCzasTrwaniaUmowy, "1");
        enterIntoTextField(SalesCloudWniosekInwestycje.poleTekstoweWysokoscSkladkiInwectycyjne, "1");
        zakres = getDataRange(SalesCloudWniosekInwestycje.zakresCzasTrwaniaUmowy);
        enterIntoTextField(SalesCloudWniosekInwestycje.poleTekstoweCzasTrwaniaUmowy, zakres);
        zakres = getDataRange(SalesCloudWniosekInwestycje.zakresWysokoscSkladkiInwectycyjne);
        enterIntoTextField(SalesCloudWniosekInwestycje.poleTekstoweWysokoscSkladkiInwectycyjne, zakres);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);

        //Zakladka 'Życie'
        clickElement(SalesCloudWniosekZycie.przyciskZycie);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        enterIntoElement(SalesCloudWniosekZycie.poleTekstoweSumaUbezpieczenia, "1");
        clickElement(SalesCloudWniosekZycie.poleTekstoweSkladka);
        zakres = getDataRange(SalesCloudWniosekZycie.zakresSumaUbezpieczenia);
        enterIntoTextField(SalesCloudWniosekZycie.poleTekstoweSumaUbezpieczenia, zakres);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);


        //Zakladka 'Zdrowie'
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
        clickElement(SalesCloudWniosekZdrowie.przyciskZdrowie);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        selectHealthRisk("Poważne zachorowanie",driver);
        selectHealthRisk("Śmierć wskutek NW",driver);
        selectHealthRisk("Niezdolność do pracy", driver);
        clickTabRole(imieDziecka);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        selectHealthRisk("Poważne zachorowanie", driver);
        selectHealthRisk("Na Zdrowie", driver);
        selectHealthRisk("Na Wypadek", driver);

        // Zakladka 'Ankieta medyczna'
        clickElement(SalesCloudWniosekAnkietaMedyczna.przyciskAnkietaMedyczna);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
        selectDefaultMedicalQuestionnaire(driver);
        clickTabRole(imieDziecka);
        selectDefaultChildMedicalQuestionnaire(driver);

        if ((waitUntilElementPresent(By.xpath("(//button[contains(., 'Zapisz')])[2]"), 1)) != null) {
            clickElement(By.xpath("(//button[contains(., 'Zapisz')])[2]"));
        }else if ((waitUntilElementPresent(By.xpath("//button[contains(., 'Zapisz')]"), 1)) != null){
            clickElement(By.xpath("//button[contains(., 'Zapisz')]"));
        }
        clickPopUp("Ok", 5);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickPopUp("Ok", 5);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

        //TODO Dokończyć
        // Zakladka 'Wynik oceny ryzyka'
        clickElement(SalesCloudWniosekWynikOcenyRyzyka.przyciskWynikOcenyRyzyka);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);

        clickPopUp("Ok", 5);

        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 60, true);
        clickElement(SalesCloudWniosekWynikOcenyRyzyka.przyciskWyboruDokumentacjaMedycznaNie);

        // Zakladka 'Zgody i oswiadczenia'
        clickElement(SalesCloudWniosekZgodyiOswiadczenia.przyciskZgodyiOswiadczenia);

        // Zakladka 'Uposazeni'
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 30, true);
        clickElement(SalesCloudWniosekUposażeni.przyciskUposazeni);

        //TODO wyniesc do jednej funkcji
        // Zakladka 'Finalizacja sprzedaży'
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 30, true);
        clickElement(SalesCloudWniosekSprzedaz.przyciskFinalizacjaSprzedazy);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 30, true);
        clickElement(SalesCloudWniosekSprzedaz.przyciskWyboruPlatnoscGotowka);
        clickElement(SalesCloudWniosekSprzedaz.przyciskAkceptacjaWnioskuSMS);
        waitTillSpinnerDisable2(ladowanieDanychWniosek, 30, false);
        clickElement(SalesCloudWniosekSprzedaz.przyciskGenerujSMS);
        waitTillSpinnerDisable2(ladowanieDanychWniosek, 30, false);
        if (waitUntilElementPresent(SalesCloudWniosekSprzedaz.przyciskGenerujNowyPIN, 1)!=null
                || (waitUntilElementPresent(SalesCloudWniosekSprzedaz.przyciskWygenerujNowyPIN, 1)!=null)) {
                waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 10, false);
                String pin = new TestDataManager(appEnv).getPin(idOferty, appEnv);
                enterIntoElement(SalesCloudWniosekSprzedaz.poleTekstoweWprowadzPIN, pin);
                clickElement(SalesCloudWniosekSprzedaz.przyciskZatwierdzKodPIN);
        }else{
            reporter().logFail("Kod PIN nie został wygenerowany po kliknięciu w przycisk 'Generuj PIN'");
        }
        waitTillSpinnerDisable2(SalesCloudCommon.ladowanieDanychWniosek, 90, true);
        if (waitUntilElementPresent(SalesCloudWniosekSprzedaz.poleTekstoweDziekujeOtrzymalismyWniosek, 60)!=null) {
            reporter().logPass("Wniosek zostal zarejestrowany");
        }else {
            reporter().logFail("Wniosek nie został zarejestrowany");
        }
        status = true;
    }

}
