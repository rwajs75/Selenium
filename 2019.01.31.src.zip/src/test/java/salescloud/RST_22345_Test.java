package salescloud;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import salescloud.pageobjects.SalesCloudCommon;
import salescloud.pageobjects.SalesCloudFolderPotrzeb;
import salescloud.pageobjects.SalesCloudSzczegolyKlienta;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudCommon.initElement;
import static salescloud.pageobjects.SalesCloudCommon.salesCloudSearchClient;
import static salescloud.pageobjects.SalesCloudListaProduktowAviva.pickProduct;
import static salescloud.pageobjects.SalesCloudMenuGlowne.salesCloudMenu;

/**
 * @author Krzysztof Janiak
 */
@DisplayName("SalesCloud")
public class RST_22345_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String nazwaTestu = "RST-22345 Rozsądny Partner";
    private String nazwaWniosku = "Wniosek_RozsądnyPartner";
    private String appEnv;
    private String aplikacja = "SalesCloud";
    private String loginAgenta = "21060";
    private String nrTel = StaticStrings.NRTEL;
    private String TEST_SKIP= StaticStrings.TEST_SKIP;
    private int idOferty;
    private String[] daneKlienta;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) {
            appEnv = "UT";
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }
        initElement(driver);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22740").env(appEnv).stage("Utworzenie nowego klienta").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
    }

    @Test
    @DisplayName("RST-22345 Rozsądny Partner")
    @Issue("RST-22345")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) {
            driver.quit();
        }
        if (daneTestowe != null) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(), daneTestowe.getParam4());
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, loginAgenta, driver);
        salesCloudMenu("Twoi klienci", driver);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

        daneKlienta = salesCloudSearchClient(daneTestowe.getParam3(), driver);

        //Folder potrzeb
        if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej, 2) != null) {
            clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebWiecej);
        }
        if (waitUntilElementPresent(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz, 2) != null) {
            clickElement(SalesCloudSzczegolyKlienta.przyciskFolderPotrzebUtworz);
        }

        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

        for (int i = 0; i < 2; i++) {
            if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskRozpocznij, 2) != null) {
                clickElement(SalesCloudFolderPotrzeb.przyciskRozpocznij);
            }
            if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb, 2) != null) {
                clickElement(SalesCloudFolderPotrzeb.przyciskZalozNowyFolderPotrzeb);
            }
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        }

        clickElement(SalesCloudFolderPotrzeb.przyciskWyboruOdmawiamAnkiety);
        clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickButton(SalesCloudFolderPotrzeb.przyciskDalej);
        pickProduct(nazwaWniosku, driver);
        waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
        clickButton(SalesCloudFolderPotrzeb.przyciskWniosekElektroniczny);
//            if (waitUntilElementPresent(SalesCloudFolderPotrzeb.przyciskPobierz, 5)!=null) {
//                clickElement(SalesCloudFolderPotrzeb.przyciskPobierz);
//            }
        reporter().logPass("Wniosek został poprawnie zarejestrowany");
        status = true;
    }
}