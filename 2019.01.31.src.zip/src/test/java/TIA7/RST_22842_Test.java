package TIA7;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.common.Common.reportSummaryAndSendResults;
import static tia7.pageobjects.Tia7Common.initElement;
import static tia7.pageobjects.Tia7CommonProcess.verifyMyAviva;
import static helpers.dictionary.StaticStrings.*;
import static tia7.pageobjects.Tia7CommonProcess.verifyTia7Balance;

/**
 * @author Przemysław Mendalka
 */
@DisplayName("TIA7")
public class RST_22842_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String appEnv;
    private String nazwaTestu = "RST-22842 Regresja TIA7 - Polisa Moto weryfikacja płatności przez MyAviva w TIA7";
    public String aplikacja = "TIA7";

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22754").env(appEnv).creationDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("YYYY-MM-dd"))).stage("Weryfikacja w MyAviva").status(DataRowStatus.AKTYWNY).build();        daneTestowe = manager.getCustomTestData(select);
    }

    @Test
    @DisplayName("RST-22842 Regresja TIA7 - Polisa Moto weryfikacja płatności przez MyAviva w TIA7")
    @Issue("RST-22842")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (daneTestowe != null) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Weryfikacja salda w TIA7", status, daneTestowe.getParam6(), daneTestowe.getParam5());
    }

    private void krok1() {
        verifyTia7Balance(aplikacja, appEnv, daneTestowe.getParam6(), daneTestowe.getParam5());
        status = false;
    }
}