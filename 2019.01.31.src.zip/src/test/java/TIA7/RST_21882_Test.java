package TIA7;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import tia7.pageobjects.*;

import static helpers.common.Common.*;
import static helpers.common.Common.clickElement;
import static helpers.common.Common.selectDropdownListOption;
import static helpers.login.Login.LoginWeb;
import static tia7.pageobjects.Tia7Common.*;
import static tia7.pageobjects.Tia7CommonProcess.*;
import static helpers.dictionary.StaticStrings.*;

/**
 * @author Przemysław Mendalka
 */
@DisplayName("TIA7")
public class RST_21882_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String appEnv;
    private String nazwaTestu = "RST-21882 Regresja TIA7 - Polisa H2 płatność przelewem";
    private String aplikacja = "TIA7";
    private String nrPolisy;
    private String nrPolisyCustom;
    private String nazwaProcesu = "Polisa";

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22625").env(appEnv).stage("Utworzenie nowego klienta").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
    }

    @Test
    @DisplayName("RST-21882 Regresja TIA7 - Polisa H2 płatność przelewem")
    @Issue("RST-21882")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
            krok2();
            krok3();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (daneTestowe!=null) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(),daneTestowe.getParam4(),daneTestowe.getParam5(),nrPolisyCustom);
    }

    private void krok1() {
        LoginWeb("TIA7", appEnv, "AGRUBA", driver);
        clickElement(Tia7StronaGlowna.przyciskWyszukajDodajKlienta);
        //daneKlienta = TIA7registerNewClient("00"+nrTel, "", appEnv, aplikacja);
        setSelectInputTia7("PESEL", daneTestowe.getParam3(), "input");
        clickElement(Tia7WyszukajDodajKlienta.przyciskSzukaj);
        clickElement(By.xpath("//*[contains(text(), '"+daneTestowe.getParam5()+"')]"));
        clickButton(Tia7Polisa.przyciskNowy);
        switchToNewPopUp();
        selectTIA7Product("H2 - Twój Dom", false);
        //TODO: Wyniesc do funkcji od tego miejsca
        selectDropdownListOption(Tia7Polisa.listaKodZrodlowy, "Inbound");
        nrPolisy = getElementText(Tia7Polisa.poleTekstoweNrPolisy);
        clickButton(Tia7Polisa.przyciskNowaLiniaPolisowa);
        switchToNewPopUp();
        clickButton(Tia7Polisa.przyciskTakNLP);
        //TODO: Do tego miejsca
    }

    private void krok2() {
        if (waitUntilElementPresent(Tia7FormularzHouse.listaPietroBy, 5) == null) {
            clickElement(Tia7FormularzHouse.listaDaneProduktowe);
        }
        setSelectInputTia7("Rok budowy lub ostatniego remontu", "2015", "input");
        setSelectInputTia7("Powierzchnia użytkowa w m2","50","input");
        setSelectInputTia7("Piętro","Pośrednie","select");
        setSelectInputTia7("Liczba osób mieszkających w nieruchomości","1","select");
        setSelectInputTia7("Liczba lat bezszkodowych","0 lat","select");
        setSelectInputTia7("Tytuł prawny","Własność","select");
        clickButton(Tia7FormularzHouse.przyciskObliczKlasyRyzykaH2);
        clickElement(Tia7FormularzHouse.poleOpcjiNieruchomośćMieszkalna);
        enterIntoTextField(Tia7FormularzHouse.poleTekstoweSumaUbezpieczenia, "350000");
    }

    private void krok3() {
        nrPolisyCustom = savePolice(nazwaProcesu, nrPolisy);
        status = true;
    }
}