package TIA7;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import tia7.pageobjects.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.common.Common.driver;
import static helpers.common.Common.reportSummaryAndSendResults;
import static helpers.login.Login.LoginWeb;
import static tia7.pageobjects.Tia7Common.initElement;
import static tia7.pageobjects.Tia7Common.selectTIA7Process;
import static tia7.pageobjects.Tia7Common.setSelectInputTia7;
import static tia7.pageobjects.Tia7CommonProcess.verifyMyAviva;
import static helpers.dictionary.StaticStrings.*;
import static tia7.pageobjects.Tia7CommonProcess.verifyTia7Balance;

/**
 * @author Przemysław Mendalka
 */
@DisplayName("TIA7")
public class RST_21885_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String appEnv;
    private String nazwaTestu = "RST-21885 Regresja TIA7 - MTA - Polisa Moto - Zmiana danych z wpływem na składkę";
    public String aplikacja = "TIA7";
    private String nazwaProcesu = "Zaakceptuj transakcje MTA";

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "UT";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-21877").env(appEnv).stage("Zarejestrowanie polisy").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
    }

    @Test
    @DisplayName("RST-21885 Regresja TIA7 - MTA - Polisa Moto - Zmiana danych z wpływem na składkę")
    @Issue("RST-21885")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (daneTestowe != null) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "MTA - Polisa Moto - Zmiana danych z wpływem na składkę", status, nazwaProcesu);
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, "AutoCZT3", driver);
        clickElement(Tia7StronaGlowna.przyciskWyszukajDodajKlienta);
        setSelectInputTia7("Numer polisy", daneTestowe.getParam6(), "input");
        clickElement(Tia7WyszukajDodajKlienta.przyciskSzukaj);
        clickElement(By.xpath("//*[contains(text(), '"+daneTestowe.getParam5()+"')]"));
        clickElement(By.xpath("//*[contains(text(), '" +daneTestowe.getParam6()+"')]//..//..//..//*[@title='Rozwiń']"));
        clickElement(By.xpath("//table//*[contains(text(), 'Linia polisowa')]"));
        clickButton(Tia7Polisa.przyciskDostosujLiniePolisowa);
        switchToNewPopUp();
        setSelectInputTia7("Powód transakcji","200 Dostosowanie składki","select");
        clickButton(Tia7Polisa.przyciskOkDLP);
        clickElement(Tia7FormularzMoto.przyciskPojazd);
        setSelectInputTia7("Pakiet", "OC+AC Srebrny", "select");
        clickElement(Tia7Common.przyciskZapisz);

        String amountBeforeChange = driver.findElement(By.xpath("//input[contains(@id, 'PreviousTariffInput')]")).getAttribute("value");
        int BeforeChange = Integer.parseInt(amountBeforeChange.replace(" ", ""));

        String amountAfterChange = driver.findElement(By.xpath("//input[contains(@id, 'OverPaymentInput')]")).getAttribute("value");
        int AfterChange = Integer.parseInt(String.valueOf(amountAfterChange.trim()));

        if (BeforeChange != AfterChange) {
            reporter().logPass("Kwota przed zmianą wynosi: " + BeforeChange + " , różnica w składce wynosi: " + AfterChange);
        } else {
            reporter().logFail("Nie została wykonana operacja zmiany danych z wpływem na składkę ");
        }
        clickElement(Tia7Common.przyciskZapisz);
        clickElement(Tia7Common.przyciskComplete);
        switchToNewPopUp();
        selectTIA7Process(nazwaProcesu);
        clickElement(Tia7FormularzMoto.przyciskOK);

        //TODO: DODAC JAKAS WERYFIKACJE !? :)

        status = true;
    }
}