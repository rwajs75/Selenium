package TIA7;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import tia7.pageobjects.Tia7StronaGlowna;


import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static tia7.pageobjects.Tia7Common.*;
import static tia7.pageobjects.Tia7CommonProcess.TIA7registerNewClient;
import static helpers.dictionary.StaticStrings.*;

/**
 * @author Krzysztof Janiak
 */
@DisplayName("TIA7")
public class RST_22625_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String appEnv;
    private String nazwaTestu = "RST-22625 - Regresja TIA7 - Utworzenie nowego klienta";
    public String aplikacja = "TIA7";
    private String nrTel = StaticStrings.NRTEL;
    private String [] daneKlienta = {"NONE", "NONE", "NONE", "NONE", "NONE", "NONE"};


    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
        manager = new TestDataManager(appEnv);
    }

    @Test
    @DisplayName("RST-22625 - Regresja TIA7 - Utworzenie nowego klienta")
    @Issue("RST-22625")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        if (driver != null) driver.quit();
        if (daneKlienta != null && daneKlienta.length >= 6)reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Utworzenie nowego klienta", status, daneKlienta[0], daneKlienta[1], daneKlienta[2],daneKlienta[4],daneKlienta[5],daneKlienta[3]);

    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, "AGRUBA", driver);
        clickElement(Tia7StronaGlowna.przyciskWyszukajDodajKlienta);
        daneKlienta = TIA7registerNewClient("00"+nrTel, "", appEnv, aplikacja);
        status = true;
    }
}