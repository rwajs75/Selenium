package TIA7;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import tia7.pageobjects.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static tia7.pageobjects.Tia7Common.*;
import static tia7.pageobjects.Tia7CommonProcess.*;
import static helpers.dictionary.StaticStrings.*;

/**
 * @author Przemysław Mendalka
 */
@DisplayName("TIA7")
public class RST_21880_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String appEnv;
    private String nazwaTestu = "RST-21880 Regresja TIA7 - Polisa Trawel płatność kartą";
    private String aplikacja = "TIA7";
    private String nrPolisy;
    private String nrPolisyCustom;
    private String nazwaProcesu = "Polisa";

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22625").env(appEnv).stage("Utworzenie nowego klienta").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
    }

    @Test
    @DisplayName("RST-21880 Regresja TIA7 - Polisa Trawel płatność kartą")
    @Issue("RST-21880")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
            krok2();
            krok3();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (daneTestowe!=null) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(),daneTestowe.getParam4(),daneTestowe.getParam5(),nrPolisyCustom);
    }

    private void krok1() {
        LoginWeb("TIA7", appEnv, "lblaszcz", driver);
        clickElement(Tia7StronaGlowna.przyciskWyszukajDodajKlienta);
        //daneKlienta = TIA7registerNewClient("00"+nrTel, "", appEnv, aplikacja);
        setSelectInputTia7("PESEL", daneTestowe.getParam3(), "input");
        clickElement(Tia7WyszukajDodajKlienta.przyciskSzukaj);
        clickElement(By.xpath("//*[contains(text(), '"+daneTestowe.getParam5()+"')]"));
        clickButton(Tia7Polisa.przyciskNowy);
        switchToNewPopUp();
        selectTIA7Product("P1 - Travel", false);
        //TODO: Wyniesc do funkcji od tego miejsca
        setSelectInputTia7("Kod źródłowy","Travel - MojaAviva", "select");
        setSelectInputTia7("Data końca ochrony", LocalDate.now().plusDays(30).format(DateTimeFormatter.ofPattern("dd.MM.yyyy")), "input");
        nrPolisy = getElementText(Tia7Polisa.poleTekstoweNrPolisy);
        clickButton(Tia7Polisa.przyciskNowaLiniaPolisowa);
        switchToNewPopUp();

        clickButton(Tia7Polisa.przyciskTakNLP);
        setSelectInputTia7("Imię", daneTestowe.getParam1(), "input");
        setSelectInputTia7("Nazwisko", daneTestowe.getParam2(), "input");
        setSelectInputTia7("PESEL", daneTestowe.getParam3(), "input");
        setSelectInputTia7("Data urodzenia", daneTestowe.getParam6(), "input");
        clickButton(Tia7FormularzTravel.przyciskAktualizuj);
        clickElement(Tia7Common.przyciskZapisz);

        //TODO: Do tego miejsca
    }

    private void krok2() {
        clickElement(By.xpath("//*[contains(text(), '- Risks -')]"));
        switchToNewPopUp();
        setSelectInputTia7("Strefa wyjazdu", "Polska", "select");
        setSelectInputTia7("Koszty leczenia i assistance", "5000", "select");
        setSelectInputTia7("Następstwa nieszczęśliwych wypadków", "", "input");
        clickElement(Tia7Common.przyciskZapisz);
        setSelectInputTia7("Następstwa nieszczęśliwych wypadków", "10000", "select");
        setSelectInputTia7("Metoda płatności", "Karta kredytowa", "select");
        clickElement(Tia7Common.przyciskZapisz);
        /** Poniższa linia to płatność 'Przelewem' z poziomu TIA7 */
        getPaymentAmount(driver);
    }

    private void krok3() {
        nrPolisyCustom = savePolice(nazwaProcesu,nrPolisy);
        clickElement(By.xpath("//a[contains(text(), '" +nrPolisy+ "')]"));
        if (waitUntilElementPresent(tabelaUproszczonyWidokPlatnosci, 5) == null) {
            clickElement(uproszczonyWidokPlatnosci);
        }
        String saldo = driver.findElement(saldoWartosc).getText();
        int saldoWartosc = Integer.parseInt(String.valueOf(saldo));
        if (saldoWartosc > 0) {
            reporter().logFail("Polisa o numerze: " + nrPolisy + " nie została opłacona");
        } else {
            reporter().logPass("Polisa o numerze: " + nrPolisy + " została opłacona", true);
        }
        status = true;
    }
}