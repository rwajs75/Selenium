package TIA7;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import tia7.pageobjects.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import static helpers.common.Common.*;
import static helpers.common.Common.clickElement;
import static helpers.generators.RegistrationPlateNumberGenerator.tablica;
import static helpers.generators.VINGenerator.vin;
import static helpers.login.Login.LoginWeb;
import static tia7.pageobjects.Tia7Common.*;
import static tia7.pageobjects.Tia7CommonProcess.*;
import static helpers.dictionary.StaticStrings.*;

/**
 * @author Przemysław Mendalka
 */
@DisplayName("TIA7")
public class RST_21881_Test {

    @FindBy(xpath = "//*[@title='C1 - Motor']")
    public static WebElement moto;
    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String appEnv;
    private String nazwaTestu = "RST-21881 Regresja TIA7 - Polisa Moto płatność przelewem";
    private String aplikacja = "TIA7";
    private String nrPolisy;
    private String nrPolisyCustom;
    private String nazwaProcesu = "Polisa";

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement(driver);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22625").env(appEnv).stage("Utworzenie nowego klienta").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
    }

    @Test
    @DisplayName("RST-21881 Regresja TIA7 - Polisa Moto płatność przelewem")
    @Issue("RST-21881")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
            krok2();
            krok3();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (daneTestowe!=null) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(),daneTestowe.getParam4(),daneTestowe.getParam5(),nrPolisyCustom);
    }

    private void krok1() {
        LoginWeb("TIA7", appEnv, "AGRUBA", driver);
        clickElement(Tia7StronaGlowna.przyciskWyszukajDodajKlienta);
        //daneKlienta = TIA7registerNewClient("00"+nrTel, "", appEnv, aplikacja);
        setSelectInputTia7("PESEL", daneTestowe.getParam3(), "input");
        clickElement(Tia7WyszukajDodajKlienta.przyciskSzukaj);
        clickElement(By.xpath("//*[contains(text(), '"+daneTestowe.getParam5()+"')]"));
        clickButton(Tia7Polisa.przyciskNowy);
        switchToNewPopUp();
        selectTIA7Product("C1 - Motor", false);
        //TODO: Wyniesc do funkcji od tego miejsca
        selectDropdownListOption(Tia7Polisa.listaKodZrodlowy, "Inbound");
        nrPolisy = getElementText(Tia7Polisa.poleTekstoweNrPolisy);
        clickButton(Tia7Polisa.przyciskNowaLiniaPolisowa);
        switchToNewPopUp();
        clickButton(Tia7Polisa.przyciskTakNLP);
        //TODO: Do tego miejsca
    }

    private void krok2() {
        setSelectInputTia7("Kraj pierwszej rejestracji", "Polska", "select");
        setSelectInputTia7("Sposób użytkowania samochodu", "prywatny", "select");
        enterIntoTextField(Tia7FormularzMoto.poleTekstoweRokProdukcji, "2010");
        clickElement(Tia7FormularzMoto.poleTekstoweKodPocztowy);
        setSelectInputTia7("Marka", "BMW", "select");
        setSelectInputTia7("Model", "Seria 3", "select");
        setSelectInputTia7("Rodzaj paliwa", "Benzyna", "select");
        setSelectInputTia7("Instalacja gazowa", "Nie", "select");
        setSelectInputTia7("Pojemność silnika", "1995ccm / 2.0", "select");
        setSelectInputTia7("Typ nadwozia", "Sedan", "select");
        setSelectInputTia7("Typ pojazdu", "320i", "select");
        setSelectInputTia7("Data nabycia pojazdu", "2011", "select");
        setSelectInputTia7("Miejsce", "Ulica", "select");
        setSelectInputTia7("Liczba samochodów w gospodarstwie domowym", "1", "select");
        clickElement(Tia7FormularzMoto.poleOpcjiWybierzWyposażenie);
        setSelectInputTia7("Sprawne zabezpieczenia w pojeździe", "Jedno zabezpieczenie elektroniczne", "select");
        enterIntoElement(Tia7FormularzMoto.poleTekstoweNumerRejestracyjny, tablica());
        enterIntoElement(Tia7FormularzMoto.poleTekstoweNumerVIN, vin());
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String thisDate = dateFormat.format(date);
        enterIntoTextField(Tia7FormularzMoto.poleTekstoweDataKolBadTechnicznego, thisDate);
        setSelectInputTia7("Pakiet", "OC+AC Złoty", "select");
        setSelectInputTia7("Metoda płatności", "Przelew", "select");
        setSelectInputTia7("LB OC", "0", "select");
        setSelectInputTia7("LB AC", "0", "select");
        setSelectInputTia7("LSZ OC", "0", "select");
        setSelectInputTia7("LSZ AC", "0", "select");

    }

    private void krok3() {
        nrPolisyCustom = savePolice(nazwaProcesu,nrPolisy);
        status = true;
    }

}