package monitor;

import helpers.common.Common;
import helpers.database.TestDataManager;
import helpers.database.TestDataManager.MonitorDTO;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j;
import org.junit.Test;

import java.util.List;

@Log4j
public class TestDataMonitor {

    @Test
    public void monitor(){

        String user = "monitordanych";
        String token = "AV$62VKyQ>fP7gx$9C*o";
        String env = System.getProperty("appEnv");

        TestDataManager manager = new TestDataManager(env);
        List<MonitorDTO> monitor = manager.getMinTestDataCount(env);
        if (monitor == null) {
            log.error("Monitor data is null");
            return;
        }

        for (MonitorDTO m : monitor) {
            try {
                int count = manager.getTestDataCount(m.getTestName(), m.getEnv(), m.getEtap());
                if (count == -1) {
                    log.error("Failed to get count");
                }
                if (!m.isEnabled()) {
                    log.info("Supply disabled for RST: " + m.getTestName());
                } else for (; count < m.getRequired(); count++) {
                    try {
                        Response crumbResp = RestAssured.given()
                                .filter(new ResponseLoggingFilter())
                                .auth().preemptive().basic(user, token)
                                .baseUri("http://10.3.134.118:8080/crumbIssuer/api/json")
                                .get();
                        Common.pauseFor(1);
                        String crumb = crumbResp.body().jsonPath().getString("crumb"),
                                crumbField = crumbResp.body().jsonPath().getString("crumbRequestField");

                        RestAssured.given()
                                .auth().preemptive().basic(user, token)
                                .header(crumbField, crumb)
                                .filter(new RequestLoggingFilter())
                                .filter(new ResponseLoggingFilter())
                                .baseUri("http://10.3.134.118:8080" + m.getEndpoint() + "build")
                                .post();

                    } catch (NoClassDefFoundError e) {
                        log.error("Test not found for given RST: " + m.getTestName() + ", aborting");
                        return;
                    }
                    Common.pauseFor(5);
                }
            } catch (Exception e) {
                log.error(e);
                e.printStackTrace();
            }
        }
    }
}
