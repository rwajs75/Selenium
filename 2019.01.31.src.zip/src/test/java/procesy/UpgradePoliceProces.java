package procesy;

import helpers.database.*;
import helpers.database.dto.TestDTO;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import helpers.throwables.GeneralStepException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static helpers.common.Common.*;
import static helpers.excel.ExcelManager.*;
import static myaviva.MyAvivaHelpers.upgradeDataRow;

/**
 * @author Sławomir Kamiński
 */
public class UpgradePoliceProces {

    private WebDriver driver;
    private TestDataManager manager;
    private String appEnv;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        manager = new TestDataManager(appEnv);
    }

    @Test
    public void upgrade() {
        try {

            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            if (System.getProperty("input-xml") == null)
                reporter().logError("Nie podano lokalizacji wejściowego pliku xml.");

            //pobranie zamówień z excela
            reporter().logPass("Pobieranie danych zapotrzebowań...");
            String inputXml = System.getProperty("input-xml");
            List<TestDataRequest> reqs = getDataRequests(inputXml, appEnv);

            //pobranie danch z DH i wprowadzenie do naszej bazy
            reporter().logPass("Pobieranie rekordów z DHuba " + appEnv + "..."); //docelowo zmienna określająca środowisko

            List<Integer> inputIds = new ArrayList<>(),
                    passed;

            Map<TestDataRequest, List<Integer>> resultMap = new HashMap<>();

            //dla każdego żądanego zestawu
            for (TestDataRequest req : reqs) {
                passed = new ArrayList<>();
                inputIds.addAll(manager.retrieveDataWithGroupNumberForBusiness(req));
                if (inputIds.isEmpty()) {
                    try {
                        reporter().logFail("Nie istnieją wolne dane testowe o wymaganych właściwościach.");
                    } catch (GeneralStepException ignored) {
                    }
                }
                reporter().logPass("Przeprowadzanie upgrade'a pobranych rekordów...");

                //upgrade wprowadzonych rekordów (i utworzenie nowch maili w razie potrzeby)
                for (int id : inputIds) {
                    // try {
                    Instant time = Instant.now();
                    if ((time.get(ChronoField.HOUR_OF_DAY) == 7 || time.get(ChronoField.HOUR_OF_DAY) == 15) &&
                            time.get(ChronoField.MINUTE_OF_HOUR) > 45) {        //okno serwisowe
                        do {
                            pauseFor(60);
                        } while (Instant.now().get(ChronoField.MINUTE_OF_HOUR) != 5);
                    }
                    upgradeDataRow(id, driver, manager, appEnv);
                    reporter().logPass("Przypisano mail do rekordu: " + id);
                    passed.add(id);
                    req.setIl_sztuk(req.getIl_sztuk() - 1);
//            } catch (PoliceUpgradeFailureException e) {
//                reporter().logWarn("Nie udało się przypisać maila do rekordu: " + id);
//            } catch (Exception e) {
//                reporter().logWarn("Nieznany błąd w trakcie trwania procesu (możliwe przerwanie): " +
//                        "zwracanie obecnie przetworzonych rekordów...");
//                resultMap.put(req, passed);
//                printResults(resultMap, reqs);
//                reporter().logFail("Proces przerwany: ", e);
//            }
                }
                if (req.getIl_sztuk() != 0)
                    try {
                        reporter().logFail("Nie udało się zaktualizować wszystkich pobranych rekordów.");
                    } catch (GeneralStepException ignored) {
                    }
                reporter().logPass("Zaktualizowano rekordy o następujących id w bazie danych testowych: " + passed);
                inputIds.clear();
                resultMap.put(req, passed);
            }

            //wydrukowanie danych upgrade'owanych rekordów do excela wynikowego
            printResults(resultMap, reqs);
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
    }

    private void printResults(Map<TestDataRequest, List<Integer>> upgraded, List<TestDataRequest> reqs) {
        List<TestDTO> upgradedRows = new ArrayList<>();
        for (List<Integer> upgradedPart: upgraded.values()) {
            upgradedRows.addAll(manager.getRowsAfterUpgrading(upgradedPart));
        }

        try {

            File reportSpreadsheet = new File(System.getProperty("output-xml") == null ?
                    ".\\target\\output\\output.xlsx" : System.getProperty("output-xml"));
            if (!reportSpreadsheet.exists()) {
                if ((!reportSpreadsheet.getParentFile().exists() && !reportSpreadsheet.getParentFile().mkdirs()) || !reportSpreadsheet.createNewFile())
                    throw new IOException("Failed to create report file");
            }
            else {
                if (!reportSpreadsheet.delete() || !reportSpreadsheet.createNewFile()) {
                    reporter().logFail("Failed to replace old report file");
                }
            }

            for(int i = 1; i <= reqs.size(); i++) {
                prepareReportFile(reportSpreadsheet, "Sheet " + i);
                for(TestDTO data: upgradedRows) {
                    writeValuesToNewRow(reportSpreadsheet, "Sheet " + i,
                            Integer.toString(data.getNr_polisy()),
                            manager.getDictValueOf("policeType", data.getTyp_polisy()),     //typ
                            manager.getDictValueOf("policeStatus", data.getStatus_polisy()),//status
                            manager.getDictValueOf("role", data.getRola_wlasc()),           //rola
                            data.getImie(), data.getNazwisko(),
                            data.getTelefon(),
                            data.getMail());
                }
            }

            reporter().logPass("Wyniki umieszczono w pliku " + reportSpreadsheet.getAbsolutePath());

        } catch (IOException e) {
            reporter().logFail("Failed to create report file", e);
        }
    }
}
