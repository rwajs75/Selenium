package myaviva.moto;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.generators.RandomIntGenerator;
import helpers.generators.RandomStringGenerator;
import helpers.generators.RegistrationPlateNumberGenerator;
import helpers.generators.VINGenerator;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.moto.*;
import myaviva.pageobjects.moto.ACKradziez.MotoACKradziezDaneZdarzenia;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.generators.PESELGenerator.*;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Moto")
public class RST_22507_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String aplikacja = "MyAviva";
    private String nazwaTestu = "RST-22507 Zgłoszenie Bezpośrednia likwidacja szkody";
    private String appEnv;
    private String email;
    private String numerTelefonu = StaticStrings.NRTEL;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) {
            appEnv = "CP";
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22500").env(appEnv).stage(
                "Obsługa polisy w MyAviva").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
        email = daneTestowe.getParam4();

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MotoDaneSamochodu.class);
        PageFactory.initElements(driver, MotoWyborSzkody.class);
        PageFactory.initElements(driver, MotoDziekujemy.class);
        PageFactory.initElements(driver, MotoBezposredniaLikwidacjaSzkody1.class);
        PageFactory.initElements(driver, MotoZgloszenieSzkody2.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22507 Zgłoszenie Bezpośrednia likwidacja szkody")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
            krok6();
            status = true;
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (status) {
            reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Zgłoszenie szkody w MyAviva", status, daneTestowe.getParam1(),
                    daneTestowe.getParam2(), daneTestowe.getParam3(), email,
                    "Moto", daneTestowe.getParam6(), numerTelefonu);
        }else if (daneTestowe != null){
            status = true;
            reportSummaryAndSendResults("RST-22500", aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Obsługa polisy w MyAviva", status, daneTestowe.getParam1(), daneTestowe.getParam2(),
                    daneTestowe.getParam3(), daneTestowe.getParam4(), daneTestowe.getParam5(),
                    daneTestowe.getParam6());
        }
    }

    private void krok1() {
        LoginWeb("MyAviva", appEnv, email, driver);
        clickElement(MyAvivaOfertaDlaCiebie.linkSamochod);
    }

    private void krok2() {
        sprawdzenieStronyPolisyMoto();
        clickElement(MotoDaneSamochodu.przyciskZglosZdarzenie);
    }

    private void krok3() {
        sprawdzenieWyboruRodzajuZgloszeniaMoto();
        clickElement(MotoWyborSzkody.linkBezposredniaLikwidacjaSzkody);
    }

    private void krok4() {
        obslugaBleduSprawdzeniaElementu(MotoBezposredniaLikwidacjaSzkody1.listaZakladowUbezpieczenSprawcy,
                "Wyświetliła się strona zgłaszanie szkody samochodowej krok 1 z 2.",
                "Nie wyświetliła się strona zgłaszanie szkody samochodowej krok 1 z 2.");
        selectDropdownListOption(MotoBezposredniaLikwidacjaSzkody1.listaZakladowUbezpieczenSprawcy, "PZU");
        clickElement(MotoBezposredniaLikwidacjaSzkody1.przyciskWyboruCzyNaTereniePolski);
        clickElement(MotoBezposredniaLikwidacjaSzkody1.przyciskWyboruCzyZostaloSpisaneOswiadczenie);
        clickElement(MotoBezposredniaLikwidacjaSzkody1.przyciskWyboruCzyWicejNizDwaPojazdy);
        clickElement(MotoBezposredniaLikwidacjaSzkody1.przyciskWyboruCzyObrazeniaCiala);
        clickElement(MotoBezposredniaLikwidacjaSzkody1.przyciskWyboruCzyUszkodzoneMieniePozaPojazdem);
        clickElement(MotoBezposredniaLikwidacjaSzkody1.przyciskWyboruCzySzkodaZgloszonaWInnymZakladzieUpezpieczen);
        selectDropdownListOption(MotoBezposredniaLikwidacjaSzkody1.listaRodzajZdarzenia, "Zderzenie pojazdów");
        selectDropdownListOption(MotoBezposredniaLikwidacjaSzkody1.listaPrzyczynaZdarzenia,
                "Wymuszenie pierwszeństwa przejazdu");
        enterIntoTextField(MotoBezposredniaLikwidacjaSzkody1.poleTekstoweNumerPolisySprawcy, "112233445566778");
        enterIntoTextField(MotoBezposredniaLikwidacjaSzkody1.poleTekstoweNumerRejestracyjnySprawcy,
                RegistrationPlateNumberGenerator.tablica());
        enterIntoTextField(MotoBezposredniaLikwidacjaSzkody1.poleTekstoweNumerPolisyAviva, "998877665544331");
        enterIntoTextArea(MotoBezposredniaLikwidacjaSzkody1.poleEdycyjneDaneSprawcyWypadku,
                "To są dane sprawcy zdarzenia: " + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoBezposredniaLikwidacjaSzkody1.poleTekstoweDataZdarzenia,
                LocalDate.now().minusDays(2).format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        MotoBezposredniaLikwidacjaSzkody1.poleTekstoweDataZdarzenia.sendKeys(Keys.TAB);
        enterIntoTextField(MotoBezposredniaLikwidacjaSzkody1.poleTekstoweGodzina,
                Integer.toString(RandomIntGenerator.liczbaLosowa(10, 13)));
        enterIntoTextField(MotoBezposredniaLikwidacjaSzkody1.poleTekstoweMinuty,
                Integer.toString(RandomIntGenerator.liczbaLosowa(10, 49)));
        enterIntoTextField(MotoBezposredniaLikwidacjaSzkody1.poleTekstoweMiejsceZdarzenia,
                "Tu było zdarzenie: " + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextArea(MotoBezposredniaLikwidacjaSzkody1.poleEdycyjneOpisZdarzenia,
                "Szczegółowy opis zdarzenia: " + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextArea(MotoBezposredniaLikwidacjaSzkody1.poleEdycyjneRodzajUszkodzen,
                "Szczegółowy rodzaj uszkodzeń: " + RandomStringGenerator.generateCharsSequence().toUpperCase());
        clickElement(MotoBezposredniaLikwidacjaSzkody1.przyciskWyboruCzyPojazdHolowany);
        clickElement(MotoBezposredniaLikwidacjaSzkody1.przyciskWyboruCzyPowiadomionoPolicje);
        clickButton(MotoBezposredniaLikwidacjaSzkody1.przyciskDalej);
    }

    private void krok5() {
        obslugaBleduSprawdzeniaElementu(MotoZgloszenieSzkody2.poleTekstoweNumerRejestracyjnyPoszkodowanego,
                "Wyświetliła się strona zgłaszanie szkody samochodowej krok 2 z 2.",
                "Nie wyświetliła się strona zgłaszanie szkody samochodowej krok 2 z 2.");
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweNumerRejestracyjnyPoszkodowanego,
                RegistrationPlateNumberGenerator.tablica());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTestoweNumerVinPoszkodowanego,
                VINGenerator.randomNumString(17));
        selectDropdownListOption(MotoZgloszenieSzkody2.listaRokProdukcjiPoszkodowanego,
                Integer.toString(RandomIntGenerator.liczbaLosowa(2002, 10)));
        selectDropdownListOption(MotoZgloszenieSzkody2.listaMarkaPoszkodowanego, "BMW");
        selectDropdownListOption(MotoZgloszenieSzkody2.listaModelPoszkodowanego, "X3");
        enterIntoTextArea(MotoZgloszenieSzkody2.poleEdycyjneMiejsceOgledzin,
                "To jest preferowane miejsce oględzin :"
                        + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweImieZglaszajacego,
                "Damian" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweNazwiskoZglaszajacego,
                "Tester" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstowePeselZglaszajacego,
                generatePESELForDate(1999, 5, 10, 'k'));
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweKodPocztowyZglaszajacego1, "01");
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweKodPocztowyZglaszajacego2, "234");
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweMiejscowoscZglaszajacego, "Młochów");
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweNumerDomuZglaszajacego,
                Integer.toString(RandomIntGenerator.liczbaLosowa(1, 149)));
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweUlicaZglaszajacego,
                "Znana" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweNumerTelefonuZglaszajacego, numerTelefonu);
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweEmailZglaszajacego, email);
        clickElement(MotoZgloszenieSzkody2.przyciskWyboruCzyZglaszajacyJestWlascicielem);
        clickElement(MotoZgloszenieSzkody2.przyciskWyboruCzyZglaszajacyKierowal);
        MotoZgloszenieSzkody2.poleTekstoweNumerKonta.sendKeys("54249000059579912479503428");
        MotoZgloszenieSzkody2.poleTekstoweNumerKonta.sendKeys(Keys.TAB);
        clickElement(MotoZgloszenieSzkody2.przyciskWyboruWlascicielaKonta);
        clickElement(MotoZgloszenieSzkody2.przyciskWyboruSposobuRozliczeniaSzkody);
        clickElement(MotoZgloszenieSzkody2.poleOpcjiAkceptuje);
        clickElement(MotoZgloszenieSzkody2.poleOpcjiWyrazamZgode);
        clickButton(MotoZgloszenieSzkody2.przyciskDalej);
    }

    private void krok6() {
        //Sprawdzić i dopisać jak zniknie komunikat usługa chwilowo niedostępna
        clickElement(MotoDziekujemy.przyciskPrzejdzDoStronyGlownej);
    }
}
