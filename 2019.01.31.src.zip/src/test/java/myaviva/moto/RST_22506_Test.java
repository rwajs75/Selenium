package myaviva.moto;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.generators.RandomIntGenerator;
import helpers.generators.RandomStringGenerator;
import helpers.generators.RegistrationPlateNumberGenerator;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.mojProfil.MojProfil;
import myaviva.pageobjects.moto.ACKradziez.MotoACKradziezDaneZdarzenia;
import myaviva.pageobjects.moto.ACUszkodzenie.*;
import myaviva.pageobjects.moto.MotoDaneSamochodu;
import myaviva.pageobjects.moto.MotoDziekujemy;
import myaviva.pageobjects.moto.MotoWyborSzkody;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.generators.PESELGenerator.generatePESEL;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Moto")
public class RST_22506_Test {

    private WebDriver driver;
    private String numerSzkody;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String aplikacja = "MyAviva";
    private String nazwaTestu = "RST-22506 Zgłoszenie Szkody AC uszkodzenie";
    private String appEnv;
    private String email;
    private String numerTelefonu;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }


        appEnv = System.getProperty("appEnv");
        if (appEnv == null) {
            appEnv = "CP";
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22503").env(appEnv).stage(
                "Obsługa polisy w MyAviva").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
        email = daneTestowe.getParam4();

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MotoDaneSamochodu.class);
        PageFactory.initElements(driver, MotoWyborSzkody.class);
        PageFactory.initElements(driver, MotoACUszkodzenieDaneZdarzenia.class);
        PageFactory.initElements(driver, MotoDziekujemy.class);
        PageFactory.initElements(driver, MotoDaneUczestnikowZdarzenia.class);
        PageFactory.initElements(driver, MotoUszkodzeniaTwojegoPojazdu.class);
        PageFactory.initElements(driver, MotoZdjeciaIDokumenty.class);
        PageFactory.initElements(driver, MotoACUszkodzeniePodsumowanie.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, MojProfil.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22506 Zgłoszenie Szkody AC uszkodzenie")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);
            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
            krok6();
            krok7();
            krok8();
            krok9();
            status = true;
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (status) {
            reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Zgłoszenie szkody w MyAviva", status, daneTestowe.getParam1(),
                    daneTestowe.getParam2(), daneTestowe.getParam3(), email,
                    "Moto", daneTestowe.getParam6(), numerSzkody, numerTelefonu);
        }else if (daneTestowe != null){
            status = true;
            reportSummaryAndSendResults("RST-22503", aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Obsługa polisy w MyAviva", status, daneTestowe.getParam1(), daneTestowe.getParam2(),
                    daneTestowe.getParam3(), daneTestowe.getParam4(), daneTestowe.getParam5(),
                    daneTestowe.getParam6());
        }
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, email, driver);
        numerTelefonu = odczytNumeruTelefonuZProfilu(appEnv);
        clickElement(MyAvivaOfertaDlaCiebie.linkSamochod);
    }

    private void krok2() {
        sprawdzenieStronyPolisyMoto();
        clickElement(MotoDaneSamochodu.przyciskZglosZdarzenie);
    }

    private void krok3() {
        sprawdzenieWyboruRodzajuZgloszeniaMoto();
        clickElement(MotoWyborSzkody.linkAcUszkodzenie);
    }

    private void krok4() {
        obslugaBleduSprawdzeniaElementu(MotoACUszkodzenieDaneZdarzenia.poleTekstoweDataZdarzenia,
                "Wyświetliła się strona AC uszkodzenie krok 1 z 5.",
                "Nie wyświetliła się strona AC uszkodzenie krok 1 z 5.");
        enterIntoTextField(MotoACUszkodzenieDaneZdarzenia.poleTekstoweDataZdarzenia,
                LocalDate.now().minusDays(2).format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        MotoACUszkodzenieDaneZdarzenia.poleTekstoweDataZdarzenia.sendKeys(Keys.TAB);
        enterIntoTextField(MotoACUszkodzenieDaneZdarzenia.poleTekstoweGodzina,
                Integer.toString(RandomIntGenerator.liczbaLosowa(10, 13)));
        enterIntoTextField(MotoACUszkodzenieDaneZdarzenia.poleTekstoweMinuty,
                Integer.toString(RandomIntGenerator.liczbaLosowa(10, 49)));
        if (waitUntilElementVisible(MotoACUszkodzenieDaneZdarzenia.poleOpcjiNieZnamAdresuZdarzenia, 5) != null) {
            clickElement(MotoACUszkodzenieDaneZdarzenia.poleOpcjiNieZnamAdresuZdarzenia);
            pauseFor(2);
        }
        enterIntoTextArea(MotoACUszkodzenieDaneZdarzenia.poleEdycyjneLokalizacja,
                "Przybliżone miejsce lub adres zdarzenia " + RandomStringGenerator.generateCharsSequence().toUpperCase());
        clickElement(MotoACUszkodzenieDaneZdarzenia.przyciskWyboruCzyBylaPolicja);
        clickElement(MotoACUszkodzenieDaneZdarzenia.przyciskWyboruCzyPojazdBylZaparkowany);
        waitUntilElementVisible(MotoACUszkodzenieDaneZdarzenia.przyciskWyboruPrzyczynaUszkodzenia, 5);
        clickElement(MotoACUszkodzenieDaneZdarzenia.przyciskWyboruPrzyczynaUszkodzenia);
        pauseFor(2);
        clickElement(MotoACUszkodzenieDaneZdarzenia.przyciskWyboruCzyPojazdBylHolowany);
        waitUntilElementVisible(MotoACUszkodzenieDaneZdarzenia.poleTekstoweNumerTelefonu, 5);
        enterIntoElement(MotoACUszkodzenieDaneZdarzenia.poleTekstoweNumerTelefonu, numerTelefonu);
        clickButton(MotoACUszkodzenieDaneZdarzenia.przyciskDalej);
    }

    private void krok5() {
        obslugaBleduSprawdzeniaElementu(MotoDaneUczestnikowZdarzenia.poleTekstoweImieSprawcy,
                "Wyświetliła się strona dane uczestników zdarzenia krok 2 z 5.",
                "Nie wyświetliła się strona dane uczestników zdarzenia krok 2 z 5.");
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstoweImieSprawcy,
                "Janusz" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstoweNazwiskoSprawcy,
                "SprawcaZdarzenia" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstowePeselSprawcy, generatePESEL('k'));
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstoweNumerTelefonuSprawcy, numerTelefonu);
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstoweKodPocztowy1, "22");
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstoweKodPocztowy2, "444");
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstoweMiejscowoscSprawcy, "Warszawa");
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstoweNumerDomuSprawcy,
                Integer.toString(RandomIntGenerator.liczbaLosowa(1, 399)));
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstoweUlicaSprawcy,
                "Rozbitków" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoDaneUczestnikowZdarzenia.poleTekstoweNumerRejestracyjnySprawcy,
                RegistrationPlateNumberGenerator.tablica());
        clickButton(MotoDaneUczestnikowZdarzenia.przyciskDalej);
    }

    private void krok6() {
        obslugaBleduSprawdzeniaElementu(MotoUszkodzeniaTwojegoPojazdu.uszkodzonyElementTyl,
                "Wyświetliła się strona uszkodzenia twojego pojazdu krok 3 z 5.",
                "Nie wyświetliła się strona uszkodzenia twojego pojazdu krok 3 z 5.");
        clickElement(MotoUszkodzeniaTwojegoPojazdu.uszkodzonyElementTyl);
        waitUntilElementVisible(MotoUszkodzeniaTwojegoPojazdu.poleOpcjiZderzakTylny, 5);
        clickElement(MotoUszkodzeniaTwojegoPojazdu.poleOpcjiZderzakTylny);
        waitUntilElementVisible(MotoUszkodzeniaTwojegoPojazdu.przyciskWyboruCzyLakierowany, 5);
        clickElement(MotoUszkodzeniaTwojegoPojazdu.przyciskWyboruCzyLakierowany);
        waitUntilElementVisible(MotoUszkodzeniaTwojegoPojazdu.przyciskWyboruCzyPekniety, 5);
        clickElement(MotoUszkodzeniaTwojegoPojazdu.przyciskWyboruCzyPekniety);
        clickButton(MotoUszkodzeniaTwojegoPojazdu.przyciskZapisz);
        waitUntilElementVisible(MotoUszkodzeniaTwojegoPojazdu.poleWyboruCzyPojazdWWarsztacie, 5);
        clickElement(MotoUszkodzeniaTwojegoPojazdu.poleWyboruCzyPojazdWWarsztacie);
        clickButton(MotoUszkodzeniaTwojegoPojazdu.przyciskDalej);
    }

    private void krok7() {
        obslugaBleduSprawdzeniaElementu(MotoZdjeciaIDokumenty.przyciskDodajZdjeciaUszkodzen,
                "Wyświetliła się strona zdjęcia i dokumenty krok 4 z 5.",
                "Nie wyświetliła się strona zdjęcia i dokumenty krok 4 z 5.");
        //Dodać mozliwość przesyłania plików
        clickElement(MotoZdjeciaIDokumenty.przyciskPrzejdzDoPodsumowania);
    }

    private void krok8() {
        obslugaBleduSprawdzeniaElementu(MotoACUszkodzeniePodsumowanie.poleOpcjiPotwierdzam,
                "Wyświetliła się strona podsumowanie krok 5 z 5.",
                "Nie wyświetliła się strona podsumowanie krok 5 z 5.");
        clickElement(MotoACUszkodzeniePodsumowanie.poleOpcjiPotwierdzam);
        clickElement(MotoACUszkodzeniePodsumowanie.przyciskWyslijWniosek);
    }

    private void krok9() {
        waitUntilElementNotVisible(MotoDziekujemy.kreciolTrwaWyliczenie, 60);
        sprawdzenieWyslaniaZgloszeniaSzkodyMoto();
        numerSzkody = pobierzNumerSzkody(MotoDziekujemy.tekstNumerSzkody);
        //Sprawdzić czy nie pojawiły się kolejne kroki
    }
}
