package myaviva.moto;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.moto.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Moto")
public class RST_22500_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String aplikacja = "MyAviva";
    private String nazwaTestu = "RST-22500 Pobranie dokumentów z polisy Moto";
    private String appEnv;
    private String email;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) {
            appEnv = "CP";
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName("TIA7").testName("RST-22749").env(appEnv).stage(
                "Weryfikacja w MyAviva").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
        email = daneTestowe.getParam4();

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MotoDaneSamochodu.class);
        PageFactory.initElements(driver, MotoSzczegoly.class);
        PageFactory.initElements(driver, MotoDokumenty.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22500 Pobranie dokumentów z polisy Moto")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);
            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
            status = true;
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (status) {
            reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Obsługa polisy w MyAviva", status, daneTestowe.getParam1(),
                    daneTestowe.getParam2(), daneTestowe.getParam3(), email,
                    "Moto", daneTestowe.getParam6());
            reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Obsługa polisy w MyAviva", status, daneTestowe.getParam1(),
                    daneTestowe.getParam2(), daneTestowe.getParam3(), email,
                    "Moto", daneTestowe.getParam6());
            reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Obsługa polisy w MyAviva", status, daneTestowe.getParam1(),
                    daneTestowe.getParam2(), daneTestowe.getParam3(), email,
                    "Moto", daneTestowe.getParam6());
        } else if (daneTestowe != null) {
            status = true;
            reportSummaryAndSendResults("RST-22749", "TIA7", appEnv, DataRowStatus.AKTYWNY,
                    "Weryfikacja w MyAviva", status, daneTestowe.getParam1(), daneTestowe.getParam2(),
                    daneTestowe.getParam3(), daneTestowe.getParam4(), daneTestowe.getParam5(),
                    daneTestowe.getParam6());
        }
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, email, driver);
        clickElement(MyAvivaOfertaDlaCiebie.linkSamochod);
    }

    private void krok2() {
        sprawdzenieStronyPolisyMoto();
        clickElement(MotoDaneSamochodu.przyciskSzczegoly);
    }

    private void krok3() {
        sprawdzenieStronySzczegolyMoto();
        clickElement(MotoSzczegoly.dokumenty);
    }

    private void krok4() {
        clickElement(MotoDokumenty.linkPobierzDokument);
    }

    private void krok5() {
        clickElement(MotoSzczegoly.linkWrocDoProduktow);
    }
}
