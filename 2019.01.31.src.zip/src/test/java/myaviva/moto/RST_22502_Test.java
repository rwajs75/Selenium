package myaviva.moto;

import formularz.moto.pageobjects.*;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.generators.*;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaListaTwoichWnioskow;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.MyAvivaStronaGlowna;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static ecard.Platnosc.platnoscEcard;
import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Moto")
public class RST_22502_Test {

    private WebDriver driver;
    private String appEnv;
    private String email;
    private String numerTelefonu = StaticStrings.NRTEL;
    private String numerPolisy;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty(
                "appEnv"); //TODO: dodać we wszystkich uruchomieniach parametr -DappEnv=UT i zamienić tutaj na CP
        if (appEnv == null) appEnv = "CP";

        switch (appEnv) {
            case "UT": {
                email = "CZTMYA5812@YOPMAIL.COM";
                break;
            }
            case "CP": {
                email = "CZTMYA5976@YOPMAIL.COM";
                break;
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MyAvivaStronaGlowna.class);
        PageFactory.initElements(driver, MyAvivaListaTwoichWnioskow.class);
        PageFactory.initElements(driver, MotoSamochod.class);
        PageFactory.initElements(driver, MotoKierowca.class);
        PageFactory.initElements(driver, MotoTwojaOferta.class);
        PageFactory.initElements(driver, MotoDaneDoPolisy.class);
        PageFactory.initElements(driver, MotoPodsumowanie.class);
        PageFactory.initElements(driver, MotoCommon.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22502 Sprawdzenie ceny polisy Moto")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            /*krok4();
            krok5();
            krok6();
            krok7();*/
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " + email);
        reporter().logPass("NUmer polisy: " + numerPolisy);
        reporter().logPass("###############################");
        if (driver != null) driver.quit();
    }

    private void krok1() {
        LoginWeb("MyAviva", appEnv, email, driver);
        if (waitUntilElementPresent(MyAvivaOfertaDlaCiebie.samochod, 5) != null) {
            clickElement(MyAvivaOfertaDlaCiebie.samochod);
            clickElement(MyAvivaOfertaDlaCiebie.przyciskKupTeraz);
        } else {
            clickElement(MyAvivaCommonPageObjects.przyciskTwojeKonto);
            pauseFor(2);
            clickElement(MyAvivaStronaGlowna.linkMojeWnioski);
           clickElement(MyAvivaListaTwoichWnioskow.linkSprawdzCeneSamochodu);
        }
    }

    private void krok2() {
        selectDropdownListOption(MotoSamochod.listaRokProdukcji, "2016");
        selectDropdownListOption(MotoSamochod.listaMarka, "SUZUKI");
        waitUntilElementVisible(MotoSamochod.listaModel, 5);
        if (waitUntilElementVisible(MotoSamochod.listaModel, 5) == null) {
            pauseFor(5);
        }
        selectDropdownListOption(MotoSamochod.listaModel, "Vitara");
        waitUntilElementVisible(MotoSamochod.listaRodzajPaliwa, 2);
        selectDropdownListOption(MotoSamochod.listaCzyInstalacjaGazowa, "Nie");
        waitUntilElementVisible(MotoSamochod.listaPojemnoscSilnika, 2);
        selectDropdownListOption(MotoSamochod.listaPojemnoscSilnika, "1.6 (1586 cm3)");
        waitUntilElementVisible(MotoSamochod.listaTypNadwozia, 2);
        selectDropdownListOption(MotoSamochod.listaTypNadwozia, "Hatchback");
        waitUntilElementVisible(MotoSamochod.listaWersjaModelu, 2);
        selectDropdownListOption(MotoSamochod.listaWersjaModelu, "1.6 Premium 4WD");
        waitUntilElementVisible(MotoSamochod.przyciskWyboruWersjaWyposazenia, 2);
        selectRadioOption(MotoSamochod.przyciskWyboruCzyZabezpieczeniaFabryczne);
        selectRadioOption(MotoSamochod.przyciskWyboruRodzajZabezpieczen);
        selectDropdownListOption(MotoSamochod.listaPlanowanyPrzebieg, "17501 - 22500");
        selectDropdownListOption(MotoSamochod.listaMiejsceParkowania, "Prywatny garaż (zamykany)");
        enterIntoTextField(MotoSamochod.poleTekstoweKodMiejscaParkowania, "05-830");
        MotoSamochod.poleTekstoweKodMiejscaParkowania.sendKeys(Keys.TAB);
        pauseFor(5);
        if (waitUntilElementPresent(MotoSamochod.komunikat, 2) != null) {
            clickElement(MotoSamochod.przyciskOK);
            reporter().logWarn("Pojawił się komunikat o treści '1'.");
        }
        waitUntilElementVisible(MotoSamochod.przyciskWyboruSprowadzonyZZagraniy, 15);
        selectRadioOptionByValue("sprowadzony_z_zagranicy", "0");
        pauseFor(1);
        selectRadioOptionByValue("sprowadzony_z_zagranicy", "0");
        selectRadioOptionByValue("uzywany_za_granica_wiecej_niz_30_dni", "0");
        selectRadioOptionByValue("zarejestrowany_na_firma", "false");
        selectDropdownListOption(MotoSamochod.listaRokNabyciaPojazdu, "2016");
        clickElement(MotoCommon.przyciskDalej);
        waitUntilElementStale(MotoSamochod.listaRokNabyciaPojazdu, 1);
    }

    private void krok3() {
        selectRadioOption(MotoKierowca.przyciskWyboruCzyJestesKierowca);
        selectRadioOption(MotoKierowca.przyciskWyboruCzyJestesWlascicielem);
        if (appEnv.equals("CP")) {
            selectRadioOption(MotoKierowca.przyciskWyboruOsoba0Plec);
            selectDropdownListOption(MotoKierowca.listaStanCywilny, "panna/kawaler");
            selectDropdownListOption(MotoKierowca.listaOsoba0DataUrodzeniaRok,
                    Integer.toString(RandomIntGenerator.liczbaLosowa(1965, 20)));
            selectDropdownListOption(MotoKierowca.listaOsoba0DataUrodzeniaMiesiac, "Maj");
            selectDropdownListOption(MotoKierowca.listaOsoba0DataUrodzeniaDzien, "20");
        }
        selectDropdownListOption(MotoKierowca.listaRokWydania,
                Integer.toString(RandomIntGenerator.liczbaLosowa(1995, 20)));
        selectDropdownListOption(MotoKierowca.listaLiczbaDzieci, "0");
        selectDropdownListOption(MotoKierowca.listaOsoba0LiczbaLatBezszkodowychOC, "0");
        selectDropdownListOption(MotoKierowca.listaOsoba0LiczbaLatBezszkodowychAC, "0");
        selectDropdownListOption(MotoKierowca.listaOsoba0LiczbaSzkod3LataOC, "0");
        selectDropdownListOption(MotoKierowca.listaOsoba0LiczbaSzkod3LataAC, "0");
        if (appEnv.equals("CP")) {
            enterIntoTextField(MotoKierowca.poleTekstoweNumerTelefonu, numerTelefonu);
            enterIntoTextField(MotoKierowca.poleTekstoweEmail, email);
        }
        clickCheckBox(MotoKierowca.poleOpcjiZgodaMarkentingowa1);
        clickCheckBox(MotoKierowca.poleOpcjiZgodaMarkentingowa2);
        selectDropdownListOption(MotoKierowca.listaUbezpieczonyOdRok, DataGenerator.dateInFuture(20)[0]);
        selectDropdownListOption(MotoKierowca.listaUbezpieczonyOdMiesiac, DataGenerator.dateInFuture(20)[1]);
        selectDropdownListOption(MotoKierowca.listaUbezpieczonyOdDzien, DataGenerator.dateInFuture(20)[2]);
        clickElement(MotoCommon.przyciskDalej);
        waitUntilElementStale(MotoKierowca.listaUbezpieczonyOdRok, 1);
    }

    private void krok4() {
        //Zrobić obsługę suwaka
//        WebElement slider = driver.findElement(By.xpath("//*[@id='caplider']/a"));
        clickElement(MotoTwojaOferta.reklama);
        waitUntilElementStale(MotoTwojaOferta.reklama, 5);
        clickElement(MotoTwojaOferta.przyciskZapisz);
        enterIntoTextField(MotoTwojaOferta.poleTekstoweImie,
                "Tomasz" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoTwojaOferta.poleTekstoweNazwisko,
                "Testowy" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        clickElement(MotoTwojaOferta.przyciskZapiszDane);
        clickElement(MotoTwojaOferta.przyciskOK);
        pauseFor(3);
        selectDropdownListOption(MotoTwojaOferta.listaFormaPlatnosci, "Karta płatnicza lub kredytowa");
        pauseFor(5);
        enterIntoTextField(MotoTwojaOferta.poleTekstoweImiePlatnik,
                "Tomasz" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoTwojaOferta.poleTekstoweNazwiskoPlatnik,
                "Testowy" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        clickElement(MotoTwojaOferta.przyciskKupTeraz);
    }

    private void krok5() {
        waitUntilElementVisible(MotoDaneDoPolisy.poleTekstoweVin, 10);
        enterIntoTextField(MotoDaneDoPolisy.poleTekstoweVin, VINGenerator.randomNumString(17));
        enterIntoTextField(MotoDaneDoPolisy.poleTekstoweNumerRejestracyjny, RegistrationPlateNumberGenerator.tablica());
        selectDropdownListOption(MotoDaneDoPolisy.poleTekstoweBadaniaTechniczneRok,
                DataGenerator.dateInFuture(200)[0]);
        selectDropdownListOption(MotoDaneDoPolisy.poleTekstoweBadaniaTechniczneMiesiac,
                DataGenerator.dateInFuture(200)[1]);
        selectDropdownListOption(MotoDaneDoPolisy.poleTekstoweBadaniaTechniczneDzien,
                DataGenerator.dateInFuture(200)[2]);
        selectDropdownListOption(MotoDaneDoPolisy.listaUbezpieczajacy, "Kierowca");
        clickCheckBox(MotoDaneDoPolisy.poleOpcjiZaznaczWszystkie);
        clickElement(MotoCommon.przyciskDalej);
    }

    private void krok6() {
        waitUntilElementVisible(MotoPodsumowanie.przyciskZaplac, 20);
        clickElement(MotoPodsumowanie.przyciskZaplac);
    }

    private void krok7() {
        numerPolisy = platnoscEcard(false, driver);
        clickElement(MotoPodsumowanie.przyciskZapiszKalkulacje);
        clickElement(MotoPodsumowanie.przyciskZapisz);
        clickElement(MotoPodsumowanie.przyciskOK);
        clickElement(MotoPodsumowanie.przyciskZamknij);
    }
}
