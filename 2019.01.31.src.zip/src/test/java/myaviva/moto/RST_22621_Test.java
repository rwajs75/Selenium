package myaviva.moto;

import formularz.moto.pageobjects.*;
import helpers.database.TestDataManager;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.generators.*;
import helpers.reporter.ReportManagerFactory;
import helpers.throwables.GeneralStepException;
import io.qameta.allure.junit4.DisplayName;
import myaviva.MyAvivaHelpers;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaListaTwoichWnioskow;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.MyAvivaStronaGlowna;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.generators.PESELGenerator.generatePESELForDate;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Moto")
public class RST_22621_Test {

    private WebDriver driver;
    private String email;
    private String numerTelefonu  = StaticStrings.NRTEL;
    private TestDataManager manager;
    private String appEnv;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty(
                "appEnv"); //TODO: dodać we wszystkich uruchomieniach parametr -DappEnv=UT i zamienić tutaj na CP
        if (appEnv == null) appEnv = "UT";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }
        manager = new TestDataManager(appEnv);

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MotoSamochod.class);
        PageFactory.initElements(driver, MotoKierowca.class);
        PageFactory.initElements(driver, MotoTwojaOferta.class);
        PageFactory.initElements(driver, MotoDaneDoPolisy.class);
        PageFactory.initElements(driver, MotoPodsumowanie.class);
        PageFactory.initElements(driver, MotoCommon.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, MyAvivaStronaGlowna.class);
        PageFactory.initElements(driver, MyAvivaListaTwoichWnioskow.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22621 Zakup polisy Moto z tworzeniem konta")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
            krok6();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " + email);
        reporter().logPass("Numer telefonu: " + numerTelefonu);
        reporter().logPass("###############################");
        if (driver != null) driver.quit();
    }

    private void krok1() {
        //TODO !!!!!!!!!!!!!!!!!!!!
        //email = MyAvivaHelpers.registerMailMyAviva(driver, manager, appEnv);
        manager.updateMailStatus(email);
        if (waitUntilElementPresent(MyAvivaOfertaDlaCiebie.samochod, 2) != null) {
            clickElement(MyAvivaOfertaDlaCiebie.samochod);
            clickElement(MyAvivaOfertaDlaCiebie.przyciskKupTeraz);
        } else {
            try {
                reporter().logPass("############################");
                reporter().logError("Brak linka do zakupu polisy Moto na ekranie głównym");
            }catch (GeneralStepException e) {
                reporter().logPass("############################");
            }clickElement(MyAvivaCommonPageObjects.przyciskTwojeKonto);
            clickElement(MyAvivaStronaGlowna.linkMojeWnioski);
            clickElement(MyAvivaListaTwoichWnioskow.linkSprawdzCeneSamochodu);
        }
    }

    private void krok2() {
        selectDropdownListOption(MotoSamochod.listaRokProdukcji, "2008");
        selectDropdownListOption(MotoSamochod.listaMarka, "FORD");
        waitUntilElementVisible(MotoSamochod.listaModel, 5);
        if (waitUntilElementVisible(MotoSamochod.listaModel, 5) == null) {
            pauseFor(5);
        }
        selectDropdownListOption(MotoSamochod.listaModel, "Focus");
        waitUntilElementVisible(MotoSamochod.listaRodzajPaliwa, 2);
        selectDropdownListOption(MotoSamochod.listaRodzajPaliwa, "Diesel");
        selectDropdownListOption(MotoSamochod.listaPojemnoscSilnika, "1.8 (1753 cm3)");
        waitUntilElementVisible(MotoSamochod.listaTypNadwozia, 2);
        selectDropdownListOption(MotoSamochod.listaTypNadwozia, "Hatchback");
        waitUntilElementVisible(MotoSamochod.listaWersjaModelu, 2);
        selectDropdownListOption(MotoSamochod.listaWersjaModelu, "1.8 TDCi Platinium X");
        selectRadioOption(MotoSamochod.przyciskWyboruWersjaWyposazenia); //pierwsza wartość
        selectRadioOption(MotoSamochod.przyciskWyboruCzyZabezpieczeniaFabryczne);
        selectRadioOption(MotoSamochod.przyciskWyboruRodzajZabezpieczen);
        selectDropdownListOption(MotoSamochod.listaPlanowanyPrzebieg, "17501 - 22500");
        selectDropdownListOption(MotoSamochod.listaMiejsceParkowania, "Podjazd");
        enterIntoTextField(MotoSamochod.poleTekstoweKodMiejscaParkowania, "05-800");
        MotoSamochod.poleTekstoweKodMiejscaParkowania.sendKeys(Keys.TAB);
        pauseFor(15);
        waitUntilElementVisible(MotoSamochod.przyciskWyboruSprowadzonyZZagraniy, 15);
        selectRadioOptionByValue("sprowadzony_z_zagranicy", "0");
        pauseFor(5);
        selectRadioOptionByValue("sprowadzony_z_zagranicy", "0");
        selectRadioOptionByValue("uzywany_za_granica_wiecej_niz_30_dni", "0");
        selectRadioOptionByValue("zarejestrowany_na_firma", "false");
        selectDropdownListOption(MotoSamochod.listaRokNabyciaPojazdu,
                Integer.toString(RandomIntGenerator.liczbaLosowa(2008, 10)));
        clickElement(MotoCommon.przyciskDalej);
        waitUntilElementStale(MotoSamochod.listaRokNabyciaPojazdu, 1);
    }

    private void krok3() {
        selectRadioOption(MotoKierowca.przyciskWyboruCzyJestesKierowca);
        selectRadioOption(MotoKierowca.przyciskWyboruCzyJestesWlascicielem);
        selectRadioOption(MotoKierowca.przyciskWyboruOsoba0Plec);
        selectDropdownListOption(MotoKierowca.listaStanCywilny, "panna/kawaler");
        selectDropdownListOption(MotoKierowca.listaOsoba0DataUrodzeniaRok,
                Integer.toString(RandomIntGenerator.liczbaLosowa(1970, 30)));
        selectDropdownListOption(MotoKierowca.listaOsoba0DataUrodzeniaMiesiac, "Maj");
        selectDropdownListOption(MotoKierowca.listaOsoba0DataUrodzeniaDzien,
                Integer.toString(RandomIntGenerator.liczbaLosowa(1, 31)));
        selectDropdownListOption(MotoKierowca.listaRokWydania,
                Integer.toString(RandomIntGenerator.liczbaLosowa(2005, 10)));
        selectDropdownListOption(MotoKierowca.listaLiczbaDzieci, "0");
        selectRadioOptionByValue("czy_kierowcy_pon_26_roku", "false");
        selectDropdownListOption(MotoKierowca.listaOsoba0LiczbaLatBezszkodowychOC, "0");
        selectDropdownListOption(MotoKierowca.listaOsoba0LiczbaLatBezszkodowychAC, "0");
        selectDropdownListOption(MotoKierowca.listaOsoba0LiczbaSzkod3LataOC, "0");
        selectDropdownListOption(MotoKierowca.listaOsoba0LiczbaSzkod3LataAC, "0");
        selectDropdownListOption(MotoKierowca.listaTelefonRodzaj, "Komórkowy");
        enterIntoTextField(MotoKierowca.poleTekstoweNumerTelefonu, numerTelefonu);
        enterIntoTextField(MotoKierowca.poleTekstoweEmail, email);
        clickCheckBox(MotoKierowca.poleOpcjiZgodaMarkentingowa1);
        clickCheckBox(MotoKierowca.poleOpcjiZgodaMarkentingowa2);
        selectDropdownListOption(MotoKierowca.listaUbezpieczonyOdRok, DataGenerator.dateInFuture(20)[0]);
        selectDropdownListOption(MotoKierowca.listaUbezpieczonyOdMiesiac, DataGenerator.dateInFuture(20)[1]);
        selectDropdownListOption(MotoKierowca.listaUbezpieczonyOdDzien, DataGenerator.dateInFuture(20)[2]);
        clickElement(MotoCommon.przyciskDalej);
        waitUntilElementStale(MotoKierowca.listaUbezpieczonyOdRok, 1);
    }

    private void krok4() {
        sprawdzenieCaptchaMoto();
        clickElement(MotoTwojaOferta.przyciskDalejCaptcha);
        waitUntilElementStale(MotoTwojaOferta.przyciskDalejCaptcha, 10);
        clickElement(MotoTwojaOferta.reklama);
        waitUntilElementStale(MotoTwojaOferta.reklama, 10);
        clickElement(MotoTwojaOferta.przyciskKontynuujBezZnizki);
        waitUntilElementStale(MotoTwojaOferta.przyciskKontynuujBezZnizki, 5);
        clickElement(MotoTwojaOferta.przyciskKupTeraz);
        waitUntilElementStale(MotoTwojaOferta.przyciskKupTeraz, 5);
    }

    private void krok5() {
        enterIntoTextField(MotoDaneDoPolisy.poleTekstoweVin, VINGenerator.randomNumString(17));
        enterIntoTextField(MotoDaneDoPolisy.poleTekstoweNumerRejestracyjny, RegistrationPlateNumberGenerator.tablica());
        selectDropdownListOption(MotoDaneDoPolisy.poleTekstoweBadaniaTechniczneRok,
                DataGenerator.dateInFuture(200)[0]);
        selectDropdownListOption(MotoDaneDoPolisy.poleTekstoweBadaniaTechniczneMiesiac,
                DataGenerator.dateInFuture(200)[1]);
        selectDropdownListOption(MotoDaneDoPolisy.poleTekstoweBadaniaTechniczneDzien,
                DataGenerator.dateInFuture(200)[2]);
        enterIntoTextField(MotoDaneDoPolisy.poleTekstowePeselGlownyKierowca,
                generatePESELForDate(1985, 5, 25, 'm'));
        enterIntoTextField(MotoDaneDoPolisy.poleTekstoweImieGlownyKierowca,
                "Tomasz" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoDaneDoPolisy.poleTekstoweNazwiskoGlownyKierowca,
                "Testowy" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        selectDropdownListOption(MotoDaneDoPolisy.listaMiejscowoscGlownyKierowca, "PRUSZKÓW");
        enterIntoTextField(MotoDaneDoPolisy.poleTekstoweUlicaGlownyKierowca,
                "Testowa" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoDaneDoPolisy.poleTekstoweNumerDomuGlownyKierowca,
                Integer.toString(RandomIntGenerator.liczbaLosowa(1, 199)));
        waitUntilElementVisible(MotoDaneDoPolisy.listaUbezpieczajacy, 5);
        selectDropdownListOption(MotoDaneDoPolisy.listaUbezpieczajacy, "Kierowca");
        waitUntilElementVisible(MotoDaneDoPolisy.poleOpcjiZaznaczWszystkie, 5);
        clickCheckBox(MotoDaneDoPolisy.poleOpcjiZaznaczWszystkie);
        waitUntilElementVisible(MotoCommon.przyciskDalej, 5);
        clickElement(MotoCommon.przyciskDalej);
        waitUntilElementStale(MotoDaneDoPolisy.poleOpcjiZaznaczWszystkie, 5);
    }

    private void krok6() {
        clickElement(MotoPodsumowanie.przyciskDalejOstatni);
        waitUntilElementStale(MotoPodsumowanie.podsumowanie, 5);
        waitUntilElementVisible(MotoPodsumowanie.powitanie, 5);
    }
}
