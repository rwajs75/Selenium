package myaviva.moto;

import formularz.FormularzCommon;
import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.MyAvivaStronaGlowna;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import tia7.pageobjects.Tia7Common;
import tia7.pageobjects.Tia7Polisa;
import tia7.pageobjects.Tia7StronaGlowna;
import tia7.pageobjects.Tia7WyszukajDodajKlienta;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.dictionary.StaticStrings.NRTEL;
import static helpers.dictionary.StaticStrings.TEST_SKIP;
import static helpers.login.Login.LoginWeb;
import static tia7.pageobjects.Tia7Common.selectTIA7Process;
import static tia7.pageobjects.Tia7Common.setSelectInputTia7;
import static tia7.pageobjects.Tia7CommonProcess.*;

@DisplayName("MyAviva Moto")
public class RST_22916_Odnowienie_Moto {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String appEnv;
    private String nazwaTestu = "RST-21916";
    private String aplikacja = "MyAviva";
    private String nrPolisy;
    private String nrPolisyCustom ;
    private String expiryCode;
    private String email;
    private String nazwaProcesu = "Polisa";

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);

        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22830").env(appEnv).creationDate(LocalDateTime.now().minusDays(1).format(DateTimeFormatter.ofPattern("YYYY-MM-dd"))).stage("Moto - polisa do odnowienia").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
        email = daneTestowe.getParam4();

        Tia7Common.initElement(driver);
//        MyAvivaCommonPageObjects.

    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("Polisa: " + nrPolisyCustom);
//        if(expiryCode.equals("9 Policy is Renewal Active")) {
//            reporter().logError("Polisa się nie odnowiła");
//        }else {
//            reporter().logPass("Polisa odnowiła się poprawnie");
//        }
        reporter().logPass("Polisa opłacona przez MyAviva" + nrPolisyCustom);
        reporter().logPass("###############################");

        if (driver != null) driver.quit();
        if (daneTestowe != null) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Moto - odnowiona polisa", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(),daneTestowe.getParam4(),daneTestowe.getParam5(),nrPolisyCustom);
    }

    /**
     * Zakładanie polisy Moto w TIA7 z datą wsteczną do testowania Odnowień
     */
    @Test
    @DisplayName("RST-21916 Odnowienie Moto - odnowienie w MYA, opłacenie przez MYA i weryfikacja płatności w TIA7")
    @Issue("RST-21916")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
//            krok1();
//            krok2();
//            krok3();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, email, driver);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);



        clickElement(Tia7StronaGlowna.przyciskWyszukajDodajKlienta);
        setSelectInputTia7("Numer polisy", daneTestowe.getParam6(), "input"); //nr. polisy długi
        clickElement(Tia7WyszukajDodajKlienta.przyciskSzukaj);
        clickElement(By.xpath("//*[contains(text(), '"+daneTestowe.getParam5()+"')]")); //id Klienta
        nrPolisy = daneTestowe.getParam6().substring(5);
        clickElement(By.xpath("//a[contains(text(), '" + nrPolisy + "')]"));
        clickElement(Tia7Polisa.podgladLiniiPolisowej);
        clickElement(Tia7Polisa.przyciskDostosujLiniePolisowa);
        switchToNewPopUp();
        selectDropdownListOption(Tia7Polisa.listaPowodTransakcji, "250 Edycja odnowienia");
        clickButton(Tia7Polisa.przyciskOkDLP);
        clickButton(Tia7Polisa.przyciskZapiszPoOdnowieniu);
        clickButton(Tia7Polisa.przyciskZatwierdzPoOdnowieniu);
        switchToNewPopUp();
        selectTIA7Process("Zaakceptuj transakcje MTA");
        clickButton(Tia7Polisa.przyciskWystawPoliseTAK);

    }

    //TODO Ustaliś czy od tego miejsca wynosimy do osobnego testu?
    //Sprawdzenie w MYA czy jest polisa i jej opłacenie (RST-22504)
    private void krok2() {
        nrPolisyCustom = savePolice(nazwaProcesu,nrPolisy);
        if (waitUntilElementPresent(By.xpath("//input[contains(@id, 'PolicyRenewalDate')]"), 5) == null) {
            clickElement(By.xpath("//a[contains(text(), '" + nrPolisy + "')]"));
            expiryCode = driver.findElement(By.xpath("//select[contains(@id, 'pt:PolicyExpiryCode')]")).getAttribute("value");
            reporter().logPass("Sprawdzenie w MYA czy jest polisa i jej opłacenie");
            verifyMyAviva(nazwaProcesu, nrPolisyCustom, daneTestowe.getParam4(), NRTEL, appEnv, driver, false, false);
            status = true;
        }
    }

    //spr w TIA7 czy jest opłacona (RST-22842)
    private void krok3() {
        reporter().logPass("Sprawdzenie w TIA7 czy polisa została opłacona");
        verifyTia7Balance(aplikacja, appEnv, nrPolisyCustom, daneTestowe.getParam5());
        status = true;
    }
    //TODO - dotąd

}

