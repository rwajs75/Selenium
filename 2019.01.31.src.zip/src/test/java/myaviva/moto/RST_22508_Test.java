package myaviva.moto;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.generators.RandomIntGenerator;
import helpers.generators.RandomStringGenerator;
import helpers.generators.RegistrationPlateNumberGenerator;
import helpers.generators.VINGenerator;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.moto.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.generators.PESELGenerator.*;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Moto")
public class RST_22508_Test {

    private WebDriver driver;
    private String appEnv;
    private String email;
    private String numerTelefonu = StaticStrings.NRTEL;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty(
                "appEnv"); //TODO: dodać we wszystkich uruchomieniach parametr -DappEnv=UT i zamienić tutaj na CP
        if (appEnv == null) {
            appEnv = "CP";
        }

        switch (appEnv) {
            case "UT": {
                email = "CZTMYA5831@YOPMAIL.COM";
                break;
            }
            case "CP": {
                email = "CZTMYA0093@YOPMAIL.COM";
                break;
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MotoDaneSamochodu.class);
        PageFactory.initElements(driver, MotoWyborSzkody.class);
        PageFactory.initElements(driver, MotoDziekujemy.class);
        PageFactory.initElements(driver, MotoOCZgloszenieSzkody1.class);
        PageFactory.initElements(driver, MotoZgloszenieSzkody2.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22508 Zgłoszenie Szkody OC")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
            krok6();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " + email);
        reporter().logPass("Numer telefonu: " + numerTelefonu);
        reporter().logPass("###############################");
        if (driver != null) {
            driver.quit();
        }
    }

    private void krok1() {
        LoginWeb("MyAviva", appEnv, email, driver);
        clickElement(MyAvivaOfertaDlaCiebie.linkSamochod);
    }

    private void krok2() {
        clickElement(MotoDaneSamochodu.przyciskZglosZdarzenie);
    }

    private void krok3() {
        sprawdzenieWyboruRodzajuZgloszeniaMoto();
        clickElement(MotoWyborSzkody.linkOc);
    }

    private void krok4() {
        selectDropdownListOption(MotoOCZgloszenieSzkody1.listaRodzajZdarzenia, "Zderzenie pojazdów");
        selectDropdownListOption(MotoOCZgloszenieSzkody1.listaPrzyczynaZdarzenia,
                "Wymuszenie pierwszeństwa przejazdu");
        enterIntoTextField(MotoOCZgloszenieSzkody1.poleTekstoweNumerPolisySprawcy, "112233445566778");
        enterIntoTextField(MotoOCZgloszenieSzkody1.poleTekstoweNumerRejestracyjnySprawcy,
                RegistrationPlateNumberGenerator.tablica());
        enterIntoTextArea(MotoOCZgloszenieSzkody1.poleEdycyjneDaneSprawcyWypadku,
                "To są dane sprawcy zdarzenia: " + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoOCZgloszenieSzkody1.poleTekstoweDataZdarzenia,
                LocalDate.now().minusDays(2).format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        MotoOCZgloszenieSzkody1.poleTekstoweDataZdarzenia.sendKeys(Keys.TAB);
        enterIntoTextField(MotoOCZgloszenieSzkody1.poleTekstoweGodzina,
                Integer.toString(RandomIntGenerator.liczbaLosowa(10, 13)));
        enterIntoTextField(MotoOCZgloszenieSzkody1.poleTekstoweMinuty,
                Integer.toString(RandomIntGenerator.liczbaLosowa(10, 49)));
        enterIntoTextField(MotoOCZgloszenieSzkody1.poleTekstoweMiejsceZdarzenia,
                "Tu było zdarzenie:" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextArea(MotoOCZgloszenieSzkody1.poleEdycyjneOpisZdarzenia,
                "Szczegółowy opis zdarzenia: " + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextArea(MotoOCZgloszenieSzkody1.poleEdycyjneRodzajUszkodzen,
                "Szczegółowy rodzaj uszkodzeń: " + RandomStringGenerator.generateCharsSequence().toUpperCase());
        clickElement(MotoOCZgloszenieSzkody1.przyciskWyboruCzyPojazdHolowany);
        clickElement(MotoOCZgloszenieSzkody1.przyciskWyboruCzyPowiadomionoPolicje);
        clickButton(MotoOCZgloszenieSzkody1.przyciskDalej);
    }

    private void krok5() {
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweNumerRejestracyjnyPoszkodowanego,
                RegistrationPlateNumberGenerator.tablica());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTestoweNumerVinPoszkodowanego, VINGenerator.randomNumString(17));
        selectDropdownListOption(MotoZgloszenieSzkody2.listaRokProdukcjiPoszkodowanego, "2015");
        selectDropdownListOption(MotoZgloszenieSzkody2.listaMarkaPoszkodowanego, "BMW");
        selectDropdownListOption(MotoZgloszenieSzkody2.listaModelPoszkodowanego, "X3");
        enterIntoTextArea(MotoZgloszenieSzkody2.poleEdycyjneMiejsceOgledzin,
                "To jest preferowane miejsce oględzin: "
                        + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweImieZglaszajacego,
                "Damian" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweNazwiskoZglaszajacego,
                "Tester" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstowePeselZglaszajacego,
                generatePESELForDate(1999, 5, 10, 'k'));
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweKodPocztowyZglaszajacego1, "01");
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweKodPocztowyZglaszajacego2, "234");
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweMiejscowoscZglaszajacego, "Młochów");
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweNumerDomuZglaszajacego,
                Integer.toString(RandomIntGenerator.liczbaLosowa(1, 149)));
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweUlicaZglaszajacego,
                "Znana" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweNumerTelefonuZglaszajacego, numerTelefonu);
        enterIntoTextField(MotoZgloszenieSzkody2.poleTekstoweEmailZglaszajacego, email);
        clickElement(MotoZgloszenieSzkody2.przyciskWyboruCzyZglaszajacyJestWlascicielem);
        clickElement(MotoZgloszenieSzkody2.przyciskWyboruCzyZglaszajacyKierowal);
        MotoZgloszenieSzkody2.poleTekstoweNumerKonta.sendKeys("54249000059579912479503428");
        MotoZgloszenieSzkody2.poleTekstoweNumerKonta.sendKeys(Keys.TAB);
        clickElement(MotoZgloszenieSzkody2.przyciskWyboruWlascicielaKonta);
        clickElement(MotoZgloszenieSzkody2.przyciskWyboruSposobuRozliczeniaSzkody);
        clickElement(MotoZgloszenieSzkody2.poleOpcjiAkceptuje);
        clickElement(MotoZgloszenieSzkody2.poleOpcjiWyrazamZgode);
        clickButton(MotoZgloszenieSzkody2.przyciskDalej);
    }

    private void krok6() {
        clickElement(MotoDziekujemy.przyciskPrzejdzDoStronyGlownej);
    }
}
