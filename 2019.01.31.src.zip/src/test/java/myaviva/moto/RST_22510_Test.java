package myaviva.moto;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.moto.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Moto")
public class RST_22510_Test {

    private WebDriver driver;
    private String appEnv;
    private String email;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty(
                "appEnv"); //TODO: dodać we wszystkich uruchomieniach parametr -DappEnv=UT i zamienić tutaj na CP
        if (appEnv == null) appEnv = "CP";

        switch (appEnv) {
            case "UT": {
                email = "CZTMYA5831@YOPMAIL.COM";
                break;
            }
            case "CP": {
                email = "CZTMYA0093@YOPMAIL.COM";
                break;
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MotoDaneSamochodu.class);
        PageFactory.initElements(driver, MotoWyborSzkody.class);
        PageFactory.initElements(driver, MotoUszkodzenieSzyb.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22510 Zgłoszenie szkody uszkodzenia szyb")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " + email);
        reporter().logPass("###############################");
        if (driver != null) driver.quit();
    }

    private void krok1() {
        LoginWeb("MyAviva", appEnv, email, driver);
        clickElement(MyAvivaOfertaDlaCiebie.linkSamochod);
    }

    private void krok2() {
        clickElement(MotoDaneSamochodu.przyciskZglosZdarzenie);
    }

    private void krok3() {
        sprawdzenieWyboruRodzajuZgloszeniaMoto();
        clickElement(MotoWyborSzkody.linkUszkodzenieSzyb);
    }

    private void krok4() {
        clickElement(MotoUszkodzenieSzyb.przyciskWstecz);
    }

    private void krok5() {
        clickElement(MotoWyborSzkody.przyciskWstecz);
    }
}
