package myaviva.mojprofil;

import helpers.common.Common;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.login.Login;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaStronaLogowania;
import myaviva.pageobjects.mojProfil.MojProfil;
import myaviva.pageobjects.mojProfil.ZmienHaslo;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import templates.PageObjectTemplate;

import static helpers.common.Common.*;

@DisplayName("MyAviva")
public class RST_16929_Test {
    private static final String PASS = "Aviva123";
    private static final String ALT_MAIL = "mya11744@yopmail.com";
    protected WebDriver driver;
    private String appEnv;
    private String email;
    private boolean isAlternativeMailActiveBeforeTestStarts = false;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv"); //środowisko (CP/UT)
        if (appEnv == null) {
            appEnv = "CP";
        }

        switch (appEnv) {
            case "UT": {
                email = "mya4744@yopmail.com";
                break;
            }
            case "CP": {
                email = "mya11715@yopmail.com";
                break;
            }
            default: {
                email = "";
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }
        PageFactory.initElements(driver, PageObjectTemplate.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, MojProfil.class);
        PageFactory.initElements(driver, ZmienHaslo.class);
    }

    @Test
    @DisplayName("RST-16929 Zmiana maila na MójProfil")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
            krok6();
            krok7();
            krok8();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " );
        reporter().logPass("###############################");
        if (driver != null)  {
            driver.quit();
        }
    }

    private void krok1() {
        Login.loginToAccountMyAviva(appEnv, email, PASS, driver);
        if(isElementPresent(MyAvivaStronaLogowania.nieprawidloweDaneLogowaniaMsg, 2)) {
            isAlternativeMailActiveBeforeTestStarts = true;
            Login.loginToAccountMyAviva(appEnv, ALT_MAIL, PASS, driver);
        }
    }

    private void krok2() {
        MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Mój Profil", appEnv, driver);
    }

    private void krok3() {
        clickElement(MojProfil.przyciskEdytujMail);
    }

    private void krok4() {
        if(!isAlternativeMailActiveBeforeTestStarts) {
            enterIntoTextField(MojProfil.poleTekstoweMail, ALT_MAIL);
        } else {
            enterIntoTextField(MojProfil.poleTekstoweMail, email);
        }
        clickButton(MojProfil.przyciskZapisz);
    }

    private void krok5() {
        verifyElementDisplayed(MojProfil.successMsg, "Wyświetlono komunikat o udanej zmianie maila",
                "Nie został wyświetlony komunikat o udanej zmianie maila");
    }

    private void krok6() {
        MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Wyloguj", appEnv, driver);
        driver.manage().deleteAllCookies();
    }

    private void krok7() {
        if(isAlternativeMailActiveBeforeTestStarts) {
            Login.loginToAccountMyAviva(appEnv, ALT_MAIL, PASS, driver);
        } else {
            Login.loginToAccountMyAviva(appEnv, email, PASS, driver);
        }
        verifyElementDisplayed(getElement(MyAvivaStronaLogowania.nieprawidloweDaneLogowaniaMsg),
                "Nie można się zalogować na stary mail", "Można się zalogować na stary mail");
    }

    private void krok8() {
        if(isAlternativeMailActiveBeforeTestStarts) {
            Login.loginToAccountMyAviva(appEnv, email, PASS, driver);
        } else {
            Login.loginToAccountMyAviva(appEnv, ALT_MAIL, PASS, driver);
        }
        if(driver.getCurrentUrl().contains("Profil")) {
            reporter().logPass("Można zalogować się na nowy mail");
        } else {
            reporter().logFail("Nie można się zalogować na nowy mail");
        }
    }
}
