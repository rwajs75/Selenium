package myaviva.mojprofil;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.login.Login;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaStronaLogowania;
import myaviva.pageobjects.mojProfil.MojProfil;
import myaviva.pageobjects.mojProfil.ZmienHaslo;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import templates.PageObjectTemplate;

import static helpers.common.Common.*;

@DisplayName("MyAviva")
public class RST_9489_Test {
    private static final String PASS = "Aviva123";
    protected WebDriver driver;
    private String appEnv;
    private String email;
    private boolean isEmailActiveContactFormBeforeTestStarts = false;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv"); //środowisko (CP/UT)
        if (appEnv == null) {
            appEnv = "CP";
        }

        switch (appEnv) {
            case "UT": {
                email = "mya4744@yopmail.com";
                break;
            }
            case "CP": {
                email = "mya11719@yopmail.com";
                break;
            }
            default: {
                email = "";
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }
        PageFactory.initElements(driver, PageObjectTemplate.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, MojProfil.class);
    }

    @Test
    @DisplayName("RST-9489 Zmiana preferencji kontaktu na MójProfil")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " );
        reporter().logPass("###############################");
        if (driver != null)  {
            driver.quit();
        }
    }

    private void krok1() {
        Login.loginToAccountMyAviva(appEnv, email, PASS, driver);
    }

    private void krok2() {
        MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Mój Profil", appEnv, driver);
    }

    private void krok3() {
        if(isElementPresent(MojProfil.emailTick, 1)) {
            isEmailActiveContactFormBeforeTestStarts = true;
        }
        clickElement(MojProfil.przyciskEdytujPreferencjeKontaktu);
    }

    private void krok4() {
        clickElement(MojProfil.checkboxEmail);
        clickElement(MojProfil.przyciskZapisz);
    }

    private void krok5() {
        verifyElementDisplayed(MojProfil.successMsg, "Wyświetlony został komunikat o poprawnej zmianie danych",
                "Nie zostął wyświetlony komunikat o poprawnej zmianie danych");

        if(isEmailActiveContactFormBeforeTestStarts) {
            verifyElementDisplayed(MojProfil.emailCross, "Email jest preferowaną formą kontaktu",
                    "Email nie jest preferowaną formą kontaktu");
        } else {
            verifyElementDisplayed(getElement(MojProfil.emailTick), "Email nie jest preferowaną formą kontaktu",
                    "Email jest preferowaną formą kontaktu");
        }
    }
}
