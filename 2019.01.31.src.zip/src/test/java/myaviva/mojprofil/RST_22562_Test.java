package myaviva.mojprofil;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.login.Login;
import helpers.reporter.ReportManagerFactory;
import helpers.reporter.screenshot.SeleniumScreenshotManager;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaStronaLogowania;
import myaviva.pageobjects.mojProfil.MojProfil;
import myaviva.pageobjects.mojProfil.ZmienHaslo;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import templates.PageObjectTemplate;

import java.io.IOException;

import static helpers.common.Common.*;

@DisplayName("MyAviva")
public class RST_22562_Test {
    private static final String PASS = "Aviva123";
    private static final String ALT_PASS = "Aviva1234";
    protected WebDriver driver;
    private String appEnv;
    private String email;
    private boolean isAlternativePassActiveBeforeTestStarts = false;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv"); //środowisko (CP/UT)
        if (appEnv == null) {
            appEnv = "CP";
        }

        switch (appEnv) {
            case "UT": {
                email = "mya4751@yopmail.com";
                break;
            }
            case "CP": {
                email = "mya11702@yopmail.com";
                break;
            }
            default: {
                email = "";
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }
        PageFactory.initElements(driver, PageObjectTemplate.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, MojProfil.class);
        PageFactory.initElements(driver, ZmienHaslo.class);
    }

    @Test
    @DisplayName("RST-22562 Zmiana hasła na MójProfil")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
            krok6();
            krok7();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " );
        reporter().logPass("###############################");
        if (driver != null)  {
            driver.quit();
        }
    }

    private void krok1() {
        Login.loginToAccountMyAviva(appEnv, email, PASS, driver);
        if(isElementPresent(MyAvivaStronaLogowania.nieprawidloweDaneLogowaniaMsg, 2)) {
            isAlternativePassActiveBeforeTestStarts = true;
            Login.loginToAccountMyAviva(appEnv, email, ALT_PASS, driver);
        }
    }

    private void krok2() {
        MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Mój Profil", appEnv, driver);
    }

    private void krok3() {
        clickElement(MojProfil.przyciskZmienHaslo);
    }

    private void krok4() {
        if(!isAlternativePassActiveBeforeTestStarts) {
            enterIntoTextField(ZmienHaslo.poleTekstoweObecneHaslo, PASS);
            enterIntoTextField(ZmienHaslo.poleTekstoweNoweHaslo, ALT_PASS);
        } else {
            enterIntoTextField(ZmienHaslo.poleTekstoweObecneHaslo, ALT_PASS);
            enterIntoTextField(ZmienHaslo.poleTekstoweNoweHaslo, PASS);
        }
        clickButton(ZmienHaslo.przyciskZmien);
        verifyElementDisplayed(MojProfil.successMsg, "Wyświetlony został komunikat o udanej zmianie hasła",
                "Nie został wyświetlony komunikat o udanej zmianie hasła");
    }

    private void krok5() {
        MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Wyloguj", appEnv, driver);
    }

    private void krok6() {
        if(isAlternativePassActiveBeforeTestStarts) {
            Login.loginToAccountMyAviva(appEnv, email, ALT_PASS, driver);
        } else {
            Login.loginToAccountMyAviva(appEnv, email, PASS, driver);
        }
        verifyElementDisplayed(getElement(MyAvivaStronaLogowania.nieprawidloweDaneLogowaniaMsg),
                "Nie można się zalogować na stare hasło", "Można się zalogować na stare hasło");
    }

    private void krok7() {
        if(isAlternativePassActiveBeforeTestStarts) {
            Login.loginToAccountMyAviva(appEnv, email, PASS, driver);
        } else {
            Login.loginToAccountMyAviva(appEnv, email, ALT_PASS, driver);
        }
        if(driver.getCurrentUrl().contains("Profil")) {
            reporter().logPass("Można zalogować się na nowe hasło");
        } else {
            reporter().logFail("Nie można się zalogować na nowe hasło");
        }
    }
}
