package myaviva.stronaLogowania;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.login.Login;
import helpers.reporter.ReportManagerFactory;
import helpers.urls.MyAvivaURL;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaStronaLogowania;
import myaviva.pageobjects.inne.PrzypomnienieLoginuDane;
import myaviva.pageobjects.inne.PrzypomnienieLoginuKrok1;
import myaviva.pageobjects.inne.PrzypomnienieLoginuKrok2;
import myaviva.pageobjects.mojProfil.MojProfil;
import myaviva.pageobjects.mojProfil.ZmienHaslo;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import templates.PageObjectTemplate;

import static helpers.common.Common.*;

@DisplayName("MyAviva")
public class RST_16793_Test {
    private static final String NOT_EXISTING_EMAIL = "mya11729@yop.com";
    protected WebDriver driver;
    private String appEnv;
    private String email;
    private String firstName;
    private String lastName;
    private String pesel;
    private String policyNumber;
    private boolean isMarketingConsentInAvivaGroupActiveBeforeTestStarts = false;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv"); //środowisko (CP/UT)
        if (appEnv == null) {
            appEnv = "CP";
        }

        switch (appEnv) {
            case "UT": {
                email = "MNP3848@NFGDPZC.SFD";//mya3848@yopmail.com
                firstName = "ANNA";
                lastName = "BLĄPHKNĄ";
                pesel = "67041796428";
                policyNumber = "4460653";
                break;
            }
            case "CP": {
                email = "mya11729@yopmail.com";
                firstName = "ŁQŻDYŹGJŻFP";
                lastName = "ZÓPGDPGEYDBBGB";
                pesel = "59041522288";
                policyNumber = "212010820499417";
                break;
            }
            default: {
                email = "";
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }
        PageFactory.initElements(driver, PageObjectTemplate.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, MyAvivaStronaLogowania.class);
        PageFactory.initElements(driver, PrzypomnienieLoginuKrok1.class);
        PageFactory.initElements(driver, PrzypomnienieLoginuKrok2.class);
        PageFactory.initElements(driver, PrzypomnienieLoginuDane.class);
    }

    @Test
    @DisplayName("RST-16793 Przypomnienie loginu na stronie logowania")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
            krok6();
            krok7();
            krok8();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " );
        reporter().logPass("###############################");
        if (driver != null)  {
            driver.quit();
        }
    }

    private void krok1() {
        openUrl(true, MyAvivaURL.loginPageUrl(appEnv));
        clickElement(MyAvivaStronaLogowania.linkNiePamietamLoginu);
    }

    private void krok2() {
        clickElement(PrzypomnienieLoginuKrok1.przyciskSprawdz);
        verifyElementDisplayed(PrzypomnienieLoginuKrok1.wpiszEmailMsg, "Wyświetlono komunikat o konieczności wpisania maila",
                "Nie wyświetlono komunikatu o konieczności wpisania maila");
    }

    private void krok3() {
        enterIntoTextField(PrzypomnienieLoginuKrok1.poleTekstoweMail, NOT_EXISTING_EMAIL);
        clickElement(PrzypomnienieLoginuKrok1.przyciskSprawdz);
        verifyElementDisplayed(PrzypomnienieLoginuKrok1.nieZnalezionoLoginuMsg, "Wyświetlono komunikat o nie znalezieniu maila",
                "Nie wyświetlono komunikatu o nie znalezieniu maila");
    }

    private void krok4() {
        PrzypomnienieLoginuKrok1.poleTekstoweMail.clear();
        enterIntoTextField(PrzypomnienieLoginuKrok1.poleTekstoweMail, email);
        clickElement(PrzypomnienieLoginuKrok1.przyciskSprawdz);
        verifyLoginRemindedPageExists();
    }

    private void krok5() {
        openUrl(true, MyAvivaURL.przypomnienieLoginu(appEnv));
        clickElement(PrzypomnienieLoginuKrok1.linkOdzyskajLoginPoDanychOs);
    }

    private void krok6() {
        enterIntoTextField(PrzypomnienieLoginuDane.poleTekstoweImie, firstName);
        enterIntoTextField(PrzypomnienieLoginuDane.poleTekstoweNazwisko, lastName);
        enterIntoTextField(PrzypomnienieLoginuDane.poleTekstoweDzienUrodzenia, pesel.substring(4, 6));
        enterIntoTextField(PrzypomnienieLoginuDane.poleTekstoweMiesiacUrodzenia, pesel.substring(2 ,4));
        enterIntoTextField(PrzypomnienieLoginuDane.poleTekstoweRokUrodzenia,  "19" + pesel.substring(0, 2));
        enterIntoTextField(PrzypomnienieLoginuDane.poleTekstoweNumerPolisy, policyNumber);
        clickButton(PrzypomnienieLoginuDane.przyciskWyslij);
        verifyLoginRemindedPageExists();
    }

    private void krok7() {
        openUrl(true, MyAvivaURL.przypomnienieLoginuDane(appEnv));
        clickElement(PrzypomnienieLoginuDane.przyciskPesel);
    }

    private void krok8() {
        enterIntoTextField(PrzypomnienieLoginuDane.poleTekstoweImie, firstName);
        enterIntoTextField(PrzypomnienieLoginuDane.poleTekstoweNazwisko, lastName);
        enterIntoTextField(PrzypomnienieLoginuDane.getPoleTekstowePesel, pesel);
        enterIntoTextField(PrzypomnienieLoginuDane.poleTekstoweNumerPolisy, policyNumber);
        clickButton(PrzypomnienieLoginuDane.przyciskWyslij);
        verifyLoginRemindedPageExists();
    }

    private void verifyLoginRemindedPageExists() {
        if(driver.getCurrentUrl().equals(MyAvivaURL.przypomnienieLoginuZnaleziono(appEnv))
                && isElementVisible(PrzypomnienieLoginuKrok2.nagłówekH3, 1)) {
            reporter().logPass("Znaleziono stronę informującą o znalezieniu loginu");
        } else {
            reporter().logFail("Nie znaleziono strony infomrmującej o znalezieniu loginu");
        }
    }
}
