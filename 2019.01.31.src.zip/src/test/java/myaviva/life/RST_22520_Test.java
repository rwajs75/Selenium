package myaviva.life;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.generators.RandomStringGenerator;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.life.LifeRodzajSzkody;
import myaviva.pageobjects.life.LifeSmierBliskich;
import myaviva.pageobjects.life.LifeStronaGlowna;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.generators.PESELGenerator.generatePESEL;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Life")
public class RST_22520_Test {

    private WebDriver driver;
    private String appEnv;
    private String email;
    private String numertelefonu = StaticStrings.NRTEL;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty(
                "appEnv"); //TODO: dodać we wszystkich uruchomieniach parametr -DappEnv=UT i zamienić tutaj na CP
        if (appEnv == null) {
            appEnv = "CP";
        }

        switch (appEnv) {
            case "UT": {
                email = "CZTMYA5812@YOPMAIL.COM";
                break;
            }
            case "CP": {
                email = "CZTMYA100@YOPMAIL.COM";
                break;
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, LifeStronaGlowna.class);
        PageFactory.initElements(driver, LifeRodzajSzkody.class);
        PageFactory.initElements(driver, LifeSmierBliskich.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22520 Zgłoszenie szkody śmierć bliskich")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            if (appEnv.equals("UT")) {
                krok5();
                krok6();
                krok7();
            }
            krok8();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " + email);
        reporter().logPass("Numer telefonu: " + numertelefonu);
        reporter().logPass("###############################");
        if (driver != null) {
            driver.quit();
        }
    }

    private void krok1() {
        LoginWeb("MyAviva", appEnv, email, driver);
        sprawdzenieMojeProduktyLife();
        clickElement(MyAvivaOfertaDlaCiebie.zycieIZdrowie);
        clickElement(LifeStronaGlowna.przyciskZglosZdarzenie);
    }

    private void krok2() {
        obslugaBleduSprawdzeniaElementu(LifeRodzajSzkody.linkChoroba,
                "Można wybrać zgłoszenie szkody - śmnierć bliskich.",
                "Nie można wybrać zgłoszenia szkody - śmierć bliskich.");
        clickElement(LifeRodzajSzkody.linkSmiercBliskich);
    }

    private void krok3() {
        selectDropdownListOption(LifeSmierBliskich.listaKtoZmarl, "Rodzic");
        enterIntoTextField(LifeSmierBliskich.poleTekstoweDataSmierci,
                LocalDate.now().minusDays(3).format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        clickElement(LifeSmierBliskich.poleTekstoweImie);
        enterIntoTextField(LifeSmierBliskich.poleTekstoweImie,
                "Janusz" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(LifeSmierBliskich.poleTekstoweNazwisko,
                "Zmarly" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(LifeSmierBliskich.poleTekstowePesel, generatePESEL('k'));
        enterIntoElement(LifeSmierBliskich.poleTekstoweTelefon, numertelefonu);
        clickButton(LifeSmierBliskich.przyciskPrzejdzDoPodsumowania);
    }

    private void krok4() {
        clickElement(LifeSmierBliskich.przyciskWyboruOswiadczenie);
        clickButton(LifeSmierBliskich.przyciskWyslijWniosek);
    }

    private void krok5() {
        obslugaBleduSprawdzeniaElementu(LifeSmierBliskich.przyciskPrzeslijDokumentyPozniej, "Przycisk Prześlij dokumenty później jest aktywny.", "Nieaktywny przycisk Prześlij dokumenty później.");
        clickElement(LifeSmierBliskich.przyciskPrzeslijDokumentyPozniej);
    }

    private void krok6() {
        clickElement(LifeSmierBliskich.przyciskPodajNumerRachunku);
    }

    private void krok7() {
        enterIntoTextField(LifeSmierBliskich.poleTekstoweNumerRachunku, "60957500041977583142214969");
        clickButton(LifeSmierBliskich.przyciskZatwierdz);
    }

    private void krok8() {
        obslugaBleduSprawdzeniaElementu(LifeSmierBliskich.przyciskPrzejdzDoProduktow, "Przycisk Przejdź do strony głównej jest aktywny.", "Nieaktywny przycisk Przejdź do strony głównej.");
        clickElement(LifeSmierBliskich.przyciskPrzejdzDoProduktow);
    }
}
