package myaviva.life;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.life.LifeStronaGlowna;
import myaviva.pageobjects.life.LifeSzczegoly;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Life")
public class RST_22524_Test {

    private WebDriver driver;
    private String appEnv;
    private String email;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty(
                "appEnv"); //TODO: dodać we wszystkich uruchomieniach parametr -DappEnv=UT i zamienić tutaj na CP
        if (appEnv == null) {
            appEnv = "CP";
        }

        switch (appEnv) {
            case "UT": {
                email = "CZTMYA5818@YOPMAIL.COM";
                break;
            }
            case "CP": {
                email = "CZTMYA100@YOPMAIL.COM";
                break;
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, LifeStronaGlowna.class);
        PageFactory.initElements(driver, LifeSzczegoly.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22524 Szczegóły polisy Nowa Perspektywa")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
            krok6();
            krok7();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " + email);
        reporter().logPass("###############################");
        if (driver != null) {
            driver.quit();
        }
    }

    private void krok1() {
        LoginWeb("MyAviva", appEnv, email, driver);
        sprawdzenieMojeProduktyLife();
        clickElement(MyAvivaOfertaDlaCiebie.zycieIZdrowie);
        clickElement(LifeStronaGlowna.przyciskSzczegoly);
    }

    private void krok2() {
        if (waitUntilElementVisible(LifeSzczegoly.linkZgromadzoneSrodki, 5) != null) {
            reporter().logPass("Pomyślnie wyświetlono szczegóły polisy");
        }
        else {
            reporter().logFail("Nie ma aktywnego linka Zgromadzone środki");
        }
        clickElement(LifeSzczegoly.linkZgromadzoneSrodki);
    }

    private void krok3() {
        clickElement(LifeSzczegoly.linkPlatnosci);
        clickElement(LifeSzczegoly.przyciskPokazKolejnePozycje);
    }

    private void krok4() {
        clickElement(LifeSzczegoly.linkHistoria);
        selectDropdownListOption(LifeSzczegoly.listaDataOperacji, "Ostatni rok");
        clickElement(LifeSzczegoly.przyciskPokaz);
    }

    private void krok5() {
        clickElement(LifeSzczegoly.linkDokumenty);
        if (waitUntilElementPresent(LifeSzczegoly.poleOpcjiZgody, 2) != null) {
            clickElement(LifeSzczegoly.poleOpcjiZgoda);
            clickButton(LifeSzczegoly.przyciskRozpocznijPobieranie);
        }
        if (waitUntilElementPresent(LifeSzczegoly.linkPobierz, 2) != null) {
            clickElement(LifeSzczegoly.linkPobierzDokumenty);
        }
    }

    private void krok6() {
        clickElement(LifeSzczegoly.linkUposazeni);
    }

    private void krok7() {
        clickElement(LifeSzczegoly.linkZlecenia);
        if (waitUntilElementPresent(LifeSzczegoly.poleOpcjiZgody, 2) != null) {
            clickElement(LifeSzczegoly.poleOpcjiZgoda);
            clickButton(LifeSzczegoly.przyciskDalej);
        }
    }
}
