package myaviva.life;

import formularz.FormularzCommon;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.life.LifeRodzajSzkody;
import myaviva.pageobjects.life.LifeSmiercUbezpieczonego;
import myaviva.pageobjects.life.LifeStronaGlowna;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Life")
public class RST_22521_Test {

    private WebDriver driver;
    private String appEnv;
    private String email;
    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty(
                "appEnv"); //TODO: dodać we wszystkich uruchomieniach parametr -DappEnv=UT i zamienić tutaj na CP
        if (appEnv == null) {
            appEnv = "CP";
        }

        switch (appEnv) {
            case "UT": {
                email = "CZTMYA5812@YOPMAIL.COM";
                break;
            }
            case "CP": {
                email = "CZTMYA100@YOPMAIL.COM";
                break;
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, FormularzCommon.class);
        PageFactory.initElements(driver, LifeStronaGlowna.class);
        PageFactory.initElements(driver, LifeRodzajSzkody.class);
        PageFactory.initElements(driver, LifeSmiercUbezpieczonego.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22521 Zgłoszenie szkody śmierć ubezpieczonego")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " + email);
        reporter().logPass("###############################");
        if (driver != null) {
            driver.quit();
        }
    }

    private void krok1() {
        LoginWeb("MyAviva", appEnv, email, driver);
        sprawdzenieMojeProduktyLife();
        clickElement(MyAvivaOfertaDlaCiebie.zycieIZdrowie);
        clickElement(LifeStronaGlowna.przyciskZglosZdarzenie);
    }

    private void krok2() {
        obslugaBleduSprawdzeniaElementu(LifeRodzajSzkody.linkChoroba,
                "Można wybrać zgłoszenie szkody - śmierć ubezpieczonego.",
                "Nie można wybrać zgłoszenia szkody - śmierć ubezpieczonego.");
        clickElement(LifeRodzajSzkody.linkSmiercUbezpieczonego);
    }

    private void krok3() {
        clickElement(LifeSmiercUbezpieczonego.linkSmierc);
        clickElement(LifeSmiercUbezpieczonego.linkSmiercDlaNajblizszych);
        clickButton(LifeSmiercUbezpieczonego.przyciskWstecz);
    }
}
