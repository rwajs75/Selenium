package myaviva.life;

import helpers.database.TestDataManager;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.generators.RandomStringGenerator;
import helpers.reporter.ReportManagerFactory;
import helpers.restapi.Rest;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.life.LifeStronaGlowna;
import myaviva.pageobjects.life.LifeSzczegoly;
import myaviva.pageobjects.life.LifeUposazeni;
import myaviva.pageobjects.mojProfil.MojProfil;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

/**
 * Szablon klasy testowej. W projekcie budowanym za pomocą Mavena
 * nazwy klas testowych powinny być zakończone słowem -Test.
 */

@DisplayName("MyAviva Life")
public class RST_22614_Test {

    private String email;
    private String numerTelefonu;
    private WebDriver driver;
    private String appEnv;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty(
                "appEnv"); //TODO: dodać we wszystkich uruchomieniach parametr -DappEnv=UT i zamienić tutaj na CP
        if (appEnv == null) {
            appEnv = "CP";
        }

        switch (appEnv) {
            case "UT": {
                email = "CZTMYA5875@YOPMAIL.COM";
                break;
            }
            case "CP": {
                email = "CZTMYA6160@YOPMAIL.COM";
                break;
            }
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        PageFactory.initElements(driver,
                MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, LifeStronaGlowna.class);
        PageFactory.initElements(driver, LifeUposazeni.class);
        PageFactory.initElements(driver, LifeSzczegoly.class);
        PageFactory.initElements(driver, MojProfil.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22614 Zlecenie wznowienie opłaty składki w polisie Nowa Perspektywa")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();           //oddzielne kroki zdefiniowane jako funkcje
            krok2();
            krok3();
            krok4();
            krok5();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("E-MAIL: " + email);
        reporter().logPass("Numer telefonu: " + numerTelefonu);
        reporter().logPass("###############################");
        if (driver != null) {
            driver.quit();
        }
    }

    private void krok1() {
        LoginWeb("MyAviva", appEnv, email, driver);
        numerTelefonu = odczytNumeruTelefonuZProfilu(appEnv);
        sprawdzenieMojeProduktyLife();
        clickElement(MyAvivaOfertaDlaCiebie.zycieIZdrowie);
        clickElement(LifeStronaGlowna.przyciskSzczegoly);
    }

    private void krok2() {
        sprawdzenieSzczegolowPolisy();
        clickElement(LifeSzczegoly.linkZlecenia);
    }

    private void krok3() {
        if (waitUntilElementPresent(LifeSzczegoly.poleOpcjiZgody, 2) != null) {
            clickElement(LifeSzczegoly.poleOpcjiZgoda);
            clickButton(LifeSzczegoly.przyciskDalej);
        }
        selectDropdownListOption(LifeSzczegoly.listaRodzajZlecenia,"Wznowienie opłaty składki");
        clickElement(LifeSzczegoly.linkOStanieZdrowia);
        pauseFor(3);
        /*backUrl();
        selectDropdownListOption(LifeSzczegoly.listaRodzajZlecenia,"Wznowienie opłaty składki");*/
        enterIntoTextArea(LifeSzczegoly.poleEdycyjneOpisZlecenia,
                "Opis zlecenia: " + RandomStringGenerator.generateCharsSequence().toUpperCase());
        LifeSzczegoly.poleTekstoweZalaczPlik.sendKeys(StaticStrings.PLIK_PNG);
        pauseFor(5);
        clickElement(LifeSzczegoly.przyciskWyslijZgloszenie);
    }

    private void krok4() {
        sprawdzeniePotwierdzZmiane();
        obslugaBleduSprawdzeniaElementu(LifeSzczegoly.tekstWyslanySMS,
                "SMS z kodem został wysłany.",
                "Operacja wysłania SMS-a z kodem nie powiodła się.");
        TestDataManager manager = new TestDataManager(appEnv);
        Map<String, String> map = manager.getUsersOanAndPartyId(email,appEnv);
        enterIntoTextField(LifeSzczegoly.poleTekstowePodajKodSMS, Rest.getTwoFAPin(map.get("partyId"), map.get("oan")
                , numerTelefonu, appEnv));
        clickElement(LifeSzczegoly.przyciskZapisz);
        sprawdzenieZatwierdzeniaSMS();
        clickElement(LifeSzczegoly.przyciskWrocDoPolisy);
    }

    private void krok5() {
        sprawdzenieSzczegolowPolisyLife();
        clickElement(LifeSzczegoly.linkHistoria);
        pauseFor(3);
        sprawdzenieHistoriiOperacji();
        historiaPolisyNaDzis();
        String dataOperacji = getElementProperty(LifeSzczegoly.tekstDataOperacji, "textContent"),
                odwieszeniePlatnosci = getElementProperty(LifeSzczegoly.tekstOdwieszeniePlatnosci, "textContent");
        if (!dataOperacji.equals(LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))))
            reporter().logFail("Błędna data operacji (oczekiwano: " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")) + "), (otrzymano: " + dataOperacji + ").");
        if (!odwieszeniePlatnosci.equals("Odwieszenie płatności"))
            reporter().logFail("Błędny tekst odwieszenia płatności (oczekiwano: Odwieszenie płatności)" +
                    ", (otrzymano: " + odwieszeniePlatnosci + ").");
    }
}
