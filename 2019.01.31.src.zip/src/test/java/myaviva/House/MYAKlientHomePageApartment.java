package myaviva.House;

public class MYAKlientHomePageApartment {
}
