package myaviva.House;

public class MYAKlientObliczSkladkeHouse {
}
