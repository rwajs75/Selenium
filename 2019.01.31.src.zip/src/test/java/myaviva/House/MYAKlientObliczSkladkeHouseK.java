package myaviva.House;

public class MYAKlientObliczSkladkeHouseK {
}
