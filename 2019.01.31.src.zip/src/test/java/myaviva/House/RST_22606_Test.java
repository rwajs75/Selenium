package myaviva.House;

import formularz.FormularzCommon;
import formularz.RST_22602_Test;
import formularz.house.pageobjects.*;
import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import helpers.throwables.GeneralStepException;
import io.qameta.allure.junit4.DisplayName;
import myaviva.MyAvivaHelpers;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.gosc.MyAvivaStronaGlownaGoscia;
import myaviva.pageobjects.house.MyAvivaHouse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.generators.PESELGenerator.generatePESEL;
import static helpers.login.Login.LoginWeb;

/**
 * @author Maria Khabur / Krzysztof Janiak
 */


@DisplayName("MyAviva House")

public class RST_22606_Test {

    private WebDriver driver;
    private String appEnv;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String aplikacja = "MyAviva";
    private String nazwaTestu = "RST-22606 MYA - Formularz zakupu ubezpieczenia 'Dom' przez funkcjonalność 'Moje wnioski' - Gość";
    private String PESEL = generatePESEL('m');
    private Boolean testUrlMojeWnioskiHouse;


    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName("MyAviva").testName("RST-22781").env(appEnv).stage("Utworzenie i aktywacja konta w MyAviva").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
        FormularzCommon.initElement(driver);

    }

    /**
     * Metoda testowa
     */

    @Test
    @DisplayName("RST-22606 MYA - Formularz zakupu ubezpieczenia 'Dom' przez funkcjonalność 'Moje wnioski' - Gość")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            StronaGlowna();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     */

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (daneTestowe != null) reportSummaryAndSendResults(nazwaTestu, "MyAviva", appEnv, DataRowStatus.AKTYWNY, "Zarejestrowanie polisy w MyAviva", status, daneTestowe.getParam1(), daneTestowe.getParam2(), daneTestowe.getParam3(), PESEL,"House");
    }

    private void StronaGlowna() {

        LoginWeb(aplikacja, appEnv, daneTestowe.getParam3(), driver);
        MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Moje Wnioski", appEnv, driver);



        clickElement(HouseStronaGlowna.przyciskWybierzDom);
        nazwaPakietu[0] = "formularz";
        //Wykorzystanie krokow z testu House_Test
        RST_22602_Test.krok1();
        RST_22602_Test.krok2();
        RST_22602_Test.krok3(daneTestowe.getParam3(), PESEL, daneTestowe.getParam1(), daneTestowe.getParam2());
        RST_22602_Test.krok4();
        RST_22602_Test.krok5(driver);
        status = true;

    }
}