package myaviva.House;

public class MYAKlientObliczSkladkeApartmentK {
}
