package myaviva.travel;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.travel.TravelDokumenty;
import myaviva.pageobjects.travel.TravelSzczegoly;
import myaviva.pageobjects.travel.TravelTwojaPodroz;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

@DisplayName("MyAviva Travel")
public class RST_22511_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String aplikacja = "MyAviva";
    private String nazwaTestu = "RST-22511 Dokumenty polisy Travel";
    private String appEnv;
    private String email;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22514").env(appEnv).stage(
                "Obsługa polisy w MyAviva").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
        email = daneTestowe.getParam4();

        PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class);
        PageFactory.initElements(driver, TravelSzczegoly.class);
        PageFactory.initElements(driver, TravelTwojaPodroz.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, TravelDokumenty.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22511 Dokumenty polisy Travel")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);
            krok1();
            krok2();
            krok3();
            krok4();
            status = true;
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (status) {
            reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Obsługa polisy w MyAviva", status, daneTestowe.getParam1(),
                    daneTestowe.getParam2(), daneTestowe.getParam3(), daneTestowe.getParam4(),
                    daneTestowe.getParam5(), daneTestowe.getParam6());
        } else if (daneTestowe != null){
            status = true;
            reportSummaryAndSendResults("RST-22514", aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Obsługa polisy w MyAviva", status, daneTestowe.getParam1(), daneTestowe.getParam2(),
                    daneTestowe.getParam3(), daneTestowe.getParam4(), daneTestowe.getParam5(),
                    daneTestowe.getParam6());
        }
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, email, driver);
        clickElement(MyAvivaOfertaDlaCiebie.podroze);
        clickElement(TravelTwojaPodroz.przyciskSzczegoly);
    }

    private void krok2() {
        sprawdzenieStronySzczegolyTravel();
        clickElement(TravelSzczegoly.dokumenty);
    }

    private void krok3() {
        sprawdzenieStronyDokumentyTravel();
        clickElement(TravelDokumenty.polisa);
        clickElement(TravelDokumenty.ogolneWarunkiUbezpieczenia);
    }

    private void krok4() {
        sprawdzenieStronyDokumentyTravel();
        clickElement(TravelSzczegoly.linkWrocDoProduktow);
    }
}
