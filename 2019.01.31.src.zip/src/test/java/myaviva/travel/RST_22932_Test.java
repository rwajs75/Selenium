package myaviva.travel;

import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.generators.RandomIntGenerator;
import helpers.generators.RandomStringGenerator;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaListaTwoichWnioskow;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.travel.TravelSzczegoly;
import myaviva.pageobjects.travel.TravelTwojaPodroz;
import myaviva.pageobjects.travel.kupPolise.TravelDaneDoUbezpieczenia;
import myaviva.pageobjects.travel.kupPolise.TravelOferta;
import myaviva.pageobjects.travel.kupPolise.TravelPodsumowanie;
import myaviva.pageobjects.travel.kupPolise.TravelSprawdzCeneUbezpieczenia;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static ecard.Platnosc.platnoscEcard;
import static helpers.common.Common.*;
import static helpers.generators.PESELGenerator.generatePESELForDate;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.*;

/**
 * @author Roman Wajs
 */

@DisplayName("MyAviva Travel")
public class RST_22932_Test {

    private WebDriver driver;
    private TestDataManager manager;
    CustomDataRequest select;
    CustomTestDTO daneTestowe;
    boolean status = false;
    private String aplikacja = "MyAviva";
    private String nazwaTestu = "RST-22932 Zakup polisy Travel przez klienta z inną polisą z Moje wnioski";
    private String appEnv;
    private String email;
    private String numerPolisy;
    private String dataOd = LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    private String dataDo = LocalDate.now().plusDays(50).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    private String pesel = generatePESELForDate(RandomIntGenerator.liczbaLosowa(1950, 30),
            RandomIntGenerator.liczbaLosowa(1, 12),  RandomIntGenerator.liczbaLosowa(1, 28), 'm');
    private String numerPolisySprawdzenie;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }

        manager = new TestDataManager(appEnv);
        select = CustomDataRequest.builder().appName(aplikacja).testName("RST-22505").env(appEnv).stage(
                "Zgłoszenie szkody w MyAviva").status(DataRowStatus.AKTYWNY).build();
        daneTestowe = manager.getCustomTestData(select);
        email = daneTestowe.getParam4();

        PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class);
        PageFactory.initElements(driver, TravelSprawdzCeneUbezpieczenia.class);
        PageFactory.initElements(driver, TravelOferta.class);
        PageFactory.initElements(driver, TravelDaneDoUbezpieczenia.class);
        PageFactory.initElements(driver, TravelPodsumowanie.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, TravelTwojaPodroz.class);
        PageFactory.initElements(driver, TravelSzczegoly.class);
        PageFactory.initElements(driver, MyAvivaListaTwoichWnioskow.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("RST-22932 Zakup polisy Travel przez klienta z inną polisą z Moje wnioski")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);
            krok1();
            krok2();
            krok3();
            krok4();
            krok5();
            krok6();
            status = true;
            krok7();
            krok8();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     * Zapisanie ważnych zmiennych użytych podczas testu
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
        if (status) {
            reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Zakup polisy w MyAviva", status, daneTestowe.getParam1(), daneTestowe.getParam2(),
                    pesel, daneTestowe.getParam3(), "Travel", numerPolisy, numerPolisySprawdzenie);
        } else if (daneTestowe != null) {
            status = true;
            reportSummaryAndSendResults("RST-22505", aplikacja, appEnv, DataRowStatus.AKTYWNY,
                    "Zgłoszenie szkody w MyAviva", status, daneTestowe.getParam1(),
                    daneTestowe.getParam2(), daneTestowe.getParam3(), daneTestowe.getParam4(),
                    daneTestowe.getParam5(), daneTestowe.getParam6(), daneTestowe.getParam7());
        }
    }

    private void krok1() {
        LoginWeb(aplikacja, appEnv, email, driver);
        MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Moje Wnioski", appEnv, driver);
        clickElement(MyAvivaListaTwoichWnioskow.linkSprawdzCeneTurystyczne);
        verifyDomainUrl(aplikacja, appEnv, true);
    }

    private void krok2() {
        sprawdzenieStronyZakupuUbezpieczeniaTravel();
        clickElement(TravelSprawdzCeneUbezpieczenia.przyciskEU);
        enterIntoTextField(TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyOd, dataOd);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyDo);
        enterIntoTextField(TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyDo,dataDo);
        TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyDo.sendKeys(Keys.RETURN);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiNarciarstwo);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiSportEkstremalne);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiCiezkaPracaFizyczna);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiLeczenieNaWypadek);
        clickElement(TravelSprawdzCeneUbezpieczenia.poleOpcjiLeczenieSkutkow);
        clickButton(TravelSprawdzCeneUbezpieczenia.przyciskSprawdzSzczegoly);
        clickButton(TravelSprawdzCeneUbezpieczenia.przyciskKontynuujBezKodu);
    }

    private void krok3() {
        sprawdzenieStronyOfertaTravel();
        clickElement(TravelOferta.przyciskWybierzPakietElastyczny);
    }

    private void krok4() {
        sprawdzenieStronyDaneDoUbezpieczeniaTravel();
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstowePesel, pesel);
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweNumerTelefonu, StaticStrings.NRTEL);
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweKodPocztowy1, "05");
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweKodPocztowy2, "830");
        TravelDaneDoUbezpieczenia.poleTekstoweMiejscowosc.sendKeys(Keys.RETURN);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweMiejscowosc, "Urzut");
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweUlica,
                "Testowa" + RandomStringGenerator.generateCharsSequence().toUpperCase());
        enterIntoTextField(TravelDaneDoUbezpieczenia.poleTekstoweNumerDomu,
                Integer.toString(RandomIntGenerator.liczbaLosowa(1, 299)));
        clickElement(TravelDaneDoUbezpieczenia.poleOpcjiSkopiujMojeDane);
        clickElement(TravelDaneDoUbezpieczenia.poleOpcjiOsobaJestPrzewlekleChora);
        clickElement(TravelDaneDoUbezpieczenia.poleOpcjiAkceptujeWszystkie);
        waitUntilElementVisible(TravelDaneDoUbezpieczenia.przyciskDalej, 5);
        clickButton(TravelDaneDoUbezpieczenia.przyciskDalej);
    }

    private void krok5() {
        sprawdzenieStronyPodsumowanieTravel();
        clickElement(TravelPodsumowanie.przyciskZaplacOnline);
    }

    private void krok6() {
        numerPolisy = platnoscEcard(true, driver);
        sprawdzenieStronyGratulujemyTravel();
    }

    private void krok7() {
        wylogowaniePrzezLink(driver);
        LoginWeb(aplikacja, appEnv, email, driver);
        clickElement(MyAvivaOfertaDlaCiebie.podroze);
        clickElement(TravelTwojaPodroz.przyciskSzczegoly);
    }

    private void krok8() {
        sprawdzenieStronySzczegolyTravel();
        numerPolisySprawdzenie = TravelSzczegoly.numerPolisy.getText();
        if (!numerPolisySprawdzenie.equals(numerPolisy))
            reporter().logFail("Błędny numer polisy lub jej brak (oczekiwano: " + numerPolisy +
                    "), (otrzymano: " + numerPolisySprawdzenie + ").");
    }
}
