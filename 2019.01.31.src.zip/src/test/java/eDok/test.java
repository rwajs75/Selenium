package eDok;

import helpers.database.TestDataManager;
import helpers.generators.RandomIntGenerator;
import helpers.restapi.Rest;
import org.junit.Test;
import helpers.generators.DataGenerator;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class test {

    @Test
    public void testMethod() {
        /*int liczbaDni = 20;
        String rok = LocalDate.now().plusDays(liczbaDni).format(DateTimeFormatter.ofPattern("yyyy"));
        String miesiac = LocalDate.now().plusDays(liczbaDni).getMonth().getDisplayName(TextStyle.FULL_STANDALONE, Locale.forLanguageTag("pl-PL"));
        String Miesiac = miesiac.substring(0, 1).toUpperCase() + miesiac.substring(1);
        String dzien = LocalDate.now().plusDays(liczbaDni).format(DateTimeFormatter.ofPattern("dd"));*/
//        String[] rrr = new String[3];
        /*String[] rrr = DataGenerator.dateInFuture(20);
        System.out.println(rrr[0] + "." + rrr[1] + "." + rrr[2]);
        System.out.println(DataGenerator.dateInFuture(20)[0]);
        System.out.println(Integer.toString(DataGenerator.dateFromPastInt(3)[0]));
        System.out.println(Integer.toString(DataGenerator.dateFromPastInt(3)[1]));
        System.out.println(Integer.toString(DataGenerator.dateFromPastInt(3)[2]));*/

        /*TestDataManager manager = new TestDataManager();
        Map<String, String> map = manager.getUsersOanAndPartyId("CZTMYA220@YOPMAIL.COM");
        String pin = Rest.getTwoFAPin(map.get("partyId"), map.get("oan"));
        *//*String pin = Rest.getTwoFAPin("935493450478017", "5984022267");*//*
         *//*System.out.println(map.get("partyId"));
        System.out.println(map.get("oan"));*//*
        System.out.println(pin);*/

        /*for (int i = 1; i < 30; i++) {
            System.out.println(RandomIntGenerator.liczbaLosowa(1, 12));
        }*/
//        System.out.println(DataGenerator.dateFromPastInt(10)[2]);

        String tytul = "sdfs: 214010820518578";
        String numer = null;
        System.out.println(tytul);
        System.out.println(tytul.length());
        Pattern pattern = Pattern.compile("[0-9]+$");
        Matcher m = pattern.matcher(tytul);
        if (m.find()) {
            numer = m.group();
        }

//        String numer = tytul.substring(tytul.length() - 15, tytul.length());
        System.out.println(numer);
    }

    private String findPattern(String text) {
        Pattern pattern = Pattern.compile("[0-9]+$");
        Matcher m = pattern.matcher(text);
        String result = null;

        if (m.find()) {
            result = m.group();
        }
        return result;
    }
}
