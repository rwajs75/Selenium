package eDok;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import static helpers.common.Common.*;
import static java.lang.Thread.sleep;

public class eDok {

    private WebDriver driver;
    private String appEnv;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void eDok() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            driver.manage().window().maximize();
            driver.get("http://cezar.cu.com.pl:8080/eDok/secure/eDok.jsp");
            sleep(30000);
            for (int j = 0; j < 250; j++) {
                System.out.println("Pętla nr: " + j);
                Scanner odczyt = new Scanner(new File("C:\\autoczt\\src\\test\\java\\eDok\\robot_wydajnosci.txt"));
                for (int i = 0; i < 75; i++) {
                    String barcode = odczyt.nextLine();
                    System.out.println(barcode);
                    driver.get("http://cezar.cu.com.pl:8080/eDok/secure/DocumentBrowser3R?barcode=" + barcode);
                    sleep(1000);
                }
            }
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        if (driver != null) driver.quit();
    }
}
