package smoketests.salescloud;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import salescloud.pageobjects.SalesCloudCommon;
import salescloud.pageobjects.SalesCloudDashboard;
import salescloud.pageobjects.SalesCloudMenuGlowne;
import salescloud.pageobjects.SalesCloudStronaLogowania;

import static helpers.common.Common.*;
import static helpers.common.Common.reporter;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudCommon.initElement;

/**
 * @author Maria Khabur
 */

@DisplayName("SalesCloud")
public class RST_22726_Test {

    private WebDriver driver;
    private String appEnv;
    private String aplikacja = "SalesCloud";
    private String login;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) {
            appEnv = "CP";
        }

        if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        } else if (System.getProperty("env").equals("remote")) {
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        }
        initElement(driver);

        PageFactory.initElements(driver, SalesCloudDashboard.class);
        PageFactory.initElements(driver, SalesCloudMenuGlowne.class);
        PageFactory.initElements(driver, SalesCloudStronaLogowania.class);
        PageFactory.initElements(driver, SalesCloudCommon.class);
    }

    @Test
    @DisplayName("RST_22726 SalesCloud Auto - SmokeTest - Prezentacja strony glównej oraz Tryb Biuro - Dyrektor")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            login = "11307";
            LoginWeb(aplikacja, appEnv, login, driver);
            StronaGlowna(login);
            SalesCloudCommon.clickMenuSalesCloud("Wyloguj", appEnv, driver);
            //----------------------------------------------------------------------------
            login = "54020";
            LoginWeb(aplikacja, appEnv, login, driver);
            StronaGlowna(login);
            SalesCloudCommon.clickMenuSalesCloud("Wyloguj", appEnv, driver);
            //----------------------------------------------------------------------------
            login = "49137";
            LoginWeb(aplikacja, appEnv, login, driver);
            StronaGlowna(login);
            SalesCloudCommon.clickMenuSalesCloud("Wyloguj", appEnv, driver);
            //----------------------------------------------------------------------------
            login = "44192";
            LoginWeb(aplikacja, appEnv, login, driver);
            StronaGlowna(login);
            SalesCloudCommon.clickMenuSalesCloud("Wyloguj", appEnv, driver);
            //----------------------------------------------------------------------------
            login = "316478";
            LoginWeb(aplikacja, appEnv, login, driver);
            StronaGlowna(login);
            SalesCloudCommon.clickMenuSalesCloud("Wyloguj", appEnv, driver);
            //----------------------------------------------------------------------------

        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        reporter().logPass("Aplikacja " + aplikacja);
        reporter().logPass("###############################");
        reporter().logPass("TODO:  5 testów o jednej klasy");
        driver.quit();
    }

    private void StronaGlowna(String login) {
        switch (login) {
            case "11307": //Dyrektor
            case "54020": //Kierownik
            case "44192": //Agent
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskPulpit, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskKalendarz, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskTwoiKlienci, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskOferty, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskPolisy, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskAkcje, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskWyniki, 3);
                if (!login.equals("44192")) {
                    waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskPrzydzielanie, 2);
                }
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskAkademiaRozwoju, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskSrdowiskoSzkolniowe, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskPoczta, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskPortalAgentow, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskTrybBiuro, 2);
                break;

            case "49137": //Asystent
            case "316478"://Kandydat
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskPulpit, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskKalendarz, 2);
                if (login.equals("49137")) {
                    waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskKlienci, 2);
                    waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskPrzydzielanie, 2);
                    waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskWyniki, 3);
                }
                if (login.equals("316478")) {
                    waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskTwoiKlienci, 2);
                }
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskAkademiaRozwoju, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskSrdowiskoSzkolniowe, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskPoczta, 2);
                waitUntilElementVisibleFail(SalesCloudMenuGlowne.przyciskPortalAgentow, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskTrybBiuro, 2);
                break;
        }

        switch (login) {
            case "11307": //Dyrektor
            case "54020": //Kierownik
            case "49137": //Asystent
                //Dashboard Wyniki
                clickElement(SalesCloudDashboard.przyciskTrybBiuro);
                waitUntilElementVisibleFail(SalesCloudDashboard.tablicaDashboardWyniki, 3);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskSpotkaniaZKlientami, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskFolderyPotrzeb, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskWnioski, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskPokazSzczegoly.get(0), 2);
                //Dashboard Powiadomienia
                waitUntilElementVisibleFail(SalesCloudDashboard.tablicaDashboardPowiadomienia, 2);
                //Dashboard Aktywność
                waitUntilElementVisibleFail(SalesCloudDashboard.tablicaDashboardAktywnosc, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskOnline, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskDzisiajAktywniwSC, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskNieaktywniPonad3Dni, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskPokazSzczegoly.get(1), 2);

                //Akcje Retencyjne
                waitUntilElementVisibleFail(SalesCloudDashboard.tablicaDashboardAkcjeRetencyjne, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskNiezakonczone, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskUratowane, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskNieuratowane, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskSzczegolowyRaport, 2);
                if (waitUntilElementPresent(By.xpath("(//*[contains(text(), 'no data')])[1]"), 5) != null) {
                    reporter().logFail("Problem z zasileniem DHUB");
                }
                break;

            case "44192": //Agent
                //Dashboard Wyniki
                clickElement(SalesCloudDashboard.przyciskTrybBiuro);
                waitUntilElementVisibleFail(SalesCloudDashboard.tablicaDashboardWyniki, 3);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskSpotkaniaZKlientami, 3);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskFolderyPotrzeb, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskWnioski, 2);
                waitUntilElementVisibleFail(SalesCloudDashboard.przyciskPokazSzczegoly.get(0), 2);
                //Dashboard Powiadomienia
                waitUntilElementVisibleFail(SalesCloudDashboard.tablicaDashboardPowiadomienia, 2);
                SalesCloudCommon.clickMenuSalesCloud("Wyloguj", appEnv, driver);
                break;
            case "316478"://Kandydat
                clickElement(SalesCloudDashboard.przyciskTrybBiuro);
                SalesCloudCommon.clickMenuSalesCloud("Wyloguj", appEnv, driver);
                break;
        }
    }
}