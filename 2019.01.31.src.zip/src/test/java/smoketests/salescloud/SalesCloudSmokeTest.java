package smoketests.salescloud;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import salescloud.pageobjects.SalesCloudCommon;
import salescloud.pageobjects.SalesCloudMenuGlowne;
import salescloud.pageobjects.SalesCloudTwoiKlienci;

import static salescloud.pageobjects.SalesCloudTwoiKlienci.*;
import static helpers.common.Common.*;
import static helpers.login.Login.*;

/**
 * @author Przemysław Mendalka
 */

@DisplayName("SmokeTest")
public class SalesCloudSmokeTest {

    protected WebDriver driver;
    private String appEnv;

    @Before
    public void setUp() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        PageFactory.initElements(driver, SalesCloudMenuGlowne.class);
        PageFactory.initElements(driver, SalesCloudTwoiKlienci.class);
    }

    @Test
    @DisplayName("SalesCloud")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            /** Do akceptacji / potwierdzania - czy wystarczy */

            LoginWeb("SalesCloud", appEnv, "54020", driver);
            SalesCloudMenuGlowne.salesCloudMenu("Twoi klienci", driver);
            clickElement(przyciskSzukaj);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);

            if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Wystąpił błąd w trakcie wyszukiwania')]"), 5) == null) {
                if (waitUntilElementPresent(By.xpath("(//*[@data-label='Klient'])[1]/*[1]"), 30) != null
                        || (waitUntilElementPresent(By.xpath("(//*[@class='sc-table'][@role='list'])[1]"), 30) != null )){
                    reporter().logPass("Klienci: Tabela z danymi zostala wyswietlona");
                } else {
                    reporter().logFail("Klienci: Tabela z danymi nie zostala wyswietlona");
                }
            }else{
                reporter().logFail("Klienci: Wystąpił błąd w trakcie wyszukiwania");
            }

            SalesCloudMenuGlowne.salesCloudMenu("Polisy", driver);
            waitTillSpinnerDisable1(SalesCloudCommon.ladowanieDanych);
            if (waitUntilElementPresent(By.xpath("//*[contains(text(), 'Wystąpił błąd w trakcie wyszukiwania')]"), 5) == null) {
                if (waitUntilElementPresent(By.xpath("(//*[@data-label='Klient'])[1]/*[1]"), 30) != null
                        || (waitUntilElementPresent(By.xpath("(//*[@class='sc-table'][@role='list'])[1]"), 30) != null )){
                    reporter().logPass("Polisy: Tabela z danymi zostala wyswietlona");
                } else {
                    reporter().logFail("Polisy: Tabela z danymi nie zostala wyswietlona");
                }
            }else{
                reporter().logFail("Polisy: Wystąpił błąd w trakcie wyszukiwania");
            }
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        if (driver != null) driver.quit();
    }
}