package smoketests.salescloud;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import salescloud.pageobjects.SalesCloudRaportStatusuLeadow;

import static helpers.common.Common.*;
import static helpers.common.Common.clickElement;
import static helpers.common.Common.waitUntilElementVisible;
import static helpers.login.Login.LoginWeb;
import static salescloud.pageobjects.SalesCloudCommon.initElement;




    /**
     * @author Maria Khabur
     */


    @DisplayName("SalesCloud")
    public class RST_22410_Test  {

        private WebDriver driver;
        private String nazwaTestu = "RST-22410 SalesCloud Auto - SmokeTest - Weryfikacja, zakładek oraz raportów widocznych dla Dyrektora";
        private String appEnv;
        private String aplikacja = "SalesCloud";



        @Before
        public void setUp() {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
                initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
                return;
            }

            appEnv = System.getProperty("appEnv");
            if (appEnv == null) appEnv = "CP";

            if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
                driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
            else if (System.getProperty("env").equals("remote"))
                driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
            initElement(driver);

            PageFactory.initElements(driver, SalesCloudRaportStatusuLeadow.class);

        }


        @Test
        @DisplayName("RST-22410 SalesCloud Auto - SmokeTest - Weryfikacja, zakładek oraz raportów widocznych dla Dyrektora")

        public void testMethod() {
            try {
                if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                    reporter().skipTest(StaticStrings.TEST_SKIP);

                krok1();
            } catch (Exception e) {
                reporter().logError("", e);
            }

        }


        @After
        public void tearDown() {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

            reporter().logPass("###############################");
            reporter().logPass("PODSUMOWANIE");
            reporter().logPass("Środowisko: "+ appEnv);
            reporter().logPass("Aplikacja "+aplikacja);
            reporter().logPass("###############################");
            reporter().logPass("TODO: Rozpoznawanie treści dokumentów");
            driver.quit();
        }


        private void krok1() {

            LoginWeb(aplikacja, appEnv, "11307", driver);


            clickElement(SalesCloudRaportStatusuLeadow.przyciskWyniki);
            waitUntilElementVisible(SalesCloudRaportStatusuLeadow.przyciskRaportujAktywnosc, 1);
            waitUntilElementVisible(SalesCloudRaportStatusuLeadow.przyciskRaportStatusuLeadow, 1);
            clickElement(SalesCloudRaportStatusuLeadow.przyciskRaportStatusuLeadow);
        }


        private void krok2() {

            waitUntilElementVisible(SalesCloudRaportStatusuLeadow.listaKamapania, 1);
            selectMDDropdownListOption (SalesCloudRaportStatusuLeadow.listaKamapania, "Dobrze Pomyślane");
            waitUntilElementVisible(SalesCloudRaportStatusuLeadow.listaPrzedzialCzasowy, 1);
            selectMDDropdownListOption (SalesCloudRaportStatusuLeadow.listaPrzedzialCzasowy, "Bieżący miesiąc");
            waitUntilElementVisible(SalesCloudRaportStatusuLeadow.przyciskGeneruj, 2);
            clickElement(SalesCloudRaportStatusuLeadow.przyciskGeneruj);
            waitUntilElementVisible(SalesCloudRaportStatusuLeadow.tabelazRaportem, 5);
            waitUntilElementVisible(SalesCloudRaportStatusuLeadow.tabelazRaportem, 1);
        }

        private void krok3() {

            clickElement(SalesCloudRaportStatusuLeadow.przyciskEksportdoPliku);
        }




    }




