package smoketests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import smoketests.aplikacjagrupa.AplikacjaGrupaSmokeTest;
import smoketests.formularz.house.RST_22808_Test;
import smoketests.formularz.moto.RST_22814_Test;
import smoketests.myaviva.MyAvivaSmokeTest;
import smoketests.salescloud.SalesCloudSmokeTest;
import smoketests.tia7.Tia7SmokeTest;
import smoketests.webportalagent.WebPortalAgentSmokeTest;
import smoketests.webportaljv.WebPortalJVSmokeTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        CasSmokeTest.class,
        AplikacjaGrupaSmokeTest.class,
        MyAvivaSmokeTest.class,
        SalesCloudSmokeTest.class,
        Tia7SmokeTest.class,
        WebPortalAgentSmokeTest.class,
        WebPortalJVSmokeTest.class,
        RST_22808_Test.class,
        RST_22814_Test.class})
public class SmokeTestSuite {
}
