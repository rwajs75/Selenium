package smoketests.clas;

/**
 * @author Sławomir Kamiński
 */


public class ClasSmokeTest {//WARN: nie może być uruchamiany równocześnie z innymi testami
//
//    private Robot r;
//    private Screen s;
//    private TestDataManager manager;
//
//    @Before
//    public void setUp() throws Exception {
//        r = new Robot();
//        s = new Screen();
//        initReporter(ReportManagerFactory.ReporterType.ALLURE, s);
//        //Desktop.getDesktop().open(file);
//        manager = new TestDataManager("CP");
//        ImagePath.add(System.getProperty("user.dir") + "/src/test/resources/sikuli");
//    }
//
//
//    @Test
//    public void testMethod() {
//        try {
//            Login.LoginCLAS("rcyrny", "CP");
//        } catch (Exception e) {
//            reporter().logError("", e);
//        }
//    }
//
//
//    @After
//    public void tearDown() {
//        clickKey(r, VK_ALT);
//        clickKey(r, VK_ENTER);
//        clickKey(r, VK_UP);
//        clickKey(r, VK_ENTER);
//        clickKey(r, VK_ENTER);
//    }

}
