package smoketests.formularz.travel;

import formularz.FormularzCommon;
import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import helpers.throwables.GeneralStepException;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.travel.TravelTwojaPodroz;
import myaviva.pageobjects.travel.kupPolise.TravelDaneDoUbezpieczenia;
import myaviva.pageobjects.travel.kupPolise.TravelOferta;
import myaviva.pageobjects.travel.kupPolise.TravelPodsumowanie;
import myaviva.pageobjects.travel.kupPolise.TravelSprawdzCeneUbezpieczenia;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
import static myaviva.MyAvivaHelpers.sprawdzenieStronyZakupuUbezpieczeniaTravel;
import static salescloud.pageobjects.SalesCloudCommon.initElement;
/**
 * @author Olga Klincewicz
 */
@DisplayName("SmokeTest")
public class RST_22822_Test {

	protected WebDriver driver;
	private String appEnv;
	private String email;
	private TestDataManager manager;
	CustomDataRequest select;
	CustomTestDTO daneTestowe;
	private String aplikacja = "MyAviva";
	boolean areUrlsDifferent = false;
	boolean testStatus = false;

	private Boolean testUrlMojeWnioskiTravel;

	/**
	 * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
	 */
	@Before
	public void setUp() {
		if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
			initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
			return;
		}

		appEnv = System.getProperty("appEnv");
		if (appEnv == null) appEnv = "CP";

		if (System.getProperty("env") == null || System.getProperty("env").equals("local")) {
			driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
		} else if (System.getProperty("env").equals("remote")) {
			driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
		}

		manager = new TestDataManager(appEnv);
		select = CustomDataRequest.builder().appName("MyAviva").testName("RST-22513").env(appEnv).stage("Utworzenie i aktywacja konta w MyAviva").status(DataRowStatus.AKTYWNY).build();
		daneTestowe = manager.getCustomTestData(select);
		email = daneTestowe.getParam3();

		PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
		FormularzCommon.initElement(driver);
	}

	/**
	 * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
	 * Zapisanie ważnych zmiennych użytych podczas testu
	 */
	@After
	public void tearDown() {
		if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
		reporter().logPass("###############################");
		reporter().logPass("PODSUMOWANIE");
		reporter().logPass("Środowisko: " + appEnv);
		reporter().logPass("E-MAIL: " + email);
		if (testUrlMojeWnioskiTravel.equals(false)) {
			reporter().logError("Błędne przekierowania linków");
		}else {
			reporter().logPass("Linki poprawnie przekierowuja na srodowisko testowe");
		}
		reporter().logPass("###############################");
		if (driver != null) driver.quit();
	}

	/**
	 * Metoda testowa
	 * Travel z MYA - Konto KLIENT dla tych samych osób ( mający juz wcześniej polisę Travel)- kupno polisy z home page
	 */
	@Test
	@DisplayName("RST-22822 SmokeTest MYA Travel Klient próba kupna następnej polisy z homepage - te same osoby")
	public void testMethod() {
		try {
			if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
				reporter().skipTest(StaticStrings.TEST_SKIP);
			krok1();
			krok2();
			testStatus = true;
		} catch (Exception e) {
			reporter().logError("", e);
		}
	}

	private void krok1() {
		LoginWeb(aplikacja, appEnv, email, driver);
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

		try {
			if (waitUntilElementVisible(MyAvivaOfertaDlaCiebie.podroz, 2) != null) {
				clickElement(MyAvivaOfertaDlaCiebie.podroz);
				waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
				clickElement(TravelTwojaPodroz.przyciskKupNowaPoliseDlaTychSamychOsob);
				switchToNewTab();

				testUrlMojeWnioskiTravel = verifyDomainUrl("MyAviva", appEnv, false);
			}
		} catch (GeneralStepException e) {
			reporter().logPass("############################");
			reporter().logError("Brak linka do zakupu polisy Travel na ekranie głównym");
			reporter().logPass("############################");
		}
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
	}

	private void krok2() {
		sprawdzenieStronyZakupuUbezpieczeniaTravel();
		clickElement(TravelSprawdzCeneUbezpieczenia.przyciskPolska);
		enterIntoTextField(TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyOd,
		                   LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
		clickElement(TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyDo);
		enterIntoTextField(TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyDo,
		                   LocalDate.now().plusDays(50).format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
		TravelSprawdzCeneUbezpieczenia.poleTekstoweOkresOchronyDo.sendKeys(Keys.RETURN);
	}
}
