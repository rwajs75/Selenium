package smoketests.formularz.moto;

import formularz.FormularzCommon;
import formularz.moto.pageobjects.MotoCommon;
import formularz.moto.pageobjects.MotoSamochod;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import static formularz.moto.pageobjects.MotoCommon.*;
import static helpers.common.Common.*;
import static helpers.common.Common.waitUntilElementVisible;
import static helpers.login.Login.LoginWeb;
/**
 * @author Olga Klincewicz
 */
@DisplayName("SmokeTest")
public class RST_22814_Test {

    protected WebDriver driver;
    private String appEnv;
    boolean testStatus = false;

    private Boolean testUrlMojeWnioskiSamochod;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);

        FormularzCommon.initElement(driver);
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reporter().logPass("Środowisko: " + appEnv);
        if (testUrlMojeWnioskiSamochod.equals(false)) {
            reporter().logError("Błędne przekierowania linków");
        }else {
            reporter().logPass("Linki poprawnie przekierowuja na srodowisko testowe");
        }
        reporter().logPass("###############################");
        if (driver != null) driver.quit();
    }

    /**
     * Metoda testowa
     * Motor bez konta - sprawdźenie oferty
     */
    @Test
    @DisplayName("RST-22814 SmokeTest Moto bez konta próba sprawdzenia ceny")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);
            krok1();
            testStatus = true;
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    private void krok1() {
        LoginWeb("Moto", appEnv, "", driver);
        testUrlMojeWnioskiSamochod = verifyDomainUrl("Moto", appEnv, false);

        try {
            waitUntilElementVisible(obiektSamochod, 5);
            waitUntilElementVisible(obiektKierowca, 5);
            waitUntilElementVisible(obiektTwojaOferta, 5);
            waitUntilElementVisible(obiektDaneDoPolisy, 5);
            waitUntilElementVisible(obiektPodsumowanie, 5);

            selectDropdownListOption(MotoSamochod.listaRokProdukcji, "2010");
            selectDropdownListOption(MotoSamochod.listaMarka, "BMW");
            if (waitUntilElementVisible(MotoSamochod.listaModel, 10) == null) {
                pauseFor(5);
            }
            selectDropdownListOption(MotoSamochod.listaModel, "Seria 3");

        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

}
