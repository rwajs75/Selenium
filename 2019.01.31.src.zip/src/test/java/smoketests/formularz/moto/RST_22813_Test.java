package smoketests.formularz.moto;

import formularz.FormularzCommon;
import formularz.moto.pageobjects.MotoCommon;
import formularz.moto.pageobjects.MotoSamochod;
import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import helpers.throwables.GeneralStepException;
import io.qameta.allure.junit4.DisplayName;
import myaviva.MyAvivaHelpers;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaListaTwoichWnioskow;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import myaviva.pageobjects.MyAvivaStronaGlowna;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static formularz.moto.pageobjects.MotoCommon.obiektDaneDoPolisy;
import static formularz.moto.pageobjects.MotoCommon.obiektKierowca;
import static formularz.moto.pageobjects.MotoCommon.obiektPodsumowanie;
import static formularz.moto.pageobjects.MotoCommon.obiektSamochod;
import static formularz.moto.pageobjects.MotoCommon.obiektTwojaOferta;
import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
/**
 * @author Olga Klincewicz
 */
@DisplayName("SmokeTest")
public class RST_22813_Test {

	protected WebDriver driver;
	private String appEnv;
	private String email;
	private TestDataManager manager;
	CustomDataRequest select;
	CustomTestDTO daneTestowe;
	private String aplikacja = "MyAviva";
	boolean areUrlsDifferent = false;
	boolean testStatus = false;

	private Boolean testUrlMojeWnioski;
	private Boolean testUrlMojeWnioskiSamochod;

	/**
	 * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
	 */
	@Before
	public void setUp(){
		if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
			initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
			return;
		}

		appEnv = System.getProperty("appEnv");
		if (appEnv == null) appEnv = "CP";

		if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
			driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
		else if (System.getProperty("env").equals("remote"))
			driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);

		manager = new TestDataManager(appEnv);
		select = CustomDataRequest.builder().appName("MyAviva").testName("RST-22781").env(appEnv).stage("Utworzenie i aktywacja konta w MyAviva").status(DataRowStatus.AKTYWNY).build();
		daneTestowe = manager.getCustomTestData(select);
		email = daneTestowe.getParam3();

		PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
		PageFactory.initElements(driver, MyAvivaListaTwoichWnioskow.class);
		PageFactory.initElements(driver, MyAvivaStronaGlowna.class);
		FormularzCommon.initElement(driver);
	}

	/**
	 * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
	 */
	@After
	public void tearDown() {
		if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
		reporter().logPass("###############################");
		reporter().logPass("PODSUMOWANIE");
		reporter().logPass("Środowisko: " + appEnv);
		reporter().logPass("E-MAIL: " + email);
		if (testUrlMojeWnioski.equals(false) ||
				    (testUrlMojeWnioskiSamochod.equals(false))) {
			reporter().logError("Błędne przekierowania linków");
		}else {
			reporter().logPass("Linki poprawnie przekierowuja na srodowisko testowe");
		}
		reporter().logPass("###############################");
		if (driver != null) driver.quit();
	}

	/**
	 * Metoda testowa
	 * Motor z MYA - Konto GOSC( nowy klient) - kupno polisy z Moje wnioski
	 */
	@Test
	@DisplayName("RST-22813 SmokeTest MYA Moto Gość próba kupna polisy z Moje wnioski")
	public void testMethod() {
		try {
			if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
				reporter().skipTest(StaticStrings.TEST_SKIP);
			krok1();
			krok2();
			testStatus = true;
		} catch (Exception e) {
			reporter().logError("", e);
		}
	}

	private void krok1() {
		LoginWeb(aplikacja, appEnv, email, driver);
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

		MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Moje Wnioski", appEnv, driver);
		testUrlMojeWnioski = verifyDomainUrl("MyAviva", appEnv, false);

		try {
			if (waitUntilElementVisible(MyAvivaListaTwoichWnioskow.linkSprawdzCeneSamochodu, 10) != null) {
				clickElement(MyAvivaListaTwoichWnioskow.linkSprawdzCeneSamochodu);
				switchToNewTab();

				testUrlMojeWnioskiSamochod = verifyDomainUrl("Moto", appEnv, false);
			}
		} catch (GeneralStepException e) {
			reporter().logPass("############################");
			reporter().logError("Brak linka do zakupu polisy Moto w Moich wnioskach");
			reporter().logPass("############################");
		}
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
	}

	private void krok2() {
		try {
			waitUntilElementVisible(obiektSamochod, 5);
			waitUntilElementVisible(obiektKierowca, 5);
			waitUntilElementVisible(obiektTwojaOferta, 5);
			waitUntilElementVisible(obiektDaneDoPolisy, 5);
			waitUntilElementVisible(obiektPodsumowanie, 5);

			selectDropdownListOption(MotoSamochod.listaRokProdukcji, "2010");
			selectDropdownListOption(MotoSamochod.listaMarka, "BMW");
			if (waitUntilElementVisible(MotoSamochod.listaModel, 10) == null) {
				pauseFor(5);
			}
			selectDropdownListOption(MotoSamochod.listaModel, "Seria 3");

		} catch (Exception e) {
			reporter().logError("", e);
		}
	}
}
