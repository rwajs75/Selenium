package smoketests.formularz.house;

import formularz.FormularzCommon;
import formularz.house.pageobjects.HouseKrok1;
import formularz.house.pageobjects.HouseStronaGlowna;
import helpers.database.TestDataManager;
import helpers.database.dto.CustomTestDTO;
import helpers.database.request.CustomDataRequest;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import helpers.throwables.GeneralStepException;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.MyAvivaCommonPageObjects;
import myaviva.pageobjects.MyAvivaListaTwoichWnioskow;
import myaviva.pageobjects.MyAvivaOfertaDlaCiebie;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;
/**
 * @author Olga Klincewicz
 */
@DisplayName("SmokeTest")
public class RST_22807_Test {

	protected WebDriver driver;
	private String appEnv;
	private String email;
	private TestDataManager manager;
	CustomDataRequest select;
	CustomTestDTO daneTestowe;
	private String aplikacja = "MyAviva";
	boolean testStatus = false;

	private Boolean testUrlMojeWnioski;
	private Boolean testUrlMojeWnioskiHouse;
	private Boolean testUrlMojeWnioskiMieszkanie;
	private Boolean testUrlMojeWnioskiDom;
	private Boolean testUrlMojeWnioskiMieszkaniezKredytem;
	private Boolean testUrlMojeWnioskiDomzKredytem;

	/**
	 * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
	 */
	@Before
	public void setUp() {
		if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
			initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
			return;
		}

		appEnv = System.getProperty("appEnv");
		if (appEnv == null) appEnv = "CP";

		if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
			driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
		else if (System.getProperty("env").equals("remote"))
			driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);

		manager = new TestDataManager(appEnv);
		select = CustomDataRequest.builder().appName("MyAviva").testName("RST-22781").env(appEnv).stage("Utworzenie i aktywacja konta w MyAviva").status(DataRowStatus.AKTYWNY).build();
		daneTestowe = manager.getCustomTestData(select);
		email = daneTestowe.getParam3();

		PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class); //klasa zawierająca WebElementy wykorzystywane w teście (do zamiany)
		PageFactory.initElements(driver, MyAvivaListaTwoichWnioskow.class);
		FormularzCommon.initElement(driver);
	}

	/**
	 * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
	 */
	@After
	public void tearDown() {
		if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
		reporter().logPass("###############################");
		reporter().logPass("PODSUMOWANIE");
		reporter().logPass("Środowisko: " + appEnv);
		reporter().logPass("E-MAIL: " + email);
		if (testUrlMojeWnioski.equals(false) ||
				    (testUrlMojeWnioskiHouse.equals(false)) ||
				    (testUrlMojeWnioskiMieszkanie.equals(false)) ||
				    (testUrlMojeWnioskiDom.equals(false)) ||
				    (testUrlMojeWnioskiMieszkaniezKredytem.equals(false)) ||
				    (testUrlMojeWnioskiDomzKredytem.equals(false))) {
			reporter().logError("Błędne przekierowania linków");
		}else {
			reporter().logPass("Linki poprawnie przekierowuja na srodowisko testowe");
		}
		reporter().logPass("###############################");
		if (driver != null) driver.quit();
	}

	/**
	 * Metoda testowa
	 * House z MYA - Konto GOSC( nowy klient)- próba kupna polisy z Moje wnioski (4 typy)
	 */
	@Test
	@DisplayName("RST-22807 SmokeTest MYA House Gość próba kupna polisy z Moje wnioski (4 typy)")
	public void testMethod() {
		try {
			if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
				reporter().skipTest(StaticStrings.TEST_SKIP);
			krok1();
			krok2();
			testStatus = true;
		} catch (Exception e) {
			reporter().logError("", e);
		}
	}

	private void krok1() {
		LoginWeb(aplikacja, appEnv, email, driver);
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

		MyAvivaCommonPageObjects.clickMenuMyAviva("Twoje konto", "Moje Wnioski", appEnv, driver);
		testUrlMojeWnioski = verifyDomainUrl("MyAviva", appEnv, false);

		try {
			if (waitUntilElementVisible(MyAvivaListaTwoichWnioskow.linkSprawdzCeneMieszkania, 10) != null) {
				clickElement(MyAvivaListaTwoichWnioskow.linkSprawdzCeneMieszkania);
				switchToNewTab();

				testUrlMojeWnioskiHouse = verifyDomainUrl("MyAviva", appEnv, false);
			}
		} catch (GeneralStepException e) {
			reporter().logPass("############################");
			reporter().logError("Brak linka do zakupu polisy House w Moich wnioskach");
			reporter().logPass("############################");
		}
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych);
		waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
	}

	private void krok2() {
		try {
			WebElement step1;
			for (int i = 1; i < 5; i++) {
				clickButton(HouseStronaGlowna.przyciskWybierzMieszkanie);
				testUrlMojeWnioskiMieszkanie = verifyDomainUrl("MyAviva", appEnv, false);

				if ((step1 = waitUntilElementPresent(By.xpath("//*[@id='main']//*[contains(text(), 'Krok 1')]"), 30)) != null) {
					reporter().logPass("Strona zostala wyswietlona");
					break;
				} else {
					reporter().logWarn("Otwarcie strony, próba nr: " + i);
					if (i == 2) reporter().logFail("Strona nie zostala wyswietlona");
					pauseFor(1);
				}
			}

			enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy1, "03");
			enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy2, "980");
			clickElement(HouseKrok1.poleTekstoweMiejscowosc);
			if (waitUntilElementVisible(HouseKrok1.poleTekstoweMiejscowosc, 5) == null) {
				pauseFor(10);
			}

			backUrl();

			for (int i = 1; i < 5; i++) {
				clickButton(HouseStronaGlowna.przyciskWybierzDom);
				testUrlMojeWnioskiDom = verifyDomainUrl("MyAviva", appEnv, false);

				if ((step1 = waitUntilElementPresent(By.xpath("//*[@id='main']//*[contains(text(), 'Krok 1')]"), 30)) != null) {
					reporter().logPass("Strona zostala wyswietlona");
					break;
				} else {
					reporter().logWarn("Otwarcie strony, próba nr: " + i);
					if (i == 2) reporter().logFail("Strona nie zostala wyswietlona");
					pauseFor(1);
				}
			}

			enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy1, "03");
			enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy2, "980");
			clickElement(HouseKrok1.poleTekstoweMiejscowosc);
			if (waitUntilElementVisible(HouseKrok1.poleTekstoweMiejscowosc, 5) == null) {
				pauseFor(10);
			}

			backUrl();

			for (int i = 1; i < 5; i++) {
				clickButton(HouseStronaGlowna.przyciskWybierzMieszkaniezKredytem);
				testUrlMojeWnioskiMieszkaniezKredytem = verifyDomainUrl("MyAviva", appEnv, false);

				if ((step1 = waitUntilElementPresent(By.xpath("//*[@id='main']//*[contains(text(), 'Krok 1')]"), 30)) != null) {
					reporter().logPass("Strona zostala wyswietlona");
					break;
				} else {
					reporter().logWarn("Otwarcie strony, próba nr: " + i);
					if (i == 2) reporter().logFail("Strona nie zostala wyswietlona");
					pauseFor(1);
				}
			}

			enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy1, "03");
			enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy2, "980");
			clickElement(HouseKrok1.poleTekstoweMiejscowosc);
			if (waitUntilElementVisible(HouseKrok1.poleTekstoweMiejscowosc, 5) == null) {
				pauseFor(10);
			}

			backUrl();

			for (int i = 1; i < 5; i++) {
				clickButton(HouseStronaGlowna.przyciskWybierzDomzKredytem);
				testUrlMojeWnioskiDomzKredytem = verifyDomainUrl("MyAviva", appEnv, false);

				if ((step1 = waitUntilElementPresent(By.xpath("//*[@id='main']//*[contains(text(), 'Krok 1')]"), 30)) != null) {
					reporter().logPass("Strona zostala wyswietlona");
					break;
				} else {
					reporter().logWarn("Otwarcie strony, próba nr: " + i);
					if (i == 2) reporter().logFail("Strona nie zostala wyswietlona");
					pauseFor(1);
				}
			}

			enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy1, "03");
			enterIntoTextField(HouseKrok1.poleTekstoweKodPocztowy2, "980");
			clickElement(HouseKrok1.poleTekstoweMiejscowosc);
			if (waitUntilElementVisible(HouseKrok1.poleTekstoweMiejscowosc, 5) == null) {
				pauseFor(10);
			}
		} catch (Exception e) {
			reporter().logError("", e);
		}
	}
}
