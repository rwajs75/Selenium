package smoketests.myaviva;

import helpers.database.TestDataManager;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.dictionary.testdata.DataRowStatus;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.Issue;
import io.qameta.allure.junit4.DisplayName;
import myaviva.MyAvivaHelpers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;

import static helpers.common.Common.*;
import static helpers.dictionary.StaticStrings.TEST_SKIP;

@DisplayName("MyAviva")
public class RST_22781_Test {


    protected WebDriver driver;
    private TestDataManager manager;
    private String appEnv;
    private String nazwaTestu = "RST-22781 - Regresja MyAviva - utworzenie i aktywacja konta gościa";
    private String aplikacja = "MyAviva";
    private String [] daneKonta;
    boolean status = false;


    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        manager = new TestDataManager(appEnv);
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        if (driver != null) driver.quit();
        if (daneKonta != null && daneKonta.length >= 3) reportSummaryAndSendResults(nazwaTestu, aplikacja, appEnv, DataRowStatus.AKTYWNY, "Utworzenie i aktywacja konta w MyAviva", status, daneKonta[0], daneKonta[1], daneKonta[2]);
    }

    @Test
    @DisplayName("RST-22781 - Regresja MyAviva - utworzenie i aktywacja konta gościa")
    @Issue("RST-22781")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    private void krok1() {
        daneKonta = MyAvivaHelpers.registerMailMyAviva(driver, manager, appEnv);
        status = true;
    }




}
