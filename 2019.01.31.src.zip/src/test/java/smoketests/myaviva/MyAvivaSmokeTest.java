package smoketests.myaviva;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import myaviva.pageobjects.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static helpers.common.Common.*;
import static helpers.dictionary.StaticStrings.ERR_503;
import static helpers.login.Login.LoginWeb;
import static myaviva.pageobjects.MyAvivaCommonPageObjects.clickMenuMyAviva;

/**
 * @author Krzysztof Janiak
 */

@DisplayName("SmokeTest")
public class MyAvivaSmokeTest {

    protected WebDriver driver;
    private String appEnv;
    private Boolean testUrlMieszkanie;
    private Boolean testUrlSamochod;
    private Boolean testUrlUbezpieczenia;
    private Boolean testUrlInwestycje;
    private Boolean testUrlEmerytura;
    private Boolean testUrlCentrumKlienta;
    private Boolean testUrlMojeWnioski;
    private Boolean testUrlMojeWnioskiTurystyczne;
    private Boolean testUrlMojeWnioskiMieszkanie;
    private Boolean testUrlMojeWnioskiSamochod;

    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        PageFactory.initElements(driver, MyAvivaStronaLogowania.class);
        PageFactory.initElements(driver, MyAvivaStronaGlowna.class);
        PageFactory.initElements(driver, MyAvivaRejestracjaKrok1.class);
        PageFactory.initElements(driver, MyAvivaOfertaDlaCiebie.class);
        PageFactory.initElements(driver, MyAvivaCommonPageObjects.class);
        PageFactory.initElements(driver, MyAvivaListaTwoichWnioskow.class);
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("MyAviva")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null)  driver.quit();
    }

    private void krok1() {
        LoginWeb("MyAviva", appEnv ,  appEnv.equals("CP") ? "autoczt0986@yopmail.com" :"autoczt0959@yopmail.com", driver);
        if (driver.getTitle().contains("503"))
            reporter().logFail(ERR_503);

        //Analiza strony pod kątem poprawności przełącznia URL i wyświetlania zakładek

        reporter().logPass("# Strona glowna #");
        //Weryfikacja Mieszkanie
        if (waitUntilElementPresent(MyAvivaOfertaDlaCiebie.mieszkanie, 2)!=null) {
            clickElement(MyAvivaOfertaDlaCiebie.mieszkanie);
            waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
            clickElement(MyAvivaOfertaDlaCiebie.przyciskObliczSkladke);
            waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
            testUrlMieszkanie = verifyDomainUrl("MyAviva", appEnv, true);
            backUrl();
        }else{
            testUrlMieszkanie = false;
        }


        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

/*        //Weryfikacja Moto
        if (waitUntilElementPresent(MyAvivaOfertaDlaCiebie.samochod, 2)!=null) {
            clickElement(MyAvivaOfertaDlaCiebie.samochod);
            waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
            clickElement(MyAvivaOfertaDlaCiebie.przyciskKupTeraz);
            waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
            testUrlSamochod = checkUrlVerify();
            backUrl();
        }else{
            testUrlSamochod = false;
        }*/
        //TODO
        testUrlSamochod = false;

        reporter().logPass("# Menu glowne #");
        clickMenuMyAviva("Ubezpieczenia", "Kompleksowe ubezpieczenie na życie i zdrowie", appEnv, driver);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        testUrlUbezpieczenia = verifyDomainUrl("MyAviva", appEnv, false);
        backUrl();
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

        clickMenuMyAviva("Inwestycje", "Notowania", appEnv, driver);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        testUrlInwestycje = verifyDomainUrl("MyAviva", appEnv, false);
        backUrl();
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

        clickMenuMyAviva("Emerytura", "OFE", appEnv, driver);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        testUrlEmerytura = verifyDomainUrl("MyAviva", appEnv, false);
        backUrl();
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

        clickMenuMyAviva("Centrum Klienta", "Moja Aviva", appEnv, driver);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        testUrlCentrumKlienta = verifyDomainUrl("MyAviva", appEnv, false);
        backUrl();
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);


        reporter().logPass("# Moje Wnioski #");

        clickMenuMyAviva("Twoje konto", "Moje Wnioski", appEnv, driver);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        testUrlMojeWnioski = verifyDomainUrl("MyAviva", appEnv, false);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

        clickElement(MyAvivaListaTwoichWnioskow.linkSprawdzCeneTurystyczne);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        testUrlMojeWnioskiTurystyczne = verifyDomainUrl("MyAviva", appEnv, false);
        backUrl();
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

        clickElement(MyAvivaListaTwoichWnioskow.linkSprawdzCeneSamochodu);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        testUrlMojeWnioskiSamochod = verifyDomainUrl("Moto", appEnv, false);
        backUrl();
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

        clickElement(MyAvivaListaTwoichWnioskow.linkSprawdzCeneMieszkania);
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);
        testUrlMojeWnioskiMieszkanie = verifyDomainUrl("MyAviva", appEnv, false);
        backUrl();
        waitTillSpinnerDisable1(MyAvivaCommonPageObjects.ladowanieDanych1);

        //Podsumowanie
        reporter().logPass("###############################");
        reporter().logPass("PODSUMOWANIE");
        reportStatus(testUrlMieszkanie, "Strona Główna", "Mieszkanie");
        reportStatus(testUrlSamochod, "Strona Główna", "Samochód");
        reportStatus(testUrlUbezpieczenia, "Menu Główne", "Ubezpieczenia");
        reportStatus(testUrlInwestycje, "Menu Główne", "Inwestycje");
        reportStatus(testUrlEmerytura, "Menu Główne", "Emerytura");
        reportStatus(testUrlCentrumKlienta, "Menu Główne", "Centrum Klienta");
        reportStatus(testUrlMojeWnioski, "Moje Wnioski", "");
        reportStatus(testUrlMojeWnioskiMieszkanie, "Moje Wnioski", "Mieszkanie");
        reportStatus(testUrlMojeWnioskiSamochod, "Moje Wnioski", "Samochód");
        reportStatus(testUrlMojeWnioskiTurystyczne, "Moje Wnioski", "Turystyczne");

        if (testUrlMieszkanie.equals(false) ||
                (testUrlSamochod.equals(false)) ||
                (testUrlUbezpieczenia.equals(false)) ||
                (testUrlInwestycje.equals(false)) ||
                (testUrlEmerytura.equals(false)) ||
                (testUrlCentrumKlienta.equals(false)) ||
                (testUrlMojeWnioski.equals(false)) ||
                (testUrlMojeWnioskiMieszkanie.equals(false)) ||
                (testUrlMojeWnioskiSamochod.equals(false)) ||
                (testUrlMojeWnioskiTurystyczne.equals(false))) {
            reporter().logError("Błędne przekierowania linków");

        }else {
            reporter().logPass("Linki poprawnie przekierowuja na srodowisko testowe");
        }
        reporter().logPass("###############################");

    }

    private static void reportStatus(Boolean nazwaBoolean , String strona, String nazwaURL){
        if (nazwaBoolean) {
            reporter().logPass(strona+"/"+nazwaURL+" poprawny");
        }else{
            reporter().logWarn("## "+strona+"/"+nazwaURL+" niepoprawny ##");
        }
    }
}
