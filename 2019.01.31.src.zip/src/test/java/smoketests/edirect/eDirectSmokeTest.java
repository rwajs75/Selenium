package smoketests.edirect;

import eDirect.pageobjects.eDirectStronaGlowna;

import static eDirect.pageobjects.eDirectStronaGlowna.*;
import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import static helpers.common.Common.*;
import static helpers.common.Common.waitUntilElementVisibleFail;
import static helpers.login.Login.LoginWeb;

/**
 * @author
 */

@DisplayName("SmokeTest")
public class eDirectSmokeTest {

    protected WebDriver driver;
    private String appEnv;

    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        PageFactory.initElements(driver, eDirectStronaGlowna.class);
    }

    @Test
    @DisplayName("eDirect")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);
            krok1();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        try {
            if (driver != null) driver.quit();
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

    private void krok1() {

        LoginWeb("eDirect", appEnv, "pmendalk", driver);
        waitUntilElementVisibleFail(linkKalendarze, 1);
        waitUntilElementVisibleFail(linkTwojeKonto, 1);
        waitUntilElementVisibleFail(linkZgody, 1);
        waitUntilElementVisibleFail(linkPliki, 1);
        waitUntilElementVisibleFail(linkTransakcje, 1);
        waitUntilElementVisibleFail(linkProdukty, 1);
        waitUntilElementVisibleFail(linkRaporty, 1);
        waitUntilElementVisibleFail(linkAdministracja, 1);
        linkProdukty.click();
        linkProduktyLista.click();
        WebElement tabListaKontraktow;
        if ((tabListaKontraktow = waitUntilElementPresent(By.xpath("//table/caption[contains(text(), 'Lista kontraktów')]"), 30))!=null) {
            reporter().logPass("Tabela z lista kontraktow zostala wyswietlona");
        }else{
            reporter().logFail("Tabela z lista kontraktow nie zostala wyswietlona");
        }
        reporter().logPass("eDirectSmokeTestPozytywny");
    }
}
