package smoketests.aplikacjagrupa;

import aplikacjaGrupa.pageobjects.aplikacjaGrupaStronaGlowna;
import helpers.dictionary.Browser;

import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import static aplikacjaGrupa.aplikacjaGrupaCommon.clickRandomPoliceNumber;
import static aplikacjaGrupa.pageobjects.aplikacjaGrupaStronaGlowna.*;
import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;

/**
 * @author Przemysław Mendalka
 */

@DisplayName("SmokeTest")
public class AplikacjaGrupaSmokeTest {

    protected WebDriver driver;
    private String appEnv;

    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "UT";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        PageFactory.initElements(driver, aplikacjaGrupaStronaGlowna.class);
    }

    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;
        if (driver != null) driver.quit();
    }


    @Test
    @DisplayName("AplikacjaGrupa")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            LoginWeb("aplikacjaGrupa", appEnv, "", driver);
            if (waitUntilElementPresent(By.id("message_negative"), 15)!=null)
                reporter().logFail("Problem z wczytaniem informacji w aplikacjaGrupa");
            AGMenu("menu", "Polisy", driver);
            clickRandomPoliceNumber(driver);
            //AGMenu("menu", "Pre-zadania", driver);
            AGMenu("menu", "Zadania", driver);
            waitUntilElementVisibleFail(menuZadania, 5);
            AGMenu("menu", "Formularze", driver);
            waitUntilElementVisibleFail(menuFormularze, 5);
            AGMenu("menu", "Komunikaty", driver);
            waitUntilElementVisibleFail(menuKomunikaty, 5);
            AGMenu("menu", "Administracja", driver);
            waitUntilElementVisibleFail(menuAdministracja, 5);
            AGMenu("menu", "Pomoc", driver);
            waitUntilElementVisibleFail(menuPomoc, 5);
        } catch (Exception e) {
            reporter().logError("", e);
        }
    }

}
