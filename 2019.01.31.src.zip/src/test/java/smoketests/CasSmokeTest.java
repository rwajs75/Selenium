package smoketests;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;

/**
 * @author Krzysztof Janiak
 */

@DisplayName("SmokeTest")
public class CasSmokeTest {

    protected WebDriver driver;
    private String appEnv;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "CP";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
    }

    @Test
    @DisplayName("CAS")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

            krok1();
        } catch (Exception e){
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        if (driver != null) driver.quit();
    }

    private void krok1() {
        LoginWeb("CAS", appEnv, "54020", driver);
    }

}
