package smoketests.tia7;

import helpers.dictionary.Browser;
import helpers.dictionary.StaticStrings;
import helpers.reporter.ReportManagerFactory;
import io.qameta.allure.junit4.DisplayName;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import tia7.pageobjects.*;

import static helpers.common.Common.*;
import static helpers.login.Login.LoginWeb;

/**
 * @author Krzysztof Janiak
 */

@DisplayName("SmokeTest")
public class Tia7SmokeTest {

    //Inicjalizajca obiektow
    public void initElement(){
        reporter().logPass("# Inicjalizacja obiektów $");
        PageFactory.initElements(driver, Tia7StronaGlowna.class);
        PageFactory.initElements(driver, Tia7WyszukajDodajKlienta.class);
        PageFactory.initElements(driver, Tia7Common.class);
    }

    protected WebDriver driver;
    private String appEnv;

    /**
     * Ustawienie warunków wstępnych (driver, inicjalizacja elementów)
     */
    @Before
    public void setUp(){
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) {
            initSkippingReporter(ReportManagerFactory.ReporterType.ALLURE);
            return;
        }

        appEnv = System.getProperty("appEnv");
        if (appEnv == null) appEnv = "UT";

        if (System.getProperty("env") == null || System.getProperty("env").equals("local"))
            driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
        else if (System.getProperty("env").equals("remote"))
            driver = initRemoteDriver(Browser.CHROME, Platform.WINDOWS, ReportManagerFactory.ReporterType.ALLURE, false);
        initElement();
    }

    /**
     * Metoda testowa
     */
    @Test
    @DisplayName("Tia7")
    public void testMethod() {
        try {
            if (System.getProperty("skip") != null && System.getProperty("skip").equals("true"))
                reporter().skipTest(StaticStrings.TEST_SKIP);

                krok1();
                krok2();

        } catch (Exception e){
            reporter().logError("", e);
        }
    }

    /**
     * Finalizacja testu (zamknięcie drivera, utworzenie raportu)
     */
    @After
    public void tearDown() {
        if (System.getProperty("skip") != null && System.getProperty("skip").equals("true")) return;

        if (driver != null)  driver.quit();
    }

    private void krok1() {
        LoginWeb("TIA7", appEnv, "AGRUBA", driver);
        waitUntilElementVisibleFail(Tia7StronaGlowna.przyciskWyszukajDodajKlienta,1);
        waitUntilElementVisibleFail(Tia7StronaGlowna.przyciskKonfiguracja,1);
        waitUntilElementVisibleFail(Tia7StronaGlowna.przyciskManagement,1);
        waitUntilElementVisibleFail(Tia7StronaGlowna.poleTekstowePolicyNo,1);
        waitUntilElementVisibleFail(Tia7StronaGlowna.poleTekstoweNrSzkody,1);
        waitUntilElementVisibleFail(Tia7StronaGlowna.listaRozwijanaFirma,1);
        waitUntilElementVisibleFail(Tia7StronaGlowna.listaRozwijanaDepartament,1);
        waitUntilElementVisibleFail(Tia7StronaGlowna.poleTekstoweUzytkownik,1);
        selectDropdownListOption(Tia7StronaGlowna.listaRozwijanaFirma,"Zewnętrzni dostawcy usług");
        initElement();
        clickElement(Tia7StronaGlowna.poleTekstoweUzytkownik);
        clickButton(Tia7StronaGlowna.przyciskSzukaj);
        waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);
        //waitUntilElementStale(Tia7StronaGlowna.pasekPostepuLadowaniaDanych,10);

        String listaZ[] = getElementText(Tia7StronaGlowna.tekstListaZadań).split(": ");
        initElement();
        int iloscZ = Integer.parseInt(listaZ[1]);
        if (iloscZ>0){
            reporter().logPass("Lista polis zostala wyswietlona");
        }else{
            reporter().logFail("Lista polis nie zostala wyswietlona");
        }
    }



    private void krok2() {

        clickElement(Tia7StronaGlowna.przyciskWyszukajDodajKlienta);
        waitUntilElementVisibleFail(Tia7WyszukajDodajKlienta.poleTekstoweIdKlienta,1);
        waitUntilElementVisibleFail(Tia7WyszukajDodajKlienta.poleTekstowePesel,1);
        waitUntilElementVisibleFail(Tia7WyszukajDodajKlienta.poleTekstoweDataUrodzenia,1);
        waitUntilElementVisibleFail(Tia7WyszukajDodajKlienta.poleTekstoweNazwisko,1);
        waitUntilElementVisibleFail(Tia7WyszukajDodajKlienta.poleTekstoweImię,1);

        enterIntoTextField(Tia7WyszukajDodajKlienta.poleTekstoweKodPocztowy, "03-980");
        initElement();
        clickElement(Tia7WyszukajDodajKlienta.poleTekstoweMiasto);
        initElement();
        int i=0;
        while (getElementText(Tia7WyszukajDodajKlienta.poleTekstoweMiasto).equals("")){
            initElement();
            i++;
            enterIntoTextField(Tia7WyszukajDodajKlienta.poleTekstoweMiasto, "Warszawa");
            initElement();
            clickElement(Tia7WyszukajDodajKlienta.poleTekstowePesel);
            if (i==10)
                reporter().logFail("Pole tekstowe [Miasto] nie zostało uzupełnione.");
        }
        initElement();
        clickElement(Tia7WyszukajDodajKlienta.przyciskSzukaj);
        waitTillSpinnerDisable1(Tia7Common.ladowanieDanych);

        //Weryfikacja wyszukiwania klienta
        WebElement wiersz;
        if ((wiersz = waitUntilElementPresent(By.id("pageTemplate1:sf_c:r1:1:pt:P2000PartySearchPC:P2000PartySearchTab:0:P2000PartySearchCity::content"), 30))!=null) {
            reporter().logPass("Lista klientow zostala wyswietlona");
        }else{
            reporter().logFail("Lista klientow nie zostala wyswietlona");
        }

        reporter().logPass("Tia7SmokeTestPozytywny");

    }

}

