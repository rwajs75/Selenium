package helpers.excel;

import helpers.database.TestDataRequest;
import org.junit.Test;

import java.io.File;
import java.util.List;

import static helpers.excel.ExcelManager.*;
import static org.junit.Assert.*;

public class ExcelManagerTest {
    private String testfile = System.getProperty("user.dir") + "/src/test/resources/helpers/testsheet.xlsx";
    private String temptestfile = System.getProperty("user.dir") + "/src/test/resources/helpers/tempfile.xlsx";

    @Test(expected = IndexOutOfBoundsException.class)
    public void readCellIndexException() {
        readFromCell(testfile,"test", 0, 10);
    }

    @Test
    public void copyCellTest() {
        copyCellValue(testfile, "test", 0, 0, 4, 3);
        assertEquals("string", readFromCell(testfile, "test", 0,4));
        writeToCell(testfile, "test", 0, 4, "");

        copyCellValue(testfile, "test", 1, 1, 4, 3);
        assertEquals("1", readFromCell(testfile, "test", 1, 4));
        writeToCell(testfile, "test", 1,4, "");

        copyCellValue(testfile, "test", 2, 2, 4, 3);
        assertEquals("TRUE()", readFromCell(testfile, "test", 2, 4));
        writeToCell(testfile, "test", 2, 4, "");

        copyCellValue(testfile, "test", 3, 3, 4, 3);
        assertEquals("LEN(B2)", readFromCell(testfile, "test", 3, 3));
        writeToCell(testfile, "test", 3, 4, "");

    }

    @Test
    public void writeValuesToNewColumnTest() {
        writeValuesToNewColumn(testfile, "test", "test01", "test02", "test03");

        assertEquals("test01", readFromCell(testfile, "test", 0, 4));
        assertEquals("test02", readFromCell(testfile, "test", 1, 4));
        assertEquals("test03", readFromCell(testfile, "test", 2, 4));

        deleteCell(testfile, "test", 0, 4);
        deleteCell(testfile, "test", 1, 4);
        deleteCell(testfile, "test", 2, 4);
    }

    @Test
    public void readFromCellTest() {
        assertEquals("testA1", readFromCell(testfile, "test", 0, 0));
        assertEquals("testB3", readFromCell(testfile, "test", 2, 1));
        assertEquals("testC1", readFromCell(testfile, "test", 0, 2));
    }

    @Test
    public void doesColumnExistTest() {
        assertTrue(doesColumnExist(testfile, "test", 0));
        assertFalse(doesColumnExist(testfile, "test", 5));
    }

    @Test
    public void prepareReportFileTest() {
        prepareReportFile(temptestfile, "testreport");

        assertTrue(new File(temptestfile).exists());
        assertEquals("Numer polisy", readFromCell(temptestfile, "testreport", 0, 0));
        assertEquals("Typ polisy", readFromCell(temptestfile, "testreport", 0, 1));
        assertEquals("Status polisy", readFromCell(temptestfile, "testreport", 0, 2));
        assertEquals("Rola właściciela", readFromCell(temptestfile, "testreport", 0, 3));
        assertEquals("Telefon", readFromCell(temptestfile, "testreport", 0, 4));
        assertEquals("Mail", readFromCell(temptestfile, "testreport", 0, 5));

        if (!new File(temptestfile).delete()) throw new RuntimeException();
    }

    @Test
    public void getDataRequestsTest() {
        String testReqFile= System.getProperty("user.dir") + "/src/test/resources/helpers/testsheet-request.xlsx";
        List<TestDataRequest> reqs = getDataRequests(testReqFile, "CP");

        assertEquals("PIP", reqs.get(0).getTyp_polisy());
        assertEquals("100", reqs.get(0).getStatus_polisy());
        assertEquals("Ubezpieczony", reqs.get(0).getRola_wlasc());
        assertEquals("555666222", reqs.get(0).getTelefon());
        assertEquals(50, reqs.get(0).getIl_sztuk());

        assertEquals("PIP", reqs.get(1).getTyp_polisy());
        assertEquals("99", reqs.get(1).getStatus_polisy());
        assertEquals("Ubezpieczający", reqs.get(1).getRola_wlasc());
        assertEquals("222888444", reqs.get(1).getTelefon());
        assertEquals(25, reqs.get(1).getIl_sztuk());

        assertEquals("FPP+", reqs.get(2).getTyp_polisy());
        assertEquals("100", reqs.get(2).getStatus_polisy());
        assertEquals("Ubezpieczający", reqs.get(2).getRola_wlasc());
        assertEquals("555666222", reqs.get(2).getTelefon());
        assertEquals(25, reqs.get(2).getIl_sztuk());
    }


}
