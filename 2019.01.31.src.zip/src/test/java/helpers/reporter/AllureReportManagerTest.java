package helpers.reporter;

import helpers.dictionary.Browser;
import io.qameta.allure.junit4.DisplayName;
import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.concurrent.TimeUnit;

import static helpers.common.Asserts.*;
import static helpers.common.Common.*;

@DisplayName("Report Testing")
public class AllureReportManagerTest{

    private WebDriver driver;

    @Before
    public void setUp() {
        driver = initLocalDriver(Browser.CHROME, ReportManagerFactory.ReporterType.ALLURE, false);
    }

    @Test
    @DisplayName("Passing test")
    public void testPass() {
        driver.get("http://www.gooogle.com");
        WebElement element = driver.findElement(By.xpath("//*[@title='Szukaj']"));
        enterIntoTextField(element, "testvalue");
        assertEquals("testvalue", getElementText(element));
        reporter().logPass("Test zakończony sukcesem", true);
    }

    @Test
    @DisplayName("Failing test")
    public void testFail() {
        driver.get("http://www.gooogle.com");
        assertNotNull(waitUntilElementPresent(By.id("TESTTESTTEST"), 10));
    }

    @Test
    @DisplayName("Broken test")
    public void testError() {
        try {
            driver.get("http://www.wp.pl");
            driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
            pauseFor(20);
            WebElement element = driver.findElement(By.id("lst-top"));
            assertTrue(waitUntilElementStale(element, 3));
        } catch (Exception e) {
            reporter().logError("", e);
            throw e;
        }
    }

    @Test
    @DisplayName("Broken test forced as skipped")
    public void testErrorSkipped() {
        try {
            driver.get("http://www.google.pl");
            driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
            pauseFor(20);
            WebElement element = driver.findElement(By.id("lst-topkek"));
            assertTrue(waitUntilElementStale(element, 3));
        } catch (Exception e) {
            ((AllureReportManager)reporter()).logError("", e, true);
            //throw e;
        }
    }

    @Test
    @DisplayName("Skipped test")
    @Ignore
    public void testSkipped() {
        try {
            driver.get("http://www.google.pl");
            driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
            pauseFor(20);
            WebElement element = driver.findElement(By.id("lst-topkek"));
            assertTrue(waitUntilElementStale(element, 3));
        } catch (Exception e) {
            ((AllureReportManager)reporter()).logError("", e, true);
        }
    }

    @After
    public void tearDown() {
        driver.quit();
    }
}
