package helpers.database;

import helpers.database.dto.TestDTO;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static helpers.dictionary.testdata.DataRowStatus.*;
import static org.junit.Assert.*;

public class TestDataManagerVerif {

    private TestDataManager manager;
    private static final String TEST_VERIF =
            "SELECT tp.typ_polisy, sp.status_polisy " +
            "FROM public.danetestowedh dt " +
            "INNER JOIN public.typypolis tp ON dt.typ_polisy = tp.lp " +
            "INNER JOIN public.statusypolis sp ON dt.status_polisy = sp.lp " +
            "WHERE telefon = '111222333'";

    @Before
    public void setUp() {
        manager = new TestDataManager("CP");
    }

    @Test
    public void getLoginCredentialsTest() {
        List<String> cred = manager.getLoginCredentials("MyAviva", "msykula1@aviva.pl","CP");
        assertEquals("https://moja-uat.cu.com.pl/Konto/logowanie/", cred.get(0)); //url
        assertEquals("msykula1@aviva.pl", cred.get(1));
        assertEquals("Aviva123", cred.get(2));
    }

    @Test
    public void getRowForProcessingTest() {
        TestDTO row = manager.getRowForProcessing("TI");
        System.out.println(row);
        assertNull(row.getMail());
        assertEquals(NIEAKTYWNY, row.getStatus_danej());
        manager.executeCustomTDBUpdate("UPDATE public.danetestowedh SET status_danych = 2 WHERE lp = " + row.getLp());
    }

    @Test
    public void getRowTest() {
        TestDTO row = manager.getRow("TI");
        System.out.println(row);
        assertNotNull(row.getMail());
        assertEquals(AKTYWNY, row.getStatus_danej());
        manager.executeCustomTDBUpdate("UPDATE public.danetestowedh SET status_danych = 1 WHERE lp = " + row.getLp());
    }

    @Test
    public void getRowByIdTest() {
        TestDTO row = manager.getRowById(2);
        System.out.println(row);
        assertNotNull(row.getMail());
        assertEquals(AKTYWNY, row.getStatus_danej());
        manager.executeCustomTDBUpdate("UPDATE public.danetestowedh SET status_danych = 1 WHERE lp = 2");
    }

    @Test
    public void getDictValueOfTest() {
        String dictValue = manager.getDictValueOf("role", 5);
        assertEquals("Insured", dictValue);

        dictValue = manager.getDictValueOf("policeType", 12);
        assertEquals("BON1", dictValue);
    }

    @Test
    @Ignore
    public void retrieveDataWithPoliceNumberFromDHTest() {

        try {
            TestDataRequest request = TestDataRequest.builder()
                    .typ_polisy("PGB")
                    .status_polisy("3109")
                    .rola_wlasc("Uposażony główny")
                    .telefon("111222333")
                    .il_sztuk(2)
                    .env("CP")
                    .build();
            List<Integer> down = manager.retrieveDataWithPoliceNumberFromDH(request);
            ResultSet result = manager.executeCustomTDBQuery(TEST_VERIF);
            int i = 0;
            while (result.next()) {
                assertEquals("PGB", result.getString("typ_polisy"));
                assertEquals("3109", result.getString("status_polisy"));
                i++;
            }
            if (i == 0) {
                System.out.println("retrieveDataWithPoliceNumberFromDHTest: \u001B[33mTest inconclusive (no rows added)\u001B[0m");
                return;
            }
            assertEquals(down.size(), i);
            assertTrue(i <= 2);
            manager.executeCustomTDBUpdate("DELETE FROM danetestowedh WHERE telefon = '111222333'");
            System.out.println("retrieveDataWithPoliceNumberFromDHTest: \u001B[33mTest zakończony (należy ręcznie " +
                    "zmniejszyć licznik tabeli głównej o " + i + ")\u001B[0m");

        } catch(SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void getRowByPersonalDataTest() {
        TestDTO res = manager.getRowByPersonalData(123456789, "Adam", "Testowy",
                "41012219893", "123456789");
        assertEquals(1, res.getLp());
        assertEquals("Adam", res.getImie());
        assertEquals("Testowy", res.getNazwisko());
        assertEquals(38, res.getTyp_polisy());
        assertEquals(1, res.getStatus_polisy());
    }

    @Test(expected = NullPointerException.class)
    public void noSuchRowByPersonalDataTest() {
        TestDTO res = manager.getRowByPersonalData(123456789, "Janusz", "Testowy",
                "41012219893", "123456789");
    }

    @Test
    public void updateMailForDataTest() {
        manager.updateMailForData("testmail", 1);
        try {
            ResultSet res = manager.executeCustomTDBQuery("SELECT mail FROM public.danetestowedh WHERE lp = 1");
            res.next();
            String mail = res.getString(1);
            assertEquals(mail, "testmail");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        manager.executeCustomTDBUpdate("UPDATE public.danetestowedh SET mail = NULL WHERE lp = 1");
    }

    @Test
    @Ignore
    public void getTestDataCountTest() {
        assertEquals(6, manager.getTestDataCount("RST-22625", "CP", "Utworzenie nowego klienta"));
    }

    @Test
    public void getMinTestDataCountTest() {
        assertEquals(10, manager.getMinTestDataCount("CP").get(0).getRequired());
    }

}
